<?php
#
# (c) 2009 Michael Schierl
# Licensed under GNU GPL v2 or later
#
if (!defined('IN_MICROBAN')) 
	die('Hacking attempt.');

require('config.php');

$link = mysql_connect($db_host, $db_user, $db_password);
if (!$link)
	die('Could not connect: ' . mysql_error());

if (!mysql_select_db($db_schema, $link))
    die ('Can\'t select db : ' . mysql_error());

ini_set("session.use_cookies", "0");
ini_set("session.use_trans_sid", "false");
session_start();
$SID = SID . '&';

if(isset($_GET['logout'])) {
	$_SESSION['userid'] = -1;
	$_SESSION['username'] = '';
}

$userid=-1;
$username = '';

if (isset($_SESSION['userid'])) {
	$userid = intval($_SESSION['userid']);
	$username = $_SESSION['username'];
}
?>