-- phpMyAdmin SQL Dump

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Datenbank: `sokoban`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur f�r Tabelle `microban_levels`
--

CREATE TABLE IF NOT EXISTS `microban_levels` (
  `levelsetid` int(11) NOT NULL,
  `levelid` int(11) NOT NULL,
  `name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `width` int(11) NOT NULL,
  `playerX` int(11) NOT NULL,
  `playerY` int(11) NOT NULL,
  `field` text COLLATE latin1_general_ci NOT NULL,
  `records` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`levelsetid`,`levelid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur f�r Tabelle `microban_levelsets`
--

CREATE TABLE IF NOT EXISTS `microban_levelsets` (
  `id` int(11) NOT NULL,
  `name` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `version` int(11) NOT NULL,
  `levelcount` int(11) NOT NULL,
  `description` varchar(250) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur f�r Tabelle `microban_solved`
--

CREATE TABLE IF NOT EXISTS `microban_solved` (
  `userid` int(11) NOT NULL,
  `levelsetid` int(11) NOT NULL,
  `levelid` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`levelsetid`,`levelid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur f�r Tabelle `microban_users`
--

CREATE TABLE IF NOT EXISTS `microban_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL,
  `password` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;
