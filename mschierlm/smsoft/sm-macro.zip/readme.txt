_______________________________  __ __
|  ____                  _    |  / ///  
|  |    \  /            /  /  | 
|  |___ |\/|    ___ __ / _/   |
|     | |  |   /__ / //� /�   |
|  ___| |  |  ___//_//  /     | 
|                             | 
|  http://www.smsoft.ixy.de/  |
|_____________________________|

Smart Macro V0.95
=================

Smart Macro, a macro recorder and editor which can
-  create loops
-  calculate and write the results or use them to control loops
-  manipulate the clipboard
-  get the length of a text (e.g. from the clipboard) or cut one text into parts
-  use random events
-  check if a user has pressed a hotkey
-  switch windows and check if they are here
-  ask the user questions or ask for an input
-  record keyboard and mouse actions
-  record delays between them
-  use modules
-  get window attributes
-  get screen size
-  display file selection boxes and copy/move/delete files
-  get environment variables
and much more...
___________________________________________________________________________

This tool requires "MS VB6 runtime"
If you don't have them, or if other problems occur, go to

http://smsoft.ixy.de/

Please send bug reports and suggestions to

sm-soft@gmx.de


-----------------------------------------------------------------

Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

sm-soft@gmx.de


______________________________________________
Eingetragen in S-A-VE: http://www.s-a-ve.com/
����������������������������������������������
