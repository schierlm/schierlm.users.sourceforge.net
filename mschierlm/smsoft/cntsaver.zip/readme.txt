Michael's Windows-Tools: ContentsSaver V0.83
============================================

A tool that can save the contents of various controls and 
change password boxes into text boxes.

--------

Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

sm-soft@gmx.de


--------

This program requires VB6 runtime modules.

if you do not have them or if other problems occur, visit:

http://smsoft.ixy.de/

Please send bug reports and suggestions to

sm-soft@gmx.de

