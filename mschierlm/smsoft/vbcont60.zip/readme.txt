Bei diesen Dateien handelt es sich um die Visual Basic 6 SP5 Controls 
(CommonControls und ComminDialogs). Diese sollten entweder ins 
Windows\System-Verzeichnis oder in das Verzeichnis der Anwendung 
kopiert werden.

Da einige Setup-Programme diese DLLs gerne wieder "entsorgen" w�rden, 
k�nnen Sie noch die Datei vbcont60.reg in die Registry importieren. 
Diese sollte daf�r sorgen, dass ein gutes Installationsprogramm diese 
Dateien nicht wieder aus c:\windows\system entfernt.
