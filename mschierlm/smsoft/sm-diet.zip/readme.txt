Michael's Windows-Tools
=======================

Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

sm-soft@gmx.de

Hinweise
========

Dieses Programm ist f�r die Verwendung unter Windows 95/98/ME gedacht. 
Unter Windows NT/2000/XP sollte es zwar auch laufen, allerdings stehen 
dort einige Funktionen nicht zur Verf�gung.

Wenn Sie bereits fr�here Versionen von Dietrich benutzt haben und dort 
die Funktionen zum Umgehen von Registry-policies benutzt haben, so 
befinden sich m�glicherweise noch Einstellungen davon in der Regitry. 
Diese haben auf das System keine Auswirkungen, allerdings erscheint in 
diesem Falle beim Aktivieren der Registry-Policies keine Warnung.
Um diese Wrnum wiederherzustellen l�schen Sie mit Regedit unter

HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System

den EIntrag "DisableRegistryTools".


CD-Erstellung
=============

F�r einige Funktionenn dieses Programms ist es erforderlich, 
dass dieses auf CD gebrannt wird. In diesem Fall brennen Sie alle
Dateien aus diesem Verzeichnis und die Datei MSVBVM60.DLL aus dem
Windows\Systemverzeichnis in das Hauptverzeichnis einer leeren CD.
Sie d�rfen auf die CD ohne weiteres noch andere Tools brennen.
Diese beeintr�chtigen die Funktion dieses Programmes nicht, solange
es in der Autorun.Inf als Startprogramm eingetragen ist.

N�here Informationen �ber die Verwendung dieses Programms finden Sie in HILFE.TXT.