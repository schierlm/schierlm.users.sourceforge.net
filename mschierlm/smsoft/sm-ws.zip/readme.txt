Michael's Winsock Tools (English)
=================================

A winsock functions collection: Can create TCP and UDP "connections"
and send data, may also connect two connections to see what is sent 
there and/or to send something else, and there is also a port scanner 
and an IP scanner included. An IP bot and a port list (RFC 1340) have 
been added.


This tool requires "MS VB6 runtime".
If you don't have them, or if other problems occur, go to

http://smsoft.ixy.de/

Please send bug reports and suggestions to

schierl@gmx.de


-----------------------------------------------------------------
Eine Sammlung von Winsock-Funktionen: TCP/IP-Verbindungen k�nnen 
aufgebaut, angenommen, weitergeleitet und/oder mitgeschnitten werden. 
Zus�tzlich ist noch ein Portscanner und ein IP-Scanner mitgeliefert. 
Ein IP-Bot, um h�ufige Aktionen zu automatisieren, und eine Portliste 
nach RFC 1340 runden das Programm ab.


Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de
