Michael's Window Gags
=====================

WindowGags in a utitlity you can use to "examine" windows. But unless 
most of the other tools available, you can also change properties of 
these windows to see their effect. Possible "manipulations" are 
resizing info dialogs to see if there is something hidden outside 
the window, showing hidden windows, moving them  around 
(How about a start-button in the middle of your taskbar?) and much more.

This tool requires "MS VB6 runtime".
If you don't have them, or if other problems occur, go to

http://smsoft.ixy.de/

Please send bug reports and suggestions to

schierl@gmx.de


-----------------------------------------------------------------

WindowGags ist ein Programm, mit dem Sie "hinter die Kulissen der 
Windows-Fensterverwaltung" blicken k�nnen. Anders als die meisten �hnlichen 
Programme ist es aber auch m�glich, deren Eigenschaften zu ver�ndern.
Dadurch lassen sich  interessante Effekte erzielen (Startbutton verschieben, 
Men�s/Buttons aktivieren/deaktivieren, Passwortboxen mit Punkten statt 
Sternen, Dialoge "verformen", Fensterelemente verstecken/anzeigen, ...), 
sinnvolle (arbeitserleichternde) Aktionen ausf�hren (Fenstergr��e festlegen 
in Pixel, Fenster an einen Bildschirmrand schieben oder auch, wenn das 
Fenster es mag, andocken oder abdocken, immer in den Vordergrund stellen, 
Fenstertexte speichern ...), Programme, die Fensterfunktionen verwenden, 
debuggen, oder ihren M�ll per Hand wieder aufr�umen, aber auch das komplette 
Windows instabil werden oder abst�rzen lassen. Um dies so weit wie m�glich 
zu vermeiden, habe ich einen "Safe Mode" eingebaut, der nur Zugriff auf 
Funktionen l�sst, die meines Erachtens "ungef�hrlich" sind. 


Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de
