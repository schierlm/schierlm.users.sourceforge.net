Adventure-Script
================

Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de
_______________________________________________________________

Adventure-Script ist eine Skriptsprache, mit der sich Adventure-Spiele 
erstellen lassen (was auch sonst).
N�here Infos erhalten Sie in advscript.hlp.

Folgende Dateien sind in diesem Paket enthalten:

readme.txt	Diese Datei

adventure.exe	Adventure-Script-Programm
adventure.hlp	Hilfedatei f�r das Spiel
adventure.cnt	Hilfe-Inhalt f�r das Spiel
adventure.ini	INI-Datei f�r Adventure-Script

save\		Ordner f�r Spielst�nde:
 start.sav	Spielstand, der beim STart des SPiels gespeichert wurde
		(Winzip packt keine leeren Ordner)

tools\		Diverse Hilfsprogramme:
 adv-area.exe	Hilfsprogramm Bereiche festlegen
 adv-anal.exe	Hilfsprogramm, das h�ufige Syntaxfehler 
		im Adventure-Script findet
 advscript.hlp	Adventure-Script-Hilfe
 advscript.cnt	Adventure-Script-Hilfe-Inhalt

samples\	Beispiel-Dateien:

 start.adv	Startdatei f�r Beispiele
 start.gif	Startbild f�r Beispiele

 ex1.adv	Beispiel-Adventure 1
 ex11.gif	Bild 1 f�r Beispiel 1
 ex12.gif	Bild 2
 ex13.gif	Bild 3 

 ex2.adv	Beispiel-Adventure 2
 ex21.jpg	Bild 1 f�r Beispiel 2
 ex22.jpg	Bild 2
 ex23.jpg	Bild 3
 ex24.jpg	Bild 4
 ex25.jpg	Bild 5
 ex2i00.ico	Symbol 1 f�r Beispiel 2
 ex2i01.ico	Symbol 2
 ex2i02.ico	Symbol 3
 ex2i03.ico	Symbol 4
 ex2i04.ico	Symbol 5
 ex2i05.ico	Symbol 6 

 ex3.adv	Beispiel-Adventure 3
 ex31.jpg	Bild 1 f�r Beispiel 3
 ex32.jpg	Bild 2
 ex33.jpg	Bild 3
 ex34.jpg	Bild 4
 ex35.jpg	Bild 5
 ex36.jpg	Bild 6
 ex37.jpg	Bild 7
 ex38.jpg	Bild 8
 ex39.jpg	Bild 9