Michael's Windows-Spiele: Jagd
==============================

Um einen eigenen Skin zu erzeugen, kopieren Sie die "wolken.jagdskin" 
(nennen Sie die neue Datei auch ".jagdskin" )
und bearbeiten Sie sie mit einem Texteditor.
Die Datei sollte selbsterkl�rend sein, achten Sie auf die doppelten
Leerzeichen.


_________________________________________
Dieses Programm ben�tigt die VB6-Runtime 
(oder zumindest die MSVBVM60.DLL)


Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

