AppStop V0.90
=============


Hinweise:
~~~~~~~~~
Dieses Utility ist Freeware. (Da es innerhalb einer halben Stunde geschrieben 
wurde, kann ich kleinere Fehler nicht ausschlie�en. Wenn Sie welche finden, 
schreiben Sie bitte eine E-Mail an <schierl@gmx.de>. Danke.)

Zur ordnungsgem��en Funktion ben�tigt dieses Programm die Visual Basic 6.0 
Runtime. Das Programm funktioniert auch mit der Version ohne Steuerelemente,
die Version mit STeuerelementen k�nnen Sie auf meiner Homepage

<http://smsoft.ixy.de/>

unter "Allgemeines" herunterladen.

Dieses Programm arbeitet sicher unter Win95/98/ME, unter NT sicher nicht.
Wie es mit Win2000 und XP aussieht, kann ich leider nicht beurteilen.

Verwendung:
~~~~~~~~~~~
Dieses Kommandozeilen-Programm kann verwendet werden, um andere Programme 
zu beenden (terminieren). Dadurch ist es ideal daf�r geeignet, wenn beim 
automatischen Start eines Programmes (z. B. �ber den Windows-Taskplaner) 
zuerst ein anderes Programm beendet werden muss.

Das Programm entstand w�hrend einer Diskussion in der Newsgroup 
de.comp.shareware (ab Message-ID <9nv912$9lcg0$1@ID-16994.news.dfncis.de>), 
in der es darum ging, Programme zeitgesteuert zu beenden.

AppStop geht folgenderma�en vor:

Zun�chst wird �berpr�ft, ob ein Programm mit dem �bergebenen Programmnamen, 
der wahlweise einen kompletten Pfad enthalten darf oder gar keinen, gerade
l�uft. Ist dies nicht der Fall, erscheint f�r 5 Sekunden eine Meldung und
das Programm beendet sich selbst (es k�nnte ja sein, dass der zu beendende
Prozess bereits mit seinen Aufgaben fertig ist; in diesem Falle soll die
automatische Ausf�hrung ja nicht behindert werden). Sollten mehrere 
Instanzen dieses Programmes geladen sein, wird die "neueste" ausgew�hlt.

Daraufhin wird an alle Fenster dieses Programmes eine Close-Nachricht 
versandt, also eine Aufforderung, sich zu schlie�en. F�r die Ausf�hrung 
dieser Aufforderung bekommt das Programm 30 Sekunden Zeit. Ist das Programm
bis dahin immer noch nicht beendet, wird es "abgeschossen": der Prozess
wird terminiert (�hnlich wie bei "Task Beenden" �ber den Taskmanager).
Beendet sich das Programm vorher, wird AppStop auch beendet, ansonsten 
beendet sich AppStop nach Abschluss des "Abschie�ens".


Syntax:
~~~~~~~

APPSTOP [/nn] [X:\Pfad\]Programmname.exe

/nn	Ist dieser Paramteter gegeben, wird dem Programm <nn> Sekunden Zeit 
	gelassen, bevor es terminiert wird. Ist nn = 0, so wird das Programm
	gar nicht erminiert; schl�gt der Beendigungsversuch fehl, beendet
	sich AppStop gleich wieder.
X:\Pfad	Bei Bedarf kann f�r das Programm ein Pfad �bergeben werden.
	Dieser Pfad muss aber absolut sein (von Laufwerk bis Dateiname),
	oder gar nicht vorhanden sein
Prog.	Der Programmname steht f�r das zu beendende Programm. Es ist nicht
	n�tig, den Programmnamen (evtl. inkl. Pfad) in Anf�hrungszeichen
	einzuschlie�en, wenn er Leerr�ume enth�lt; es verursacht aber auch
	keinen Fehler, wenn der Name in Anf�hrungszeichen steht.

Beispiele:
~~~~~~~~~~

APPSTOP notepad.exe
appstop ein Programm mit Leer�umen.exe
APPSTOP "Ein Programm mit Leerr�umen.exe"
APPSTOP "C:\Programme\Geheime Progs\Testen.exe"
AppStop /1 c:\windows\notepad.exe
appstop /60 c:\eigene programme\coolie.exe
Appstop.Exe /0 "notepad.exe"
