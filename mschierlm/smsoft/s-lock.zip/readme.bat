@echo off
echo S-LOCK.COM (c) 2000 by Michael Schierl
echo ======================================
echo.
echo http://smsoft.ixy.de/
echo.
echo Dieses 32 Byte gro�e Assembler-Programm liefert 
echo ERRORLEVEL 1 zuzr�ck, falls Scroll-Lock aktiviert ist
echo und kann daher f�r Verzweigungen in Batches ohne
echo (sichtbare) Abfrage verwendet werden.
echo.
echo Ich verwende es, um in AUTOEXEC.BAT bei Bedarf den Debugger 
echo zu laden.
echo.
echo.
echo Beispiel:
echo ---------
echo.
s-lock
if errorlevel 1 echo Scroll-Lock ist an
if not errorlevel 1 echo Scroll-Lock ist aus


