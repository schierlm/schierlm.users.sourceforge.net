Michael's Windows-Tools: SetDate V0.9
=====================================

For additional information see HELP.TXT

This tool requires "MS VB6 runtime".
If you don't have them, or if other problems occur, go to

http://smsoft.ixy.de/

Please send bug reports and suggestions to

schierl@gmx.de


-----------------------------------------------------------------

Weitere Informationen finden Sie in der Datei HILFE.TXT

Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de
