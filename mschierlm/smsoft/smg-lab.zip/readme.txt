Michael's Windows-Spiele: Jagd
==============================

Sie k�nnen eigene Levels mit jedem Malprogramm erzeugen. Als "Vorlage"
k�nnen Sie die "leer.gif" verwenden.
Die erste Pixelzeile gibt die verwendeten Farben an. 
Alle anderen werden als "begehbar" erachtet.

VORSICHT: Auch bei Palettenbildern wird nicht nach der Palettenposition, 
sondern nach den RGB-Werten entschieden, weshalb Sie keine zwei Farben 
mit den selben RGB-Werten verwenden sollten. 
Im Zweifelsfall �ndern Sie einen Wert geringf�gig.

Die Farben an Position (x/y)
(0/0) begehbar
(1/0) Wand
(2/0) Ziel
(3/0) nicht begehbar
(4/0) �bergang zur Wand
(5/0) Einbahnstra�e 1
(6/0) Einbahnstra�e 2
(7/0) reserviert
Rest (bis zu einem Pixel, der dieselbe Farbe hat wie (1/0):
 abwechselnd Schl�ssel und das dazugeh�rige "Schloss"


_________________________________________
Dieses Programm ben�tigt die VB6-Runtime 
(oder zumindest die MSVBVM60.DLL)


Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

