Michael's MegaCalc-Win V0.81
============================

Diese Programme ben�tigen die VB6-Runtime.
Eine DOS-Version (0.8) ist auch verf�gbar.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

www.schierl.2see.de

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de
