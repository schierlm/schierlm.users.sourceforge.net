_______________________________  __ __
|  ____                  _    |  / ///  
|  |    \  /            /  /  | 
|  |___ |\/|    ___ __ _ __   |
|     | |  |   /__ / //  /    |
|  ___| |  |  ___//_//  /     | 
|                             | 
|  http://www.smsoft.ixy.de/  |
|_____________________________|


Michael's Smart Dialog
======================

NOTE: If you are upgrading from version 0.80 or earlier, delete your old 
version completely before "installing" new one( or intall in another directory).

Additional information about this tool are in the other text file 
of this archive.

This tool requires "MS VB6 runtime".
If you don't have them, or if other problems occur, go to

http://smsoft.ixy.de/

Please send bug reports and suggestions to

schierl@gmx.de


-----------------------------------------------------------------

HINWEIS: Wenn Sie bereits Version 0.80 oder fr�her verwenden, m�ssen Sie diese
vor der "Installation" der neuen l�schen (oder in ein anderes Verzeichnis installieren).

Weitere Informationen �ber dieses Programm finden Sie in der anderen
Textdatei dieses Archivs.

Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de
