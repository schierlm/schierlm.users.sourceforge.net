SMsoft Windows-Tools: Dialog Sizer V0.8
=======================================

Dieses Programm ben�tigt die VB6-Runtime.

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de

Danke.

--------

This program requires VB6 runtime modules.

if you do not have them or if other problems occur, visit:

http://smsoft.ixy.de/

Please send bug reports and suggestions to

schierl@gmx.de

Thank you.

