Michael's Windows-Tools: Freeware-Starter
=========================================

Dieses Programm ben�tigt die VB6-Runtime 
(oder zumindest die MSVBVM60.DLL)

Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Zur Konfiguration klicken Sie auf den Text am oberen Rand des Fensters