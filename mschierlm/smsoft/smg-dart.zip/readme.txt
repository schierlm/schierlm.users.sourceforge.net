Michael's Windows-Spiele: Dart
==============================
Sie zielen mit der Maus: Wenn Sie die linke Maustaste dr�cken,
bewegt sich der Zielcursor nch rechts, wenn Sie sie wieder loslassen, 
nach unten und wenn Sie wieder klicken, wird geschossen.


_________________________________________
Dieses Programm ben�tigt die VB6-Runtime 
(oder zumindest die MSVBVM60.DLL)


Wenn Sie diese nicht besitzen oder andere Probleme haben, 
surfen Sie zu

http://smsoft.ixy.de/

Bitte senden Sie gefundene Fehler und Anregungen an

schierl@gmx.de

