package webparser.parameter;

import webparser.ParserState;

public class LiteralTag extends Tag {

	private final String literal;
	
	public LiteralTag(String literal) {
		this.literal = literal;
	}

	@Override
	public String getString(ParserState state) {
		return getString();
	}

	public String getString() {
		return literal;
	}
}
