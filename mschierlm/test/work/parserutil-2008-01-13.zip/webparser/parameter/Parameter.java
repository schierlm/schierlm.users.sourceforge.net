package webparser.parameter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

import webparser.ParserState;

public class Parameter {
	
	public static Parameter parseParameter(String text, boolean ascii, boolean entities) {
		return parseParameters(text, 1, 1, 0, ascii, entities)[0];
	}
	
	public static Parameter parseRawParameter(String rawText) {
		return parseRawParameters(rawText, 1, 1, 0)[0];
	}
	
	public static Parameter[] parseParameters(String text, int minparamcount, int maxparamcount, int noCommaCount, boolean ascii, boolean entities) {
		if (text.indexOf('\1') != -1 || text.indexOf('\2') != -1) throw new RuntimeException("Invalid control characters found");
		if (ascii) {
			text = text.replaceAll("<<([^<])", "\1$1").replaceAll("([^>])>>", "$1\2");
			text = text.replace("\1[\2", "<<").replace("\1]\2", ">>");
			if (entities) {
				text = text.replace("&llt;", "<<").replace("&ggt;", ">>");
			}			
		} else {
			text = text.replace('�', '\1').replace('�', '\2');
			text = text.replace("\1[\2", "�").replace("\1]\2", "�");
			if (entities) {
				text = text.replace("&llt;", "�").replace("&ggt;", "�");
			}
		}
		return parseRawParameters(text, minparamcount, maxparamcount, noCommaCount);
	}
	
	public static Parameter[] parseRawParameters(String rawText, int minparamcount, int maxparamcount, int noCommaCount) {
		if (rawText.indexOf('\0') != -1) 
			throw new RuntimeException("Invalid control characters found");
		Parameter[] result = new Parameter[maxparamcount];
		int current=0;
		StringBuilder literalBuffer = new StringBuilder();
		List<Tag> elems = new ArrayList<Tag>();
		while(true) {
			int pos;
			if (noCommaCount > 0) {
				pos = literalBuffer.indexOf(" ");
				int pos2 = literalBuffer.indexOf("\t");
				if (pos2 != -1 && (pos == -1 || pos > pos2)) pos = pos2;
				if (pos != -1) {
					literalBuffer.setCharAt(pos, '\0');
				}
			}
			pos = literalBuffer.indexOf("\0");
			if (pos != -1 && current < maxparamcount-1) {
				if (pos != 0) elems.add(new LiteralTag(literalBuffer.substring(0, pos)));
				literalBuffer.delete(0, pos+1);
				result[current++] = new Parameter(elems);
				elems.clear();
				if (noCommaCount>0) noCommaCount--;
				continue; // check for another parameter
			}
			if (rawText.length() == 0) break;
			pos = rawText.indexOf("\1");
			if (pos == -1) {
				literalBuffer.append(rawText);
				rawText = "";
				continue;
			} else if (pos > 0) {
				literalBuffer.append(rawText.substring(0,pos));
				rawText = rawText.substring(pos);
				continue;
			} else {
				rawText = rawText.substring(1);
			}
			int depth = 1;
			for(int i=0; i<rawText.length(); i++) {
				if (rawText.charAt(i) == '\1') depth++;
				if (rawText.charAt(i) == '\2') depth--;
				if (depth==0) {
					Tag pe = Tag.parseTag(rawText.substring(0, i));
					if (pe instanceof LiteralTag) {
						literalBuffer.append(((LiteralTag)pe).getString());
					} else {
						if (literalBuffer.length() > 0) {
							elems.add(new LiteralTag(literalBuffer.substring(0)));
							literalBuffer.delete(0, literalBuffer.length());
						}
						elems.add(pe);
					}
					rawText = rawText.substring(i+1);
					break;
				}
			}
			if (depth != 0) throw new RuntimeException("Unterminated tag.");
		}
		if (current < minparamcount-1) throw new RuntimeException("Invalid number of parameters!");
		if (literalBuffer.length()>0) elems.add(new LiteralTag(literalBuffer.toString()));
		result[current] = new Parameter(elems);
		return result;
	}
	
	private final Tag[] elements;
	
	private Parameter(List<Tag> elems) {
		this((Tag[]) elems.toArray(new Tag[elems.size()]));
	}
	
	private Parameter(Tag[] elements) {
		this.elements = elements;
	}


	public boolean isParsingOnly() {
		for(Tag e: elements) {
			if (!e.isParsingOnly()) return true;
		}
		return false;
	}
	
	public String getString(ParserState state) {
		StringBuilder sb = new StringBuilder();
		for(Tag e : elements) {
			sb.append(e.getString(state));
		}
		return sb.toString();
	}

	public String getRegex(ParserState state) {
		StringBuilder sb = new StringBuilder();
		for(Tag e : elements) {
			sb.append(e.getRegex(state));
		}
		return sb.toString();	
	}
	
	public void applyMatch(ParserState state, Matcher matcher) {
		int idx = 0;
		for(Tag e : elements) {
			int cnt = e.getUsedGroupCount();
			String[] params = new String[cnt];
			for (int i = 0; i < params.length; i++) {
				params[i] = matcher.group(i+idx+1);
			}
			e.applyMatch(state, params);
			idx+=cnt;
		}
		if (idx != matcher.groupCount()) throw new RuntimeException("Wrong number of regex groups: ");
	}

	public static Parameter getLiteralParameter(String literal) {
		return new Parameter(new Tag[] {new LiteralTag(literal)});
	}
}
