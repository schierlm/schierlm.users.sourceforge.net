package webparser.parameter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import webparser.ParserState;

public abstract class Tag {

	public boolean isParsingOnly() {
		return false;
	}
	
	public int getUsedGroupCount() {
		return 0;
	}
	
	public String getRegex(ParserState state) {
		return "\\Q"+getString(state).replace("\\", "\\\\")+"\\E";
	}
	
	public void applyMatch(ParserState state, String[] matches) {
		if (matches.length != 0) throw new RuntimeException();
	}
	
	public abstract String getString(ParserState state);
	
	public static Tag parseTag(String rawContent) {
		switch(rawContent.length() > 0 ? rawContent.charAt(0): ' ') {
		case '&':
			return new EntityWrapperTag(parseTag(rawContent.substring(1)));
		case '=':
			return new InsertLocalTag(Parameter.parseRawParameter(rawContent.substring(1)));
		case '^':
			return new CallbackFunctionTag(Parameter.parseRawParameters(rawContent.substring(1), 0, 255, 0));
		case '\\':
			char escaped;
			if (rawContent.length() == 2) {
				switch (rawContent.charAt(1)) {
				case 'r':
					escaped = '\r';
					break;
				case 'n':
					escaped = '\n';
					break;
				case 'b':
					escaped = '\b';
					break;
				case 't':
					escaped='\t';
					break;
				case '[':
					escaped = '�';
					break;
				case ']':
					escaped = '�';
					break;
				case '\\':
					escaped = '\\';
					break;
				case '(':
					return new LiteralTag("<<");
				case ')':
					return new LiteralTag(">>");
				default:
					escaped = rawContent.charAt(1);
					if (escaped >= '0' && escaped <= '9')
						escaped -= '0';
					break;
				}
			} else {
				escaped = (char)Integer.parseInt(rawContent.substring(1), 16);
			}
			return new LiteralTag(""+escaped);
		case ',':
			if (rawContent.length()>1) throw new RuntimeException("Comma tag may not have any parameters");
			return new LiteralTag("\0");
		case '?':
			return new OptionalTag(Parameter.parseRawParameter(rawContent.substring(1)));
		default:
			//case '/':
			//case '@':
			Matcher m = Pattern.compile("[/@]?((?:[a-zA-Z][a-zA-Z0-9]*)?)(:.*)?").matcher(rawContent);
			if (!m.matches()) throw new RuntimeException("Unsupported tag: "+rawContent);
			String name = m.group(1);
			String regex = m.group(2);
			if (regex == null)
				regex = ".*?";
			else
				regex = regex.substring(1);
			if (rawContent.startsWith("/")) {
				return new TagParseTag(name, regex);
			} else if (rawContent.startsWith("@")) {
				return new AttributeParseTag(name, regex);
			} else {
				return new LocalParseTag(name, regex);
			}
		}
	}
}
