package webparser.parameter;

import webparser.ParserState;

public class EntityWrapperTag extends Tag {

	private final Tag baseTag;

	public EntityWrapperTag(Tag baseTag) {
		this.baseTag = baseTag;
	}
	
	private String killEntities(String string) {
		string = string.replace("&lt;", "<");
		string = string.replace("&gt;", ">");
		string = string.replace("&quot;", "\"");
		string = string.replace("&amp;", "&");
		return string;
	}
	
	private String addEntities(String string) {
		string = string.replace("&", "&amp;");
		string = string.replace("<","&lt;");
		string = string.replace(">","&gt;");
		string = string.replace("\"","&quot;");
		return string;
	}

	@Override
	public void applyMatch(ParserState ps, String[] matches) {
		String[] m = new String[matches.length];
		for (int i = 0; i < m.length; i++) {
			m[i] = killEntities(matches[i]);
		}
		baseTag.applyMatch(ps, m);
	}

	@Override
	public String getRegex(ParserState state) {
		return baseTag.getRegex(state);
	}

	@Override
	public String getString(ParserState state) {
		return addEntities(baseTag.getString(state));
	}

	@Override
	public int getUsedGroupCount() {
		return baseTag.getUsedGroupCount();
	}

	@Override
	public boolean isParsingOnly() {
		return baseTag.isParsingOnly();
	}
}
