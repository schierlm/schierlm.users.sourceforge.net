package webparser.parameter;

import webparser.ParserState;

public class OptionalTag extends Tag {

	private final Parameter param;

	public OptionalTag(Parameter param) {
		this.param = param;
	}
	
	@Override
	public boolean isParsingOnly() {
		return true;
	}
	
	
	@Override
	public String getRegex(ParserState state) {
		return "(?:\\Q"+param.getString(state).replace("\\", "\\\\") + "\\E)?";
	}
	
	@Override
	public String getString(ParserState state) {
		throw new RuntimeException("This tag can only be used for parsing");
	}
}
