package webparser.parameter;

import webparser.ParserState;

public class TagParseTag extends ParseTag {

	private final String name;

	public TagParseTag(String name, String regex) {
		super(regex);
		this.name = name;
	}

	@Override
	protected void applyMatch(ParserState state, String match) {
		state.appendTag(name, match);
	}

}
