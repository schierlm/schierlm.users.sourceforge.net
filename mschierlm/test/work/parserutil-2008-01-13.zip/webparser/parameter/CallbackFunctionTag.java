package webparser.parameter;

import webparser.ParserState;

public class CallbackFunctionTag extends Tag {

	private final Parameter[] params;

	public CallbackFunctionTag(Parameter[] params) {
		this.params = params;
	}

	@Override
	public String getString(ParserState state) {
		String cmd = params[0].getString(state);
		int paramcount = params.length;
		for (int i = 1; i < params.length; i++) {
			if (params[i] == null) {
				paramcount = i-1;
				break;
			}
		}
		String[] args = new String[paramcount];
		for (int i = 0; i < args.length; i++) {
			args[i] = params[i+1].getString(state);
		}
		return state.getParser().getCallback(cmd).call(args);
	}
}
