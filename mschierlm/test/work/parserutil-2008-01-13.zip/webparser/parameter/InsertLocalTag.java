package webparser.parameter;

import webparser.ParserState;

public class InsertLocalTag extends Tag {

	private final Parameter localName;
	
	public InsertLocalTag(Parameter localName) {
		this.localName = localName;
	}
	
	@Override
	public String getString(ParserState state) {
		String local =  state.getLocal(localName.getString(state));
		if (local == null) throw new RuntimeException("Undefined local: "+localName.getString(state));
		return local;
	}
}
