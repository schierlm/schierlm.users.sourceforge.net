package webparser.parameter;

import webparser.ParserState;

public class AttributeParseTag extends ParseTag {

	private final String name;

	public AttributeParseTag(String name, String regex) {
		super(regex);
		this.name = name;
	}

	@Override
	protected void applyMatch(ParserState state, String match) {
		state.setAttribute(name, match);
	}

}
