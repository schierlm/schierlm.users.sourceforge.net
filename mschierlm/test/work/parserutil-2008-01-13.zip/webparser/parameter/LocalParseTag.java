package webparser.parameter;

import webparser.ParserState;

public class LocalParseTag extends ParseTag {

	private final String name;

	public LocalParseTag(String name, String regex) {
		super(regex);
		this.name = name;
	}

	@Override
	protected void applyMatch(ParserState state, String match) {
		state.setLocal(name, match);
	}
}
