package webparser.parameter;

import webparser.ParserState;

public abstract class ParseTag extends Tag {

	private final String regex;
	
	public ParseTag(String regex) {
		this.regex = regex;
	}
	
	@Override
	public boolean isParsingOnly() {
		return true;
	}
	
	@Override
	public int getUsedGroupCount() {
		return 1;
	}
	
	@Override
	public String getRegex(ParserState state) {
		return "(" + regex + ")";
	}
	
	@Override
	public void applyMatch(ParserState state, String[] matches) {
		if (matches.length != 1) throw new RuntimeException();
		applyMatch(state, matches[0]);
	}
	
	protected abstract void applyMatch(ParserState state, String match);
	
	@Override
	public String getString(ParserState state) {
		throw new RuntimeException("This tag can only be used for parsing");
	}

}
