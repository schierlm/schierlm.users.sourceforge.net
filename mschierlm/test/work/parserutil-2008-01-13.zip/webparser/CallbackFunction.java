package webparser;

public interface CallbackFunction {
	public String call(String[] arguments);
}
