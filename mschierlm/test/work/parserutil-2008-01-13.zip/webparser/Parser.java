package webparser;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import parserutil.CSVWriter;
import webparser.operation.Operation;
import webparser.operation.Operation.OperationResult;
import webparser.script.ParserScript;

public class Parser {
	
	private CharSequence file = null;
	private StringBuilder writeBuffer = new StringBuilder();
	
	private List<ParserState> queuedStates = new ArrayList<ParserState>();
	private final ParserScript script;
	private CSVWriter[] csvFiles;
	private Map<String,CallbackFunction> callbacks = new HashMap<String, CallbackFunction>();
	
	public Parser(String filename, String encoding) throws IOException {
		this(new ParserScript(filename, encoding));
	}
	
	public Parser(File file, String encoding) throws IOException {
		this(new ParserScript(file, encoding));
	}
	
	public Parser(Class clazz, String resourcename, String encoding) throws IOException {
		this(new ParserScript(clazz, resourcename, encoding));
	}
	
	public Parser(BufferedReader br) throws IOException {
		this(new ParserScript(br));
	}
	
	public Parser(ParserScript script) {
		this.script = script;
		queuedStates.add(new ParserState(this));
		DefaultCallbackFunctions.addTo(this);
	}
	
	public void setLocal(String name, String value) {
		if (file != null) 
			throw new IllegalStateException("Parser has already been used");			
		queuedStates.get(0).setLocal(name, value);
	}
	
	public Document parse(InputStream stream, String encoding, String toplevelTag) throws ParserException, ParserConfigurationException, IOException {
		return parse(stream, encoding, toplevelTag, new CSVWriter[0]);
	}
	
	public Document parse(InputStream stream, String encoding, String toplevelTag, CSVWriter[] csvFiles) throws ParserException, ParserConfigurationException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(stream, encoding));
		return parse(br, toplevelTag, csvFiles);
	}

	public void parse(InputStream stream, String encoding, Element target, CSVWriter[] csvFiles) throws ParserException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(stream, encoding));
		parse(br, target, csvFiles);
	}

	public Document parse(BufferedReader reader, String toplevelTag) throws ParserException, ParserConfigurationException, IOException {
		return parse(reader, toplevelTag, new CSVWriter[0]);
	}
	
	public Document parse(BufferedReader reader, String toplevelTag, CSVWriter[] csvFiles) throws ParserException, ParserConfigurationException, IOException {		
		Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		doc.appendChild(doc.createElement(toplevelTag));
		parse(reader, doc.getDocumentElement(), csvFiles);
		return doc;
	}
	
	public void parse(BufferedReader reader, Element target, CSVWriter[] csvFiles) throws ParserException, IOException{
		StringWriter sw = new StringWriter();
		char[] buff = new char[4096];
		int len;
		while ((len = reader.read(buff, 0, buff.length)) != -1) {
			sw.write(buff, 0, len);
		}
		String file = sw.toString().replace("\r\n", "\n").replace('\r', '\n');
		if (!file.endsWith("\n")) file +="\n";
		parse(file, target, csvFiles);
	}

	public Document parse(CharSequence file, String toplevelTag) throws ParserException, ParserConfigurationException, IOException {
		return parse(file, toplevelTag, new CSVWriter[0]);
	}
	
	public Document parse(CharSequence file, String toplevelTag, CSVWriter[] csvFiles) throws ParserException, ParserConfigurationException, IOException {
		Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		doc.appendChild(doc.createElement(toplevelTag));
		parse(file, doc.getDocumentElement(), csvFiles);
		return doc;
	}
	
	public void parse(CharSequence file, Element target, CSVWriter[] csvFiles) throws ParserException, IOException {
		if (this.file != null)
			throw new IllegalStateException("Parser has already been used");	
		this.csvFiles = csvFiles;
		this.file = file;
		ParserState finalState = run();
		finalState.applyXMLActions(target);
		for (CSVWriter csv : this.csvFiles) {
			csv.flush();
		}
	}
	
	private ParserState run() throws ParserException, IOException {
		int lastFailOffset = -1;
		List<Integer> lastFailLineNumbers = new ArrayList<Integer>();
		ParserState finishedState = null;
		while(queuedStates.size()>0) {
			ParserState current = queuedStates.remove(0);
			OperationResult opres = OperationResult.CONTINUE;
			while (opres == OperationResult.CONTINUE) {
				int ip = current.getNextInstructionAndIncrement();
				Operation op = script.getOperation(ip);
				try {
					opres = op.execute(current);
				} catch (RuntimeException ex) {
					throw new RuntimeException("Cannot execute operation in line "+op.getLineNumber()+"\n\t"+
							script.getLineText(op.getLineNumber()), ex);
				}
				if (opres == null) throw new RuntimeException(op.getClass().toString()+" returned invalid operation result.");
				switch(opres) {
				case CONTINUE:
					// everything fine
					break;
				case NEXTPASS:
					lastFailOffset=-1;
					lastFailLineNumbers.clear();
					opres = OperationResult.CONTINUE;
					break;
				case DIE:
					if (queuedStates.size() == 0)
						throw new RuntimeException("Last state died");
					break;
				case FAIL:
					if (current.getOffset() > lastFailOffset) {
						lastFailOffset = current.getOffset();
						lastFailLineNumbers.clear();
					}
					if (current.getOffset() == lastFailOffset) {
						int lineno = op.getLineNumber();
						if (!lastFailLineNumbers.contains(lineno)) {
							lastFailLineNumbers.add(lineno);
						}
					}
					break;
				case FINISHED:
					if (finishedState != null) {
						throw new IOException("Multiple paths finished successfully.");
					}
					finishedState = current;
					break;			
				}
			}
		}
		if (finishedState == null) {
			if (lastFailOffset == -1) throw new RuntimeException("No fail offset recorded!");
			int[] linenos = new int[lastFailLineNumbers.size()];
			for (int i = 0; i < linenos.length; i++) {
				linenos[i] = lastFailLineNumbers.get(i);
			}
			throw new ParserException(this, lastFailOffset, linenos);
		}
		return finishedState;
	}

	public CharSequence getFile() {
		return file;
	}
	
	public String getBuffer() {
		String result = writeBuffer.toString();
		writeBuffer.setLength(0);
		return result;
	}
	
	public void writeBuffer(String text) {
		if (hasQueuedStates()) throw new RuntimeException("There are queued states!");
		writeBuffer.append(text);
	}

	
	public void writeCSV(int fileIndex, String[] record) throws IOException {
		if (hasQueuedStates()) throw new RuntimeException("There are queued states!");
		csvFiles[fileIndex].write(record);
	}

	public ParserScript getScript() {
		return script;
	}

	public boolean hasQueuedStates() {
		return queuedStates.size() > 0;
	}

	public void enqueueState(ParserState toEnqueue) {
		queuedStates.add(toEnqueue);
	}

	public void setFile(ParserState current, CharSequence newFile) {
		if (hasQueuedStates()) throw new RuntimeException("There are queued states!");
		if (current.getOffset() != 0) throw new RuntimeException("Some text has already been parsed:"+current.getOffset());
		file = newFile;
	}
	
	public void addCallback(String name, CallbackFunction function) {
		callbacks.put(name, function);
	}
	public CallbackFunction getCallback(String name) {
		return callbacks.get(name);
	}
}
