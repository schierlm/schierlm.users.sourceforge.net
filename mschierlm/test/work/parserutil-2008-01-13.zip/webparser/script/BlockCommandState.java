package webparser.script;

public abstract class BlockCommandState {

	private int startLine;
	public BlockCommandState(ParserScript script) {
		startLine = script.getCurrentLineNumber();
	}
	public int getStartLine() {
		return startLine;
	}
	
	public abstract boolean canParse(String commandName);
	public abstract BlockCommandState parseCommand(ParserScript script, String commandName, String parameters);
}
