package webparser.script.command;

import webparser.operation.MatchOperation;
import webparser.operation.WriteOperation;
import webparser.operation.Operation.OperationResult;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class WriteCommand extends Command {

	private final boolean newLine;

	public WriteCommand(boolean newLine) {
		this.newLine = newLine;
	}

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		script.appendOperation(new WriteOperation(script.getCurrentLineNumber(), 
				Parameter.parseParameter(parameters, script.isUseAscii(), script.isUseEntities()),
				newLine));
		return null;
	}
}
