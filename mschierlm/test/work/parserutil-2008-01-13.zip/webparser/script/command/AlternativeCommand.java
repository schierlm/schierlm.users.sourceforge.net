package webparser.script.command;

import webparser.operation.DieOperation;
import webparser.operation.ForkOperation;
import webparser.operation.JumpOperation;
import webparser.operation.Label;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class AlternativeCommand extends Command {

	private final boolean optional;

	public AlternativeCommand(boolean optional) {
		this.optional = optional;
	}
	
	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Label endLabel = new Label(), nextPartLabel =new Label(), forkLabel = new Label();
		if (optional) {
			script.appendOperation(new ForkOperation(script.getCurrentLineNumber(), endLabel, false));
		}
		script.appendOperation(new ForkOperation(script.getCurrentLineNumber(),forkLabel, false));
		script.appendOperation(new JumpOperation(script.getCurrentLineNumber(), nextPartLabel));
		forkLabel.setDestinationToNextCommand(script);
		return new AlternativeCommandState(script, nextPartLabel, endLabel);
	}
	
	private class AlternativeCommandState extends BlockCommandState {

		private Label nextPartLabel;
		private final Label endLabel;

		public AlternativeCommandState(ParserScript script,
				Label nextPartLabel, Label endLabel) {
			super(script);
			this.nextPartLabel = nextPartLabel;
			this.endLabel = endLabel;
		}

		@Override
		public boolean canParse(String commandName) {
			return commandName.equals("nextalternative") || commandName.equals("nextalt") || commandName.equals("endalternative") || commandName.equals("endalt");
		}

		@Override
		public BlockCommandState parseCommand(ParserScript script,
				String commandName, String parameters) {
			script.appendOperation(new JumpOperation(script.getCurrentLineNumber(), endLabel));
			nextPartLabel.setDestinationToNextCommand(script);
			if (commandName.startsWith("end")) {
				script.appendOperation(new DieOperation(script.getCurrentLineNumber()));
				endLabel.setDestinationToNextCommand(script);
				return null;
			} else {
				nextPartLabel = new Label();
				Label forkLabel = new Label();
				script.appendOperation(new ForkOperation(script.getCurrentLineNumber(),forkLabel, false));
				script.appendOperation(new JumpOperation(script.getCurrentLineNumber(), nextPartLabel));
				forkLabel.setDestinationToNextCommand(script);
				return this;
			}
		}		
	}
}
