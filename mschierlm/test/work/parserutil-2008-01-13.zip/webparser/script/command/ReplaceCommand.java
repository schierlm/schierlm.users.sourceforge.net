package webparser.script.command;

import webparser.operation.ReplaceOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class ReplaceCommand extends Command {

	private final boolean eachLine;

	public ReplaceCommand(boolean eachLine) {
		this.eachLine = eachLine;
	}

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Parameter[] params = Parameter.parseParameters(parameters, 2, 2, 0, script.isUseAscii(), script.isUseEntities());
		script.appendOperation(new ReplaceOperation(script.getCurrentLineNumber(), params[0], params[1], eachLine));
		return null;
	}

}
