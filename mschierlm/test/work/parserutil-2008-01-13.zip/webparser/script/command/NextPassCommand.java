package webparser.script.command;

import webparser.operation.CheckFinishedOperation;
import webparser.operation.FinishOthersOperation;
import webparser.operation.NextPassOperation;
import webparser.operation.Operation.OperationResult;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class NextPassCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		script.appendOperation(new CheckFinishedOperation(script.getCurrentLineNumber(), OperationResult.CONTINUE));
		script.appendOperation(new NextPassOperation(script.getCurrentLineNumber()));
		return null;
	}

}
