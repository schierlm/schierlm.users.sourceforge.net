package webparser.script.command;

import webparser.operation.SetOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class SetCommand extends Command {

	private final boolean commaNeeded;

	public SetCommand(boolean commaNeeded) {
		this.commaNeeded = commaNeeded;
	}
	
	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Parameter[] params = Parameter.parseParameters(parameters, 2, 2, commaNeeded ? 0 : 1, script.isUseAscii(), script.isUseEntities());		
		script.appendOperation(new SetOperation(script.getCurrentLineNumber(), params[0], params[1]));
		return null;
	}

}
