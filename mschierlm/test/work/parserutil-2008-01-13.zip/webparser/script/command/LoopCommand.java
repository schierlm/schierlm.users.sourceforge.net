package webparser.script.command;


import webparser.operation.CounterOperation;
import webparser.operation.IncrementCounterOperation;
import webparser.operation.JumpOperation;
import webparser.operation.Label;
import webparser.operation.LoopForkOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class LoopCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		// Continue after the loop and fork inside the loop.
		// The other way round is easier to code, but will cause
		// a huge pile of queued of states to pile up if the loop repeats 
		// a lot of times.
		Parameter[] params = Parameter.parseParameters(parameters, 0, 2, 1, script.isUseAscii(), script.isUseEntities());
		if (params[0] == null) params[0] = Parameter.getLiteralParameter("0");
		Label startLabel = new Label(), endLabel = new Label(), forkLabel = new Label();
		CounterOperation co = new CounterOperation(script.getCurrentLineNumber());
		script.appendOperation(co);
		startLabel.setDestinationToNextCommand(script);
		script.appendOperation(new LoopForkOperation(script.getCurrentLineNumber(), forkLabel, co, params[0], params[1]));
		script.appendOperation(new JumpOperation(script.getCurrentLineNumber(),endLabel));
		forkLabel.setDestinationToNextCommand(script);
		return new LoopCommandState(script, co, startLabel, endLabel);
	}
	
	private class LoopCommandState extends BlockCommandState {

		private final CounterOperation co;
		private final Label startLabel;
		private final Label endLabel;

		public LoopCommandState(ParserScript script, CounterOperation co, Label startLabel, Label endLabel) {
			super(script);
			this.co = co;
			this.startLabel = startLabel;
			this.endLabel = endLabel;
		}

		@Override
		public boolean canParse(String commandName) {
			return commandName.equals("endloop");
		}

		@Override
		public BlockCommandState parseCommand(ParserScript script,
				String commandName, String parameters) {
			script.appendOperation(new IncrementCounterOperation(script.getCurrentLineNumber(), co));
			script.appendOperation(new JumpOperation(script.getCurrentLineNumber(), startLabel));
			endLabel.setDestinationToNextCommand(script);
			return null;
		}
	}
}
