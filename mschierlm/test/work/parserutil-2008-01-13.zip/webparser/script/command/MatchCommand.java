package webparser.script.command;

import webparser.operation.MatchOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class MatchCommand extends Command {

	private final boolean checkOnly;
	private final boolean negateCheck;
	private final boolean wholeLine;

	public MatchCommand(boolean checkOnly, boolean negateCheck, boolean wholeLine) {
		this.checkOnly = checkOnly;
		this.negateCheck = negateCheck;
		this.wholeLine = wholeLine;
		if (negateCheck && !checkOnly) throw new RuntimeException();
	}
	
	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		script.appendOperation(new MatchOperation(script.getCurrentLineNumber(), 
				Parameter.parseParameter(parameters, script.isUseAscii(), script.isUseEntities()),
				checkOnly, negateCheck, wholeLine));
		return null;
	}

}
