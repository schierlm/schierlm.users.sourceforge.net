package webparser.script.command;


import webparser.operation.ForkOperation;
import webparser.operation.Label;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class CheckOthersCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Label forkLabel = new Label();
		script.appendOperation(new ForkOperation(script.getCurrentLineNumber(), forkLabel, true));
		forkLabel.setDestinationToNextCommand(script);
		return null;
	}
}
