package webparser.script.command;

import webparser.operation.DebugWriteOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class DebugWriteCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Parameter param = Parameter.parseParameter(parameters, script.isUseAscii(), script.isUseEntities());
		script.appendOperation(new DebugWriteOperation(script.getCurrentLineNumber(), param));
		return null;
	}

}
