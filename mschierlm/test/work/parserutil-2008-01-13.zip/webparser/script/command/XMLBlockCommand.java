package webparser.script.command;

import webparser.operation.XMLBlockEndOperation;
import webparser.operation.XMLBlockStartOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class XMLBlockCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Parameter param = Parameter.parseParameter(parameters, script.isUseAscii(), script.isUseEntities());
		script.appendOperation(new XMLBlockStartOperation(script.getCurrentLineNumber(), param));
		return new XMLBlockCommandState(script);
	}


	private class XMLBlockCommandState extends BlockCommandState {

		public XMLBlockCommandState(ParserScript script) {
			super(script);
		}

		@Override
		public boolean canParse(String commandName) {
			return commandName.equals("endblock");
		}

		@Override
		public BlockCommandState parseCommand(ParserScript script,
				String commandName, String parameters) {
			script.appendOperation(new XMLBlockEndOperation(script.getCurrentLineNumber()));
			return null;
		}
	}
}
