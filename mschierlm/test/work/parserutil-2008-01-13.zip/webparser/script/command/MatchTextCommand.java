package webparser.script.command;

import webparser.operation.MatchTextOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class MatchTextCommand extends Command {

	private final boolean checkOnly;
	private final boolean negateCheck;

	public MatchTextCommand(boolean checkOnly, boolean negateCheck) {
		this.checkOnly = checkOnly;
		this.negateCheck = negateCheck;
		if (negateCheck && !checkOnly) throw new RuntimeException();
	}

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Parameter[] params = Parameter.parseParameters(parameters, 2, 2, 1, script.isUseAscii(), script.isUseEntities());
		script.appendOperation(new MatchTextOperation(script.getCurrentLineNumber(), params[0], 
				params[1],
				checkOnly, negateCheck));
		return null;
	}
}
