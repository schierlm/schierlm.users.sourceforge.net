package webparser.script.command;

import webparser.operation.WriteCSVOperation;
import webparser.parameter.Parameter;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class WriteCSVCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		Parameter[] params = Parameter.parseParameters(parameters, 2, 2, 1, script.isUseAscii(), script.isUseEntities());	
		script.appendOperation(new WriteCSVOperation(script.getCurrentLineNumber(), params[0], params[1]));
		return null;
	}

}
