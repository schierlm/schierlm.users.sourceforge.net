package webparser.script.command;

import webparser.operation.ForkOperation;
import webparser.operation.Label;
import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class OptionalCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String line) {
		Label forkLabel = new Label();
		script.appendOperation(new ForkOperation(script.getCurrentLineNumber(), forkLabel, false));
		int pos = line.indexOf(" ");
		int pos2 = line.indexOf("\t");
		if (pos2 != -1 && (pos == -1 || pos > pos2)) pos = pos2;
		String commandName, parameters;
		if (pos == -1) {
			commandName = line.toLowerCase();
			parameters = "";
		} else {
			commandName = line.substring(0, pos).toLowerCase();
			parameters = line.substring(pos+1);
		}
		Command cmd = Command.getCommand(commandName);
		if (cmd != null) {
			BlockCommandState bcs = cmd.parse(script, parameters);
			if (bcs != null) throw new RuntimeException("Optional command cannot be used for block commands!");
		}else {
			throw new RuntimeException("Unsupported command:" +commandName);
		}
		forkLabel.setDestinationToNextCommand(script);
		return null;
	}

}
