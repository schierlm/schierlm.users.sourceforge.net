package webparser.script;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import webparser.operation.CheckFinishedOperation;
import webparser.operation.Operation;
import webparser.operation.Operation.OperationResult;
import webparser.script.command.Command;

public class ParserScript {

	private boolean useAscii, useEntities;
	private List<String> lines = new ArrayList<String>();

	private List<Operation> operations = new ArrayList<Operation>();

	public ParserScript(String filename, String encoding) throws IOException {
		this(new File(filename), encoding);
	}
	public ParserScript(File file, String encoding) throws IOException {
		this(new BufferedReader(new InputStreamReader(new FileInputStream(file), encoding)));
	}
	
	public ParserScript(Class<?> clazz, String resourcename, String encoding) throws IOException {
		this(new BufferedReader(new InputStreamReader(clazz.getResourceAsStream(resourcename), encoding)));
	}
	
	public ParserScript(BufferedReader br) throws IOException {
		List<BlockCommandState> openBlockStates = new ArrayList<BlockCommandState>();
		String line;
		while ((line = br.readLine()) != null) {
			lines.add(line);
			try {
				if (line.trim().length()> 0 && !line.trim().startsWith("#")) {
					while (line.startsWith(" ") || line.startsWith("\t")) line = line.substring(1);
					int pos = line.indexOf(" ");
					int pos2 = line.indexOf("\t");
					if (pos2 != -1 && (pos == -1 || pos > pos2)) pos = pos2;
					String commandName, parameters;
					if (pos == -1) {
						commandName = line.toLowerCase();
						parameters = "";
					} else {
						commandName = line.substring(0, pos).toLowerCase();
						parameters = line.substring(pos+1);
					}
					Command cmd = Command.getCommand(commandName);
					boolean parsed = false;
					if (cmd != null) {
						BlockCommandState bcs = cmd.parse(this, parameters);
						if (bcs != null) openBlockStates.add(bcs);
						parsed = true;
					} else if(openBlockStates.size()> 0) {
						BlockCommandState bcs = openBlockStates.remove(openBlockStates.size()-1);
						if (bcs.canParse(commandName)) {
							bcs = bcs.parseCommand(this, commandName, parameters);
							parsed = true;
							if (bcs != null) openBlockStates.add(bcs);
						}
					}
					if (!parsed) {
						throw new RuntimeException("Unsupported command: " +commandName);
					}
				}
			} catch (RuntimeException ex) {
				throw new RuntimeException("Cannot parse line "+lines.size()+":\n\t"+line, ex);
			}
		}
		br.close();
		if (openBlockStates.size()!= 0) {
			int lineno = openBlockStates.get(openBlockStates.size()-1).getStartLine();
			throw new IOException("Unclosed block in line "+lineno+":\n\t"+getLineText(lineno));
		}
		lines.add("[End of file]");
		operations.add(new CheckFinishedOperation(getCurrentLineNumber(), OperationResult.FINISHED));
	}

	public int getCurrentLineNumber() {
		return lines.size();
	}

	public String getLineText(int lineno) {
		return lines.get(lineno-1);
	}

	public int getNextOperationIndex() {
		return operations.size();
	}

	public void appendOperation(Operation op) {
		operations.add(op);
	}

	public Operation getOperation(int ip) {
		return operations.get(ip);
	}
	
	public boolean isUseAscii() {
		return useAscii;
	}
	
	public boolean isUseEntities() {
		return useEntities;
	}
	
	public void setUseAscii(boolean useAscii) {
		this.useAscii = useAscii;
	}
	public void setUseEntities(boolean useEntities) {
		this.useEntities = useEntities;
	}
}
