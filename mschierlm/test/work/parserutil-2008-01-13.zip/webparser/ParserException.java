package webparser;

@SuppressWarnings("serial")
public class ParserException extends Exception {

	private final Parser parser;
	private final int offset;
	private final int[] lineNumbers;

	public ParserException(Parser parser, int offset, int[] lineNumbers) {
		this.parser = parser;
		this.offset = offset;
		this.lineNumbers = lineNumbers;
	}
	
	public Parser getParser() {
		return parser;
	}
	public int getOffset() {
		return offset;
	}
	public int[] getLineNumbers() {
		return lineNumbers;
	}
	
	@Override
	public String getMessage() {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("Could not parse file. Script position(s):");
			for(int lineno : lineNumbers) {
				sb.append("\n\t["+lineno+"]\t"+parser.getScript().getLineText(lineno));
			}
			sb.append("\nNext 1K to parse:\n\t");
			sb.append(parser.getFile().subSequence(offset, Math.min(parser.getFile().length(), offset + 1024)).toString().replace("\n", "\n\t"));
			return sb.toString();
		} catch(Exception ex) {
			ex.printStackTrace();
			return "[Error while constructing message]";
		}
	}
}
