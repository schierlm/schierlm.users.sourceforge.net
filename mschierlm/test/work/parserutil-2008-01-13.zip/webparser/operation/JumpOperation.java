package webparser.operation;

import webparser.ParserState;

public class JumpOperation extends Operation {

	private final Label target;

	public JumpOperation(int lineNumber, Label target) {
		super(lineNumber);
		this.target = target;
	}

	@Override
	public OperationResult execute(ParserState state) {
		state.setNextInstruction(target.getDestination());
		return OperationResult.CONTINUE;
	}
}
