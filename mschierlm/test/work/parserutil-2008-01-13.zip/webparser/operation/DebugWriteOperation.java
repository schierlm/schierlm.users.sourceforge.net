package webparser.operation;

import webparser.ParserState;
import webparser.parameter.Parameter;

public class DebugWriteOperation extends SideEffectOperation {

	private final Parameter param;

	public DebugWriteOperation(int lineNumber, Parameter param) {
		super(lineNumber);
		this.param = param;
	}

	@Override
	public OperationResult executeWithSideEffects(ParserState state) {
		// TODO have a "debug write stream" to write this to
		System.out.println(param.getString(state));
		return OperationResult.CONTINUE;
	}
}
