package webparser.operation;

import java.util.regex.Matcher;

import parserutil.PatternCache;
import webparser.ParserState;
import webparser.parameter.Parameter;

public class SetOperation extends Operation {

	private final Parameter tag;
	private final Parameter value;
	public SetOperation(int lineno, Parameter tag, Parameter value) {
		super(lineno);
		this.tag = tag;
		this.value = value;
	}
	
	@Override
	public OperationResult execute(ParserState state) {
		String v = value.getString(state);
		Matcher m = PatternCache.compile(tag.getRegex(state)).matcher(v);
		if (!m.matches()) return OperationResult.FAIL;
		tag.applyMatch(state, m);
		return OperationResult.CONTINUE;
	}
}
