package webparser.operation;

import java.util.regex.Matcher;

import parserutil.PatternCache;
import webparser.ParserState;
import webparser.parameter.Parameter;

public class MatchTextOperation extends Operation {

	private final Parameter varname;
	private final Parameter parameter;
	private final boolean checkOnly;
	private final boolean negateCheck;

	public MatchTextOperation(int lineno, Parameter varname, Parameter parameter, boolean checkOnly, boolean negateCheck) {
		super(lineno);
		this.varname = varname;
		this.parameter = parameter;
		this.checkOnly = checkOnly;
		this.negateCheck = negateCheck;
		if (negateCheck && !checkOnly) throw new RuntimeException();
	}

	@Override
	public OperationResult execute(ParserState state) {
		String regex = parameter.getRegex(state);
		boolean success;
		Matcher m;
		String var = varname.getString(state);
		String rest = state.getLocal(var);
		m = PatternCache.compile("^"+regex).matcher(rest);
		success = m.find();
		if (success) {
			parameter.applyMatch(state, m);
			if (!checkOnly) {
				if (m.start() != 0) throw new RuntimeException();
				state.setLocal(var, rest.substring(m.end()));
			}
		}
		if (success != negateCheck) { 
			return OperationResult.CONTINUE;
		} else {
			return OperationResult.FAIL;
		}
	}
}
