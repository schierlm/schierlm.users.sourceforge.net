package webparser.operation;

import java.util.regex.Matcher;

import parserutil.PatternCache;
import webparser.ParserState;
import webparser.parameter.Parameter;

public class MatchOperation extends Operation{
	
	private final Parameter parameter;
	private final boolean checkOnly;
	private final boolean negateCheck;
	private final boolean wholeLine;

	public MatchOperation(int lineno, Parameter parameter, boolean checkOnly, boolean negateCheck, boolean wholeLine) {
		super(lineno);
		this.parameter = parameter;
		this.checkOnly = checkOnly;
		this.negateCheck = negateCheck;
		this.wholeLine = wholeLine;
		if (negateCheck && !checkOnly) throw new RuntimeException();
	}

	@Override
	public OperationResult execute(ParserState state) {
		String regex = parameter.getRegex(state);
		boolean success;
		Matcher m;
		if (wholeLine) {
			CharSequence rest = state.getFirstLine();
			if (rest == null) {
				m = null;
				success = false;
			} else {
				m = PatternCache.compile(regex).matcher(rest);
				success = m.matches();
			}
		} else {
			CharSequence rest = regex.contains("\n") ? state.getRest() : state.getFirstLine();
			m = PatternCache.compile("^"+regex).matcher(rest);
			success = m.find();
		}
		if (success) {
			parameter.applyMatch(state, m);
			if (!checkOnly) {
				if (m.start() != 0) throw new RuntimeException();
				int end = m.end() + (wholeLine ? 1 : 0);
				state.discardCharacters(end);
			}
		}
		if (success != negateCheck) { 
			return OperationResult.CONTINUE;
		} else {
			return OperationResult.FAIL;
		}
	}
}
