package webparser.operation;

import webparser.ParserState;

public class DieOperation extends Operation {

	public DieOperation(int lineNumber) {
		super(lineNumber);
	}

	@Override
	public OperationResult execute(ParserState state) {
		return OperationResult.DIE;
	}

}
