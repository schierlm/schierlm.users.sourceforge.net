package webparser.operation;

import webparser.ParserState;

public class ForkOperation extends Operation {

	private final Label forkLabel;
	private final boolean die;

	public ForkOperation(int lineNumber, Label forkLabel, boolean die) {
		super(lineNumber);
		this.forkLabel = forkLabel;
		this.die = die;
	}

	@Override
	public OperationResult execute(ParserState state) {
		state.getParser().enqueueState(new ParserState(state, forkLabel.getDestination()));
		if (die) return OperationResult.DIE;
		return OperationResult.CONTINUE;
	}
}
