package webparser.operation;

import webparser.ParserState;

public abstract class Operation {
	
	private final int lineNumber;

	public static enum OperationResult {
		CONTINUE, NEXTPASS, FAIL, DIE, FINISHED
	}
	
	public Operation(int lineNumber) {
		this.lineNumber = lineNumber;	
	}

	public abstract OperationResult execute(ParserState state);

	public int getLineNumber() {
		return lineNumber;
	}
}
