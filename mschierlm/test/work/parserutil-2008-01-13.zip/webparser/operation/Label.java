package webparser.operation;

import webparser.script.ParserScript;

public class Label {
	
	private int destination = -1;
	
	public int getDestination() {
		if (destination == -1) throw new RuntimeException("Trying to use an uninitialized label!");
		return destination;
	}
	
	public void setDestinationToNextCommand(ParserScript script) {
		this.destination = script.getNextOperationIndex();
	}
}
