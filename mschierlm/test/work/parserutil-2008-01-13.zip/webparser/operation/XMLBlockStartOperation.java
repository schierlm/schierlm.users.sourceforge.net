package webparser.operation;

import org.w3c.dom.Element;

import webparser.ParserState;
import webparser.parameter.Parameter;

public class XMLBlockStartOperation extends Operation {

	private final Parameter blockname;

	public XMLBlockStartOperation(int lineNumber, Parameter blockname) {
		super(lineNumber);
		this.blockname = blockname;
	}

	@Override
	public OperationResult execute(ParserState state) {
		state.appendXmlAction("<>", blockname.getString(state));
		return OperationResult.CONTINUE;
	}
}
