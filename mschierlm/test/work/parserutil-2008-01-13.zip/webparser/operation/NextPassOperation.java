package webparser.operation;

import webparser.ParserState;

public class NextPassOperation extends SideEffectOperation {

	public NextPassOperation(int lineno) {
		super(lineno);
	}

	@Override
	public OperationResult executeWithSideEffects(ParserState state) {
		state.startNextPass();
		return OperationResult.NEXTPASS;
	}


}
