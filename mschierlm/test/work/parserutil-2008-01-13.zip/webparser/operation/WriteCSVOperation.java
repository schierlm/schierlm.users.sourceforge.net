package webparser.operation;

import java.io.IOException;

import webparser.ParserState;
import webparser.parameter.Parameter;

public class WriteCSVOperation extends Operation {

	private final Parameter index;
	private final Parameter fields;

	public WriteCSVOperation(int lineNumber, Parameter index, Parameter fields) {
		super(lineNumber);
		this.index = index;
		this.fields = fields;
	}

	@Override
	public OperationResult execute(ParserState state) {
		String[] flds = fields.getString(state).split(",");
		String[] actions = new String[flds.length+1];
		actions[0] = "C"+Integer.parseInt(index.getString(state));
		for (int i = 0; i < flds.length; i++) {
			if (state.getLocal(flds[i]) == null)
				throw new RuntimeException("Invalid field: "+flds[i]);
			flds[i] = state.getLocal(flds[i]);
			actions[i+1]=flds[i];
		}
		state.appendXmlAction(actions);
		return OperationResult.CONTINUE;
	}
}
