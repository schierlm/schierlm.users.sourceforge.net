package webparser.operation;

import webparser.ParserState;

public class CounterOperation extends Operation {

	private int counter;
	
	public CounterOperation(int lineNumber) {
		super(lineNumber);
	}

	@Override
	public OperationResult execute(ParserState state) {
		counter = 0;
		return OperationResult.CONTINUE;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void incrementCounter() {
		counter++;
	}
}
