package webparser.operation;

import webparser.ParserState;

public class IncrementCounterOperation extends Operation {

	private final CounterOperation co;

	public IncrementCounterOperation(int lineNumber, CounterOperation co) {
		super(lineNumber);
		this.co = co;
	}

	@Override
	public OperationResult execute(ParserState state) {
		co.incrementCounter();
		return OperationResult.CONTINUE;
	}
}
