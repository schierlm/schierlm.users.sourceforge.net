package webparser.operation;

import org.w3c.dom.Element;

import webparser.ParserState;

public class XMLBlockEndOperation extends Operation {

	public XMLBlockEndOperation(int lineNumber) {
		super(lineNumber);
	}

	@Override
	public OperationResult execute(ParserState state) {
		state.appendXmlAction("/");
		return OperationResult.CONTINUE;
	}

}
