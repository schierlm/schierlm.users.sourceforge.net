package webparser.operation;

import webparser.ParserState;
import webparser.parameter.Parameter;

public class LoopForkOperation extends Operation {

	private final Label label;
	private final CounterOperation co;
	private final Parameter mincount;
	private final Parameter maxcount;

	public LoopForkOperation(int lineNumber, Label label,
			CounterOperation co, Parameter mincount, Parameter maxcount) {
		super(lineNumber);
		this.label = label;
		this.co = co;
		this.mincount = mincount;
		this.maxcount = maxcount;
	}

	@Override
	public OperationResult execute(ParserState state) {
		int min = 0,max = Integer.MAX_VALUE;
		try {
			min = Integer.parseInt(mincount.getString(state));
		} catch (NumberFormatException ex) {}
		if (maxcount != null) {
			try {
				max = Integer.parseInt(maxcount.getString(state));
			} catch (NumberFormatException ex) {}
		}
		if (min > max) {
			int tmp = max; max = min; min = tmp;
		}
		int counter = co.getCounter();
		if (counter < max) {
			// fork inside the loop
			state.getParser().enqueueState(new ParserState(state, label.getDestination()));
		}
		if (counter < min) {
			return OperationResult.DIE;
		}
		return OperationResult.CONTINUE;
	}
}
