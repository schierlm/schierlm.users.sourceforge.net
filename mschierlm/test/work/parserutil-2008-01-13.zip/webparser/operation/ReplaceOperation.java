package webparser.operation;

import webparser.Parser;
import webparser.ParserState;
import webparser.parameter.Parameter;

public class ReplaceOperation extends SideEffectOperation {

	private final Parameter search;
	private final Parameter replace;
	private final boolean eachLine;

	public ReplaceOperation(int lineNumber, Parameter search,
			Parameter replace, boolean eachLine) {
		super(lineNumber);
		this.search = search;
		this.replace = replace;
		this.eachLine = eachLine;
	}

	@Override
	public OperationResult executeWithSideEffects(ParserState state) {
		String ss = search.getString(state);
		String rr = replace.getString(state);
		Parser parser = state.getParser();
		String file = parser.getFile().toString();
		if (eachLine) {
			StringBuffer result = new StringBuffer();
			int pos; 
			while ((pos = file.indexOf("\n")) != -1) {
				result.append(file.substring(0, pos).replaceAll(ss,rr)+"\n");
				file = file.substring(pos+1);
			}
			result.append(file.replaceAll(ss, rr));
			file = result.toString();
		} else {
			file=file.replaceAll(ss, rr);
		}
		parser.setFile(state, file);
		return OperationResult.CONTINUE;
	}
}
