package webparser.operation;

import webparser.ParserState;
import webparser.parameter.Parameter;

public class WriteOperation extends SideEffectOperation {

	private final Parameter parameter;
	private final boolean newLine;

	public WriteOperation(int lineno, Parameter parameter, boolean newLine) {
		super(lineno);
		this.parameter = parameter;
		this.newLine = newLine;
	}

	@Override
	public OperationResult executeWithSideEffects(ParserState state) {
		state.write(parameter.getString(state));
		if (newLine) state.write("\n");
		return OperationResult.CONTINUE;
	}

}
