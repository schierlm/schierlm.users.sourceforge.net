package webparser.operation;

import webparser.ParserState;

public class FinishOthersOperation extends SideEffectOperation {

	public FinishOthersOperation(int lineNumber) {
		super(lineNumber);
	}

	@Override
	public OperationResult executeWithSideEffects(ParserState state) {
		// do nothing here - the fact that this method has been reached
		// is enough to ensure that all other states have been finished
		return null;
	}
}
