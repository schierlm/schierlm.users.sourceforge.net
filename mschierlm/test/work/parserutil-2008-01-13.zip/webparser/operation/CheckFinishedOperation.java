package webparser.operation;

import webparser.ParserState;

public class CheckFinishedOperation extends Operation {

	private final OperationResult result;

	public CheckFinishedOperation(int lineNumber, OperationResult result) {
		super(lineNumber);
		this.result = result;
	}

	@Override
	public OperationResult execute(ParserState state) {
		if (state.getOffset() == state.getParser().getFile().length())
			return result;
		else
			return OperationResult.FAIL;
	}
}
