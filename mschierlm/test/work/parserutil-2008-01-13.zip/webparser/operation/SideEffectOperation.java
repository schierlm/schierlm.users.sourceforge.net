package webparser.operation;

import webparser.ParserState;


// these operations have a side effect,
// and can only be called if there are no other
// queued states
public abstract class SideEffectOperation extends Operation {

	private static ParserState waitingSideEffectState = null;
	
	public SideEffectOperation(int lineNumber) {
		super(lineNumber);
	}

	@Override
	public final OperationResult execute(ParserState state) {
		// note that this operation can be run a lot of times before
		// all states are away, because the other states may fork a lot
		// before all of them die
		if (waitingSideEffectState == state) 
			waitingSideEffectState = null;
		if (state.getParser().hasQueuedStates()) {
			if (waitingSideEffectState != null) {
				// another operation is waiting as well; so set
				// waitingSideEffectOperation to this so that
				// the other one will fail as well
				// TODO report somewhere else!
				System.out.println("*** Side effect blocked in line "+this.getLineNumber());
				waitingSideEffectState = state;
				return OperationResult.FAIL;
			} else {
				waitingSideEffectState = state;
				// put this state to the end and wait for the others to die
				state.setNextInstruction(state.getNextInstruction()-1);
				state.getParser().enqueueState(state);
				return OperationResult.DIE;
			}
		} else {
			if (waitingSideEffectState != null) {
				return OperationResult.FAIL;
			}
			return executeWithSideEffects(state);
		}
	}

	public abstract OperationResult executeWithSideEffects(ParserState state);
}
