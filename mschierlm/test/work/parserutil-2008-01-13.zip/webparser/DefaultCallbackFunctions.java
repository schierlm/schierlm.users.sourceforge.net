package webparser;

class DefaultCallbackFunctions {
	static void addTo(Parser parser) {
		parser.addCallback("replace", new CallbackFunction() {
			public String call(String[] arguments) {
				if (arguments.length %2 != 1) throw new RuntimeException("Replace needs odd number of arguments: "+ arguments.length);
				String result = arguments[0];
				for (int i = 1; i < arguments.length; i+=2) {
					result = result.replaceAll(arguments[i], arguments[i+1]);
				}
				return result;
			}
		});
	}
}
