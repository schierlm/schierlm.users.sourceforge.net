package parserutil;

public class RegexQuoter {
	
	public static String quote(String expression) {
		return "\\Q"+expression.replace("\\", "\\\\")+"\\E";
	}

	public static String quotePartially(String expression) {
		StringBuilder sb = new StringBuilder();
		int pos = expression.indexOf("�");
		while (pos != -1) {
			sb.append(quote(expression.substring(0, pos))).append("(");
			expression = expression.substring(pos+1);
			pos = expression.indexOf("�");
			if (pos == -1) throw new RuntimeException("Missing delimiter");
			if (pos == 0) sb.append(".*?");
			sb.append(expression.substring(0, pos)).append(")");
			expression = expression.substring(pos+1);
			pos = expression.indexOf("�");		
		}
		return sb.append(quote(expression)).toString();
	}
}
