/*
 * (c) 2006, 2007 Michael Schierl
 */
package parserutil;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExpectString {

	private String rest;
	private int offset;
	
	public ExpectString(String rest) {
		this.rest = rest;
		this.offset = 0;
	}
	
	// generic methods

	private void cleanup() {
		if (offset != 0) {
			rest = rest.substring(offset);
			offset = 0;
		}
	}
	
	public String getRest() {
		return rest.substring(offset);
	}
	
	public String changeRest(String newRest) {
		String oldRest = rest.substring(offset);
		rest = newRest;
		offset = 0;
		return oldRest;
	}

	public String expectStringBeforeString(String s) {
		int pos = rest.indexOf(s, offset);
		if (pos == -1) throw new ExpectException(getRest(), "'...'"+s);
		String result = rest.substring(offset, pos);
		offset = pos+s.length();
		return result;
	}
	
	public String expectStringAfterString(String s) {
		cleanup();
		int pos = rest.lastIndexOf(s);
		if (pos == -1) throw new ExpectException(rest, s+"'...'");
		String result = rest.substring(pos + s.length());
		rest = rest.substring(0, pos);
		return result;
	}
	
	@Deprecated
	public String expectStringBeforeRegex(String regex) {
		throw new RuntimeException("Not implemented!");
	}
	
	@Deprecated
	public String expectStringAfterRegex(String regex) {
		throw new RuntimeException("Not implemented!");		
	}

	public void expect(String start) {
		if (!rest.startsWith(start, offset)) {
			throw new ExpectException(getRest(), start);
		}
		offset +=start.length();
	}
	
	public void expectEnd(String end) {
		if (!rest.endsWith(end)) {
			throw new ExpectException(getRest(), end);
		}
		rest = rest.substring(offset, rest.length() - end.length());
		offset = 0;
	}

	// regex matches

	public Matcher expectRegex(String regex) {
		return expectRegex(regex+"(.*)", -1);
	}

	public Matcher expectRegex(String pattern, int keptGroup) {
		return expectRegex(PatternCache.compile(pattern), keptGroup);
	}

	public Matcher expectRegex(Pattern pattern, int keptGroup) {
		cleanup();
		Matcher m = pattern.matcher(rest);
		if (!m.matches()) {
			throw ExpectException.fromRegex(rest, pattern);
		}
		if (keptGroup == -1) keptGroup = m.groupCount();
		rest = m.group(keptGroup);
		return m;
	}

	// multi regex match

	public List<Matcher> expectMultiRegexMatch(String regex, int restGroup) {
		return expectMultiRegexMatch(PatternCache.compile(regex),  
						restGroup);
	}

	public List<Matcher> expectMultiRegexMatch(Pattern pattern, int restGroup) {
		cleanup();
		List<Matcher> lm = ExpectReader.ensureMultiRegexMatch(rest, pattern, null, restGroup);
		if (lm.size()>0) {
			rest = lm.get(lm.size()-1).group(restGroup);
		}
		return lm;
	}
}
