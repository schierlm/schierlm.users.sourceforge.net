/*
 * (c) 2006 Michael Schierl
 */
package parserutil;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Map;

public class CSVWriter {
	private Writer w;
	private char separator = ';';
	public CSVWriter(Writer w) {
		this.w=w;
	}
	
	public CSVWriter(OutputStream out, String charsetName) throws UnsupportedEncodingException {
		this(new OutputStreamWriter(out, charsetName));
	}
	
	public void flush() throws IOException { w.flush(); }
	public void close() throws IOException { w.close(); }
	
	public char getSeparator() {
		return separator;
	}
	
	public void setSeparator(char separator) {
		this.separator = separator;
	}
	
	public void write(String... record) throws IOException {
		for (int i = 0; i < record.length; i++) {
			if (i != 0)
				w.write(separator);
			w.write("\""+record[i].replaceAll("\"", "\"\"")+"\"");
		}
		w.write("\r\n");
	}
	
	public void write(Map<String,String>recordMap, String[] headers) throws IOException {
		String[] record = new String[headers.length];
		for(int i=0; i<headers.length; i++) {
			String value = recordMap.get(headers[i]);
			if (value == null) value = "";
			record[i] = value;
		}
		write(record);
	}
}
