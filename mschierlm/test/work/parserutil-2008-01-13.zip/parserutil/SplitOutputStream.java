/*
 * (c) 2006 Michael Schierl
 */
package parserutil;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;


public class SplitOutputStream extends OutputStream {

	public static interface StreamFactory {
		public OutputStream createOutputStream(int index) throws IOException;
	}
	
	public static enum SplitRuleDecision {
		KEEP, SPLIT_AFTER, TOO_LONG
	}
	
	public static abstract class SplitRule {
		
		public abstract void update(byte[] data, int off, int len);
		
		public abstract SplitRuleDecision decide(byte[] data, int off, int len);

		public void update(byte data) {
			update(new byte[] {data}, 0, 1);
		}
		
		public SplitRuleDecision decide(byte data) {
			return decide(new byte[] {data}, 0, 1);
		}
	}
	
	private static enum OutMode {
		START, HEADER, FOOTER, NORMAL, CLOSED;
	}
	
	private OutputStream out = null;
	private OutMode outMode = OutMode.START;
	private final StreamFactory factory;
	private final SplitRule rule;
	private byte[] header = null, footer = null;
	int index=0;
	
	public SplitOutputStream(StreamFactory factory, SplitRule rule) {
		this.factory = factory;
		this.rule = rule;
	}
	
	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		if (shouldCount()) {
			SplitRuleDecision dec = rule.decide(b, off, len);
			if (dec == SplitRuleDecision.KEEP) {
				out.write(b, off, len);
				rule.update(b, off, len);
			} else if (dec == SplitRuleDecision.SPLIT_AFTER) {
				out.write(b, off, len);
				rule.update(b, off, len);
				next();
			} else if (len == 1){
				throw new IOException("Cannot split one byte");
			} else {
				int half = len/2;
				// recursive, divide&conquer
				write(b, off, half);
				write(b, off+half, len-half);
			}			
		} else {
			out.write(b, off, len);
		}
	}
	
	@Override
	public void write(int b) throws IOException {
		if (shouldCount()) {
			SplitRuleDecision dec = rule.decide((byte)b);
			if (dec == SplitRuleDecision.KEEP) {
				out.write(b);
				rule.update((byte)b);
			} else if (dec == SplitRuleDecision.SPLIT_AFTER) {
				out.write(b);
				rule.update((byte)b);
				next();
			} else {
				throw new IOException("Cannot split one byte");
			}
		} else {
			out.write(b);
		}
	}

	private void next() throws IOException {
		if (footer != null) out.write(footer);
		out.flush();
		out.close();
		out = factory.createOutputStream(++index);
		if (header != null) out.write(header);
	}

	private boolean shouldCount() throws IOException {
		switch(outMode) {
		case START:
			out = factory.createOutputStream(index);
			if (header != null) out.write(header);
			outMode = OutMode.NORMAL;
			return true;
		case NORMAL:
			return true;
		case FOOTER:
		case HEADER:
			return false;
		case CLOSED:
		default:
			throw new IOException("Stream closed");
		}
	}
	
	public void startHeaderBlock() {
		if (outMode != OutMode.START || header != null) throw new IllegalStateException();
		outMode = OutMode.HEADER;
		out = new ByteArrayOutputStream();
	}
	
	public void startFooterBlock() {
		if (outMode != OutMode.START || footer != null) throw new IllegalStateException();
		outMode = OutMode.FOOTER;
		out = new ByteArrayOutputStream();
	}
	
	public void finishBlock() throws IOException {
		if (outMode == OutMode.HEADER) {
			out.flush();
			out.close();
			header = ((ByteArrayOutputStream)out).toByteArray();
		} else if (outMode == OutMode.FOOTER) {
			out.flush();
			out.close();
			footer = ((ByteArrayOutputStream)out).toByteArray();
		} else {
			throw new IllegalStateException();
		}
		outMode = OutMode.START;
		out = null;
	}
	
	public void flush() throws IOException {
		if (out != null) out.flush();
	}
	
	public void close() throws IOException {
		flush();
		if (out != null)  {
			if (footer != null) out.write(footer);
			out.flush();
			out.close();
		}
		outMode = OutMode.CLOSED;
	}
}
