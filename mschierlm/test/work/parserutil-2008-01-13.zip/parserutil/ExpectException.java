/*
 * (c) 2006, 2007 Michael Schierl 
 */
package parserutil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class ExpectException extends RuntimeException {

	private static final long serialVersionUID = 4350118922979233122L;

	public ExpectException(String actual, String expected) {
		super("Unexpected string\nActual:   '"+actual+"'\nExpected: '"+expected+"'");
	}

	private ExpectException(String actual, Pattern pattern) {
		super("Nonmatching regex\n\nActual: '"+actual+"'\nRegex:  '"+pattern.pattern()+"'");
	}
	
	private ExpectException(String actual, Pattern pattern, String debugActual, String debugPattern) {
		super("Nonmatching regex\n\nActual: '"+actual+"'\nRegex:  '"+pattern.pattern()+"'\n\nActual part: '"+debugActual+"'\nRegex part:  '"+debugPattern+"'");
	}

	private ExpectException(String actual, Pattern pattern, Exception cause) {
		super("Nonmatching regex\n\nActual: '"+actual+"'\nRegex:  '"+pattern.pattern()+"'\n\nNo debug information available", cause);
	}
	
	public static ExpectException fromRegex(final String actual, final Pattern pattern) {
		try {
		String p = pattern.pattern();
		Pattern pt = pattern;
		while (!pt.matcher(actual).matches() && p.indexOf(">{0}") != -1) {
			p = p.substring(0, p.lastIndexOf(">{0}"))+"(.*)";
			pt = PatternCache.compile(p);
		}
		if (!pattern.pattern().equals(p)) {
			String restpattern = pattern.pattern().substring(p.length()-4+4);
			Matcher m = pt.matcher(actual);
			if (!m.matches()) 
				throw new RuntimeException();
			String restactual = m.group(m.groupCount());
			return new ExpectException(actual, pattern, restactual, restpattern);
		}
		return new ExpectException(actual, pattern);
		} catch (PatternSyntaxException ex) {
			return new ExpectException(actual, pattern, ex);
		}
	}
}