/*
 * (c) 2006 Michael Schierl
 */
package parserutil;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {

	private final BufferedReader br;
	private char separator = ';';
	private boolean stripComments = false;

	public CSVReader(BufferedReader br) {
		this.br = br;
	}
	
	public CSVReader(Reader r) {
		this(new BufferedReader(r));
	}
	
	public CSVReader(InputStream in, String charsetName) throws UnsupportedEncodingException {
		this(new InputStreamReader(in, charsetName));
	}
	
	public char getSeparator() {
		return separator;
	}
	
	public void setSeparator(char separator) {
		this.separator = separator;
	}
	
	public void setStripComments(boolean stripComments) {
		this.stripComments = stripComments;
	}
	
	public void close() throws IOException {
		br.close();
	}
	
	public String[] read() throws IOException {
		String line = br.readLine();
		if (stripComments) {
			while (line != null && (line.startsWith("#") || line.length() == 0))
				line = br.readLine();
		}
		if (line == null) return null;
		if (separator == 0) {
			if (line.indexOf(';') != -1)
				separator = ';';
			else if (line.indexOf(',') != -1)
				separator = ',';
			else
				separator = ';';
		}
		final String origLine = line;
		List<String> elems = new ArrayList<String>();
		while(line != null) {
			if (line.startsWith("\"")) {
				String part = "";
				while (true) {
					int pos = line.indexOf("\"", 1);
					if (pos == -1) throw new IOException("Unparsable CSV line: "+origLine);
					part += line.substring(1, pos);
					line = line.substring(pos+1);
					if (line.length() == 0) {
						line = null;
						break;
					} else if (line.charAt(0) == separator) {
						line = line.substring(1);
						break;
					} else if (line.charAt(0) != '"') {
						throw new IOException("Unparsable CSV line: "+origLine+"\nat: "+line);
					}
					part +="\"";
				}
				elems.add(part);
			} else {
				int pos = line.indexOf(separator);
				if (pos == -1) {
					elems.add(line);
					line = null;
				} else {
					elems.add(line.substring(0, pos));
					line = line.substring(pos+1);
				}
			}
		}
		return elems.toArray(new String[elems.size()]);
	}
}
