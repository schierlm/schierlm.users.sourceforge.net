/*
 * (c) 2006 Michael Schierl
 */
package parserutil;

import parserutil.SplitOutputStream.SplitRule;
import parserutil.SplitOutputStream.SplitRuleDecision;


public class CountSplitRule extends SplitRule {

	private final int desiredSize;
	private final boolean lines;
	private int current;

	public CountSplitRule(int desiredSize, boolean lines) {
		this.desiredSize = desiredSize;
		this.lines = lines;
		current = 0;
	}

	private int count(byte[] data, int off, int len) {
		if (lines) {
			int cnt=0;
			for (int i = off; i < off+len; i++) {
				if(data[i] == '\n') cnt++;
			}
			return cnt;
		} else {
			return len;
		}
	}
	
	@Override
	public SplitRuleDecision decide(byte[] data, int off, int len) {
		int c = current+count(data, off, len);
		if (c>desiredSize) return SplitRuleDecision.TOO_LONG;
		else if (c == desiredSize) {
			if (current+count(data, off, len-1) < c)
				return SplitRuleDecision.SPLIT_AFTER;
			else 
				return SplitRuleDecision.TOO_LONG;
		}
		else return SplitRuleDecision.KEEP;
	}
	
	@Override
	public void update(byte[] data, int off, int len) {
		current += count(data, off, len);
		if (current > desiredSize) throw new IllegalStateException("SplitOutputStream has to split this!");
		if (current == desiredSize) current = 0;
	}
}
