/*
 * (c) 2006 Michael Schierl
 */
package parserutil;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;


public class CachingDownloader {
	private final File cachePath;
	private String cookies = null, useragent=null, forwardedFor=null;
	private long delay = 0;
	private final Random rnd = new Random();

	public CachingDownloader(File cachePath) {
		this.cachePath = cachePath;
	}

	public CachingDownloader(File cachePath, String cookies, String useragent, String forwardedFor, long delay) {
		this(cachePath);
		this.cookies = cookies;
		this.useragent = useragent;
		this.forwardedFor = forwardedFor;
		this.delay = delay;
	}
	
	public InputStream download(String url, String cacheName)  throws IOException {
		return download(url, null, cacheName);
	}
	
	public InputStream download(String url, String postdata, String cacheName) throws IOException {
		File cacheFile = new File(cachePath, cacheName);
		if (!cacheFile.exists()) {
			download(url, postdata, cacheFile);
		}
		return new FileInputStream(cacheFile);
	}

	
	private void download(String url, String postdata, File cacheFile) throws IOException {
		if (delay>0) {
			System.out.println("Waiting for "+url+" "+postdata);
			try {Thread.sleep(delay);} catch(InterruptedException ex){}
		}
		System.out.println("Downloading "+url+" "+postdata);
		URLConnection conn = new URL(url).openConnection();
		if (cookies != null) {
			conn.setRequestProperty("Cookie", cookies);
		}
		if (useragent != null) {
//			conn.setRequestProperty("User-Agent", "Bot/1.0 (Curiosity killed the cat)");
			conn.setRequestProperty("User-Agent", useragent);
		}
		if (forwardedFor != null) {
			String ff = forwardedFor;
			while(ff.indexOf('*') != 0) {
				int pos = ff.indexOf('*');
				ff = ff.substring(0, pos) + rnd.nextInt(256)+ff.substring(pos+1);
			}
//			conn.setRequestProperty("X-Forwarded-For", "127."+rnd.nextInt()+"."+rnd.nextInt()+"."+rnd.nextInt());
			conn.setRequestProperty("X-Forwarded-For", ff);
		}
		if (postdata != null) {
			conn.setDoOutput(true);
	        OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream(), "ISO-8859-1");
	        wr.write(postdata);
	        wr.flush();
		}
		InputStream in = conn.getInputStream();
		FileOutputStream out = new FileOutputStream(cacheFile);
		byte[] buf = new byte[4096];
		int len;
		while ((len = in.read(buf))!= -1) {
			out.write(buf, 0, len);
		}
		in.close();
		out.close();
	}
	
	public static String loadStream(InputStream in, String encoding) throws IOException {
		Reader r= new InputStreamReader(in, encoding);
		StringBuffer sb = new StringBuffer();
		char[] buf = new char[4096];
		int len;
		while ((len = r.read(buf))!= -1) {
			sb.append(buf, 0, len);
		}
		r.close();
		return sb.toString();
	}
}
