/*
 * (c) 2006 Michael Schierl
 */
package parserutil;
/*
 */

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class PatternCache {
	public static final Map<String,Pattern> patternMap = new HashMap<String, Pattern>();
	
	public static Pattern compile(String regex) {
		if (!patternMap.containsKey(regex)) {
			patternMap.put(regex, Pattern.compile(regex));
		}
		return patternMap.get(regex);
	}
}
