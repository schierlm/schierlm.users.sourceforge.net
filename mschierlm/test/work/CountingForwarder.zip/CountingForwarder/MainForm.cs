using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.IO;
using System.Net;

namespace CountingForwarder
{
    public partial class MainForm : Form
    {
        long[] bytes = new long[2];
        int connections = 0, openConnections = 0;
        long[,] connBytes = new long[4096, 2];
        object counterLock = new object();

        public MainForm()
        {
            InitializeComponent();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            startButton.Enabled = false;
            fromIP.Enabled = false;
            toIP.Enabled = false;
            toPort.Enabled = false;
            fromPort.Enabled = false;
            new Thread(new ThreadStart(Runner)).Start();
        }

        private void Runner()
        {
            TcpListener listener = new TcpListener(IPAddress.Parse(fromIP.Text), int.Parse(fromPort.Text));
            listener.Start();
            while (true)
            {
                TcpClient inClient = listener.AcceptTcpClient();
                int idx;
                lock (counterLock)
                {
                    idx = connections++;
                    openConnections++;
                }
                Stream instream = inClient.GetStream();
                TcpClient outClient = new TcpClient(toIP.Text, int.Parse(toPort.Text));
                Stream outstream = outClient.GetStream();
                new Thread(Forwarder).Start(new ForwarderArgs(idx, 0, outstream, instream, inClient));
                new Thread(Forwarder).Start(new ForwarderArgs(idx, 1, instream, outstream, outClient));
            }
        }

        private void Forwarder(object o)
        {
            ForwarderArgs fs = (ForwarderArgs)o;
            byte[] buffer = new byte[4096];
            int read;
            try
            {
                while ((read = fs.s1.Read(buffer, 0, buffer.Length)) > 0)
                {
                    lock (counterLock)
                    {
                        bytes[fs.direction] += read;
                        connBytes[fs.idx, fs.direction] += read;
                    }
                    fs.s2.Write(buffer, 0, read);
                }
            }
            catch { }
            fs.toClose.Close();
            if (fs.direction == 0)
            {
                lock (counterLock)
                {
                    openConnections--;
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            lock (counterLock)
            {
                sb.Append("Connections: " + connections + " ("+openConnections+" still open)\r\n");
                sb.Append("Bytes in/out:" + bytes[0]+"/"+bytes[1]+"\r\n\r\nConnections:\r\n");
                for (int i = 0; i < connections; i++)
                {
                    sb.Append((i + 1) + ": " + connBytes[i, 0] + "/" + connBytes[i, 1]+"\r\n");
                }
            }
            textBox1.Text = sb.ToString();
        }

        struct ForwarderArgs
        {
            public int idx, direction;
            public Stream s1, s2;
            public TcpClient toClose;

            public ForwarderArgs(int idx, int direction, Stream s1, Stream s2, TcpClient toClose)
            {
                this.idx = idx; this.direction = direction; this.s1 = s1; this.s2 = s2; this.toClose = toClose;
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}