package webparser.operation;

import webparser.ParserState;

public class FinishOperation extends Operation {

	public FinishOperation(int lineNumber) {
		super(lineNumber);
	}

	@Override
	public OperationResult execute(ParserState state) {
		if (state.getOffset() == state.getParser().getFile().length())
			return OperationResult.FINISHED;
		else
			return OperationResult.FAIL;
	}
}
