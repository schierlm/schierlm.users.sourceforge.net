package webparser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class ParserState {
	private Parser parser;
	private int nextInstruction;
	private int offset;
	private Map<String,String> locals = new HashMap<String,String>();
	private List<String[]> xmlActions = new ArrayList<String[]>();
	
	public ParserState(Parser parser) {
		this.parser = parser;
		nextInstruction = 0;
		offset = 0;
	}
	
	public ParserState(ParserState toCopy, int nextInstruction) {
		xmlActions = new ArrayList<String[]>(toCopy.xmlActions);
		parser = toCopy.parser;
		this.nextInstruction = nextInstruction;
		offset = toCopy.offset;
		locals.putAll(toCopy.locals);
	}

	public void applyXMLActions(Element target) {
		if(parser.hasQueuedStates()) throw new IllegalStateException();
		Element current = target;
		for(String[] elem : xmlActions) {
			switch(elem[0].charAt(0)) {
			case '/': 
				current = (Element)current.getParentNode(); 
				break;
			case '<':
				Element e = current.getOwnerDocument().createElement(elem[1]);
				current.appendChild(e);
				current = e;
				break;
			case 'T':
				current.appendChild(current.getOwnerDocument().createTextNode(elem[1]));
				break;
			case '@':
				current.setAttribute(elem[1], elem[2]);
				break;
			case 'C':
				int idx = Integer.parseInt(elem[0].substring(1));
				String[] flds = new String[elem.length-1];
				System.arraycopy(elem, 1, flds, 0, flds.length);
				try {
					parser.writeCSV(idx, flds);
				} catch (IOException ex) {
					throw new RuntimeException("Exception while writing CSV file "+idx, ex);
				}
				break;
			default: throw new RuntimeException();
			}
		}
		xmlActions.clear();
	}
	
	public void appendXmlAction(String... action) {
		xmlActions.add(action);
	}
	
	public String getLocal(String varname) {
		return locals.get(varname);
	}

	public void appendTag(String tagname, String value) {
		if (tagname.length() > 0)
			appendXmlAction("<>", tagname);
		appendXmlAction("T", value);
		if (tagname.length() > 0)
			appendXmlAction("/>");
	}

	public void setAttribute(String attrname, String value) {
		appendXmlAction("@", attrname, value);
	}

	public void setLocal(String varname, String value) {
		locals.put(varname, value);
	}
	
	public int getNextInstructionAndIncrement() {
		return nextInstruction++;	
	}
	
	public int getNextInstruction() {
		return nextInstruction;
	}
	
	public void setNextInstruction(int nextInstruction) {
		this.nextInstruction = nextInstruction;
	}
	
	public int getOffset() {
		return offset;
	}
	
	public Parser getParser() {
		return parser;
	}
	
	public CharSequence getRest() {
		return parser.getFile().subSequence(offset,parser.getFile().length());
	}
	
	public CharSequence getFirstLine() {
		CharSequence rest = getRest();
		for (int i = 0; i < rest.length(); i++) {
			if (rest.charAt(i) == '\n') {
				return rest.subSequence(0, i);
			}
		}
		return null;
	}

	public void discardCharacters(int count) {
		offset += count;
	}
}
