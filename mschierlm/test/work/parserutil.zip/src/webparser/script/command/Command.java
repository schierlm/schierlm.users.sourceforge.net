package webparser.script.command;

import java.util.HashMap;
import java.util.Map;

import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public abstract class Command {

	private static Map<String,Command> commands = new HashMap<String, Command>();
	
	static {
		// CHECK commands
		commands.put("check", new MatchCommand(true, false, false));
		commands.put("checknot", new MatchCommand(true, true, false));
		commands.put("checkline", new MatchCommand(true, false, true));
		commands.put("checklinenot", new MatchCommand(true, true, true));
		commands.put("checktext", new MatchTextCommand(true, false));
		commands.put("checktextnot", new MatchTextCommand(true, false));
		commands.put("cl", new MatchCommand(true, false, true));

		// MATCH commands
		commands.put("match", new MatchCommand(false, false, false));
		commands.put("matchline", new MatchCommand(false, false, true));
		commands.put("matchtext", new MatchTextCommand(false, false));
		commands.put("ml", new MatchCommand(false, false, true));
		
		// control flow commands
		commands.put("loop", new LoopCommand());
		commands.put("alternative", new AlternativeCommand(false));
		commands.put("alt", new AlternativeCommand(false));
		commands.put("optionalalternative", new AlternativeCommand(true));
		commands.put("optalt", new AlternativeCommand(true));
		commands.put("optional", new OptionalCommand());
		commands.put("opt", new OptionalCommand());
		commands.put("block", new XMLBlockCommand());
		commands.put("checkothers", new CheckOthersCommand());
		commands.put("finishothers", new FinishOthersCommand());
		
		// other commands
		commands.put("set", new SetCommand(false));
		commands.put("setexpression", new SetCommand(true));
		commands.put("replace", new ReplaceCommand(false));
		commands.put("replaceline", new ReplaceCommand(true));
		commands.put("debugwrite", new DebugWriteCommand());
		commands.put("dw", new DebugWriteCommand());
		commands.put("writecsv", new WriteCSVCommand());
		// TODO instantiate more commands here
	}
	public static Command getCommand(String commandName) {
		return commands.get(commandName);
	}
	
	public abstract BlockCommandState parse(ParserScript script, String parameters);
}
