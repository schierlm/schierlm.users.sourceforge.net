package webparser.script.command;

import webparser.script.BlockCommandState;
import webparser.script.ParserScript;

public class FinishOthersCommand extends Command {

	@Override
	public BlockCommandState parse(ParserScript script, String parameters) {
		script.appendOperation(new FinishOthersOperation(script.getCurrentLineNumber()));
		return null;
	}
}
