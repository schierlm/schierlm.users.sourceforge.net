/*
 * (c) 2006, 2007 Michael Schierl
 */
package parserutil;

import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExpectReader {
	
	private final BufferedReader br;

	public ExpectReader(BufferedReader br) {
		this.br = br;
	}
	
	public ExpectReader(Reader r) {
		this(new BufferedReader(r));
	}
	
	public ExpectReader(InputStream in, String charsetName) throws UnsupportedEncodingException {
		this(new InputStreamReader(in, charsetName));
	}
	
	// generic methods
	
	public BufferedReader getReader() {
		return br;
	}
	
	public String ensureReadLine() throws IOException {
		String l = readLine();
		if (l == null) throw new EOFException();
		return l;
	}
	public String readLine() throws IOException {
		return br.readLine();
	}
	
	// string matches
	
	public void expect(String... lines) throws IOException {
		for (String l : lines) {
			expectLine(l);
		}
	}
	
	public void expectLine(String line) throws IOException {
		ensureStringMatch(ensureReadLine(), line);
	}

	public static void ensureStringMatch(String actual, String expected) {
		if (!expected.equals(actual)) {
			throw new ExpectException(actual, expected);
		}
	}
	
	// regex matches
	
	public Matcher expectRegex(String regex) throws IOException {
		return ensureRegexMatch(ensureReadLine(), regex);
	}

	public Matcher expectRegex(Pattern pattern) throws IOException {
		return ensureRegexMatch(ensureReadLine(), pattern);
	}
	
	public static Matcher ensureRegexMatch(String actual, String pattern) {
		return ensureRegexMatch(actual, PatternCache.compile(pattern));
	}
	
	public static Matcher ensureRegexMatch(String actual, Pattern pattern) {
		Matcher m = regexMatch(actual, pattern);
		if (m == null) throw ExpectException.fromRegex(actual, pattern);
		return m;
	}
	
	public static Matcher regexMatch(String actual, String regex) {
		return regexMatch(actual, PatternCache.compile(regex));
	}
	
	public static Matcher regexMatch(String actual, Pattern pattern) {
		Matcher m = pattern.matcher(actual);
		if (m.matches()) {
			return m;
		}
		return null;
	}

	// multi regex match
	
	public static List<Matcher> ensureMultiRegexMatch(String actual, String regex, String terminalRegex, int restGroup) {
		return ensureMultiRegexMatch(actual, PatternCache.compile(regex), 
				terminalRegex == null ? null : PatternCache.compile(terminalRegex), 
						restGroup);
	}

	public static List<Matcher> ensureMultiRegexMatch(String actual, Pattern pattern, Pattern terminalPattern, int restGroup) {
		List<Matcher> result = new ArrayList<Matcher>();
		while(terminalPattern == null || !terminalPattern.matcher(actual).matches()) {
			Matcher m = pattern.matcher(actual);
			if (!m.matches()) {
				if (terminalPattern == null) return result;
				throw ExpectException.fromRegex(actual, pattern);
			}
			result.add(m);
			actual = m.group(restGroup);
		}
		return result;
	}
}