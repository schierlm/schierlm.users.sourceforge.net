/*
 * (c) 2006 Michael Schierl
 */
package parserutil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.Format;
import java.text.MessageFormat;
import java.text.NumberFormat;

public class FileOutputStreamFactory implements SplitOutputStream.StreamFactory {

	private final File directory;
	private final MessageFormat filenameFormat;
	private final int firstNumber;
	
	public FileOutputStreamFactory(File directory, String filenameFormat, int firstNumber) {
		this(directory, new MessageFormat(filenameFormat), firstNumber);
	}
	
	public FileOutputStreamFactory(File directory, MessageFormat filenameFormat, int firstNumber) {
		this.directory = directory;
		this.filenameFormat = filenameFormat;
		this.firstNumber = firstNumber;
	}
	
	public OutputStream createOutputStream(int index) throws FileNotFoundException {
		String filename = filenameFormat.format(new Object[] {new Integer(index+firstNumber)});
		return new FileOutputStream(new File(directory, filename));
	}
}
