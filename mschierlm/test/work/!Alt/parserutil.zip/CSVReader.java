/*
 * (c) 2006 Michael Schierl
 */
package parserutil;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;


public class CSVReader {

	private final BufferedReader br;
	private char separator = ';';

	public CSVReader(BufferedReader br) {
		this.br = br;
	}
	
	public CSVReader(Reader r) {
		this(new BufferedReader(r));
	}
	
	public CSVReader(InputStream in, String charsetName) throws UnsupportedEncodingException {
		this(new InputStreamReader(in, charsetName));
	}
	
	public char getSeparator() {
		return separator;
	}
	
	public void setSeparator(char separator) {
		this.separator = separator;
	}
	
	public void close() throws IOException {
		br.close();
	}
	
	public String[] read() throws IOException {
		String line = br.readLine();
		if (line == null) return null;
		final String origLine = line;
		List<String> elems = new ArrayList<String>();
		while(line.length()>1) {
			if (line.startsWith("\"")) {
				String part = "";
				while (true) {
					int pos = line.indexOf("\"", 1);
					if (pos == -1) throw new IOException("Unparsable CSV line: "+origLine);
					part += line.substring(1, pos);
					line = line.substring(pos+1);
					if (line.charAt(0) == separator) {
						line = line.substring(1);
						break;
					} else if (line.charAt(0) != '"') {
						throw new IOException("Unparsable CSV line: "+origLine+"\nat: "+line);
					}
					part +="\"";
				}
				elems.add(part);
			} else {
				int pos = line.indexOf(separator);
				if (pos == -1) {
					elems.add(line);
					line = "";
				} else {
					elems.add(line.substring(0, pos));
					line = line.substring(pos+1);
				}
			}
		}
		return elems.toArray(new String[elems.size()]);
	}
}
