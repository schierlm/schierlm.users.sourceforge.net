/*
 * Copyright (c) 2006, 2007 Michael Schierl
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are 
 * met:
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright 
 *   notice, this list of conditions and the following disclaimer in the 
 *   documentation and/or other materials provided with the distribution.
 * - No personal names or organizations names associated with this project 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission of the specific individual or 
 *   organization.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ChoiceFormat
{
    /// <summary>
    /// A choice format group that can work with any types of objects.
    /// 
    /// Choice format groups allow to select different strings or
    /// format specifiers depending on the values that should be formatted.
    /// </summary>
    public class ChoiceFormatGroup : AbstractChoiceFormatGroup<object> 
    {
        /// <summary>
        /// Creates the new choice format group.
        /// </summary>
        public ChoiceFormatGroup(params object[] values) : base(values) { }

        /// <summary>
        /// Retrieve a <see cref="ChoiceTester"/> for a given object.
        /// This method can retrieve choice testers for all builtin value types,
        /// as well as for string and enumerations.
        /// </summary>
        protected override ChoiceTester GetTester(object t)
        {
            if (t is ValueType)
            {
                if (t is byte) return new IntChoiceTester((byte)t);
                if (t is sbyte) return new IntChoiceTester((sbyte)t);
                if (t is short) return new IntChoiceTester((short)t);
                if (t is ushort) return new IntChoiceTester((ushort)t);
                if (t is int) return new IntChoiceTester((int)t);
                if (t is uint) return new ULongChoiceTester((uint)t);
                if (t is long) return new LongChoiceTester((long)t);
                if (t is ulong) return new ULongChoiceTester((ulong)t);
                if (t is char) return new IntChoiceTester((char)t);

                if (t is decimal) return new DecimalChoiceTester((decimal)t);

                if (t is float) return new DoubleChoiceTester((float)t);
                if (t is double) return new DoubleChoiceTester((double)t);

                if (t is bool) return new BoolChoiceTester((bool)t);

                if (t is Enum) return new EnumChoiceTester((Enum) t);
            }
            if (t is string) return new StringChoiceTester((string)t);

            throw new Exception("No choice tester available for type: " + t.GetType());
        }
    }

    /// <summary>
    /// A abstract choice format group template class.
    /// 
    /// Choice format groups allow to select different strings or
    /// format specifiers depending on the values that should be formatted.
    /// 
    /// Extend this class if you want to use your own objects as parameter
    /// for choices. Predefined classes for int, long, double, decimal, bool, Enum
    /// and string are already available.
    /// </summary>
    public abstract class AbstractChoiceFormatGroup<T> : IFormattable
    {
        private readonly T[] values;
        private readonly object[] valuesWithMe;
        private readonly int[] defaultIndices;

        /// <summary>
        /// Create a new instance of this class.
        /// </summary>
        public AbstractChoiceFormatGroup(params T[] values)
        {
            this.values = values;
            defaultIndices = new int[values.Length];
            for (int i = 0; i < defaultIndices.Length; i++)
            {
                defaultIndices[i] = i;
            }
            valuesWithMe = new object[values.Length + 1];
            Array.Copy(values, valuesWithMe, values.Length);
            valuesWithMe[values.Length] = this;
        }

        /// <summary>
        /// Get a choice tester for this implementation.
        /// </summary>
        protected abstract ChoiceTester GetTester(T t);

        /// <summary>
        /// Format this choice format group. This method is usually called by the
        /// <see cref="string.Format(string, object[])"/> method to do the formatting.
        /// </summary>
        public string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null || format == "")
                return ToString();
            int[] indices = defaultIndices;
            int offs = 0;
            if (format[offs] >= '0' && format[offs] <= '9')
            {
                List<int> newIndices = new List<int>();
                while (offs < format.Length && format[offs] >= '0' && format[offs] <= '9')
                {
                    int pos;
                    for (pos = offs; pos < format.Length; pos++)
                    {
                        if (format[pos] < '0' || format[pos] > '9') break;
                    }
                    int idx = int.Parse(format.Substring(offs, pos - offs));
                    if (idx >= values.Length) throw new FormatException(format);
                    newIndices.Add(idx);
                    if (pos != format.Length && format[pos] == ',') pos++;
                    offs = pos;
                }
                indices = newIndices.ToArray();
            }
            if (offs == format.Length)
            {
                if (indices.Length != 1) throw new FormatException(format);
                return FormattableToString(values[indices[0]],null, formatProvider);
            }
            else if (format[offs] == ':')
            {
                if (indices.Length != 1) throw new FormatException(format);
                return FormattableToString(values[indices[0]], Unescape(format.Substring(offs + 1)), formatProvider);
            }
            ChoiceTester[] testers = new ChoiceTester[indices.Length];
            for (int i = 0; i < testers.Length; i++)
            {
                testers[i] = GetTester(values[indices[i]]);
            }
            while (true)
            {
                if (format[offs] != '[')
                    throw new FormatException(format);
                offs++;
                int epos = format.IndexOf("]", offs);
                if (epos == -1) throw new FormatException(format);
                bool matching = true;
                for (int i = 0; i < indices.Length; i++)
                {
                    int pos = format.IndexOf("#", offs);
                    if (pos > epos) throw new FormatException(format);
                    string check = format.Substring(offs, pos - offs);
                    if (!testers[i].Matches(check))
                    {
                        matching = false;
                        break;
                    }
                    offs = pos + 1;
                }
                if (matching)
                {
                    return String.Format(formatProvider,
                        Unescape(format.Substring(offs, epos - offs)),
                        valuesWithMe);
                }
                offs = epos + 1;
            }
        }

        private string FormattableToString(object formattable, string format, IFormatProvider formatProvider)
        {
            if (formattable is IFormattable)
            {
                IFormattable f = (IFormattable)formattable;
                return f.ToString(format, formatProvider);
            }
            else
            {
                return formatProvider.ToString();
            }
        }

        internal static string Unescape(string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '\\')
                {
                    if (i + 1 == s.Length) throw new FormatException(s);
                    char replacement = s[i + 1];
                    switch (s[i + 1])
                    {
                        case '(': replacement = '{'; break;
                        case ')': replacement = '}'; break;
                        case '<': replacement = '['; break;
                        case '>': replacement = ']'; break;
                        case '*': replacement = '#'; break;
                    }
                    s = s.Substring(0, i) + replacement + s.Substring(i + 2);
                }
            }
            return s;
        }
    }

    /// <summary>
    /// A choice format group for <see cref="int"/> values (the most common case).
    /// </summary>
    public class IntChoiceFormatGroup : AbstractChoiceFormatGroup<int>
    {
        /// <summary>
        /// Create a new choice format group.
        /// </summary>
        public IntChoiceFormatGroup(params int[] values) : base(values) { }

        /// <summary>
        /// Return a <see cref="ChoiceTester"/> for an <see cref="int"/>.
        /// </summary>
        protected override ChoiceTester GetTester(int t)
        {
            return new IntChoiceTester(t);
        }
    }

    /// <summary>
    /// A choice format group for <see cref="decimal"/> values.
    /// </summary>
    public class DecimalChoiceFormatGroup : AbstractChoiceFormatGroup<decimal>
    {
        /// <summary>
        /// Create an instance of this class.
        /// </summary>
        public DecimalChoiceFormatGroup(params decimal[] values) : base(values) { }

        /// <summary>
        /// Return a <see cref="ChoiceTester"/> for a <see cref="decimal"/>.
        /// </summary>

        protected override ChoiceTester GetTester(decimal t)
        {
            return new DecimalChoiceTester(t);
        }
    }

    /// <summary>
    /// A choice format group for <see cref="double"/> values.
    /// </summary>
    public class DoubleChoiceFormatGroup : AbstractChoiceFormatGroup<double>
    {
        /// <summary>
        /// Create an instance of this class.
        /// </summary>
        public DoubleChoiceFormatGroup(params double[] values) : base(values) { }

        /// <summary>
        /// Return a <see cref="ChoiceTester"/> for a <see cref="double"/>.
        /// </summary>
        protected override ChoiceTester GetTester(double t)
        {
            return new DoubleChoiceTester(t);
        }
    }

    /// <summary>
    /// A choice format group for <see cref="string"/> values.
    /// </summary>
    public class StringChoiceFormatGroup : AbstractChoiceFormatGroup<string>
    {

        /// <summary>
        /// Create an instance of this class.
        /// </summary>
        public StringChoiceFormatGroup(params string[] values) : base(values) { }

        /// <summary>
        /// Return a <see cref="ChoiceTester"/> for a <see cref="string"/>.
        /// </summary>
        protected override ChoiceTester GetTester(string t)
        {
            return new StringChoiceTester(t);
        }
    }

    /// <summary>
    /// A choice format group for <see cref="bool"/> values.
    /// </summary>
    public class BoolChoiceFormatGroup : AbstractChoiceFormatGroup<bool>
    {

        /// <summary>
        /// Create an instance of this class.
        /// </summary>
        public BoolChoiceFormatGroup(params bool[] values) : base(values) { }

        /// <summary>
        /// Return a <see cref="ChoiceTester"/> for a <see cref="bool"/>.
        /// </summary>
        protected override ChoiceTester GetTester(bool t)
        {
            return new BoolChoiceTester(t);
        }
    }

    /// <summary>
    /// A choice format group for <see cref="Enum"/> values.
    /// </summary>
    public class EnumChoiceFormatGroup : AbstractChoiceFormatGroup<Enum>
    {
        /// <summary>
        /// Create an instance of this class.
        /// </summary>
        public EnumChoiceFormatGroup(params Enum[] values) : base(values) { }

        /// <summary>
        /// Return a <see cref="ChoiceTester"/> for an <see cref="Enum"/>.
        /// </summary>
        protected override ChoiceTester GetTester(Enum t)
        {
            return new EnumChoiceTester(t);
        }
    }

    /// <summary>
    /// This class is responsible for comparing a choice from a
    /// choice format group for a single value.
    /// </summary>
    public abstract class ChoiceTester
    {
        /// <summary>
        /// Check if the current value matches this expression.
        /// </summary>
        public abstract bool Matches(string expression);
    }
    
    /// <summary>
    /// A choice tester for comparable data types. It supports
    /// single values, value ranges and groups. There are 
    /// subclasses available for common datatypes; if you need
    /// others, the easiest way is to subclass this class.
    /// </summary>
    public abstract class OrderChoiceTester<T> : ChoiceTester where T : IComparable
    {
        /// <summary>
        /// Parse a string to a value of this datatype.
        /// </summary>
        protected abstract T Parse(string s);

        /// <summary>
        /// The current reference value.
        /// </summary>
        protected T value;

        /// <summary>
        /// Create an instance of this object.
        /// </summary>
        /// <param name="value"></param>
        public OrderChoiceTester(T value) {
            this.value = value;
        }

        /// <summary>
        /// Check for a match.
        /// </summary>
        public override bool Matches(string expression)
        {
            if (expression.Length == 0) return true;
            foreach (string expr in expression.Split(','))
            {
                int pos = expr.IndexOf('~');
                if (pos == -1)
                {
                    if (value.CompareTo(Parse(expr)) == 0)
                        return true;
                }
                else
                {
                    bool exclFirst = false, exclSecond = false;
                    string first = expr.Substring(0, pos);
                    string second = expr.Substring(pos + 1);
                    if (first.EndsWith("!"))
                    {
                        exclFirst = true; first = first.Substring(0, first.Length - 1);
                    }
                    if (second.StartsWith("!"))
                    {
                        exclSecond = true; second = second.Substring(1);
                    }
                    bool ok = true;
                    if (first != "")
                    {
                        int cmp1 = Parse(first).CompareTo(value);
                        if ((cmp1 > 0) || (cmp1 == 0 && exclFirst))
                            ok = false;
                    }
                    if (ok && second != "")
                    {

                        int cmp2 = value.CompareTo(Parse(second));
                        if (cmp2 > 0 || (cmp2 == 0 && exclSecond))
                            ok = false;
                    }
                    if (ok) return true;
                }
            }
            return false;
        }
    }

    internal class IntChoiceTester : OrderChoiceTester<int>
    {
        public IntChoiceTester(int value) : base(value) { }
        protected override int Parse(string s) { return int.Parse(s); }
    }

    internal class LongChoiceTester : OrderChoiceTester<long>
    {
        public LongChoiceTester(long value) : base(value) { }
        protected override long Parse(string s) { return long.Parse(s); }
    }

    internal class ULongChoiceTester : OrderChoiceTester<ulong>
    {
        public ULongChoiceTester(ulong value) : base(value) { }
        protected override ulong Parse(string s) { return ulong.Parse(s); }
    }

    internal class DecimalChoiceTester : OrderChoiceTester<decimal> {
        public DecimalChoiceTester(decimal value) : base(value) { }
        protected override decimal Parse(string s) { return decimal.Parse(s); }    
    }

    internal class DoubleChoiceTester : OrderChoiceTester<double> {
        public DoubleChoiceTester(double value) : base(value) { }

        protected override double Parse(string s) { return double.Parse(s); }    
    }

    internal class EnumChoiceTester : OrderChoiceTester<Enum>
    {
        public EnumChoiceTester(Enum value) : base(value) { }

        protected override Enum Parse(string s)
        {
            return (Enum) Enum.Parse(value.GetType(), s, false);
        }
    }

    internal class StringChoiceTester : ChoiceTester {

        private string value;
        public StringChoiceTester(string value)
        {
            this.value = value;
        }
        public override bool Matches(string expression)
        {
            if (expression == "") return true;
            Regex re = new Regex("^(" + AbstractChoiceFormatGroup<string>.Unescape(expression) + ")$");
            return re.IsMatch(value);
        }       
    }

    internal class BoolChoiceTester : ChoiceTester
    {

        private bool value;
        public BoolChoiceTester(bool value)
        {
            this.value = value;
        }
        public override bool Matches(string expression)
        {
            if (expression == "") return true;
            if (expression == "true") return value;
            if (expression == "false") return !value;
            throw new FormatException(expression);
        }
    }
}
