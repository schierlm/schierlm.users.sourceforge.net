using System;
using System.Collections.Generic;
using System.Text;

namespace ChoiceFormat
{
    class ChoiceFormatGroupTests
    {
        static void Main(string[] args)
        {
            RunIntTests();
            RunStringTests();
            RunObjectTests();
        }

        internal static void RunIntTests()
        {
            IntChoiceFormatGroup[] fixture = {
                new IntChoiceFormatGroup(47, 11),
                new IntChoiceFormatGroup(0, 1)
            };
            DoTest(fixture, "{0:0} and {0:1:G}", "47 and 11", "0 and 1");
            DoTest(fixture, @"{0:[~##\(0\) = \(2:0\) and \(1:X4\) = \(2:1:X4\)]}",
                "47 = 47 and 000B = 000B", "0 = 0 and 0001 = 0001");
            DoTest(fixture, "{0:1,0[11#47#First][#~#Second]}", "First", "Second");
            DoTest(fixture, "{0:1,0,0,1[11~#40~49#-1~#~100,-1~4,0~#First][####Second]Here Be Dragons!}", "First",
                "Second");
            DoTest(fixture, "{0:[3#3#][0!~#-20~!11#Never][0!~!100#~#First][~#-99~99#Second]}",
                "First", "Second");
            DoTest(fixture, "{0:[47#10#No1][48#11#No2][99#-22#No3][47,33#2,11,7#First][##Second][##No4]}", "First", "Second");
        }

        private static void DoTest(IntChoiceFormatGroup[] fixture, string p, params string[] results)
        {
            if (fixture.Length != results.Length) throw new Exception();
            for (int i = 0; i < fixture.Length; i++)
            {
                if (string.Format(p, fixture[i]) != results[i])
                    throw new Exception(string.Format(p, fixture[i]));
            }
        }

        public static void RunStringTests()
        {
            StringChoiceFormatGroup g = new StringChoiceFormatGroup("Boeing 747");
            DoTest(g, @"{0:[X#WrongX][U#WrongU][B.*#Ok][V#WrongV]}", "Ok");
            DoTest(g, @"{0:[Bo#Wrong][\<A-Z\>\<a-z\>* \<0-9\>+#Ok][.*#Wrong2]}", "Ok");
            DoTest(g, @"{0:[a\(0\)#Wrong][.*#Ok]}", "Ok");
            DoTest(g, @"{0:[a\(0\)Boeing 747#\(1:\<Air\*False\>\<.*ing 7.*\*Ok\>\<\*X\>\)]}", "Ok");
        }

        private static void DoTest(StringChoiceFormatGroup fixture, string p, string result)
        {
            if (string.Format(p, fixture) != result)
                throw new Exception(string.Format(p, fixture));

        }

        private static void RunObjectTests()
        {
            DoTest(new ChoiceFormatGroup(42, "Boo", ""));
            DoTest(new ChoiceFormatGroup(42.3m, "Boo", 44));
            DoTest(new ChoiceFormatGroup(3.14f, "Boo", true));
            DoTest(new ChoiceFormatGroup((short)3, "Boo", false));
            DoTest(new ChoiceFormatGroup((byte)9, "Boo", '@'));
            DoTest(new ChoiceFormatGroup(42L, "Boo", double.NegativeInfinity));
            DoTest(new ChoiceFormatGroup(double.NaN, "Boo", double.MinValue));
            DoTest(new ChoiceFormatGroup(3U, "Boo", "u"));
            DoTest(new ChoiceFormatGroup(4UL, "Boo", (sbyte)9));
            DoTest(new ChoiceFormatGroup((ushort)9, "Boo", System.PlatformID.Win32Windows));
            if ("Good" != string.Format("{0:[Win32Windows#Good][#Evil]}", new ChoiceFormatGroup(System.PlatformID.Win32Windows)))
                throw new Exception();
        }

        private static void DoTest(ChoiceFormatGroup cfg)
        {
            string str = @"{0:0[0#Zero][#Nonzero]} {0:1[\<a-z\>+#Lowercase][#Mixed]} {0:2[#Always]}";
            string result = "Nonzero Mixed Always";
            if (result != string.Format(str, cfg)) throw new Exception();
        }
    }
}
