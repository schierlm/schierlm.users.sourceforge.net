import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class WLWDownloader {
	public static void main(String[] args) throws IOException {
		CachingDownloader cd = new CachingDownloader(new File("./cache"));
		//cd.download("http://www.wlw.de/sse/MainServlet?anzeige=kurzliste&klobjid=73851&seite=1", "cat73851-page1.html");
		//cd.download("http://www.wlw.de/sse/MainServlet?anzeige=vollanzeige&firmaid=560929&klobjid=0&ccode=812232484077", "firma560929.html");
		//parseFirma(cd, 560929, 812232484077L);
		//parseFirma(cd, 1323179,2674402778905L);
		parseCategory(cd, 73446);
		System.out.println("+++");
		for(String s : keys) {
			System.out.println(s);
		}
	}

	public static void parseCategory(CachingDownloader cd, int klobid) throws IOException {
		int seite = 1;
		boolean next;
		do {
			seite++;
			System.out.println("*** Category "+klobid+", Page "+seite);
			String url="http://www.wlw.de/sse/MainServlet?anzeige=kurzliste&klobjid="+klobid+"&seite="+seite;
			String content = CachingDownloader.loadStream(cd.download(url, "cat"+klobid+"-page"+seite+".html"), "UTF-8");
			next = content.indexOf(">Weiter</a></p><div id=\"druckSpeichern\">") != -1;
			Pattern urlpattern = Pattern.compile("<a target=\"_top\" href=\"/sse/Klick\\?anzeige="+
					"fi-fu&land=DE&sprache=de&firmaid=([0-9]+)&klobjid="+klobid+"&fpaket=[0-9]+&kpaket=[0-9]+&url="+
						"%2Fsse%2FMainServlet%3Fanzeige%3Dvollanzeige%26land%3DDE%26sprache%3Dde%26firmaid%3D\\1%26klobjid%3D"+klobid+"%26ccode%3D([0-9]+)"+
					"\">");
			Matcher m = urlpattern.matcher(content);
			int cnt=0;
			while (m.find()) {
				cnt++;
				parseFirma(cd, Integer.parseInt(m.group(1)), Long.parseLong(m.group(2)));
			}
			if (next && cnt != 100) throw new IOException("Not all links found: "+cnt);
		} while (next);
	}

	public static final HashSet<String> keys = new HashSet<String>();
	public static void parseFirma(CachingDownloader cd, int firmaid, long ccode) throws IOException {
		String url = "http://www.wlw.de/sse/MainServlet?anzeige=vollanzeige&firmaid="+firmaid+"&klobjid=0&ccode="+ccode;
		String content = CachingDownloader.loadStream(cd.download(url, "firma"+firmaid+".html"), "UTF-8");
		int ppos = content.indexOf("<div id=\"darstellung\"><table><tr>");
		if (ppos == -1) {
			throw new IOException(""+firmaid);
		} else {
		String x = content.substring(ppos);
		int pos = x.indexOf("</tr></table>");
		String rest = x.substring(pos+13);
		x = x.substring(33, pos);
		Pattern tblpattern =Pattern.compile("^<td class=\"links\">(.*?)</td><td class=\"rechts\">(.*?)</td>$");
		for (String s : x.split("</tr><tr>")) {
			Matcher m = tblpattern.matcher(s);
			if (!m.matches()) throw new IOException();
			keys.add(m.group(1));
			//System.out.println(m.group(1)+"\t"+m.group(2));
		} 
		}
		//System.out.println("---");
	}
}
