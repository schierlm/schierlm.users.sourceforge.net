/*
 * (c) 2006 Michael Schierl
 */

import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExpectReader {
	
	private final BufferedReader br;

	public static class ExpectException extends RuntimeException {

		private static final long serialVersionUID = 4350118922979233122L;

		public ExpectException(String actual, String expected) {
			super("Unexpected string\nActual: "+actual+"\nExpected: "+expected);
		}

		public ExpectException(String actual, Pattern pattern) {
			super("Nonmatching regex\nActual: "+actual+"\nRegex: "+pattern.pattern());
		}
	}
	
	public ExpectReader(BufferedReader br) {
		this.br = br;
	}
	
	public BufferedReader getReader() {
		return br;
	}
	
	public String ensureReadLine() throws IOException {
		String l = readLine();
		if (l == null) throw new EOFException();
		return l;
	}
	public String readLine() throws IOException {
		return br.readLine();
	}
	
	// string matches
	
	public void expect(String... lines) throws IOException {
		for (String l : lines) {
			expectLine(l);
		}
	}
	
	public void expectLine(String line) throws IOException {
		ensureStringMatch(ensureReadLine(), line);
	}

	private static void ensureStringMatch(String actual, String expected) {
		if (!expected.equals(actual)) {
			throw new ExpectException(actual, expected);
		}
	}
	
	// regex matches
	
	public Matcher expectRegex(String regex) throws IOException {
		return ensureRegexMatch(ensureReadLine(), regex);
	}

	public Matcher expectRegex(Pattern pattern) throws IOException {
		return ensureRegexMatch(ensureReadLine(), pattern);
	}
	
	public static Matcher ensureRegexMatch(String actual, String pattern) {
		return ensureRegexMatch(actual, PatternCache.compile(pattern));
	}
	
	public static Matcher ensureRegexMatch(String actual, Pattern pattern) {
		Matcher m = regexMatch(actual, pattern);
		if (m == null) throw new ExpectException(actual, pattern);
		return m;
	}
	
	public static Matcher regexMatch(String actual, String regex) {
		return regexMatch(actual, PatternCache.compile(regex));
	}
	
	public static Matcher regexMatch(String actual, Pattern pattern) {
		Matcher m = pattern.matcher(actual);
		if (m.matches()) {
			return m;
		}
		return null;
	}

	// multi regex match
	
	public static List<Matcher> ensureMultiRegexMatch(String actual, String regex, String terminalRegex, int restGroup) {
		return ensureMultiRegexMatch(actual, PatternCache.compile(regex), 
				terminalRegex == null ? null : PatternCache.compile(terminalRegex), 
						restGroup);
	}

	private static List<Matcher> ensureMultiRegexMatch(String actual, Pattern pattern, Pattern terminalPattern, int restGroup) {
		List<Matcher> result = new ArrayList<Matcher>();
		while(terminalPattern == null || !terminalPattern.matcher(actual).matches()) {
			Matcher m = pattern.matcher(actual);
			if (!m.matches()) {
				if (terminalPattern == null) return result;
				throw new ExpectException(actual, pattern);
			}
			result.add(m);
			actual = m.group(restGroup);
		}
		return result;
	}
}