import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;


public class CachingDownloader {
	private final File cachePath;

	public CachingDownloader(File cachePath) {
		this.cachePath = cachePath;
	}
	
	public InputStream download(String url, String cacheName) throws IOException {
		File cacheFile = new File(cachePath, cacheName);
		if (!cacheFile.exists()) {
			download(url, cacheFile);
		}
		return new FileInputStream(cacheFile);
	}

	private void download(String url, File cacheFile) throws IOException {
		System.out.println("Downloading "+url);
		URLConnection conn = new URL(url).openConnection();
		conn.setRequestProperty("User-Agent", "Bot/1.0 (Curiosity killed the cat)");
		InputStream in = conn.getInputStream();
		FileOutputStream out = new FileOutputStream(cacheFile);
		byte[] buf = new byte[4096];
		int len;
		while ((len = in.read(buf))!= -1) {
			out.write(buf, 0, len);
		}
		in.close();
		out.close();
	}
	
	public static String loadStream(InputStream in, String encoding) throws IOException {
		Reader r= new InputStreamReader(in, encoding);
		StringBuffer sb = new StringBuffer();
		char[] buf = new char[4096];
		int len;
		while ((len = r.read(buf))!= -1) {
			sb.append(buf, 0, len);
		}
		r.close();
		return sb.toString();
	}
}
