using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using ScreensaverSample.Properties;

namespace ScreensaverSample
{
    public partial class FloatBackground : UserControl
    {
        int[] color = { 255, 0, 255 };
        int index = 0, direction = -1;

        public FloatBackground()
        {
            InitializeComponent();
        }

        private void FloatBackground_Paint(object sender, PaintEventArgs e)
        {
            Rectangle rect = new Rectangle(0, 0, Width, Height);
            e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(255, color[0], color[1], color[2])), rect);
            if (Settings.Default.ShowCircle)
            {
                e.Graphics.FillEllipse(new SolidBrush(Color.FromArgb(255, 255 - color[0], 255 - color[1], 255 - color[2])), rect);
            }
        }

        private void floatTimer_Tick(object sender, EventArgs e)
        {
            color[index] += direction;
            if (color[index] == 0 || color[index] == 255)
            {
                direction = -direction;
                index = (index + 1) % 3;
            }
            Refresh();
        }
    }
}
