using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ScreensaverSample.Properties;

namespace ScreensaverSample
{
    public partial class OptionsForm : Form
    {
        Sample sample;

        public OptionsForm(Sample sample)
        {
            InitializeComponent();
            this.sample = sample;
        }

        private void OptionsForm_Load(object sender, EventArgs e)
        {
            option.Checked = Settings.Default.ShowCircle;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            Save();
            Dispose();
        }
        
        private void cancelButton_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void previewButton_Click(object sender, EventArgs e)
        {
            Save();
            sample.DisplayScreenSaver();
        }

        private void Save()
        {
            Settings.Default.ShowCircle = option.Checked;
            Settings.Default.Save();
        }
    }
}