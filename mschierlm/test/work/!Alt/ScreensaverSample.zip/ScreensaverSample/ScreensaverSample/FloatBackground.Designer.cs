namespace ScreensaverSample
{
    partial class FloatBackground
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.floatTimer = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // floatTimer
            // 
            this.floatTimer.Enabled = true;
            this.floatTimer.Tick += new System.EventHandler(this.floatTimer_Tick);
            // 
            // FloatBackground
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.DoubleBuffered = true;
            this.Name = "FloatBackground";
            this.Size = new System.Drawing.Size(411, 305);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FloatBackground_Paint);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer floatTimer;
    }
}
