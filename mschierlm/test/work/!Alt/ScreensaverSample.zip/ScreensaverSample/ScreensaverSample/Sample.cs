using System;
using System.Collections.Generic;
using System.Text;
using ScreensaverLib;
using System.Windows.Forms;

namespace ScreensaverSample
{
    public class Sample : Screensaver
    {
        public Sample() : base(true) { }

        protected override Form CreateOptionsForm()
        {
            return new OptionsForm(this);
        }

        protected override Control CreateScreensaverControl()
        {
            return new FloatBackground();
        }

        [STAThread]
        static void Main(string[] args)
        {
            new Sample().Start(args);
        }
    }
}
