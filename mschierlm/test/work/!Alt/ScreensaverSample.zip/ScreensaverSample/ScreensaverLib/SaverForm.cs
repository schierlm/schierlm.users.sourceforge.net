using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ScreensaverLib
{
    public class SaverForm : Form
    {
        Screensaver saver;
        Point pt = new Point(-1, -1);

        public SaverForm(Screensaver saver, Control saverControl)
        {
            this.saver = saver;
            SuspendLayout();
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.Manual;
           // this.TopMost = true;
            this.MouseMove += SaverForm_MouseMove;
            this.KeyDown += SaverForm_KeyDown;
            saverControl.KeyDown += SaverForm_KeyDown;
            this.MouseDown += SaverForm_MouseDown;
            Controls.Add(saverControl);
            saverControl.Dock = DockStyle.Fill;
            ResumeLayout(false);
            Capture = true;
        }

        private void SaverForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (pt.X == -1 && pt.Y == -1) pt = e.Location;
            if (Math.Abs(pt.X - e.Location.X) + Math.Abs(pt.Y - e.Location.Y) > 10)
                saver.Quit();
        }

        private void SaverForm_MouseDown(object sender, MouseEventArgs e)
        {
            saver.Quit();
        }

        private void SaverForm_KeyDown(object sender, KeyEventArgs e)
        {
            saver.Quit();
        }
    }
}