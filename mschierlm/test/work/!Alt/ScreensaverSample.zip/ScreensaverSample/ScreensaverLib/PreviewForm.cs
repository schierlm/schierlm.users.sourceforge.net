using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ScreensaverLib
{
    public class PreviewForm : Form
    {
        public PreviewForm(IntPtr handle, Control ctrl)
        {
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            SuspendLayout();
            Controls.Add(ctrl);
            ctrl.Dock = DockStyle.Fill;
            ResumeLayout(false);
            int style = GetWindowLong(Handle, GWL_STYLE);
            style = style | WS_CHILD;
            SetWindowLong(Handle, GWL_STYLE, style);
            RECT rc;
            GetWindowRect(handle, out rc);
            Control c = ctrl;
            Left = 0;
            Top = 0;
            Width = rc.Width;
            Height = rc.Height;
            SetParent(this.Handle, handle); 
        }

        #region PInvoke Declarations

        const int WS_CHILD = 0x40000000;
        const int GWL_STYLE = (-16);

        [DllImport("user32.dll")]
        static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

        [DllImport("user32.dll", SetLastError = true)]
        static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;

            public RECT(int left_, int top_, int right_, int bottom_)
            {
                Left = left_;
                Top = top_;
                Right = right_;
                Bottom = bottom_;
            }

            public int Height { get { return Bottom - Top; } }
            public int Width { get { return Right - Left; } }
        }
        #endregion
    }
}