using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Drawing;

namespace ScreensaverLib
{
    public abstract class Screensaver
    {
        protected readonly bool oneInstancePerScreen;
        private bool optionsOpen = false;
        private List<SaverForm> openSavers = new List<SaverForm>();

        public Screensaver(bool oneInstancePerScreen)
        {
            this.oneInstancePerScreen = oneInstancePerScreen;
        }

        public void Start(string[] args)
        {
            if (args.Length > 0)
            {
                switch (args[0].ToLowerInvariant().Substring(0, 2))
                {
                    case "/c":
                        DisplayOptions();
                        break;
                    case "/p":
                        long handle;
                        if (args.Length == 2)
                        {
                            // like /p 1234
                            handle = long.Parse(args[1]);
                        }
                        else
                        {
                            // like /p:1234 or /p=1234
                            handle = long.Parse(args[0].Trim().Substring(3));
                        }
                        DisplayPreview(new IntPtr(handle));
                        break;
                    case "/s":
                        DisplayScreenSaver();
                        break;
                    default:
                        MessageBox.Show("Invalid command line argument: " + args[0], "Invalid Command Line Argument", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
            else
            {
                DisplayOptions();
            }
        }

        private void DisplayPreview(IntPtr handle)
        {
            Control c = CreatePreviewControl();
            Application.Run(new PreviewForm(handle, c));
        }

        public void DisplayScreenSaver()
        {
            Cursor.Hide();
            if (oneInstancePerScreen)
            {
                foreach (Screen s in Screen.AllScreens)
                {
                    SaverForm sf = new SaverForm(this, CreateScreensaverControl());
                    sf.Bounds = s.Bounds;
                    sf.Visible = true;
                    openSavers.Add(sf);
                }
            }
            else
            {
                int left = 0;
                int right = 0;
                int top = 0;
                int bottom = 0;
                foreach (Screen s in Screen.AllScreens)
                {
                    if (s.Bounds.Left < left) left = s.Bounds.Left;
                    if (s.Bounds.Right > right) right = s.Bounds.Right;
                    if (s.Bounds.Top < top) top = s.Bounds.Top;
                    if (s.Bounds.Bottom > bottom) bottom = s.Bounds.Bottom;
                }
                SaverForm sf = new SaverForm(this, CreateScreensaverControl());
                sf.Bounds = Rectangle.FromLTRB(left, right, top, bottom);
                sf.Visible = true;
                openSavers.Add(sf);
            }
            if (!optionsOpen) Application.Run();
        }

        internal void Quit()
        {
            foreach (SaverForm sf in openSavers)
            {
                sf.Dispose();
            }
            openSavers.Clear();
            if (optionsOpen) 
                Cursor.Show();
            else 
                Application.Exit();
        }


        protected void DisplayOptions()
        {
            Form o = CreateOptionsForm();
            if (o != null)
            {
                optionsOpen = true;
                Application.Run(o);
            }
            else
            {
                DialogResult dr = MessageBox.Show("This screensaver does not support setting options.\n\nDo you want to test it?", "Screensaver", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                if (dr == DialogResult.Yes)
                {
                    DisplayScreenSaver();
                }
            }
        }

        // methods to override

        protected abstract Control CreateScreensaverControl();

        protected virtual Control CreatePreviewControl()
        {
            return CreateScreensaverControl();
        }

        protected virtual Form CreateOptionsForm()
        {
            return null;
        }
    }
}
