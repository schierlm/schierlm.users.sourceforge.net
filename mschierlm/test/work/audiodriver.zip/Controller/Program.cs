using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Net;

namespace Controller
{
    class Program
    {
        static TcpClient client;

        static void Main(string[] args)
        {

            string toEncode = args[0] + ":" + args[1];
            Console.WriteLine(Convert.ToBase64String(Encoding.ASCII.GetBytes(toEncode)));
            TcpListener l;
            if (args.Length == 3)
            {
                IPAddress bind = IPAddress.Parse(args[2]);
                l = new TcpListener(bind, int.Parse(args[1]));
            }
            else
            {
                l = new TcpListener(int.Parse(args[1]));
            }
            l.Start();
            client = l.AcceptTcpClient();
            Console.WriteLine("Connected :)");
            new Thread(Run).Start();
            StreamReader sr = new StreamReader(client.GetStream());
            try
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
            catch { }
            Console.WriteLine("Disconnected :(");
            client.Close();
            l.Stop();
            Environment.Exit(0);
        }

        static void Run()
        {
            StreamWriter sw = new StreamWriter(client.GetStream());
            try
            {
                string line;
                while ((line = Console.ReadLine()) != null)
                {
                    sw.WriteLine(line);
                    sw.Flush();
                }
            }
            catch { }
            client.Close();
        }
    }
}
