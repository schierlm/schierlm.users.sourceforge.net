using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace EvilPlayR
{
    class Program
    {
        static MainForm mf;

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length == 0) Environment.Exit(22);
            Application.Run(new MainForm(args[0]));
        }
    }
}
