using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Text.RegularExpressions;
using System.Net;

namespace FoneNotify
{
    class LookupTcpListener
    {
        MainForm mf;
        TcpListener listener;

        public LookupTcpListener(MainForm mf)
        {
            this.mf = mf;
            listener = new TcpListener(IPAddress.Any, 30609);
            listener.Start();
            new Thread(DoListen).Start();
        }

        private void DoListen()
        {
            try {
                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    new Thread(HandleConnection).Start(client);
                }
            } catch {}
        }

        private void HandleConnection(object obj)
        {
            try
            {
                TcpClient client = (TcpClient)obj;
                StreamReader reader = new StreamReader(client.GetStream(), Encoding.Default);
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string source = "Network";
                    int pos = line.IndexOf(' ');
                    if (pos != 0)
                    {
                        source = line.Substring(pos + 1);
                        line = line.Substring(0, pos);
                    }
                    if (Regex.IsMatch(line, @"\+[0-9]*"))
                        mf.IncomingCall(source, line);
                }
            }
            catch { }
        }

        public void Close()
        {
            listener.Stop();
        }
    }
}
