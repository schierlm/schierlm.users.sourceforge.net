using System;
using System.Collections.Generic;
using System.Text;

namespace FoneNotify
{
    class HistoryEntry
    {
        private readonly DateTime when;
        private readonly string source, number;

        public HistoryEntry(DateTime when, string source, string number)
        {
            this.when = when;
            this.source = source;
            this.number = number;
        }

        public static HistoryEntry FromString(string s)
        {
            string[] elems = s.Split('\t');
            if (elems.Length != 3) throw new ArgumentException();
            return new HistoryEntry(new DateTime(long.Parse(elems[0])), elems[1], elems[2]);
        }

        public override string ToString()
        {
            return when.Ticks + "\t" + source + "\t" + number;
        }

        public DateTime When { get { return when; } }
        public string Source { get { return source; } }
        public string Number { get { return number; } }
    }
}
