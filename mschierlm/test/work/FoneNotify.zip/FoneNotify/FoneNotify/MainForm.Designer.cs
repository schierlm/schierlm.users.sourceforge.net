namespace FoneNotify
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.trayIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.trayStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.quickLookupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hotkey = new ManagedWinapi.Hotkey(this.components);
            this.shortcutBox = new ManagedWinapi.ShortcutBox();
            this.label1 = new System.Windows.Forms.Label();
            this.setHotkey = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.history = new System.Windows.Forms.ComboBox();
            this.lookupView = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.hideTimer = new System.Windows.Forms.Timer(this.components);
            this.trayStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // trayIcon
            // 
            this.trayIcon.ContextMenuStrip = this.trayStrip;
            this.trayIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("trayIcon.Icon")));
            this.trayIcon.Text = "FoneNotify�";
            this.trayIcon.Visible = true;
            this.trayIcon.BalloonTipClicked += new System.EventHandler(this.trayIcon_BalloonTipClicked);
            this.trayIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.trayIcon_MouseDoubleClick);
            // 
            // trayStrip
            // 
            this.trayStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripSeparator1,
            this.quickLookupToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.trayStrip.Name = "trayStrip";
            this.trayStrip.Size = new System.Drawing.Size(149, 82);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(145, 6);
            // 
            // quickLookupToolStripMenuItem
            // 
            this.quickLookupToolStripMenuItem.Name = "quickLookupToolStripMenuItem";
            this.quickLookupToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.quickLookupToolStripMenuItem.Text = "&Quick Lookup";
            this.quickLookupToolStripMenuItem.Click += new System.EventHandler(this.quickLookupToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(145, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // hotkey
            // 
            this.hotkey.Alt = false;
            this.hotkey.Ctrl = false;
            this.hotkey.Enabled = false;
            this.hotkey.KeyCode = System.Windows.Forms.Keys.None;
            this.hotkey.Shift = false;
            this.hotkey.WindowsKey = false;
            this.hotkey.HotkeyPressed += new System.EventHandler(this.hotkey_HotkeyPressed);
            // 
            // shortcutBox
            // 
            this.shortcutBox.Alt = false;
            this.shortcutBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.shortcutBox.Ctrl = false;
            this.shortcutBox.KeyCode = System.Windows.Forms.Keys.None;
            this.shortcutBox.Location = new System.Drawing.Point(147, 261);
            this.shortcutBox.Name = "shortcutBox";
            this.shortcutBox.Shift = false;
            this.shortcutBox.Size = new System.Drawing.Size(241, 20);
            this.shortcutBox.TabIndex = 3;
            this.shortcutBox.Text = "None";
            this.shortcutBox.WindowsKey = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 264);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "&Hotkey for Quick Lookup:";
            // 
            // setHotkey
            // 
            this.setHotkey.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.setHotkey.Location = new System.Drawing.Point(394, 259);
            this.setHotkey.Name = "setHotkey";
            this.setHotkey.Size = new System.Drawing.Size(39, 23);
            this.setHotkey.TabIndex = 5;
            this.setHotkey.Text = "&Set";
            this.setHotkey.UseVisualStyleBackColor = true;
            this.setHotkey.Click += new System.EventHandler(this.setHotkey_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "&Recent calls:";
            // 
            // history
            // 
            this.history.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.history.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.history.FormattingEnabled = true;
            this.history.Items.AddRange(new object[] {
            "(select)"});
            this.history.Location = new System.Drawing.Point(87, 12);
            this.history.Name = "history";
            this.history.Size = new System.Drawing.Size(346, 21);
            this.history.TabIndex = 1;
            this.history.SelectedIndexChanged += new System.EventHandler(this.history_SelectedIndexChanged);
            this.history.Format += new System.Windows.Forms.ListControlConvertEventHandler(this.history_Format);
            // 
            // lookupView
            // 
            this.lookupView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lookupView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lookupView.FullRowSelect = true;
            this.lookupView.Location = new System.Drawing.Point(12, 39);
            this.lookupView.MultiSelect = false;
            this.lookupView.Name = "lookupView";
            this.lookupView.Size = new System.Drawing.Size(421, 214);
            this.lookupView.TabIndex = 6;
            this.lookupView.UseCompatibleStateImageBehavior = false;
            this.lookupView.View = System.Windows.Forms.View.Details;
            this.lookupView.DoubleClick += new System.EventHandler(this.lookupView_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Number";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Name";
            this.columnHeader2.Width = 200;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Source";
            this.columnHeader3.Width = 100;
            // 
            // hideTimer
            // 
            this.hideTimer.Tick += new System.EventHandler(this.hideTimer_Tick);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(445, 293);
            this.Controls.Add(this.history);
            this.Controls.Add(this.lookupView);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.setHotkey);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shortcutBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "FoneNotify�";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.trayStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NotifyIcon trayIcon;
        private ManagedWinapi.Hotkey hotkey;
        private ManagedWinapi.ShortcutBox shortcutBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button setHotkey;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox history;
        private System.Windows.Forms.ListView lookupView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ContextMenuStrip trayStrip;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem quickLookupToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Timer hideTimer;
    }
}