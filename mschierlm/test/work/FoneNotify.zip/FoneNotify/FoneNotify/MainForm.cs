using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ManagedWinapi;
using FoneNotify.Properties;
using FoneNotify.Api;
using System.Diagnostics;
using System.IO;

namespace FoneNotify
{
    public partial class MainForm : Form
    {
        QuickLookup ql;
        LookupTcpListener tl;
        PluginLoader loader = new PluginLoader();

        public MainForm()
        {
            InitializeComponent();
            InitHotkey();
            try
            {
                StreamReader sr = new StreamReader(new FileStream(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FoneNotify.history"), FileMode.Open, FileAccess.Read));
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    history.Items.Add(HistoryEntry.FromString(line));
                }
                sr.Close();
            }
            catch (FileNotFoundException) { }
            history.SelectedIndex = 0;
            if (Settings.Default.MainWindowSet)
            {
                Location = Settings.Default.MainWindowLocation;
                Size = Settings.Default.MainWindowSize;
                Rectangle b = Screen.PrimaryScreen.Bounds;
                foreach (Screen s in Screen.AllScreens)
                {
                    b = Rectangle.Union(b, s.Bounds);
                }
                if (!b.IntersectsWith(new Rectangle(Location, Size)))
                {

                    b =  Rectangle.Inflate(Screen.PrimaryScreen.WorkingArea,-50, -50);
                    Location = b.Location;
                    Size = b.Size;
                }
            }
            else
            {
                StartPosition = FormStartPosition.CenterScreen;
            }
            if (Settings.Default.MainHidden)
            {
                hideTimer.Enabled = true;
            }
            lookupView.Columns[0].Width = Settings.Default.CWNumber;
            lookupView.Columns[1].Width = Settings.Default.CWName;
            lookupView.Columns[2].Width = Settings.Default.CWSource;
            tl = new LookupTcpListener(this);
        }

        private void setHotkey_Click(object sender, EventArgs e)
        {
            Settings.Default.HotkeyAlt = shortcutBox.Alt;
            Settings.Default.HotkeyCtrl = shortcutBox.Ctrl;
            Settings.Default.HotkeyShift = shortcutBox.Shift;
            Settings.Default.HotkeyWindowsKey = shortcutBox.WindowsKey;
            Settings.Default.HotkeyCode = shortcutBox.KeyCode;
            InitHotkey();
        }

        private void InitHotkey()
        {
            hotkey.Enabled = false;
            hotkey.Alt = shortcutBox.Alt = Settings.Default.HotkeyAlt;
            hotkey.Ctrl = shortcutBox.Ctrl = Settings.Default.HotkeyCtrl;
            hotkey.Shift = shortcutBox.Shift = Settings.Default.HotkeyShift;
            hotkey.WindowsKey = shortcutBox.WindowsKey = Settings.Default.HotkeyWindowsKey;
            hotkey.KeyCode = shortcutBox.KeyCode = Settings.Default.HotkeyCode;
            try
            {
                hotkey.Enabled = true;
            }
            catch (HotkeyAlreadyInUseException)
            {
                MessageBox.Show("Quick Lookup Hotkey is already in use. Please choose a different one", "FoneNotify", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void hotkey_HotkeyPressed(object sender, EventArgs e)
        {
            if (ql != null)
            {
                ql.Dispose();
                ql = null;
            }
            else
            {
                ql = new QuickLookup(this);
                ql.Show();
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        internal void CloseQuickLookup()
        {
            if (ql != null)
            {
                ql.Dispose();
                ql = null;
            }
        }

        private delegate void IncomingCallDelegate(string source, string number);

        internal void IncomingCall(string source, string number)
        {
            if (InvokeRequired)
            {
                Invoke(new IncomingCallDelegate(IncomingCall), source, number);
            }
            else
            {
                history.Items.Insert(0, new HistoryEntry(DateTime.Now, source, number));
                history.SelectedIndex = 0;
                if (source.EndsWith(" ")) return;
                StringBuilder sb = new StringBuilder();
                string link = null;
                foreach (LookupResult r in loader.Lookup(number, false))
                {
                    sb.Append(r.Number + ": " + r.Name + " [" + r.Source.ShortName + "]\n\n");
                    if (link == null) link = r.Hyperlink;
                }
                sb.Append(" ");
                trayIcon.Tag = link;
                trayIcon.ShowBalloonTip(10000, "Incoming Call: "+number + " [" + source + "]", sb.ToString(), ToolTipIcon.Info);
            }
        }

        internal void DoLookup(string number, ListView target, bool preview)
        {
            target.Items.Clear();
            IList<LookupResult> results = loader.Lookup(number, preview);
            foreach (LookupResult r in results)
            {
                ListViewItem lvi = new ListViewItem(r.Number);
                lvi.SubItems.Add(r.Name);
                lvi.SubItems.Add(r.Source.Name);
                if (r.Hyperlink != null)
                    lvi.Font = new Font(lvi.Font, FontStyle.Bold);
                lvi.Tag = r.Hyperlink;
                target.Items.Add(lvi);
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
            else
            {
                SaveSettings();
                tl.Close();
                Dispose();
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show();
        }

        private void quickLookupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ql == null)
            {
                ql = new QuickLookup(this);
            }
            ql.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveSettings();
            tl.Close();
            Dispose();
        }

        private void SaveSettings()
        {
            StreamWriter sw = new StreamWriter(new FileStream(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FoneNotify.history"), FileMode.Create, FileAccess.Write));
            foreach (object item in history.Items)
            {
                HistoryEntry he = item as HistoryEntry;
                if (he != null) {
                    sw.WriteLine(he.ToString());
                }
            }
            sw.Close();
            WindowState = FormWindowState.Normal;
            Settings.Default.MainWindowLocation = Location;
            Settings.Default.MainWindowSize = Size;
            Settings.Default.MainWindowSet = true;
            Settings.Default.MainHidden = !Visible;
            Settings.Default.CWNumber = lookupView.Columns[0].Width;
            Settings.Default.CWName = lookupView.Columns[1].Width;
            Settings.Default.CWSource = lookupView.Columns[2].Width;
            Settings.Default.Save();
        }

        private void trayIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
        }

        private void hideTimer_Tick(object sender, EventArgs e)
        {
            hideTimer.Enabled = false;
            Visible = false;
        }

        private void history_Format(object sender, ListControlConvertEventArgs e)
        {
            if (e.ListItem is HistoryEntry)
            {
                HistoryEntry he = (HistoryEntry)e.ListItem;
                e.Value = he.Number + " [" + he.When.ToString("yyyy-MM-dd HH:mm:ss") + ", " + he.Source + "]";
            }
            else
            {
                e.Value = e.ListItem.ToString();
            }
        }

        private void history_SelectedIndexChanged(object sender, EventArgs e)
        {
            HistoryEntry he = history.SelectedItem as HistoryEntry;
            if (he == null)
            {
                DoLookup("+", lookupView, false);
            }
            else
            {
                DoLookup(he.Number, lookupView, false);
            }
        }

        private void lookupView_DoubleClick(object sender, EventArgs e)
        {
            if (lookupView.SelectedItems.Count == 0) return;
            string url = lookupView.SelectedItems[0].Tag as string;
            if (url != null)
            {
                Process.Start(url);
            }
        }

        private void trayIcon_BalloonTipClicked(object sender, EventArgs e)
        {
            if (trayIcon.Tag != null)
            {
                Process.Start((string)trayIcon.Tag);
            }
        }
    }
}