using System;
using System.Collections.Generic;
using System.Text;
using FoneNotify.Api;
using System.IO;
using System.Windows.Forms;
using System.Reflection;

namespace FoneNotify
{
    class PluginLoader
    {
        private List<LookupPlugin> plugins = new List<LookupPlugin>();

        public PluginLoader()
        {
            foreach (string dll in Directory.GetFiles(Application.StartupPath, "*.dll"))
            {
                Assembly a = Assembly.LoadFile(dll);
                Type manifest = a.GetType("_PluginManifest");
                if (manifest != null && typeof(PluginManifest).IsAssignableFrom(manifest))
                {
                    PluginManifest m = (PluginManifest)manifest.GetConstructor(new Type[0]).Invoke(new Object[0]);
                    plugins.AddRange(m.Plugins);
                }
            }
        }

        internal Dictionary<string, IList<LookupResult>> cache = new Dictionary<string, IList<LookupResult>>();

        internal IList<LookupResult> Lookup(string number, bool preview)
        {
            if (preview) {
                return NewLookup(number, preview);
            }
            if (!cache.ContainsKey(number))
            {
                if (cache.Count > 20) cache.Clear();
                cache[number] = NewLookup(number, preview);
            }
            return cache[number];
        }

        private IList<LookupResult> NewLookup(string number, bool preview) 
        {
            List<LookupResult> results = new List<LookupResult>();
            foreach (LookupPlugin plugin in plugins)
            {
                LookupResult r = plugin.Lookup(number, preview);
                if (r != null)
                    results.Add(r);
            }
            results.Sort(delegate(LookupResult a, LookupResult b)
            {
                if (a.NumberLength != b.NumberLength) return b.NumberLength - a.NumberLength;
                return b.Source.Priority - a.Source.Priority;
            });
            return results;
        }
    }
}
