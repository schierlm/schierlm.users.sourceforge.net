using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FoneNotify.Properties;
using System.Text.RegularExpressions;

namespace FoneNotify
{
    public partial class QuickLookup : Form
    {
        MainForm mf;

        public QuickLookup(MainForm mf)
        {
            this.mf = mf;
            InitializeComponent();
            if (Settings.Default.QuickLookupSet)
            {
                Location = Settings.Default.QuickLookupLocation;
                Size = Settings.Default.QuickLookupSize;
            }
            else
            {
                StartPosition = FormStartPosition.CenterScreen;
            }
            lookup.Text = "+";
            lookup.Select(1, 0);
        }

        private void QuickLookup_LocationOrSizeChanged(object sender, EventArgs e)
        {
            Settings.Default.QuickLookupSize = Size;
            Settings.Default.QuickLookupLocation = Location;
            Settings.Default.QuickLookupSet = true;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            mf.CloseQuickLookup();
        }

        private void add_Click(object sender, EventArgs e)
        {
            mf.IncomingCall("QuickLookup", lookup.Text);
            mf.CloseQuickLookup();
        }

        private void lookup_TextChanged(object sender, EventArgs e)
        {
            add.Enabled = Regex.IsMatch(lookup.Text, @"\+[0-9]*");
            mf.DoLookup(add.Enabled ? lookup.Text : "", previewView, true);
        }
    }
}