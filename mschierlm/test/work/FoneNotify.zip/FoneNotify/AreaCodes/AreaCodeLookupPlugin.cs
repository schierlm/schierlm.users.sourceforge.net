using System;
using System.Collections.Generic;
using System.Text;
using FoneNotify.Api;
using System.IO.Compression;
using System.IO;

namespace FoneNotify.AreaCodes
{
    public class AreaCodeLookupPlugin : LookupPlugin
    {
        public string Name { get { return "Area Code"; } }
        public string ShortName { get { return "Area"; } }
        public int Priority { get { return 2; } }

        public LookupResult Lookup(string number, bool preview)
        {
            if (number.Length < 2) return null;
            char firstDigit = number[1];
            if (firstDigit < '1' || firstDigit > '9') return null;
            string res = "FoneNotify.AreaCodes.area" + firstDigit + ".txt.gz";
            StreamReader sr = new StreamReader(new GZipStream(typeof(AreaCodeLookupPlugin).Assembly.GetManifestResourceStream(res), CompressionMode.Decompress));
            string line;
            while ((line=sr.ReadLine()) != null)
            {
                string[] parts = line.Split('\t');
                if (number.StartsWith(parts[0].Replace(" ", ""))) {
                    return new LookupResult(this, parts[0], parts[1]);
                }
            }
            return null;
        }
    }
}
