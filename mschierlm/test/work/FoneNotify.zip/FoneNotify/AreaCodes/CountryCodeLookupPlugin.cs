using System;
using System.Collections.Generic;
using System.Text;
using FoneNotify.Api;
using System.IO;

namespace FoneNotify.AreaCodes
{
    class CountryCodeLookupPlugin : LookupPlugin
    {
        List<LookupResult> countries = new List<LookupResult>();

        public CountryCodeLookupPlugin()
        {
            StreamReader sr = new StreamReader(typeof(CountryCodeLookupPlugin).Assembly.GetManifestResourceStream("FoneNotify.AreaCodes.country.txt"));
            string line;
            while ((line = sr.ReadLine()) != null)
            {
                string[] fields = line.Split('\t');
                string hyperlink = null;
                countries.Add(new LookupResult(this, fields[0], fields[1] + " (NP: " + fields[2] + ", IP: " + fields[3] + ")", fields.Length > 4 && fields[4] != "" ? fields[4] : null));
            }
            sr.Close();
        }

        public string Name { get { return "Country Code"; } }
        public string ShortName { get { return "Cntry"; } }
        public int Priority { get { return 1; } }

        public LookupResult Lookup(string number, bool preview)
        {
            foreach (LookupResult cc in countries)
            {
                if (number.StartsWith(cc.Number))
                {
                    if (cc.Hyperlink == null) return cc;
                    string hlink = cc.Hyperlink.Replace("%%", number.Substring(cc.Number.Length));
                    return new LookupResult(cc.Source, cc.Number, cc.Name, hlink);
                }
            }
            return null;
        }
    }
}
