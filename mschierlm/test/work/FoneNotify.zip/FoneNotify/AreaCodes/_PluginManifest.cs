using System;
using System.Collections.Generic;
using System.Text;
using FoneNotify.Api;
using FoneNotify.AreaCodes;

public class _PluginManifest : PluginManifest
{
    public IList<LookupPlugin> Plugins
    {
        get
        {
            return new LookupPlugin[] {
                new CountryCodeLookupPlugin(),
                new AreaCodeLookupPlugin(),
            };
        }
    }
}
