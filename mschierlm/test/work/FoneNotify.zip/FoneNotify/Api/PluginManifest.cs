using System;
using System.Collections.Generic;
using System.Text;

namespace FoneNotify.Api
{
    public interface PluginManifest
    {
        IList<LookupPlugin> Plugins { get;}
    }
}
