using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace FoneNotify.Api
{
    public sealed class LookupResult
    {
        readonly string number, name, hyperlink;
        readonly LookupPlugin source;

        public LookupResult(LookupPlugin source, string number, string name)
            : this(source, number, name, null) { }

        public LookupResult(LookupPlugin source, string number, string name, string hyperlink)
        {
            if (number == null || name == null || source == null) throw new ArgumentException();
            this.number = number;
            this.name = name;
            this.source = source;
            this.hyperlink = hyperlink;
        }

        public LookupPlugin Source { get { return source; } }
        public string Number { get { return number; } }
        public string Name { get { return name; } }
        public string Hyperlink { get { return hyperlink; } }

        public int NumberLength
        {
            get
            {
                return new Regex("[^0-9]").Replace(number, "").Length;
            }
        }
    }
}
