using System;
using System.Collections.Generic;
using System.Text;

namespace FoneNotify.Api
{
    public interface LookupPlugin
    {
        int Priority { get;}
        string Name { get;}
        string ShortName { get;}
        LookupResult Lookup(string number, bool preview);
    }
}
