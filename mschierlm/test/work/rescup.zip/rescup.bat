:: LiVista RescUp (c) 2008 Michael Schierl
:: Licensed under GPL v2 or later
:: 
@echo off
cd /d %~dp0
if not exist %SYSTEMROOT%\system32\winpeshl.exe goto no
if not exist x:\sources\??-?? goto no
goto go
:no
echo LiVista RescUp works only from the Vista Setup.
pause >nul
goto end
:go
for /d %%i in (x:\sources\??-??) do set LNG=%%~ni
echo Extracting files ...
mkdir x:\rescup
copy rescup.dat x:\rescup\rescup_.exe >nul
cd /d x:\rescup
rescup_.exe >nul
del rescup_.exe
rescup2.bat
:end