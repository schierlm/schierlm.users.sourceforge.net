if (!(Test-Path Variable:__PscxContributionsProfileRanOnce)) { 

new-Alias which get-command
new-alias st scroll-table
set-alias less scroll-text
invoke-expression ("function "+[char]4+" {exit}")
add-pssnapin PscxContributionsSnapIn
Set-Variable __PscxContributionsProfileRanOnce
}

function whereis($cmd) {
  if (test-path Alias:$cmd) {
    whereis (get-childitem Alias:$cmd).Definition
  } else {
    get-alias | ? {$_.Definition -eq $cmd}
  }
}