<?php
#
# IP in title bar Netvibes module
#
# (c) 2006 Michael Schierl
# This script is FREE SOFTWARE according to the GNU GENERAL PUBLIC LICENCE version 2.
#

error_reporting(E_ALL);

ini_set("session.use_cookies", 0);

if(isset($_GET['IFRAME'])) {
	session_id($_GET['IFRAME']);
	session_start();
	echo "Loading...";
	$_SESSION['adr'] = $_SERVER['REMOTE_ADDR'];
	$_SESSION['nm'] = @gethostbyaddr($_SERVER['REMOTE_ADDR']);
} else if (isset($_GET['AJAX'])) {
	session_id($_GET['AJAX']);
	session_start();
	header("Content-type: application/xml");
	echo '<?xml version="1.0" encoding="iso-8859-1"?>';
	echo '<ip><numeric>';
	echo $_SESSION['adr'];
	echo '</numeric><name>'.$_SESSION['nm'].'</name></ip>';
} else {	
session_start();
$_SESSION['adr'] = 'Error';
$_SESSION['nm'] = 'Error';
$MYDIR="http://" . $_SERVER["HTTP_HOST"] . preg_replace("~/[^/]*$~", "/", $_SERVER['REQUEST_URI']);
$MYPATH=$MYDIR."ip.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Determining IP...</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="icon" type="image/png" href="<?php echo $MYDIR;?>/ip.gif" />

  <link rel="stylesheet" type="text/css" href="http://www.netvibes.com/api/0.3/style.css" />
  <script type="text/javascript" src="http://www.netvibes.com/api/0.3/emulation.js"></script>
  <script type="text/javascript">
	<![CDATA[
  WannaKnowMyIPNow = function()
  {
      var url = '<?php echo $MYPATH;?>?AJAX=<?php echo session_id();?>';
      function AjaxShow(xhr)
      {
        var dom = xhr.responseXML.documentElement;
        var ip = dom.firstChild.firstChild.nodeValue;
	var name = dom.firstChild.nextSibling.firstChild.nodeValue;
        NV_TITLE.innerHTML = ip+' ['+name+']'; 
     	NV_CONTENT.innerHTML = 'IP: <b>'+ip+'</b><br />Hostname: <b>'+name+
		'</b><br /><form action="http://www.iks-jena.de/cgi-bin/whois/" method="GET">'+
		'<input type="text" name="search" value="'+ip+
		'" /><input style="display:inline" type="submit" name="submit" value="Whois" /> [ v1.0 | <a href="<?php echo $MYDIR;?>netvibes.html">by mihi</a> ]</form>'; 
      }

      function AjaxFailure(xhr)
      {
        alert('Error : ' + xhr.status + ' - ' + xhr.responseText);
      }


      if(!NV_AJAX_REQUEST_URL) {
        var NV_AJAX_REQUEST_URL = '/ajaxProxy.php';
      }
      var requestParams = { method: 'get', onSuccess: AjaxShow, onFailure: AjaxFailure };

      var request = new Ajax.Request(NV_AJAX_REQUEST_URL + '?url=' + escape(url), requestParams);
  }
  // ]]>
  </script>
</head>
<body>
 <p>Determining IP...</p>
 <iframe src="<?php echo $MYPATH;?>?IFRAME=<?php echo session_id(); ?>" onload="WannaKnowMyIPNow();" width="30" height="30" style="display:none"></iframe>
</body>
</html>
<?php } ?> 