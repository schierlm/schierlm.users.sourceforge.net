<?php
#
# Get Server Time via AJAX
#
# (c) 2006 Michael Schierl
# This script is FREE SOFTWARE according to the GNU GENERAL PUBLIC LICENCE version 2.
#
header('Content-type: application/xml');
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
/*
header('Last-modified: '.gmdate('D, d M Y H:i:s').' GMT');
header('Cache-Control: no-store');
*/
echo '<?xml version="1.0" encoding="iso-8859-1"?>';
echo '<time>';
echo time();
echo '000</time>';