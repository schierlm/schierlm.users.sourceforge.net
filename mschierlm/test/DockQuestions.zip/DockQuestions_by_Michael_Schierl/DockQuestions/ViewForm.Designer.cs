namespace DockQuestions
{
    partial class ViewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.forceFloating = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // checkBox1
            // 
            this.forceFloating.AutoSize = true;
            this.forceFloating.Location = new System.Drawing.Point(12, 12);
            this.forceFloating.Name = "checkBox1";
            this.forceFloating.Size = new System.Drawing.Size(93, 17);
            this.forceFloating.TabIndex = 0;
            this.forceFloating.Text = "Force Floating";
            this.forceFloating.UseVisualStyleBackColor = true;
            this.forceFloating.CheckedChanged += new System.EventHandler(this.forceFloating_CheckedChanged);
            // 
            // ViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(219, 58);
            this.Controls.Add(this.forceFloating);
            this.Name = "ViewForm";
            this.TabText = "ViewForm";
            this.Text = "ViewForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox forceFloating;
    }
}