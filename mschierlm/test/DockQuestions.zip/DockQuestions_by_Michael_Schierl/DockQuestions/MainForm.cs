using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DockQuestions
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            new DocumentForm().Show(dockPanel, DockState.Document);
            new ViewForm("Right Pane").Show(dockPanel, DockState.DockRight);
            new ViewForm("Bottom Pane").Show(dockPanel, DockState.DockBottom);
        }

        private void menuToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
        {
            titleToolStripMenuItem.Text = "Title: " + ((DockContent)dockPanel.ActiveContent).Text;
        }
    }
}