using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DockQuestions
{
    public partial class ViewForm : DockContent
    {
        public ViewForm()
        {
            InitializeComponent();
        }

        public ViewForm(string title)
            : this()
        {
            Text = title;
            TabText = title;
            DockAreas = DockAreas.DockBottom | DockAreas.DockLeft | DockAreas.DockRight | DockAreas.DockTop | DockAreas.Float;
        }

        private void forceFloating_CheckedChanged(object sender, EventArgs e)
        {
            if (forceFloating.Checked)
            {
                DockState = DockState.Float;
                DockAreas = DockAreas.Float;
            }
            else
            {
                DockAreas = DockAreas.DockBottom | DockAreas.DockLeft | DockAreas.DockRight | DockAreas.DockTop | DockAreas.Float;
            }
        }
    }
}