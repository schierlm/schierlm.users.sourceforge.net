JHEditor V0.7
=============

This program is written in java and therefore needs an installed Java
Runtime Environment 1.3 or higher. You can get it at
http://java.sun.com/

If you have it installed, double click onto the JHEditor.jar File or
enter

java -jar JHEditor.jar

(case sensitive) at the command prompt.


Description:
------------

JHEditor is a hex editor written in Java. So it is platform
independent and works on all modern operating systemes.

It was especially designed to work with large files (up to 8 million
terabytes, if your OS supports that.) Usual hex editors load the whole
file into memory (or into a temporary file) - that can take a
while. JHEditor only reads that parts from the file that are needed at
the moment. If you change the file, only the bytes you've changed are
held in memory. So if you work on large files and make small changes
this doesn't need much memory.

As of version 0.6, it is possible to insert or delete bytes directly
and to save a file with a different name. There are also a "Paste
(insert)" and a "Cut" command now. All the other functions should
still work like in the previous version. Split Parts are still
available for those who like them.

Antivirus Programs:
-------------------

Of course, JHEditor does not contain any viruses. The problem with
JHEditor and antivirus programs is more subtle. Since you downloaded
JHEditor you might want to use it on really large files (tens or
hundreds of gigabytes, or even terabytes). Most modern antivirus
programs include an "antivirus guard" that scans each file on
access. Depending on the file type you are editing, your antivirus
program may spend linear time (i. e. double time for double file size
etc.) for scanning the file, *BEFORE* JHEditor is allowed to access
the *FIRST* byte of it! Since JHEditor needs only constant time
(independent of file size) to open a file, it might be wise to disable
your antivirus program before opening large files, since it will save
you a lot of time.



Keys in JHEditor:
-----------------

* Pressing these keys with Shift enlarges/shrinks the selection


F6, Return      switch between Hex and Ascii pane
Shift+Return    go to other end of selection
Backspace *     undo current byte position and go one byte left
Cursor keys *   Move into given direction
Page up/down *  Move one screen up/down
Home/End *      Move to beginning/end of file
F3              Find next
F9              Toggle "wide offset" view
Insert          insert one byte (or as many bytes as the selection 
                is long) after the cursor.
Delete          Delete one byte after the cursor or the selection.


And all keys given in the menu.

Windows only - how to add JHEditor to context menu:
---------------------------------------------------

Create the key �HKEY_CLASSES_ROOT\*\shell\JHEdit� and set its 
default value to �Open with &JHEditor"
now create the subkey �HKEY_CLASSES_ROOT\*\shell\JHEdit\command�
and set its default value to 
�javaw.exe -jar C:\path\to\JHEdit\JHEditor.jar -- "%1"�.

Enjoy!

Changelog
---------

+++ 2010-03-21: Version 0.7.1 +++

- Made file compare code more modular (no user visible changes)
- Fixed a deadlock occurring in progress window display on Java 6

+++ 2006-10-21: Version 0.7 +++

- File Compare
  * Progress Dialog
  * Offsets are in hex instead of decimal
  * Speeded up file compare dramatically
  * Show an error when comparing a file with itself
- Show Progress Dialog when searching
- Dialog windows can be closed by pressing the ESC key
- More efficient storage of large file changes
- New command: Select all
- Clipboard handling
  * Added an application clipboard and a command to switch between
    system and application clipboard
  * Improved performance of copy&paste
  * Fixed a problem copying 0-bytes in Windows

+++ 2004-09-30: Version 0.65 +++

- Complete rewrite of the file change storage system
- Added more options for the "Compare Files" function
- Bugfixes:
  * Joining split parts led to repetitions in output file
  * Compare could not resync if change was larger than 1KB
  * Selection was altered when scrolling with mouse

+++ 2003-09-10: Version 0.6 +++

- bugfixes
- insert/delete support
  * Cut
  * Paste inserted
  * Create New file
  * Save as
- removed "Open Dummy" command
- Compare Files...
- Drag&Drop support (open files by dropping them)
- Asks whether to save changes when quitting
- Switch to read only mode for read only files

+++ 2003-02-08: Version 0.51 +++

- fixed some minor bugs
- German readme
- better (smoother) window refresh
- added support to give filename at command line

+++ 2002-10-01: Version 0.5 +++

- first release

Contact me
----------

http://smsoft.ixy.de/
sm-soft@gmx.de
