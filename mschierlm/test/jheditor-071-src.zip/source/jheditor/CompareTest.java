package jheditor;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jheditor.compare.HexComparer;
import jheditor.file.*;

public class CompareTest {
    
    public static void main(String[] args) {
	HexFileListener hfl = new HexFileListener() {
		
		public void showError(String message, String title) {
		    System.out.println(message+":"+title);
		}
		
		public void refreshFileList() {				
		}
			
	    };
	HexFile hf1 = new HexFile(hfl);
	HexFile hf2 = new HexFile(hfl);
	hf2.open(new File("C:\\Eigenes\\jfs\\jfilesync.jar"),true);
	hf1.open(new File("C:\\Eigenes\\jhe\\jheditor.jar"),true);
	HexComparer fc = new HexComparer(hf1, hf2);
	ProgressMonitor pmon = new ProgressMonitor() {

		public boolean isCanceled() {
		    return false;
		}

		public void setProgress(long progress, long max) {
		    System.out.println(progress+"/"+max);
		}
			
	    };
	long now = System.currentTimeMillis();
	List lst = new ArrayList();
	fc.compare(16,1024, pmon, lst);
	System.out.println(System.currentTimeMillis()-now);
	for (Iterator it = lst.iterator(); it.hasNext();) {
	    String s = (String) it.next();
	    System.out.println(s);
	}
    }
}
