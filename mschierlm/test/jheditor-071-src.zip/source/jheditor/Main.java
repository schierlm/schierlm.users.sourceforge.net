// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004, 2005, 2006 Michael Schierl

package jheditor;
import jheditor.gui.*;

public class Main {

    public static final String VERSION="0.7.1";

    public static void main(String[] args) {
	boolean roflag=false;
	if (args.length!=0) {
	    for(int i=0;i<args.length;i++) {
		if ("-ro".equals(args[i])) {
		    roflag=true;
		} else if ("-rw".equals (args[i])) {
		    roflag=false;
		} else if ("-help".equals(args[i])) {
		    printHelp();
		} else if ("--".equals (args[i])) {
		    StringBuffer coll=new StringBuffer();
		    for (int j=i+1;j<args.length;j++) {
			coll.append(args[j]);
			if (j!=args.length-1) coll.append(" ");
		    }
		    new HexEditor(coll.toString(),roflag);
		    break;
		} else if (args[i].startsWith("-") ||
			   args[i].startsWith("/")) {
		    System.out.println("Unknown command switch.\n");
		    printHelp();
		} else {
		    new HexEditor(args[i], roflag);
		}
	    }
	} else {
	    new HexEditor();
	}
    }

    public static void printHelp() {
	System.out.println("JHEditor "+VERSION);
	System.out.println("\nUsage:\n\n"+
			   "java -jar JHEditor [options] filenames\n"+
			   "\n"+
			   "-ro   open following files read-only\n"+
			   "-rw   open following files read-write\n"+
			   "-help show this help screen\n"+
			   "--    all following parameters are one filename"+
			   "\n\n");
    }
}
