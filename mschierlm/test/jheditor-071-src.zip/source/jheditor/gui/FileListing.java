// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.gui;
import java.util.*;
public class FileListing {
    public static List editors=new ArrayList();

    public static synchronized void registerEditor(HexEditor file) {
	if (!editors.contains(file)) {
	    editors.add(file);
	    refresh();
	}
    }
    public static synchronized void unregisterEditor(HexEditor file) {
	if (editors.contains(file)) {
	    editors.remove(file);
	    refresh();
	}
    }

    public static void refresh() {
	JoinerWindow.refreshJoinerWindow();
    }
    public static synchronized List getEditors() {
	return editors;
    }
}
