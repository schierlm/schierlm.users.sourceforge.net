// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.gui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.datatransfer.*;

public class ConvertWindow extends Frame implements ActionListener,
						    TextListener,
						    ItemListener {

    private Choice typ1,typ2,subtyp1,subtyp2;
    private TextField input, result,output;

    public ConvertWindow(Frame parent) {
	this();
    }
    public ConvertWindow() {
	super("Converter");
	Panel p,p2,p3;
	Button b;
	setBackground(Color.lightGray);
	setIconImage(HexEditor.icon);
	add("North", p2=new Panel(new BorderLayout()));
	p2.add("North", p=new Panel(new BorderLayout()));
	p.add("West", typ1=getTypeChoice());
	p.add("Center",p3=new Panel(new BorderLayout()));
	p3.add("West",subtyp1=getSubTypeChoice());
	p3.add("Center",input = new TextField(40));
	input.addTextListener(this);
	typ1.addItemListener(this);
	subtyp1.addItemListener(this);
	p2.add("Center",p = new Panel(new BorderLayout()));
	p.add("Center",result = new TextField(60));
	p.add("East", b = new Button("^^ Up ^^"));
	b.addActionListener(this);
	p2.add("South", p=new Panel(new BorderLayout()));
	p.add("West", typ2=getTypeChoice());
	p.add("Center",p3=new Panel(new BorderLayout()));
	p3.add("West",subtyp2=getSubTypeChoice());
	p3.add("Center",output = new TextField(40));
	typ2.addItemListener(this);
	subtyp2.addItemListener(this);
	result.setEditable(false);
	output.setEditable(false);
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
	    });
	pack();
	show();
    }

    public void actionPerformed(ActionEvent e) {
	String cmd=e.getActionCommand();
	if ("^^ Up ^^".equals(cmd)) {
	    input.setText(output.getText());
	}
    }

    public void itemStateChanged(ItemEvent e) {	
	refreshView();
    }

    public void textValueChanged(TextEvent e) {
	refreshView();
    }

    private void refreshView() {
	result.setText(bytes2hex(type2bytes
				 (input.getText(),
				  typ1.getSelectedIndex(),
				  subtyp1.getSelectedIndex())));
	output.setText(bytes2type(hex2bytes(result.getText()),
				  typ2.getSelectedIndex(),
				  subtyp2.getSelectedIndex()));
    }
    public static String bytes2hex(byte[] b) {
	StringBuffer sb=new StringBuffer();
	for(int i=0;i<b.length;i++) {
	    int by=b[i] &0xff;
	    sb.append((by<16?"0":""))
		.append(Integer.toHexString(by))
		.append(" ");
	}
	return sb.toString().toUpperCase();
    }

    private static byte[] hex2bytes(String s) {
	byte[] b=new byte[s.length()/3];
	for(int i=0;i<b.length;i++) {
	    b[i]=(byte) Integer.parseInt(s.substring(i*3,i*3+2),16);
	}
	return b;
    }

    public static byte[] type2bytes(String text, int typ, int subtyp) {
	byte[] array=new byte[0];
	boolean signed=(subtyp % 2) == 1, bigendian=(subtyp/2)==1;
	switch(typ) {
	case 0: // ASCII
	    array=new byte[text.length()];
	    for(int i=0;i<text.length();i++) {
		byte[] bb=text.substring(i,i+1).getBytes();
		if (bb.length==1)
		    array[i]=bb[0];
		else
		    array[i]=0;
	    }
	    break;
	case 1: // Unicode
	    array= new byte[text.length()*2];
	    for (int i=0;i<text.length();i++) {
		int cc=text.charAt(i);
		array[i*2]=(byte)(cc %256);
		array[i*2+1]=(byte)(cc / 256);
	    }
	    break;
	case 2: //UTF-8
	    try {
		array=text.getBytes("UTF-8");
	    } catch (UnsupportedEncodingException e) {
		array=new byte[0];
	    }
	    break;
	case 3: // Hex 
	    array=new byte[text.length()/2+1];
	    int offs=0;
	    for (int i=0;i<text.length();i+=2) {
		while (i<text.length() && text.charAt(i)==' ') i++;
		if (i+1>text.length()) break;
		if (i+1<text.length() && text.substring(i,i+2).equals("0x"))
		    i+=2;
		if (i+1>text.length()) break;
		if (text.charAt(i)==' ') {
		    array[offs++]=0;
		    i--;
		} else if (i+1==text.length() || text.charAt(i+1)==' ') {
		    try {
			array[offs++] = (byte) Integer.parseInt
			    (text.substring(i,i+1),16);
		    } catch (NumberFormatException e) {
			array[offs-1]=0;
		    }
		    i--;
		} else {
		    try {
			array[offs++] = (byte) Integer.parseInt
			    (text.substring(i,i+2),16);
		    } catch (NumberFormatException e) {
			array[offs-1]=0;
		    }
		}
	    }
	    
	    byte[] array2=new byte[offs];
	    System.arraycopy (array,0,array2,0,offs);
	    array=new byte[offs];
	    System.arraycopy(array2,0,array,0,offs);
	    break;
	case 6: // byte
	    try {
		int i=Integer.parseInt(text);
		if ((!signed && i>=0 && i < 256)  ||
		    (signed && i>=-128 && i < 128)) {
		    array=new byte[]{(byte)i};
		} else {
		    array=new byte[0];
		}
	    } catch (NumberFormatException e) {
		array=new byte[0];
	    }
	    break;
	case 7: //short
	    array=makenumconvert(text,2,signed,bigendian);
	    break;
	case 8: // int
	    array=makenumconvert(text, 4, signed, bigendian);
	    break;
	case 9: // long
	    array=makenumconvert(text, 8, signed, bigendian);
	    break;
	case 4: //bits
	    int bcount=0, bcoll=0, ccount=0;;
	    byte[] collect=new byte[100];
	    for(int i=0;i<text.length();i++) {
		switch (text.charAt(i)) {
		case '0':
		    bcoll*=2;
		    bcount++;
		    break;
		case '1':
		    bcoll*=2;
		    bcoll++;
		    bcount++;
		    break;
		default:
		}
		if (bcount==8) {
		    collect[ccount++]=(byte) bcoll;
		    bcount=bcoll=0;
		}
	    }
	    if (bcount != 0) {
		// System.out.println(bcount);
		array=new byte[0];
	    } else {
		array=new byte[ccount];
		if (!bigendian) {
		    for (int i=0;i<ccount;i++) {
			array[i]=collect[ccount-i-1];
		    }
		} else {
		    System.arraycopy(collect,0,array,0,ccount);
		}
	    }
	    break;
	case 5: // clipboard
	    	String s=null;
	try {
	    s=(String) Toolkit.getDefaultToolkit().
		getSystemClipboard().getContents(null).
		getTransferData(DataFlavor.stringFlavor);
	} catch (UnsupportedFlavorException ex) {
	    s=null;
	} catch (IOException ex) {
	    s=null;
	}
	if (s==null) {
	    return new byte[0];
	} else {
	    try {
		return s.getBytes("ISO-8859-1");
	    } catch (UnsupportedEncodingException e) {
		return s.getBytes();
	    }
	}
	case 10: //float
	    try {
		float f = Float.parseFloat(text);
		array = makenumconvert(Float.floatToIntBits(f),4,true,bigendian);
	    } catch (NumberFormatException e) {
		return new byte[0];
	    }
	    break;
	case 11: //double
	    try {
		double d = Double.parseDouble(text);
		array=makenumconvert(Double.doubleToLongBits(d),8,true,bigendian);
	    } catch (NumberFormatException e) {
		return new byte[0];
	    }
	    break; 
	default:
	    array=new byte[0];
	}
	return array;
    }

    public static String bytes2type(byte[] b, int typ, int subtyp) {
	boolean signed=(subtyp % 2) == 1, bigendian=(subtyp/2)==1;
	StringBuffer sb=new StringBuffer();
//	System.out.println(typ);
	switch(typ) {
	case 0: // ASCII:
	    for(int i=0;i<b.length;i++) {
		String s=new String(new byte[]{b[i]});
		if (s.length()==1 && s.charAt(0)!=0)
		    sb.append(s);
		else
		    sb.append("?");
	    }
	    return sb.toString();
	case 1: //UNICODE:
	    for (int i=0;i<b.length;i+=2) {
		if (b.length==i+1) break;
		int ci=(b[i]&0xff)+(b[i+1]&0xff)*256;
		sb.append((char)ci);
	    }
	    // System.out.println(sb.toString());
	    return sb.toString();
	case 2: //UTF-8
	    try {
		return new String(b,"UTF-8");
	    } catch (UnsupportedEncodingException e) {
		return "";
	    }
	case 3: //hex
	    for (int i=0;i<b.length;i++) {
		sb.append(i==0?"":" ").append((b[i] & 0xff) < 16?"0":"")
		    .append(Integer.toHexString(b[i] & 0xff).toUpperCase());
	    }
	    return sb.toString();
	case 6: //byte
	    return makenumunconvert(b,1,signed,bigendian);
	case 7: // short
	    return makenumunconvert(b,2,signed,bigendian);
	case 8: // int
	    return makenumunconvert(b,4,signed,bigendian);
	case 9: // long
	    return makenumunconvert(b,8,signed,bigendian);
	case 4: //bits
	    for (int i=0;i<b.length;i++) {
		for (int j=7;j>=0;j--) {
		    if((b[bigendian?i:(b.length-i-1)] & (1<<j))!=0) {
			sb.append('1');
		    } else {
			sb.append('0');
		    }
		}
		sb.append(' ');
	    }
	    return sb.toString();
	case 5: //clipboard
	    String s;
	    try {
		s=new String(b,"ISO-8859-1");
	    } catch (UnsupportedEncodingException e) {
		s=new String(b);
		e.printStackTrace();
	    }
	    StringSelection ss=new StringSelection(s);
	    Toolkit.getDefaultToolkit().getSystemClipboard()
		.setContents(ss,ss);
	    return "Saved into clipboard";
	case 10: //float
	    try {
	    int v = (int)makenumunconvertL(b,4,true,bigendian);
	    return ""+Float.intBitsToFloat(v);
	    } catch (IllegalArgumentException e) {
		return "";
	    }
	case 11: //double
	    try {
	    long v = makenumunconvertL(b,8,true,bigendian);
	    return ""+Double.longBitsToDouble(v);
	    } catch (IllegalArgumentException e) {
		return "";
	    }
	default:
	    return "";
	}
    }

    public static byte[] makenumconvert (long num, int len, boolean signed,
					 boolean bigendian) {
	return makenumconvert(""+num,len,signed,bigendian);
    }
    
    public static byte[] makenumconvert(String text, int len, boolean signed,
					boolean bigendian) {
	byte[] array=new byte[len], leer=new byte[0];
	long max=1L <<(len*8);
	long min=0;
	if (signed) {
	    max/=2;
	    min=-max;
	}
	try {
	    long l=Long.parseLong(text);
	    if (len==8 || l>=min && l <max) {
		for (int i=0;i<len;i++) {
		    array[i]= (byte) (l & 0xff);
		    l>>=8;
		}
	    } else {
		return leer;
	    }
	} catch (NumberFormatException e) {
	    return leer;
	}
	if (bigendian) {
	    byte[] rev=new byte[len];
	    for (int i=0;i<len;i++) {
		rev[len-i-1]=array[i];
	    }
	    return rev;
	} else {
	    return array;
	}
    }

    public static long makenumunconvertL(byte[] by, int len, boolean signed,
					 boolean bigendian) {
	byte[] b=by;
	long l=0;
	if (by.length<len) {
	    b=new byte[len];
	    if (bigendian) {
		for(int i=0;i<by.length;i++) {
		    b[by.length-i-1]=by[i];
		}
	    } else {
		System.arraycopy(by,0,b,0,by.length);
	    }
	    if (by.length != 0 && b[by.length-1]<0 && signed) {
		for(int i=by.length;i<len;i++) {
		    b[i]=(byte) 0xff;
		}
	    }
	} else if (bigendian) {
	    b=new byte[len];
	    for(int i=0;i<len;i++) {
		b[i]=by[by.length-1-i];
	    }
	}
	for (int i=len-1;i>=0;i--) {
	    l<<=8;
	    l|=(b[i] & 0xff);
	}
	if (len != 8) {
	    long max=1L<<(8*len);
	    if (l >= max || l < 0) return 0;
	    if (signed && l >= max/2)
		l-=max;
	}
	return l;
    }
	
    public static String makenumunconvert(byte[] by, int len, boolean signed,
					  boolean bigendian) {
	return ""+makenumunconvertL(by,len,signed,bigendian);
    }

    public static Choice getTypeChoice() {
	Choice typ=new Choice();
	typ.add("ASCII text");
	typ.add("Unicode text");
	typ.add("UTF-8 text");
	typ.add("Hex values");
	typ.add("Bit mask");
	typ.add("Clipboard");
	typ.add("8-bit integer (byte)");
	typ.add("16-bit integer (short)");
	typ.add("32-bit integer (int)");
	typ.add("64-bit integer (long)");
	typ.add("32-bit float");
	typ.add("64-bit float (double)");
	return typ;
    }
    public static Choice getSubTypeChoice() {
	Choice typ2=new Choice();
		typ2.add("Unsigned Little Endian");
	typ2.add("Signed Little Endian");
	typ2.add("Unsigned Big Endian");
	typ2.add("Signed Big Endian");
	return typ2;
    }
}
