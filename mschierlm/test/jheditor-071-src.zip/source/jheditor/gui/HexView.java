// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.gui;
import jheditor.file.*;

import java.awt.FontMetrics;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import java.awt.datatransfer.*;

public class HexView extends Canvas implements AdjustmentListener,
					KeyListener,
					ActionListener {

    private long startpos=0;
    private HexFile file;
    private Font font;
    private Scrollbar scroll;
    long cursor, mark;
    private boolean hexing=true;
    private char halfchar=' ';
    private int visiblerange=16;
    private int mousex=-1,mousey;
    private boolean mouseshift, ignorecase;
    private Image buffer;
    private byte[] findlast;
    private Frame parent;
    private TreeSet splitmarks;
    private boolean wideOffsets=false;
    
    private static byte[] clipboard = null;
    
    public HexView (HexFile f, Scrollbar s, Frame parent){
	super();
	splitmarks=f.getSplitMarks();
	addKeyListener(this);
	this.parent=parent;
	file=f;
	scroll=s;
	addComponentListener(new ComponentAdapter() {
		public void componentResized(ComponentEvent e) {
		    repaint();
		}
	    });
	font=new Font("Courier", Font.PLAIN, 12);
	addMouseListener(new MouseAdapter() {
		public void mousePressed(MouseEvent e) {
		    mousex=e.getX();
		    mousey=e.getY();
		    mouseshift=e.isShiftDown();
		    repaint();
		}
	    });
	addMouseMotionListener(new MouseMotionAdapter() {
		public void mouseDragged(MouseEvent e) {
		    mousex=e.getX();
		    mousey=e.getY();
		    mouseshift=true;
		    repaint();
		}
	    });
    }
    
    public void update(Graphics g) {
	int height = getHeight();
	int width = getWidth();
	if (buffer == null || (buffer.getHeight(this)!=height ||
			       buffer.getWidth(this)!=width))
	    buffer = createImage(width, height);
	Graphics bufg = buffer.getGraphics();
	bufg.setColor(Color.white);
	bufg.fillRect(0,0,width,height);
	paint(bufg);
	g.drawImage(buffer, 0, 0, this);
    }
    
    public void paint(Graphics g) {
	int os=wideOffsets?17:9;
	int h=getHeight();
	int w=getWidth();
	g.setFont(font);
	long filesize=file.getSize();
	FontMetrics fm=getFontMetrics(font);
	int xskip=fm.charWidth('*');
	int yskip=fm.getHeight();
	int ystart=fm.getAscent();
	h/=yskip;
	w/=xskip;
	if (mousex!=-1) { // Mausklick
	    int xx=(mousex+xskip/2)/xskip,
		yy=mousey/yskip;
	    if (xx<os) {
		xx=0;
		hexing=true;
	    } else if (xx < 50+os) {
		xx=(xx-os)/3;
		hexing=true;
	    } else {
		xx=xx-50-os;
		hexing=false;
	    }
	    if (xx>15) xx=15;
	    halfchar=' ';
	    cursor=startpos+yy*16+xx;
	    validateCursor();
	    if (!mouseshift) mark=cursor;
	    mousex=-1;
	}
	visiblerange=h*16;
	if (visiblerange<16) visiblerange=16;
	if (filesize>0x7FFFFFFFFl) 
	    scroll.setValues(0,h,0,0);
	else
	    scroll.setValues((int)(startpos/16),h,0,(int)(filesize/16+1));
	if (w < 75-9+os) {
	    g.setColor(Color.black);
	    g.drawString("window width too small.",0,ystart);
	    return;
	} 
	draw:
	for(int i=0;i<h;i++) {
	    g.setPaintMode();
	    g.setColor(Color.blue);
	    if (i*16+startpos >filesize) break draw;
	    g.drawString(makeHexOffsetLeft(i*16+startpos),0,ystart+i*yskip);
	    for (int j=0;j<16;j++) {
		long offs=j+i*16+startpos;
		if (offs>filesize) break draw;
		if (offs!=filesize) {
		    byte b=file.getByte(offs);
		    if (file.isChanged(offs) ||
			(offs==cursor && halfchar != ' '))
			g.setColor(Color.red);
		    else
			g.setColor(Color.black);
		    if ((offs>=mark && offs <cursor )||
			(offs>=cursor && offs <mark)) {
			Color oldcol=g.getColor();
			g.setColor(Color.black);
			if (file.isInserted(offs)) {
			    g.setColor(Color.blue);
			}
			g.fillRect((j+50+os)*xskip,i*yskip,xskip,yskip);
			g.fillRect((j*3+os)*xskip,i*yskip,xskip*3,yskip);
			g.setColor((oldcol==Color.black)?Color.white:Color.yellow);
		    } else if (file.isInserted(offs)) {
			Color oldcol=g.getColor();
			g.setColor(Color.yellow);
			g.fillRect((j+50+os)*xskip,i*yskip,xskip,yskip);
			g.fillRect((j*3+os)*xskip,i*yskip,xskip*3,yskip);
			g.setColor(oldcol);
		    }
		    if (offs!=cursor || halfchar==' ') 
			g.drawString(makeHex(b), (j*3+os)*xskip,i*yskip+ystart);
		    else 
			g.drawChars(new char[] {halfchar,'-'},0,2,
				    (j*3+os)*xskip,i*yskip+ystart);
		    if ((b & 0xff)<32) b=(byte) '.';
		    g.drawString(new String(new byte[] {b}),
				 (j+50+os)*xskip,ystart+i*yskip);
		}
		if (splitmarks.contains(new Long(offs))) {
		    g.setColor(Color.green);
		    int x1=(os*2-1)*xskip/2, x2=(j*6+os*2-1)*xskip/2,
			x3=(115-18+os*2)*xskip/2,
			x4=(j+50+os)*xskip, x5=(33+100+os*2)*xskip/2;
		    g.drawLine(x1,(i+1)*yskip+2,x2,(i+1)*yskip+2);
		    g.drawLine(x2,i*yskip+2,x2,(i+1)*yskip+2);
		    g.drawLine(x2,i*yskip+2,x3,i*yskip+2);
		    g.drawLine(x3,(i+1)*yskip+2,x4,(i+1)*yskip+2);
		    g.drawLine(x4,i*yskip+2,x4,(i+1)*yskip+2);
		    g.drawLine(x4,i*yskip+2,x5,i*yskip+2);
		}
		if (file.isGapBefore(offs)) {
		    g.setColor(Color.red);
			g.fillRect((j*3+os)*xskip-3,
				   i*yskip, 1,yskip);
			g.fillRect((j+50+os)*xskip-1,i*yskip,
				  1,yskip);
		}
// 		if (file.isDEBUG(offs)) {
// 		    g.setColor(Color.cyan);
// 			g.fillRect((j*3+os)*xskip,
// 				   i*yskip-2, 5,yskip-6);
// 		}
		if (offs==cursor) {
		    g.setColor(Color.magenta);
		    if (hexing) {
			g.fillRect((j*3+os+(halfchar==' '?0:1))*xskip-1,
				   i*yskip, 2,yskip);
			if (offs!=filesize) 
			    g.fillRect((j+50+os)*xskip,(i+1)*yskip-1,
				       xskip,2);
		    } else {
			g.fillRect((j+50+os)*xskip-1,i*yskip,
				  2,yskip);
			if (offs != filesize) 
			    g.fillRect((j*3+os)*xskip, (i+1)*yskip-1,
				       xskip*2,2);
		    }
		}
	    }
	}
	((HexEditor)parent).refreshStatus();
    }
	
/*    String makeHexOffset (int offs) {
	String buf="00000000"+Integer.toHexString(offs);
	return buf.substring(buf.length()-8);
	}*/

    private String makeHexOffsetLeft(long offs) {
	String hs="00000000"+Long.toHexString(offs);
	if (wideOffsets) {
	    hs="00000000"+hs;
	    return hs.substring(hs.length()-16);
	}
	if (hs.length()>16+8) {
	    return "OVERFLOW";
	} else 	if (hs.length()>8+8) {
	    hs=hs.substring(hs.length()-16);
	    int ii=(int) ((offs/16) % 16);
	    hs=(ii<10?hs.charAt(ii):' ')+"|"+hs.substring(10);
	} else {
	    hs=hs.substring(hs.length()-8);
	}
	return hs;
    }
    
    static String makeHexOffset(long offs) {
	String hs=Long.toHexString(offs);
	if (hs.length()>16) 
	    hs="..."+hs.substring(hs.length()-5);
	else {
	    hs="0000000000000000"+hs;
	    hs=hs.substring(hs.length()-16);
	}
	return hs;
    }
    public static String makeHex(byte b) {
	String buf="00"+Integer.toHexString(b).toUpperCase();
	return buf.substring(buf.length()-2);
    }
    public Dimension getMinimumSize() {
	FontMetrics fm= getFontMetrics(font);
	return new Dimension(75*fm.charWidth('*'), fm.getHeight());
    }
    public Dimension getPreferredSize() {
	FontMetrics fm= getFontMetrics(font);
	return new Dimension(88*fm.charWidth('*'),25*fm.getHeight()+4);
    }

    public void adjustmentValueChanged(AdjustmentEvent e) {
	boolean nomark=(mark==cursor);
	startpos=e.getValue()*16L;
	if (nomark) {
	    if(cursor<startpos) cursor=startpos;
	    if(cursor>=startpos+visiblerange) cursor=startpos+visiblerange-1;
	}
	repaint();
	if (nomark) mark=cursor;
    }

    public void keyPressed(KeyEvent e) {
	if ((!e.isAltDown()) && (!e.isMetaDown()) &&
	    (!e.isControlDown())) {
	switch (e.getKeyCode()) {
	case KeyEvent.VK_TAB:
	case KeyEvent.VK_F6:
	    hexing=!hexing;
	    halfchar=' ';
	    break;
	case KeyEvent.VK_ENTER:
	    if (e.isShiftDown()) {
		long temp=cursor;
		cursor=mark;
		mark=temp;
	    } else {
	    hexing=!hexing;
	    halfchar=' ';
	    }
	    break;
	case KeyEvent.VK_BACK_SPACE:
	    if (halfchar != ' ')
		halfchar=' ';
	    else
		file.undo(--cursor);
	    break;
 	case KeyEvent.VK_DELETE:
	    deleteByte();
 	    break;
	case KeyEvent.VK_INSERT:
	    insertByte();
	    break;
	case KeyEvent.VK_LEFT:
	    cursor--;
	    break;
	case KeyEvent.VK_RIGHT:
	    cursor++;
	    break;
	case KeyEvent.VK_UP:
	    cursor-=16;
	    break;
	case KeyEvent.VK_DOWN:
	    cursor+=16;
	    break;
	case KeyEvent.VK_PAGE_DOWN:
	    cursor+=visiblerange;
	    break;
	case KeyEvent.VK_PAGE_UP:
	    cursor-=visiblerange;
	    break;
	case KeyEvent.VK_HOME:
	    cursor=0;
	    break;
	case KeyEvent.VK_END:
	    cursor=file.getSize();
	    break;
	case KeyEvent.VK_F3:
	    doFind(false,parent);
	    repaint();
	    return;
	case KeyEvent.VK_F9:
	    wideOffsets=!wideOffsets;
	    repaint();
	    return;
	default:
	    return;
	}
	validateCursor();
	if (!e.isShiftDown())
	    mark=cursor;
	} else {
	    return;
	}
	e.consume();
	repaint();
    }
    public void actionPerformed(ActionEvent e) {
	int num=e.getActionCommand().charAt(0)-'0';
	cursor=file.getSize()*num/10;
	validateCursor();
	mark=cursor;
	repaint();
    }
    
    private void validateCursor() {
	long newpos;
	if (cursor > file.getSize()) cursor = file.getSize();
	if (cursor<0) cursor=0;
	if (cursor<startpos) {
	    newpos=startpos-16*((startpos-cursor)/16);
	    if (cursor<newpos) newpos-=16;
//	    while(cursor<startpos) startpos-=16;
//	    System.out.println(startpos+","+newpos+",,"+cursor);
	    startpos=newpos;
	}
	if (cursor >=startpos+visiblerange) {
	    newpos=startpos+16*((cursor-startpos-visiblerange)/16);
	    if (cursor >=newpos+visiblerange) newpos+=16;
//	    while(cursor>=startpos+visiblerange) startpos+=16;
//	    System.out.println(startpos+","+newpos);
	    startpos=newpos;
	}
    }

    public void keyReleased(KeyEvent e) {}

    public void keyTyped(KeyEvent e) {
	char ch;
	if ((ch=e.getKeyChar())!=KeyEvent.CHAR_UNDEFINED &&
	    (e.getModifiers() &(InputEvent.CTRL_MASK|InputEvent.ALT_MASK|
				InputEvent.META_MASK))==0) {
	    if (cursor == file.getSize()) return;
	    if (!hexing) {
		byte[] by = (""+ch).getBytes();
		if (by.length==1 &&( by[0] &0xff) >31 && by[0] != 0x7f) {
		    file.setByte(cursor,by[0] );
		    cursor++;
		    validateCursor();
		    mark=cursor;
		    e.consume();
		    repaint();
		}
	    } else if ("0123456789ABCDEFabcdef".indexOf(ch) != -1) {
		if (halfchar==' ') {
		    halfchar=Character.toUpperCase(ch);
		} else {
		    int b = Integer.parseInt(""+halfchar+ch,16);
		    file.setByte(cursor,(byte)b);
		    halfchar=' ';
		    cursor++;
		    validateCursor();
		    mark=cursor;
		}
		e.consume();
		repaint();
	    }
	}
    }
    public void goToStart() {
	cursor=0;
	mark=0;
	validateCursor();
	splitmarks.clear();
	if (file.getSize()>0xFFFFFFFFl)
	    wideOffsets=true;
    }

    public void copy(boolean cut, boolean systemClipboard) {
	byte[] sel = getSelection();
	if (sel == null) {
	    new MessageBox(parent, "Selection too large to "+(cut?"cut":"copy")+".", "JHEditor");
	    return;
	} if (sel.length > 1048576 && systemClipboard) {
	    new MessageBox(parent, "Cannot use system clipboard for large selections. Some Java VMs might crash there.", "JHEditor");
	    return;
	}
	if (systemClipboard) {
	    String s;
	    try {
		s = new String(sel, "ISO-8859-1");
	    } catch (UnsupportedEncodingException ex) {
		ex.printStackTrace();
		s = new String(sel);
	    }
	    s = s.replace('\0', '\u0100');
	    StringSelection ss=new StringSelection(s);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss,ss);
	} else {
	    clipboard = sel;
	    System.out.println(clipboard.length);
	}
	if (cut && cursor != mark) {
	    deleteByte();
	}
    }
    
    public void paste(boolean insert, boolean systemClipboard) {
	byte[] bs;
	if (systemClipboard) {
	String s;
	try {
	    s=(String) Toolkit.getDefaultToolkit().
		getSystemClipboard().getContents(null).
		getTransferData(DataFlavor.stringFlavor);
	    s = s.replace('\u0100', '\0');
	} catch (UnsupportedFlavorException ex) {
	    s=null;
	} catch (IOException ex) {
	    s=null;
	}
	if (s!=null) {
	    try {
		bs = s.getBytes("ISO-8859-1");
	    } catch (UnsupportedEncodingException ex) {
		bs = s.getBytes();
	    }
	} else {
	    bs = null;
	} 
	} else {
	    bs = clipboard;
	}
	if (bs != null) {
	    if (insert) {
		long insLen = bs.length;
		if (mark<cursor) {
		    insLen-=cursor-mark;
		    cursor = mark;
		}
		insLen+=cursor-mark;
		if (insLen >0) {
		    file.insertBytes(cursor, insLen);
		} else if (insLen <0) {
		    file.deleteBytes(cursor, -insLen);
		}
		FileListing.refresh();
	    }
	    setSelection(bs);
	}
    }

    public void deleteByte() {
	halfchar=' ';
	if (cursor == mark) {
	    file.deleteBytes(cursor,1);
	} else if (cursor <mark) {
	    file.deleteBytes(cursor, mark-cursor);
	    mark = cursor;
	} else {
	    file.deleteBytes(mark, cursor-mark);
	    cursor=mark;
	}
	FileListing.refresh();
    }

    public void insertByte() {
	halfchar=' ';
	if (cursor == mark) {
	    file.insertBytes(cursor,1);
	} else {
	    file.insertBytes(cursor, Math.abs(cursor-mark));
	}
	FileListing.refresh();
    }
    
    public boolean isFocusable() {
	return true;
    }

    public boolean goTo(long pos, long size) {
	if (pos + size> file.getSize()) return false;
	if (pos<0)return false;
	if (size<0) return false;
	cursor=pos;
	validateCursor();
	mark=cursor;
	cursor=pos+size;
	validateCursor();
	return true;
    }
    
    public byte[] getSelection() {
	
	byte[] buff;
	long b=mark, en=cursor;
	if (b>en) {en=mark;b=cursor;}
	if (en-b>Integer.MAX_VALUE)
	    return null;
	buff = new byte[(int)(en-b)];
	for (long i=b;i<en;i++) {
	    byte bb = file.getByte(i);
	    buff[(int)(i-b)] = bb;
	}
	return buff;
    }

    public void setSelection(byte[] what) {
	mark=cursor;
	file.setBytes(cursor, what);
	cursor += what.length;
	repaint();
    }

    public void doFind(boolean dialog, Frame editor) {
	if(dialog || findlast ==null) {   
	    FindDialog f=new FindDialog(parent);
	    f.show();
	    findlast=f.getResult();
	    ignorecase=f.isIgnoreCase();
	}
	if (findlast!=null) {
	    final ProgressDialog prd =
		new ProgressDialog("Find in progress", parent);
	    new Thread(new Runnable() {
		    public void run() {
			long p=file.getPosition(findlast, cursor, ignorecase,
						prd);
			if (p!=-1) {
			    cursor=p;
			    validateCursor();
			    mark=cursor;
			    cursor=p+findlast.length;
			    validateCursor();
			} else {
			    mark=cursor;
			}
			prd.finish();
		    }
		}).start();
	    prd.enable();
	}
    }
    
    public byte[] getStatusSource() {
	byte[] what;
	if (cursor==mark) {
	    long mrk=cursor+16;
	    if (mrk >file.getSize()) mrk=file.getSize();
	    what=new byte[(int)(mrk-cursor)];
	    for (int i=0;i<what.length;i++) {
		what[i]=file.getByte(cursor+i);
	    }
	} else {
	    long beg=cursor, end=mark;
	    if(beg>end) {end=cursor;beg=mark;}
	    if (end-beg>1024) {
		return new byte[0];
	    }
	    what=new byte[(int)(end-beg)];
	    for(int i=0;i<end-beg;i++) {
		what[i]=file.getByte(beg+i);
	    }
	}
	return what;
    }

    public void toggleSplitMark() {
	Long lg=new Long(cursor);
	if (!splitmarks.remove(lg)) splitmarks.add(lg);
	repaint();
	System.out.println(splitmarks.size());
	FileListing.refresh();
    }
    
    public void notifySelection(long from, long to) {
	cursor=to;
	validateCursor();
	mark=to;
	cursor=from;
	validateCursor();
	repaint();
    }

    public void clearClip(boolean syscb) {
	if (syscb) {
	    StringSelection ss = new StringSelection("");
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss,ss);
	} else {
	    clipboard = null;
	}
    }

    public void selectAll() {
	cursor = 0;
	mark = file.getSize();
	validateCursor();
	repaint();	
    }
}
