// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.gui;
import java.awt.*;
import java.awt.event.*;
public class MessageBox extends Dialog implements ActionListener {

    public String clicked="Cancel";
    
    public MessageBox(Frame parent, String message, String title) {
	super(parent,title,true);
	setup(message, false);
    }

        public MessageBox(Frame parent, String message, String title,
			  boolean ync) {
	super(parent,title,true);
	setup(message, ync);
    }

    public MessageBox(Dialog parent, String message, String title) {
	super(parent,title,true);
	setup(message, false);
    }	
    private void setup(String message, boolean ync) {
	Panel p;
	Button b;
	add("Center", new Label(message));
	add("South",p=new Panel());
	if (ync) {
	    p.add(b=new Button("Yes"));
	    b.addActionListener(this);
	    p.add(b=new Button("No"));
	    b.addActionListener(this);
	    p.add(b=new Button("Cancel"));
	    b.addActionListener(this);
	} else {
	    p.add(b=new Button("OK"));
	    b.addActionListener(this);
	}
	WindowListener wl;
	addWindowListener(wl = new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
	    });
	closeOnEscape(this, wl);
	pack();
	Dimension scs=Toolkit.getDefaultToolkit().getScreenSize();
	setLocation((scs.width-getWidth())/2,(scs.height-getHeight())/2);
	show();
    }
    public void actionPerformed(ActionEvent e) {
	clicked=e.getActionCommand();
	dispose();
    }

    public static void closeOnEscape(Dialog dlg,
				       final WindowListener wl) {
	KeyListener kl = new KeyAdapter() {
		public void keyPressed(KeyEvent evt) {
		    if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
			wl.windowClosing(null);
		    }
		}
	    };
	addKeyListenerRec(dlg,kl);
    }

    private static void addKeyListenerRec(Component c, KeyListener kl) {
	c.addKeyListener(kl);
	if (c instanceof Container) {
	    Component[] children = ((Container) c).getComponents();
	    for (int i=0; i<children.length; i++) {
		addKeyListenerRec(children[i], kl);
	    }
	}
    }
}
	
