// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.gui;
import jheditor.*;
import jheditor.file.*;

import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import java.awt.dnd.*;

public class HexEditor extends Frame implements ActionListener,
						ItemListener,
						HexFileListener {

    HexView hv;
    private final HexFile file=new HexFile(this);
    private Scrollbar sb;
    private MenuItem saveItem;
    private Choice type,subType;
    private TextField convertresult;
    private Label offsetlabel;
    private CheckboxMenuItem syscb;
    
    public static Image icon=Toolkit.getDefaultToolkit()
		.createImage(Main.class.getResource
			     ("/res/icon.gif"));;

    private static int instanceCount=0;

    public HexEditor(String filename, boolean ro) {
	this(new File(filename),ro);
    }

    public HexEditor(File file, boolean ro) {
	this(false);
	openFile(file,null,ro);
	show();
	hv.requestFocus();
    }

    public HexEditor() {
	this(true);
    }
    
    public HexEditor(boolean initshow) {
	super("JHEditor "+Main.VERSION);
	setIconImage(icon);
	FileDropTargetAdapter fdta = new FileDropTargetAdapter() {
		public boolean drop(File[] f) {
		    if (f.length==1) {
			openFile(f[0],null,false);
			hv.repaint();
		    } else {
			for(int i=0;i<f.length;i++) {
			    new HexEditor(f[i],false);
			}
		    }
		    return true;
		}
	    };
	setDropTarget(new DropTarget(this, DnDConstants.ACTION_COPY,
				     fdta, true, null));
	sb=new Scrollbar
	    (Scrollbar.VERTICAL, 0,25,0,(int)file.getSize()/16+1);
	try {
	    sb.setFocusable(false);
	} catch (NoSuchMethodError e) {
	    // Java 1.3
	}
	add("Center",hv=new HexView(file, sb, this));
	add("East", sb);
	sb.addAdjustmentListener (hv);
	Panel p,p2;
	add("South",p=new Panel(new BorderLayout()));
	p.setBackground(Color.lightGray);
	p.add("North",p2=new Panel() {
		public Dimension getPreferredSize() {
		    return new Dimension(5,5);}});
	p2.setBackground(Color.black);
	p.add("West", type=ConvertWindow.getTypeChoice());
	type.select(3);
	p.add("Center",p2=new Panel(new BorderLayout()));
	p2.add("West",subType=ConvertWindow.getSubTypeChoice());
	p2.add("Center",convertresult=new TextField(""));
	p2.add("East",offsetlabel=new Label("Offset: XXXXXXXXYYYYYYYY"));
	convertresult.setEditable(false);
	type.addItemListener(this);
	subType.addItemListener(this);
	MenuBar mb=new MenuBar();
	Menu m;
	MenuItem mi;
	mb.add(m=new Menu("File",true));
	m.add(mi=new MenuItem("New Window",new MenuShortcut(KeyEvent.VK_I)));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("New"));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Open",new MenuShortcut(KeyEvent.VK_O)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Open read-only",
			      new MenuShortcut(KeyEvent.VK_O, true)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Save", new MenuShortcut(KeyEvent.VK_S)));
	mi.addActionListener(this);
	saveItem=mi;
	mi.setEnabled(false);
	m.add(mi=new MenuItem("Save as", new MenuShortcut(KeyEvent.VK_S,
							  true)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Revert"));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("Exit", new MenuShortcut(KeyEvent.VK_Q)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Exit all instances",
			      new MenuShortcut(KeyEvent.VK_Q,true)));
	mi.addActionListener(this);
	mb.add(m=new Menu("Edit"));
	m.add(mi=new MenuItem("Select all",new MenuShortcut(KeyEvent.VK_A)));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("Cut",new MenuShortcut(KeyEvent.VK_X)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Copy",new MenuShortcut(KeyEvent.VK_C)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Paste",new MenuShortcut(KeyEvent.VK_V)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Paste (insert)",
			      new MenuShortcut(KeyEvent.VK_V, true)));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("Clear clipboard", new MenuShortcut(KeyEvent.VK_X, true)));
	mi.addActionListener(this);
	m.add(mi=syscb = new CheckboxMenuItem("Use system clipboard",true));
	syscb.setShortcut(new MenuShortcut(KeyEvent.VK_C, true));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("Find",new MenuShortcut(KeyEvent.VK_F)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Next",new MenuShortcut(KeyEvent.VK_N)));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("Insert"));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Delete"));
	mi.addActionListener(this);
	mb.add(m=new Menu("View"));
	m.add(mi=new MenuItem("Go to position...",new MenuShortcut(KeyEvent.VK_G)));
	mi.addActionListener(this);
	m.addSeparator();
	for(int i=0;i<9;i++) {
	    m.add(mi=new MenuItem("Scroll to "+(char)('1'+i)+"0%",
				  new MenuShortcut(KeyEvent.VK_1+i)));
	    mi.setActionCommand(""+(char)('1'+i));
	    mi.addActionListener(hv);
	}
	mb.add(m=new Menu("Tools"));
	m.add(mi=new MenuItem("Converter",
			      new MenuShortcut(KeyEvent.VK_C,true)));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("Add/Remove Split mark",
			      new MenuShortcut(KeyEvent.VK_M)));
	mi.addActionListener(this);
	m.add(mi=new MenuItem("Join Split parts to file...",
			      new MenuShortcut(KeyEvent.VK_J)));
	mi.addActionListener(this);
	m.addSeparator();
	m.add(mi=new MenuItem("Compare Files...",
			      new MenuShortcut(KeyEvent.VK_F,true)));
	mi.addActionListener(this);
	setMenuBar(mb);
	FileListing.registerEditor(this);
	addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e) {
		    if (savedOk()) {
			FileListing.unregisterEditor(HexEditor.this);
			dispose();
			if (--instanceCount==0) 
			    System.exit(0);
		    }
		}
	    });
    
	pack();
	instanceCount++;
	setLocation(instanceCount*30,instanceCount*30);
	if (initshow) {
	    show();
	    hv.requestFocus();
	}
    }
    private boolean savedOk() {
	if (file.isChanged() && !file.isReadOnly()) {
	    MessageBox mb = new MessageBox(this,
					   "Do you want to save changes?",
					   "JHEditor",
					   true);
	    if (mb.clicked.equals("Yes")) {
		file.save();
	    } else if(mb.clicked.equals("Cancel")) {
		return false;
	    }
	}
	return true;
    }
    
    public void itemStateChanged(ItemEvent e) {
	refreshStatus();
    }

    public void refreshStatus() {
	byte[] what = hv.getStatusSource();
	convertresult.setText(ConvertWindow.bytes2type
			      (what, type.getSelectedIndex(),
			       subType.getSelectedIndex()));
	offsetlabel.setText("Offset: "+HexView.makeHexOffset(hv.cursor));
    }
    public void actionPerformed(ActionEvent e) {
	String cmd=e.getActionCommand();
	if ("Exit all instances".equals(cmd)) {
	    if (savedOk())
		System.exit(0);
	} else if ("Exit".equals(cmd)) {
	    if (savedOk()) {
		dispose();
		if (--instanceCount==0)
		    System.exit(0);
	    }
	} else if ("New Window".equals(cmd)) {
	    new HexEditor();
	} else if ("New".equals(cmd)) {
	    file.close();
	    hv.goToStart();
	    setTitle("JHEditor "+Main.VERSION);
	    setReadOnly(true);
	} else if("Save".equals(cmd)) {
	    if (!file.isReadOnly()) file.save();
	} else if("Save as".equals(cmd)) {
	    FileDialog fd=new FileDialog(this,"Save as",FileDialog.SAVE);
	    fd.show();
	    if (fd.getFile() != null) {
		File f=new File(fd.getDirectory(), fd.getFile());
		saveAs(f);
	    }
	} else if("Revert".equals(cmd)) {
	    file.revert();
	    hv.goToStart();
	} else if("Open".equals (cmd)) {
	    FileDialog fd=new FileDialog(this,"Select file");
	    fd.show();
	    if (fd.getFile() != null) {
		File f=new File(fd.getDirectory(), fd.getFile());
		openFile(f,null,false);
	    }
	} else if("Open read-only".equals (cmd)) {
	    FileDialog fd=new FileDialog(this,"Select file");
	    fd.show();
	    if (fd.getFile() != null) {
		File f=new File(fd.getDirectory(), fd.getFile());
		openFile(f,null, true);
	    }
	} else if ("Select all".equals(cmd)) {
	    hv.selectAll();
	} else if ("Cut".equals(cmd)) {
	    hv.copy(true, isSystemClipboard());
	} else if ("Copy".equals(cmd)) {
	    hv.copy(false, isSystemClipboard());
	} else if ("Paste".equals(cmd)) {
	    hv.paste(false, isSystemClipboard());
	} else if ("Paste (insert)".equals(cmd)) {
	    hv.paste(true, isSystemClipboard());
	} else if ("Clear clipboard".equals(cmd)) {
	    hv.clearClip(isSystemClipboard());
	} else if ("Use system clipboard".equals(cmd)) {
	    syscb.setState(!syscb.getState());
	} else if("Find".equals(cmd)) {
	    hv.doFind(true, this);
	} else if("Next".equals(cmd)) {
	    hv.doFind(false, this);
	} else if ("Insert".equals(cmd)) {
	    hv.insertByte();
	} else if ("Delete".equals(cmd)) {
	    hv.deleteByte();
	} else if("Converter".equals(cmd)) {
	    new ConvertWindow(this);
	} else if ("Go to position...".equals(cmd)) {
	    new GoToDialog(this, hv.cursor);
	} else if ("Add/Remove Split mark".equals(cmd)) {
	    hv.toggleSplitMark();
	} else if ("Join Split parts to file...".equals(cmd)) {
	    JoinerWindow.showJoiner();
	} else if ("Compare Files...".equals(cmd)) {
	    new FileCompareWindow(this);
//	    new MessageBox(this, "Not implemented yet","");
	} else {
	    System.out.println("-");
	    new Throwable().printStackTrace();
	}
	hv.repaint();
    }
    private boolean isSystemClipboard() {
	return syscb.getState();
    }

    private void setReadOnly(boolean state) {
	if (state != file.isReadOnly()) {
	    throw new RuntimeException("Oops");
	}
	saveItem.setEnabled(!state);
    }

    public boolean openFile(File f, Collection marks, boolean readonly) {
	int result=file.open(f,readonly);
	if (result >0) {
	    readonly=(result==1);
	    setTitle(f.getName()+" "+
		     (readonly?"[read only]":"")+
		     " - JHEditor "+Main.VERSION);
	    hv.goToStart();
	    setReadOnly(readonly);
	    if (marks!=null) {
		file.getSplitMarks().addAll(marks);
	    }
	    return true;
	} else {
	    file.close();
	    setTitle("JHEditor "+Main.VERSION);
	    setReadOnly(true);
	    hv.goToStart();
	    return false;
	}
    }

    public void saveAs(File f) {
	try {
	    BufferedOutputStream out=new BufferedOutputStream
		(new FileOutputStream(f));
	
	    file.writeByteBlock(0, file.getSize(), out);
	    out.flush();
	    out.close();
	    openFile(f, null, false);
	} catch (IOException e) {
	    new MessageBox(this,e.toString(),
		       "JHEditor - Save As");
	}
    }

    public void update (Graphics g) {
	super.update(g);
	hv.update(hv.getGraphics());
    }

    public void showError(String message, String title) {
	new MessageBox(this, message,
		       title);
    }

    public void notifySelection(long from, long to) {
	hv.notifySelection(from,to);
    }

    public void setEditorBounds(int x, int y, int width, int height) {
	setLocation(x,y);
	setSize(width,height);
	validate();
    }

    public HexFile getFile() { return file;}

    public void refreshFileList() {
	FileListing.refresh();
    }
}
