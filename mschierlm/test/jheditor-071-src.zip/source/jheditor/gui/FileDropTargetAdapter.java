// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.gui;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.io.*;

public abstract class FileDropTargetAdapter implements DropTargetListener {

    protected final DataFlavor df = DataFlavor.javaFileListFlavor;
    protected final int action = DnDConstants.ACTION_COPY;
        
    public void dragEnter (DropTargetDragEvent evt) {
	myDrag(evt);
    }
    public void dragOver(DropTargetDragEvent evt) {
	myDrag(evt);
    }
    public void dropActionChanged (DropTargetDragEvent evt) {
	myDrag(evt);
    }

    protected void myDrag(DropTargetDragEvent evt) {
	if (!evt.isDataFlavorSupported(df)) {
	    evt.rejectDrag();
	} else if (evt.getDropAction() != action) {
	    evt.acceptDrag(action);
	}
    }
	
    public void drop(DropTargetDropEvent evt) {
	if (!evt.isDataFlavorSupported(df)) {
	    evt.rejectDrop();
	} else {
	    evt.acceptDrop(action);
	    try {
		java.util.List l = (java.util.List) evt.getTransferable()
		    .getTransferData(DataFlavor.javaFileListFlavor);
		File[] fls = (File[]) l.toArray(new File[l.size()]);
		evt.dropComplete(drop(fls));
	    } catch (UnsupportedFlavorException e) {
		e.printStackTrace();
		evt.dropComplete(false);
	    } catch (IOException e) {
		e.printStackTrace();
		evt.dropComplete(false);
	    }		    
	}
    }

    public void dragExit(DropTargetEvent dte) {}
    
    public abstract boolean drop(File[] files);
}
