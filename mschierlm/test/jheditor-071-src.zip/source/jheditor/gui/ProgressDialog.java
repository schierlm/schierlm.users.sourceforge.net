package jheditor.gui;

import jheditor.file.*;

import java.awt.*;
import java.awt.event.*;


public class ProgressDialog extends Dialog implements ProgressMonitor {

    private boolean canceled = false, disposed = false;
    private Label l;
    private String title;
    private long lastP=-1;
    
    public ProgressDialog(String title, Frame parent) {
	super(parent, title, true);
	this.title=title;
	setLayout(new BorderLayout());
	add(BorderLayout.CENTER, l = new Label(title+": 000%"));
	Button b;
	add(BorderLayout.SOUTH, b=new Button("Cancel"));
	b.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {
		    setCanceled();
		}
	    });
	WindowListener wl;
	addWindowListener(wl = new WindowAdapter() {
		public void windowClosing(WindowEvent evt) {
		    setCanceled();
		}
	    });
	MessageBox.closeOnEscape(this, wl);
	pack();
	setLocation((Toolkit.getDefaultToolkit().getScreenSize().width
		     - getWidth())/2,
		    (Toolkit.getDefaultToolkit().getScreenSize().height
		     - getHeight())/2);
    }

    private synchronized void setCanceled() {
	canceled=true;
    }
    
    public void enable() {
	synchronized(this) {
	    if (disposed) return;
	}
	// not synchronized here! show() will not return until dispose
	// has been called!
	show();
    }
    
    public synchronized boolean isCanceled() {
	return canceled;
    }

    public synchronized void setProgress(long progress, long max) {
	long p = progress * 100L / max;
	if (p != lastP) {
	l.setText(title+": "+p+"%");
	lastP = p;
	}
    }

    public void finish() {
	synchronized(this) {
	    disposed=true;
	}
	dispose();
    }
}
