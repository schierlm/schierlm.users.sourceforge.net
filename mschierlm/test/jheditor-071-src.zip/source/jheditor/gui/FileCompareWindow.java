// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004, 2005, 2006 Michael Schierl

package jheditor.gui;
import jheditor.compare.HexComparer;
import jheditor.file.*;

import java.awt.*;
import java.util.*;
import java.awt.List;
import java.awt.event.*;

public class FileCompareWindow extends Frame implements ActionListener,
							ItemListener {

    private Choice file1, file2;
    private Checkbox align;
    private TextField minMatchLength, maxResyncLength;
    
    private java.util.List editors;
    private List results;
    private CardLayout cl;
    private HexFile hf1, hf2;
    private HexEditor he1, he2;
    private HexEditor[] toFocus = new HexEditor[2];
    private boolean ignoreNextFocus=false;
    private ProgressDialog prd = null;
    
    public FileCompareWindow(Frame startedFrom) {
	super("Compare files");
	setBackground(Color.lightGray);
	setIconImage(HexEditor.icon);
	Panel p;
	Button b;
	editors=FileListing.getEditors(); //FIXME: dynamic
	setLayout(cl=new CardLayout());
	add("Start",p=new Panel(new BorderLayout()));
	p.add("North",p=new Panel(new GridLayout(8,1)));
	p.add(file1 = makeChoice());
	p.add(file2=makeChoice());
	p.add(align=new Checkbox("Align windows", true));
	p.add(new Label("MinMatchLength:"));
	p.add(minMatchLength = new TextField("16"));
	p.add(new Label("MaxResyncLength:"));
	p.add(maxResyncLength = new TextField("1024"));	
	p.add(b=new Button("Compare!"));
	b.addActionListener(this);
	add("Results",p = new Panel(new BorderLayout()));
	p.add("Center", results=new List());
	p.add("South", b = new Button("Back"));
	b.addActionListener(this);
	results.add("Please click Compare first! 00000000");
	results.addItemListener(this);
	int h = Toolkit.getDefaultToolkit().getScreenSize().height;
	Insets i;
	try {
	    i = Toolkit.getDefaultToolkit().getScreenInsets(getGraphicsConfiguration());
	} catch (NoSuchMethodError e) {
	    i = new Insets(0,0,0,0);
	}
	setLocation(startedFrom.getWidth()+startedFrom.getX(),
		    i.top);
	pack();
	setSize(getWidth(),h-i.top-i.bottom);
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
		public void windowActivated(WindowEvent e) {
		    if (ignoreNextFocus) {
			ignoreNextFocus=false;
		    } else {
			refocus();
		    }
		}
	    });
	show();
    }

    private Choice makeChoice() {
	Choice c=new Choice();
	Iterator i = editors.iterator();
	while(i.hasNext()) {
	    String name=((HexEditor)i.next()).getFile().getName();
	    if (name==null) {
		c.add("(dummy file)");
	    } else {
		c.add(name);
	    }
	}
	return c;
    }
    
    public void actionPerformed(ActionEvent e) {
	if (e.getActionCommand().equals("Back")) {
	    cl.show(this,"Start");
	    return;
	} else {
	    if (file1.getSelectedIndex() == file2.getSelectedIndex()) {
		new MessageBox(this, "Cannot compare a file with itself.", "JHEditor - Compare files");
		return;
	    }
	    prd = new ProgressDialog("Compare in progress", this);
	    new Thread(new Runnable() {
		    public void run() {
			doCompare();
		    }
		}).start();
	    prd.enable();
	}
    }

    private void doCompare() {
	he1 = (HexEditor)editors.get(file1.getSelectedIndex());
	hf1=he1.getFile();
	he2=(HexEditor)editors.get(file2.getSelectedIndex());
	hf2=he2.getFile();
	if (align.getState()) {
	    int xMin=Math.min(he1.getX(), he2.getX());
	    int xMe=xMin+Math.max(he1.getWidth(),he2.getWidth());
	    if (xMe<getX()) xMe=getX();
	    int width=xMe-xMin;
	    int height=getHeight()/2;
	    setLocation(xMe,getY());
	    he1.setEditorBounds(xMin, getY(), width,  height);
	    he2.setEditorBounds(xMin, getY()+height, width, height);
	    toFocus[0]= he1;
	    toFocus[1]=he2;
	    refocus();
	} else {
	    toFocus[0] = toFocus[1] = null;
	}
	int minMatch=Integer.parseInt(minMatchLength.getText()),
	    maxResync=Integer.parseInt(maxResyncLength.getText());

	results.removeAll();
	ArrayList lst = new ArrayList();
	if (minMatch <=0) minMatch = 1;
	if (maxResync < 0) maxResync = 0;
	new HexComparer(hf1, hf2).compare(minMatch, maxResync, prd, lst);
	for (Iterator it = lst.iterator(); it.hasNext();) {
	    String str = (String) it.next();
	    results.add(str);
	}
	if (!prd.isCanceled())
	    cl.show(this,"Results");
	prd.finish();
	prd = null;
    }


    public void itemStateChanged(ItemEvent e) {
	String it = results.getSelectedItem();
	if (it != null) {
	    int pos=it.indexOf("[");
	    StringTokenizer st= new StringTokenizer
		(it.substring(pos+1,it.length()-1), "|-");
	    long from1=Long.parseLong(st.nextToken(),16),
		to1=Long.parseLong(st.nextToken(), 16),
		from2=Long.parseLong(st.nextToken(), 16),
		to2=Long.parseLong(st.nextToken(), 16);
	    he1.notifySelection(from1, to1);
	    he2.notifySelection(from2, to2);
	}
    }

    private void refocus() {
	for (int i=0;i<2;i++) {
	    if (toFocus[i] != null)
		toFocus[i].requestFocus();
	}
	ignoreNextFocus=true;
	requestFocus();
    }

}
