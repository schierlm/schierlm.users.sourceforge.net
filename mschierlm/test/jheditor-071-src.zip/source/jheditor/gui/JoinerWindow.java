// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.gui;
import jheditor.file.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.awt.List;

public class JoinerWindow extends Frame implements ActionListener{

    private static JoinerWindow instance=null;

    private List leftlist, rightlist;

    public static void refreshJoinerWindow() {
	if (instance != null)
	    instance.refreshView();
    }
    
    public JoinerWindow() {
	super("Join Split parts");
	setIconImage(HexEditor.icon);
	Panel p;
	Button b;
	setLayout(new GridLayout(1,2));
	add(p=new Panel(new BorderLayout()));
	p.add("North", b=new Button("Refresh & Clear"));
	b.addActionListener(this);
	p.add("Center", leftlist=new List(20));
 	p.add("South", b=new Button("Add >>"));
	b.addActionListener(this);
	add(p=new Panel(new BorderLayout()));
	p.add("North", b=new Button("Save file..."));
	b.addActionListener(this);
	p.add("Center",rightlist=new List(20));
	p.add("South", b=new Button("Remove"));
	b.addActionListener(this);
	leftlist.add("[0] (dummy file with long name) "+
		     "(1) 0000000000000000-000000000000000F");
	pack();
	refreshView();
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		    instance=null;
		}
	    });
	show();
    }

    private void refreshView() {
	java.util.List editors = FileListing.getEditors();
	leftlist.removeAll();
	rightlist.removeAll();
	rightlist.add("---end---");
	rightlist.select(0);
	for(int i=0;i<editors.size();i++) {
	    HexFile elem=((HexEditor) editors.get(i)).getFile();
	    String nm=elem.getName();
	    if (nm==null) nm="(dummy file)";
	    if (nm !=null) {
		nm = "["+(i+1)+"] "+nm;
		TreeSet sm=elem.getSplitMarks();
		Iterator it = sm.iterator();
		int j=0;
		long lastIndex=0;
		while (it.hasNext()) {
		    long newIndex=((Long) it.next()).longValue();
		    leftlist.add(nm+" ("+(++j)+
				 ") "+HexView.makeHexOffset(lastIndex)+"-"
				 +HexView.makeHexOffset(newIndex));
		    lastIndex=newIndex;
		}
		leftlist.add(nm+" ("+(++j)+
			     ") "+HexView.makeHexOffset(lastIndex)+"-"
			     +HexView.makeHexOffset(elem.getSize()));
	    }
	}
    }
    public void actionPerformed(ActionEvent e) {
	String cmd=e.getActionCommand();
	if ("Add >>".equals(cmd)) {
	    if (rightlist.getSelectedIndex() != -1 &&
		leftlist.getSelectedIndex() != -1) {
		rightlist.add(leftlist.getSelectedItem(),
			      rightlist.getSelectedIndex());
	    }
	} else if ("Remove".equals(cmd)) {
	    if (rightlist.getSelectedIndex() != -1 &&
		!rightlist.getSelectedItem().equals("---end---")) {
		int si=rightlist.getSelectedIndex();
		rightlist.remove(si);
		rightlist.select(si);
	    }
	} else if ("Refresh & Clear".equals(cmd)) {
	    refreshView();
	} else if ("Save file...".equals(cmd)) {
	    saveFile();
	} else {
	    System.out.println(cmd);
	}
    }

    private void saveFile() {
	FileDialog fd=new FileDialog(this,"New Filename:",FileDialog.SAVE);
	fd.show();
	if (fd.getFile()==null) return;
	File f=new File(fd.getDirectory(), fd.getFile());
	TreeSet newmarks=new TreeSet();
	long offs=0;
	try {
	    BufferedOutputStream out=new BufferedOutputStream
		(new FileOutputStream(f));
	
	    for(int i=0;i<rightlist.getItemCount()-1;i++) {
		if (i!=0)
		    newmarks.add(new Long(offs));
		String item=rightlist.getItem(i);
		int j=item.indexOf("] ");
		if (j==-1) return;
		System.out.println(item.substring(1,j));
		int findex=Integer.parseInt(item.substring(1,j))-1;
		j=item.lastIndexOf(" ");
		if (j==-1) return;
		item=item.substring(j+1);
		j=item.indexOf("-");
		long start=Long.parseLong(item.substring(0,j),16),
		    end = Long.parseLong(item.substring(j+1),16);
		HexFile hf=((HexEditor) FileListing.getEditors().get(findex))
		    .getFile();
		hf.writeByteBlock(start, end, out);
		offs+=end-start;
	    }
	    out.flush();
	    out.close();
//	    rightlist.removeAll();
	    HexEditor he=new HexEditor();
	    he.openFile(f,newmarks,false);
	} catch (IOException e) {
	    new MessageBox(this,e.toString(),
		       "JHEditor - Save Joined File");
//	    e.printStackTrace();
	}
    }
    public static void showJoiner() {
	if (instance==null) {
	    instance=new JoinerWindow();
	} else {
	    instance.show();
	}
    }
}
