// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004, 2005, 2006 Michael Schierl

package jheditor.compare;

import jheditor.file.ProgressMonitor;

import java.util.*;

public class HexComparer {

    static class CompareHash implements Comparable {
	public final long hash;
	public final long position;
	
	public int compareTo(Object arg0) {
	    CompareHash other = (CompareHash)arg0;
	    // -1: this < other
	    if (hash < other.hash) return -1;
	    if (hash > other.hash) return 1;
	    if (position > other.position) return -1;
	    if (position < other.position) return 1;
	    return 0;
	}
	
	public CompareHash(long hash, long position) {
	    this.hash = hash;
	    this.position = position;
	}
	
    }
    
    private final HexComparable hf1;
    private final HexComparable hf2;

    public HexComparer(HexComparable hf1, HexComparable hf2) {
	if(hf1 == hf2) throw new IllegalArgumentException("Same files");
	this.hf1 = hf1;
	this.hf2 = hf2;
    }
	
    public void compare(final int minMatch, final int maxResync, 
			final ProgressMonitor pmon, final List results) {
	long p1=0, p2=0;
	long size1 = hf1.getSize();
	long size2 = hf2.getSize();
	long maxProgress = size1 + size2;
	if (maxProgress == 0) maxProgress = 1;
	final long refreshInterval = Math.max(10,maxProgress/200);
	final int hashBits;
	int hashCollisions=0, hashMatches=0; 
	final long hashMask;
	CompareHash[] hashes1 = new CompareHash[maxResync], hashes2 = new CompareHash[maxResync];
	TreeSet set1 = new TreeSet(), set2 = new TreeSet();
	if (minMatch <1) throw new IllegalArgumentException();
	if (minMatch < 8) {
	    hashBits = 1 << 8;
	    hashMask = (1L << 8*minMatch) - 1;
	} else if (minMatch < 16) {
	    hashBits = 1 << 4;
	    hashMask = (1L << 4*minMatch) - 1;
	} else if (minMatch < 30) {
	    hashBits = 1 << 2;
	    hashMask = (1L << 2*minMatch) - 1;
	} else {
	    hashBits = 1 << 2;
	    hashMask = (1L << 60) -1;
	}
	while(p1<size1 && p2<size2) {
	    if(pmon.isCanceled()) break;
	    long p12=p1+p2;
	    pmon.setProgress(p12, maxProgress);
	    if (matches(p1,p2,size1,size2,minMatch)) {
		long i,  op1 = p1, op2 = p2;
		p1+=minMatch;
		p2+=minMatch;
		for (i=minMatch;;i++,p1++,p2++) {
		    if(pmon.isCanceled()) break;
		    if (i%refreshInterval == 0)
			pmon.setProgress(p1+p2, maxProgress);
		    if (p1 >=size1 || p2 >= size2)
			break;
		    if (hf1.getByte(p1) != hf2.getByte(p2))
			break;
		}
		results.add("Identical ["+hex(op1)+"-"+hex(p1)+"|"+hex(op2)+"-"+hex(p2)+"]");
	    } else {
		long poi1=0, poi2=0;
		long howFar = Math.min(size1-p1, size2-p2)-minMatch+1;
		long p1poi1=p1, p2poi1=p2;
		long hash1 = 0, hash2 = 0;
		Arrays.fill(hashes1, null);
		Arrays.fill(hashes2,null);
		set1.clear();
		set2.clear();
		for(int i=0; i<minMatch-1; i++) {
		    hash1 = hash1 * hashBits+hf1.getByte(p1);
		    hash2 = hash2 * hashBits+hf2.getByte(p2);
		    hash1 &=hashMask;
		    hash2 &=hashMask;
		}
		outer:
		for (poi1=0;poi1<howFar;poi1++,p1poi1++,p2poi1++) {
		    if(pmon.isCanceled()) break;
		    long howFarDown = Math.max(0, poi1-maxResync);
		    if (poi1 % refreshInterval == 0)
			pmon.setProgress(p12+poi1+howFarDown, maxProgress);
		    hash1 = hash1 *hashBits+ hf1.getByte(p1poi1+minMatch-1);
		    hash1 &=hashMask;
		    hash2 = hash2 * hashBits + hf2.getByte(p2poi1+minMatch-1);
		    hash2 &=hashMask;
		    if (hash1 == hash2) {
			if (matches(p1poi1,p2poi1, size1,size2,minMatch)) {
			    poi2=poi1;
			    hashMatches++;
			    break;
			} else {
			    hashCollisions++;
			}
		    }
		    int p1idx = (int)(p1poi1 % maxResync);
		    if (hashes1[p1idx] != null) {
			set1.remove(hashes1[p1idx]);
		    }
		    hashes1[p1idx] = new CompareHash(hash1, p1poi1);
		    set1.add(hashes1[p1idx]);
		    int p2idx = (int)(p2poi1 % maxResync);
		    if (hashes2[p2idx] != null) {
			set2.remove(hashes2[p2idx]);
		    }
		    hashes2[p2idx] = new CompareHash(hash2, p2poi1);
		    set2.add(hashes2[p2idx]);		    
		    CompareHash h1, h2 = hashes2[p2idx];
		    Iterator it1 = set1.tailSet(h2).iterator();
		    long match1= -1, match2 = -1;
		    while(it1.hasNext()) {
			if(pmon.isCanceled()) break;
			h1 = (CompareHash)it1.next();
			if (h1.hash != hash2) break;
			if (matches(h1.position, h2.position, size1, size2, minMatch)) {
			    match1 = h1.position - p1;
			    hashMatches++;
			    break;
			} else {
			    hashCollisions++;
			}
		    }
		    h1 = hashes1[p1idx];
		    Iterator it2 = set2.tailSet(h1).iterator();
		    while(it2.hasNext()) {
			if(pmon.isCanceled()) break;
			h2 = (CompareHash)it2.next();
			if (h2.hash != hash1) break;
			if (matches(h1.position, h2.position, size1, size2, minMatch)) {
			    match2 = h2.position - p2;
			    hashMatches++;
			    break;
			} else {
			    hashCollisions++;
			}
		    }
		    if (match1 != -1 && match1 > match2) {
			poi2 = poi1;
			poi1 = match1;
			break outer;
		    } else if (match2 != -1 && match2 > match1) {
			poi2 = match2;
			break outer;
		    }
		}
		if (poi1 >= howFar) { // no way
		    break;
		}
		results.add(makeChanged(p1,p1+poi1,p2,p2+poi2));
		p1+=poi1;
		p2+=poi2;
	    }
	}
	if (p1 != size1 || p2 != size2) {
	    results.add(makeChanged(p1,size1,p2,size2));
	}
	System.out.println("Hash collisions: "+hashCollisions);
	pmon.setProgress(maxProgress, maxProgress);
    }
	
    private boolean matches (long p1, long p2, long size1, long size2,
			     long len) {
	for(int i=0;i<len;i++) {
	    if (hf1.getByte(p1++) != hf2.getByte(p2++))
		return false;
	}
	return true;
    }
	    
    private static String makeChanged(long f1, long t1, long f2, long t2) {
	if (f1==t1 || f2==t2) {
	    return "Added/Removed ["+hex(f1)+"-"+hex(t1)+"|"+hex(f2)+"-"+hex(t2)+"]";
	} else if (t1-f1==t2-f2) {
	    return "Replaced ["+hex(f1)+"-"+hex(t1)+"|"+hex(f2)+"-"+hex(t2)+"]";
	} else {
	    return "Changed ["+hex(f1)+"-"+hex(t1)+"|"+hex(f2)+"-"+hex(t2)+"]";
	}
    }
	    
    private static String hex(long value) {
	return Long.toHexString(value);
    }    
}