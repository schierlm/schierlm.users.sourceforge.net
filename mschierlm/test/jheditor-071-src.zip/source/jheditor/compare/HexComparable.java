// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.compare;

public interface HexComparable {

    public byte getByte(long address);
    public long getSize();
}
