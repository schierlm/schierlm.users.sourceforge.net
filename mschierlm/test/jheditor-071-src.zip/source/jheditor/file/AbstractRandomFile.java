// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

import java.io.*;


public abstract class AbstractRandomFile implements RandomFile {

    public void write(byte[] b) throws IOException {
	write(b, 0, b.length);
    }
    
    public int read(byte[] b) throws IOException {
	return read(b, 0, b.length);
    }

    public void readFully(byte[] b) throws IOException {
	readFully(b, 0, b.length);
    }

    public void readFully(byte b[], int off, int len) throws IOException {
	while (len>0) {
	    int count = read(b, off, len);
	    if (count < 0)
		throw new EOFException();
	    off += count;
	    len -= count;
	}
    }
}
