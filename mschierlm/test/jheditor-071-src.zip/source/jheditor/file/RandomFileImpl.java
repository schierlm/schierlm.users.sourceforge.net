// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;
import java.io.*;

public class RandomFileImpl extends AbstractRandomFile {
    private RandomAccessFile raf;
    private File file;
    private boolean readOnly;

    public RandomFileImpl(RandomAccessFile raf, File file, boolean readOnly) {
	this.raf=raf;
	this.file=file;
	this.readOnly=readOnly;
    }

    public void seek(long pos) throws IOException{
	if (pos<0 || pos > file.length()) throw new IllegalArgumentException("Seek to"+pos);
	raf.seek(pos);
    }
    public long getLength() throws IOException {
	return raf.length();
    }
    
    public void setLength(long newLength) throws IOException{
	raf.setLength(newLength);
    }
    
    public void write(byte[] b, int off, int len) throws IOException{
	raf.write(b, off,len);
    }

    public void write(int b) throws IOException {
	raf.write(b);
    }

    public void close() throws IOException {
	raf.close();
    }
    
    public int read(byte[] b, int off, int len) throws IOException {
	return raf.read(b, off, len);
    }
    
    public int read() throws IOException {
	return raf.read();
    }

    public String getName() {
	return file.getName();
    }

    public boolean isReadOnly() {
	return readOnly;
    }
}
