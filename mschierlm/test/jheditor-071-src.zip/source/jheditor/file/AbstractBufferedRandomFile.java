// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

import java.io.*;


public abstract class AbstractBufferedRandomFile
    implements BufferedRandomFile {

    public void write(byte[] b) {
	write(b, 0, b.length);
    }
    
    public int read(byte[] b) throws IOException {
	return read(b, 0, b.length);
    }
}
