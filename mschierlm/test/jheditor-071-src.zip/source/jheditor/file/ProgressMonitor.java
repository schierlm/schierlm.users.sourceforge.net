// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004, 2005, 2006 Michael Schierl

package jheditor.file;

public interface ProgressMonitor {
    public boolean isCanceled();

    public void setProgress(long progress, long max);


}