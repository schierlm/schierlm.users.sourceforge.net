// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

import java.util.*;
import java.io.*;

public class BufferedRandomFileImpl extends AbstractBufferedRandomFile {

    private RandomFile file;
    private SortedMap changes=new TreeMap();
    private long sizeDiff=0;
    private long cachedSize;
    private TreeMap changePoints = new TreeMap();

    private long position=0, lastChange = 0, rawPosition=0, nextChange=-1;
    private boolean changedHere;

    public BufferedRandomFileImpl(RandomFile file) throws IOException {
	this.file=file;
	cachedSize=file.getLength();
    }

    public void revert() {
	changes.clear();
	changePoints.clear();
	sizeDiff=0;
	nextChange = -1;
    }

    public void save() throws IOException {
	if (file.isReadOnly()) {
	    throw new IOException("File is read only");
	}
	if (!changePoints.isEmpty()) {
	    saveChangePoints();
	}
	for (Iterator it = changes.keySet().iterator();it.hasNext();) {
	    Long key=(Long)it.next();
	    byte[] elem=(byte[])changes.get(key);
	    file.seek(key.longValue());
	    file.write(elem,0,elem.length);
	}
	changes.clear();
	changePoints.clear();
	nextChange = -1;
    }

    public int read() throws IOException {
	byte[] dummy = new byte[1];
	if ((read(dummy, 0, 1)) != 1) {
	    return -1;
	} else {
	    return dummy[0] & 0xff;
	}
    }

    public void seek(long pos) {
	if (pos > getLength()) {
	    throw new IllegalArgumentException("Outside the file");
	}
	if (pos != position) {
	    if (rawPosition != -1)
		rawPosition+= pos-position;
	    position=pos;
	}
    }

    public int read(byte[] buff, int offs, int len) throws IOException {
//	System.out.println("Read#"+offs+"/"+len);
	int read = 0;
	while (len>0) {
	    int count = lazyRead(buff, offs, len);
	    if (count < 0)
		break;
	    offs += count;
	    len  -= count;
	    read += count;
	}
	return read;
    }

    public int lazyRead(byte[] buff, int offs, int len) throws IOException{
	if (len==0) return 0;
	if (offs < 0 || len < 0 || offs+len > buff.length) {
	    throw new IndexOutOfBoundsException("Incorrect values: "+offs+
						", "+len+", "+buff.length);
	}
	if (position > getLength()) {
	    throw new RuntimeException ("assert: pointer inside file");
	} else if (position == getLength()) {
	    return -1; // end of file
	}
	fixSeek();
	if (len > nextChange-position) {
	    len = (int) (nextChange - position);
	}
	if (changedHere) {
	    if (len >1) {
		throw new RuntimeException ("Multichange byte read");
	    }
	    byte b=(byte)getChange(position);
	    buff[offs] =  b;
	} else if (rawPosition == -1) { // inserted bytes
	    Arrays.fill(buff, offs, offs+len, (byte)0);
	} else { // shifted or unmodified data
	    file.seek(rawPosition);
	    len = file.read(buff, offs, len);
	}
	position += len;
	if (rawPosition != -1)
	    rawPosition += len;
	return len;
    }


    private void fixSeek() {
	if (nextChange <= position || lastChange > position) {
	    lastChange=position;
	    if (getChange(position) != -1) {
		changedHere=true;
		nextChange = position+1;
	    } else {
		ChangePointEx cp = getRelevantChangePoint(position);
		if (cp == null) {
		    rawPosition=position;
		} else if (cp.isInsertAfter()) {
		    rawPosition = -1; // `freshly inserted byte'
		} else {
		    rawPosition= position - cp.getExPos() + cp.getPos();
		}
		nextChange = getLength(); 
		nextChange = getNextPos(changes, position+1, nextChange);
		nextChange = getNextPos(changePoints, position+1, nextChange);
		changedHere=false;
	    }
// 	    System.out.println("FixSeek prepared bytes "+position+
// 			       " to "+nextChange); // DEBUG
	}
    }
	
    private ChangePointEx getRelevantChangePoint(long address) {
	SortedMap cpBefore = changePoints.headMap(new Long(address+1));
	if (cpBefore.isEmpty()) {
	    return null;
	}
	Long posL = ((Long)cpBefore.lastKey());
	ChangePoint cp = (ChangePoint) cpBefore.get(posL);
	if (cp == null) throw new RuntimeException ("Oops, value for "+posL+
						    " is null!");
	if (posL.longValue() > address) throw new RuntimeException("Ouch!");
	return new ChangePointEx(cp, posL.longValue());
    }

    private int getChange(long offset) {
	byte[] b = (byte[])changes.get(new Long(offset));
	if (b != null) {
	    return (b[0] & 0xff);
	} 
	Long soffset = changeSpanningOver(offset);
	if (soffset != null) {
	    b = (byte[])changes.get(soffset);
	    if (b == null) throw new RuntimeException();
	    if (offset - soffset.longValue() < b.length) {
		return b[(int)(offset-soffset.longValue())] & 0xFF;
	    }
	}
	return -1;
    }

    private static long getNextPos(SortedMap tm, long after,
				   long maxValue) {
	SortedMap mapAfter=tm.tailMap(new Long(after));
	if (mapAfter.isEmpty()) {
	    return maxValue;
	} else {
	    return Math.min(maxValue, ((Long)mapAfter.firstKey()).longValue());
	}
    }

    public void write(int b) {
	write(new byte[] {(byte) b}, 0, 1);
    }

    public void write(byte[] buff, int offs, int len) {
	splitChangesAt(position);
	splitChangesAt(position+len);
	for (Iterator it = changes.subMap(new Long(position), new Long(position+len)).keySet().iterator(); it.hasNext();) {
	    it.next();
	    it.remove();
	}
	byte[] value = new byte[len];
	System.arraycopy(buff, offs, value, 0, len);
	changes.put(new Long(position), value);
	joinChangesAt(position);
	joinChangesAt(position+len);
	checkChangesConsistent(true);
	position+=len;
	if (rawPosition != -1)
	    rawPosition+=len;
	nextChange=-1;
    }

    public void insertBytes(long count) {
	if (count<0) throw new IllegalArgumentException();
	long cc = count;
	while (cc>0) {
	    cc-=tryInsertBytes(cc);
	}
    }
    
    private long tryInsertBytes(final long count) {
	if (count == 0) {
	    throw new IllegalArgumentException();
	}
	ChangePointEx relevant = getRelevantChangePoint(position);
	Long positionL = new Long(position);
	if (relevant == null) {
	    long rawAddress= position;
	    changePoints.put(positionL,
			     new ChangePoint(rawAddress, rawAddress,
					     false, true));
	    moveEntries(position, count, true);
	    changePoints.put(positionL,
			     new ChangePoint(-1,-1,true, false));
	} else if (relevant.isInsertAfter()) {
	    moveEntries(position, count, false);
	} else if (relevant.getExPos() == position) {
	    if (relevant.getPos() > relevant.getAfterPos()) {
		// reinsert deleted parts...
		if (relevant.getPos() <= relevant.getAfterPos() +count
		    && relevant.getPos() >= relevant.getAfterPos()+1
		    && !relevant.isInsertBefore()) {
		    long befcount = relevant.getPos() -
			(relevant.getAfterPos() +1);
		    changePoints.put
			(positionL,
			 new ChangePoint(relevant, relevant.getPos() -
					 befcount));
		    moveEntries(position, befcount, false);
		    changePoints.remove(positionL);
		    moveEntries(position, 1, false);
		    return befcount+1;
		} else if (relevant.getPos() <= relevant.getAfterPos() +count
			   && relevant.getPos() >= relevant.getAfterPos()+1
			   && relevant.isInsertBefore()) {
		    long befcount = relevant.getPos() -
			(relevant.getAfterPos() +1);
		    changePoints.put
			(positionL,
			 new ChangePoint(relevant, relevant.getPos() -
					 befcount-1));
		    moveEntries(position, befcount+1, false);
		    return befcount+1;	    
		} else {
		    changePoints.put
			(positionL,
			 new ChangePoint(relevant, relevant.getPos() -
					 count));
		    moveEntries(position, count, false);
		}
	    } else if (relevant.isInsertBefore()) { // another alternative...
		moveEntries(position, count, true);
	    } else { // Ahem. what is that point good for here?
		throw new RuntimeException ("What does '"+relevant+ "'do?");
	    }
	} else {
	    long rawAddress= getRawAddress(position);
	    changePoints.put(positionL,
			     new ChangePoint(rawAddress, rawAddress,
					     false, true));
	    moveEntries(position, count, true);
	    changePoints.put(positionL,
			     new ChangePoint(-1,-1,true, false));
	}
	return count;
    }

    public void deleteBytes(long count) {
	if (position+count > getLength()) return;
	long cc = count;
	while (cc>0) {
	    cc-=tryDeleteBytes(cc);
	}
    }
    
    private long tryDeleteBytes(long count) {
	Long positionL = new Long(position);
	long howfar=1;
	ChangePointEx relevant = getRelevantChangePoint(position);
	ChangePoint cp2 = (ChangePoint) changePoints.get(new Long(position+howfar));
	while (howfar < count && cp2 == null) {
	    SortedMap tail = changePoints.tailMap(new Long(position+howfar));
	    if (tail.size() > 0) {
		howfar = ((Long)tail.firstKey()).longValue();
		if (howfar > count) howfar = count;
	    } else {
		howfar = count;
	    }
	    cp2 = (ChangePoint) changePoints.get(new Long(position+howfar));
	}
	if (relevant != null && relevant.isInsertAfter()) {
	    long d = position - relevant.getExPos();
	    if (cp2 != null) {
		if (!cp2.isInsertBefore())
		    throw new RuntimeException("Assert failed");
		if (cp2.getPos() == cp2.getAfterPos() && d == 0) {
		    changePoints.remove(positionL);
		} else {
		    changePoints.put(positionL, new ChangePoint
				     (cp2.getPos(), cp2.getAfterPos(),
				      false, d != 0));
		}
	    }
	} else if (cp2 != null) {
	    if (cp2.isInsertAfter()) {
		// add the deleted characters after the insertion
		ChangePoint cp = (ChangePoint)changePoints.get(positionL);
		long killed =0;
		if (cp != null) {
		    killed = cp.getPos()-cp.getAfterPos();
		}
		if (cp != null && cp.isInsertBefore()) {
		    changePoints.remove(positionL);
		} else {
		    changePoints.put(positionL, cp2);
		}
		SortedMap s = changePoints.tailMap(new Long(position+howfar+1));
		if (s.isEmpty()) throw new RuntimeException("Ouch");
		Long key = (Long)s.firstKey();
		cp = (ChangePoint)s.get(key);
		s.put(key, new ChangePoint(cp.getPos(),
					   cp.getAfterPos()- howfar - killed,
					   false, true));
	    } else if (relevant == null) {
		changePoints.put(positionL, new ChangePoint
				 (cp2.getPos(), position,
				  false, false));
	    } else {
		long d = position - relevant.getExPos();
		changePoints.put(positionL, new ChangePoint
				 (cp2.getPos(), relevant.getAfterPos()+d,
				  false, relevant.isInsertBefore() & d == 0));
	    }
	} else if (relevant == null) {
	    changePoints.put(positionL, new ChangePoint
			     (position+howfar, position, false, false));
	} else {
	    long d = position - relevant.getExPos();
	    changePoints.put(positionL, new ChangePoint
			     (relevant.getPos()+howfar+d,
			      (d == 0?relevant.getAfterPos():relevant.getPos())
			      +d, false,
			      relevant.isInsertBefore() & d == 0));
	}
	moveEntries(position, -howfar, false);
	return howfar;
    }

    private void saveChangePoints() throws IOException {
	int length = saveChangePoints(null);
	byte[] buffer = new byte[length+1];
	saveChangePoints(buffer);
    }
    
    private int saveChangePoints(byte[] buffer) throws IOException {
	// FIXME: make shorter methods
	if (changePoints.isEmpty()) return 0;
 	int startB=0, endB=0; // modulo len
	long startF=0;
 	int len=0, maxLen = 0, blocklen;
 	SortedMap rest = changePoints;
	long startPos = 0, endPos0 = 0, rawPos = 0;
	while (endPos0 < getLength()) {
	    if (rest.isEmpty()) {
		endPos0=getLength();
	    } else {
		endPos0 = ((Long)rest.firstKey()).longValue();
		rest=rest.tailMap(new Long(endPos0+1));
	    }
	    if (endPos0 == startPos) continue;
	    for (long pos = startPos; pos < endPos0; pos+=16384) {
		long endPos = endPos0;
		if (endPos-pos > 16384) endPos = pos+16384;
		blocklen = (int) (endPos-pos);
		byte[] bb = new byte[blocklen];
		rawPos = getRawAddress(pos);
//		System.out.println(pos+" - "+ endPos + " -> "+rawPos);
		if (rawPos != -1 &&
		    pos - rawPos != (endPos-1) - getRawAddress(endPos-1)) {
		    throw new RuntimeException("Oops: "+pos+" "+rawPos+"/"+
					       (endPos-1) + "/" +
					       getRawAddress(endPos-1));
		}
		if (rawPos == -1 && getRawAddress(endPos-1) != -1 ) {
		    throw new RuntimeException("Oops!");
		}
		if (rawPos >= pos) {
		    startF = endPos; // clear buffer && finished
		    len=0;
		    startB=endB=0;
		    if (rawPos > pos && buffer != null) {
			file.seek(rawPos);
			file.readFully(bb);
			file.seek(pos);
			file.write(bb);
		    }
		} else if (rawPos == -1 || rawPos <pos ) {
		    if ((startF + len) != pos) {
			throw new RuntimeException(startF+"+"+len+" != "+pos);
		    }
		    if (rawPos != -1 && rawPos < startF)
			throw new RuntimeException("Data lost");
		    len+=bb.length;
		    if (len > maxLen) maxLen = len;
		    if (buffer != null && len > buffer.length)
			throw new RuntimeException("Buffer too small!");
		    if (buffer != null) {
			if (file.getLength() > pos) {
			    file.seek(pos);
			    int readlen = (int) (endPos-pos);
			    if (endPos > file.getLength())
				readlen =(int) (file.getLength()-pos);
			    file.readFully(bb, 0 , readlen);
			}
			for (int i=0; i<bb.length; i++) {
			    buffer[endB++] = bb[i];
			    endB %= buffer.length;
			    if (endB==startB) {
				throw new RuntimeException("Overflow");
			    }
			}
		    }
		    if (rawPos == -1) {
			if (buffer != null) {
			    bb= new byte[bb.length];
			    file.seek(pos);
			    file.write(bb);
			}
		    } else {
			while (rawPos > startF) {
			    startF++; len--;
			    if (buffer != null) {
				if (startB == endB)
				    throw new RuntimeException("Underflow");
				startB++;
				startB%=buffer.length;
			    }
			}
			len-=endPos-pos;
			startF+=endPos-pos;
			if (buffer != null) {
			    for (int i=0;i<bb.length;i++) {
				bb[i] = buffer[startB++];
				startB %=buffer.length;
			    }
			    file.seek(pos);
			    file.write(bb);
			}
		    }
		}
	    }
	    startPos=endPos0;
	}
	if (buffer != null) {
	    file.setLength(getLength());
	    cachedSize=file.getLength();
	    sizeDiff = 0;
	}
	return maxLen;
    }
	    
    private void moveEntries(long minAddress, long howFar, boolean includeCP) {
	splitChangesAt(minAddress);
	if (howFar <0) 
	    splitChangesAt(minAddress - howFar);
	sizeDiff+=howFar;
	Map newChanges = new HashMap(); 
	for(Iterator it = changes.tailMap(new Long(minAddress)).keySet().iterator(); it.hasNext();) {
	    Long key = (Long) it.next();
	    long k= key.longValue();
	    byte[] val = (byte[])changes.get(key);
	    if (k >= minAddress) {
		it.remove();
		if (k+howFar >= minAddress) {
		    newChanges.put(new Long(k+howFar), val);
		}
	    } else {
		throw new RuntimeException("Filtered?");
	    }
	}
	changes.putAll(newChanges);
	joinChangesAt(minAddress);
	checkChangesConsistent(true);
	
	Map newChangePoints = new HashMap();
	for(Iterator it = changePoints.tailMap(new Long(minAddress+(includeCP?0:1))).keySet().iterator(); it.hasNext();) {
	    Long key = (Long) it.next();
	    long k= key.longValue();
	    Object val = changePoints.get(key);
	    if (val == null) throw new RuntimeException("Not expected!");
	    if (k >= minAddress+(includeCP?0:1)) {
		it.remove();
		if (k+howFar >= minAddress+(includeCP?0:1)) {
		    newChangePoints.put(new Long(k+howFar), val);
		}
	    } else {
		throw new RuntimeException("Already filtered?");
	    }
	}
	changePoints.putAll(newChangePoints);
	nextChange=-1;
    }
    
    private void joinChangesAt(long joinAddress) {
	Long jaLong = new Long(joinAddress);
	// must be only done if there is a change directly after
	if (changes.get(jaLong) != null) {
	    SortedMap before = changes.headMap(jaLong);
	    if (before.size() > 0) {
		Long befLong = (Long)before.lastKey();
		byte[] val = (byte[])before.get(befLong);
		if (befLong.longValue() + val.length == joinAddress) {
		    byte[] val2 = (byte[])changes.get(jaLong);
		    byte[] both = new byte[val.length + val2.length];
		    System.arraycopy(val, 0, both, 0, val.length);
		    System.arraycopy(val2, 0, both, val.length, val2.length);
		    changes.put(befLong, both);
		    changes.remove(jaLong);
		}
	    }
	}
	checkChangesConsistent(false);
    }

    public void undoAt(long addressFrom, long addressTo) {	
	splitChangesAt(addressFrom);
	splitChangesAt(addressTo);
	SortedMap inside = changes.subMap(new Long(addressFrom), new Long(addressTo));
	for (Iterator it = inside.entrySet().iterator(); it.hasNext();) {
	    Map.Entry entry = (Map.Entry) it.next();
	    Long offset = (Long)entry.getKey();
	    byte[] value = (byte[])entry.getValue();
	    if (offset.longValue()+value.length > addressTo) {
		throw new RuntimeException("Should have been split before");
	    }
	    it.remove();
	}
	nextChange=addressFrom;
	checkChangesConsistent(true);
    }

    private void splitChangesAt(long splitPoint) {
	Long lastBefore = changeSpanningOver(splitPoint);
	if (lastBefore != null) {
	    byte[] lbValue = (byte[])changes.get(lastBefore);
	    byte[] nv = new byte[(int)(splitPoint - lastBefore.longValue())];
	    System.arraycopy(lbValue, 0, nv, 0, nv.length);
	    changes.put(lastBefore, nv);
	    byte[] nv2 = new byte[lbValue.length - nv.length];
	    System.arraycopy(lbValue, nv.length, nv2, 0, nv2.length);
	    changes.put(new Long(splitPoint), nv2);
	}
	checkChangesConsistent(false);
    }

    private void checkChangesConsistent(boolean mustBeOptimal) {
	long coveredTo = -1;
	for (Iterator iter = changes.entrySet().iterator(); iter.hasNext();) {
	    Map.Entry entry = (Map.Entry) iter.next();
	    Long key = (Long)entry.getKey();
	    byte[] value = (byte[])entry.getValue();
	    if (key.longValue() < coveredTo) throw new RuntimeException("Overlap detected");
	    if (key.longValue() == coveredTo && mustBeOptimal) {
		new RuntimeException("Joinable changes detected").printStackTrace();
	    }
	    coveredTo = key.longValue() + value.length;
	}
    }

    public boolean isChangedAt(long address) {
	return(getChange(address) != -1);
    }
    
    public boolean isChanged() {	
	return !changes.isEmpty() || !changePoints.isEmpty();
    }

    public boolean isInsertedHere() {
	return getRawAddress(position) == -1;
    }
    
    public boolean isDeletedBeforeHere() {
	ChangePoint cp = (ChangePoint) changePoints.get(new Long(position));
	if (cp == null || cp.isInsertAfter()) return false;
	if (cp.getPos() != cp.getAfterPos()) return true;
	return false;
    }

    public String getName() {
	return file.getName();
    }

    public void close() throws IOException {
	file.close();
    }

    public boolean isSavable() {
	return file.isReadOnly();
    }
    
    public long getLength() {
	return cachedSize + sizeDiff;
    }

    public long getFirstChange(long from, long to) {
	if (changeSpanningOver(from) != null) return from;
	long temp = getNextPos(changes, from, to);
	return getNextPos(changePoints, from, temp);
    }

    private Long changeSpanningOver(long position) {
	SortedMap before = changes.headMap(new Long(position));
	if (before.size() > 0) {
	    Long key = (Long)before.lastKey();
	    if (key.longValue() >= position) throw new RuntimeException();
	    byte[] value = (byte[])before.get(key);
	    if (key.longValue() + value.length > position)
		return key;
	}
	return null;
    }

    private long getRawAddress(long address) {
	ChangePointEx cp = getRelevantChangePoint(address);
	if (cp == null) {
	    return address;
	} else if (cp.isInsertAfter()) {
	    return -1; // freshly inserted byte
	} else {
	    return address - cp.getExPos() + cp.getPos();
	}
    }
}
