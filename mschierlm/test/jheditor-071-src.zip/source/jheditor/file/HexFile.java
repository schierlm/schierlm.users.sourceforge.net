// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;
import jheditor.compare.HexComparable;

import java.util.*;
import java.io.*;

public class HexFile implements HexComparable {

    private static final boolean USE_CACHE = true;
    
    private byte[] cache=USE_CACHE ? new byte[16384] : null;
    private long cacheStart;
    private int cacheLen;
    private boolean isReadOnly;
    private boolean cacheInvalid=false;
    private HexFileListener hfl;
    private BufferedRandomFile brf;

    private TreeSet splitMarks=new TreeSet();
    
    public HexFile(HexFileListener hfl) {
	this.hfl = hfl;
	close();
    }

    public void revert() {
	brf.revert();
	cacheInvalid=true;
    }
    
    public void save() {
    	if (brf==null || isReadOnly) return;
	try {
	    brf.save();
	} catch (IOException ex) {
	    hfl.showError(ex.toString(), "JHEditor - Save file");
	    return;
	}
	cacheInvalid=true; // for bugfixing
    }

    public boolean close() {
	return open(null,true) != 0;
    }

    /** 0 = error, 1 = ro, 2= rw */
    public int open(File f, boolean ro) {
	int result=0;
	isReadOnly=true;
	try {
	    if (brf!=null) brf.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}
	RandomAccessFile raf;
	RandomFile rf = null;
	if (f==null) {
	    raf = null;
	    rf = new DummyRandomFile(0);
	    result=1;
	} else {
	    try {
 		if (!ro) {
 		    try {
 			raf=new RandomAccessFile (f, "rw");
			rf=new RandomFileImpl(raf, f, false);
 			result=2;
			isReadOnly=false;
 		    } catch (FileNotFoundException e) {
 			//nothing, retry read only
 		    }
 		}
		if (result == 0) {
		    raf=new RandomAccessFile (f, "r");
		    rf=new RandomFileImpl(raf, f, true);
		    result = 1;
		}
	    } catch (IOException e) {
		hfl.showError(e.toString(), "JHEditor - Open file");
		raf = null;
		rf = new DummyRandomFile(0);
		result=0;
	    }
	}
	try {
	    brf=new BufferedRandomFileImpl(rf);
	} catch (IOException ex) {
	    hfl.showError(ex.toString(), "JHEditor - Open file");
	    ex.printStackTrace();
	    System.exit(1);
	}   
	cacheStart=0;
	loadCache();
	hfl.refreshFileList();
	return result;
    }

    private void loadCache() {
	if (USE_CACHE) {
	cacheLen=0;
	if (brf.getLength()==0) return;
	try {
	    brf.seek(cacheStart);
	    cacheLen=brf.read(cache);
	} catch (IOException ex) {
	    ex.printStackTrace();
	}
	}
    }
    
    public synchronized byte getByte(long address) {
	if (USE_CACHE) {
	if (cacheInvalid) noChangeEnd = -1;
	
	boolean notBehindCache = address <cacheStart+cacheLen;
	boolean notBeforeCache = address>=cacheStart;
	
	if ((cacheInvalid || !notBehindCache) && address>=brf.getLength()) {
	    throw new IllegalArgumentException("Access Outside!");
	}
	if (cacheInvalid ||
	    !(notBeforeCache && notBehindCache)) {
	    cacheStart=address-1024;
	    if (cacheStart<0) cacheStart=0;
	    loadCache();
	    notBehindCache = address <cacheStart+cacheLen;
	    notBeforeCache = address>=cacheStart;
	}
	if (!(notBeforeCache && notBehindCache)) {
	    new Exception("Cache miss at pos "+address +
			  "(cache start at "+cacheStart+", cache size "+
			  cacheLen+", LOF = "+
			  brf.getLength()+")").printStackTrace();
	    return 0;
	}
	cacheInvalid=false;
	return cache[(int)(address-cacheStart)];
	} else {
	    try {
	    brf.seek(address);
	    int b=brf.read();
	    if(b==-1) throw new RuntimeException("End of file!");
	    return (byte) b;
	    } catch (IOException ex) {
		ex.printStackTrace();
		throw new RuntimeException(ex.toString());
	    }
	}
    }
    
    public void setByte(long address, byte value) {
	brf.seek(address);
	brf.write(value);
	cacheInvalid=true;
    }
    
    public void setBytes(long address, byte[] values) {
	brf.seek(address);
	brf.write(values);
	cacheInvalid = true;
    }

    public void insertBytes(long address, long count) {
	brf.seek(address);
	brf.insertBytes(count);
	moveEntries(address, (int) count);
	cacheInvalid=true;
    }

    public void deleteBytes(long address, long count) {
	brf.seek(address);
	brf.deleteBytes(count);
	moveEntries(address, (int) -count);
	cacheInvalid=true;
    }

    private void moveEntries(long minAddress, int howFar) {
	Set newSplitMarks = new HashSet();
	for (Iterator it = splitMarks.iterator(); it.hasNext();) {
	    Long val = (Long) it.next();
	    long v = val.longValue();
	    if (v >= minAddress) {
		it.remove();
		if (v+howFar >= minAddress) {
		    newSplitMarks.add(new Long(v+howFar));
		}
	    }
	}
	splitMarks.addAll(newSplitMarks);
    }
    
    public void undo(long address) {
	brf.undoAt(address, address+1);
	cacheInvalid=true;
    }
    
    public boolean isChanged() {
	return brf.isChanged();	
    }

    public boolean isChanged(long address) {
	return updateCache(address) && brf.isChangedAt(address);

    }

    public boolean isInserted(long address) {
//	if (!updateCache(address)) return false; // FIXME
	brf.seek(address);
	return brf.isInsertedHere();
    }
    
    public boolean isGapBefore(long address) {
	if (!updateCache(address)) return false;
	brf.seek(address);
	return brf.isDeletedBeforeHere();
    }

    private long noChangeStart=-1, noChangeEnd=-1;

    /**
     * Update the cache where no changes are
     * @return if there are changes at address
     */
    private boolean updateCache(long address) {
	if (cacheInvalid || noChangeStart > address
	    || noChangeEnd <= address) {
	    noChangeEnd = brf.getFirstChange(address, brf.getLength());
	    noChangeStart=address;
	    return noChangeEnd == address;
	} else {
	    return false;
	}
    }

    public long nextChange(long after) {
	return brf.getFirstChange(after, brf.getLength());
    }
        
    public long getSize() {
	return brf.getLength();
    }

    public long getPosition (byte[] ba, long from, boolean icase,
			     ProgressMonitor pm) {
	if (ba.length == 0) return -1;
	long p=from;
	long size = brf.getLength();
	long cnt=0;
	long refreshInterval = size / 100;
	if (refreshInterval == 0) refreshInterval = 1;
	loop:
	while(p< size-ba.length) {
	    if (pm.isCanceled()) return -1;
	    cnt++;
	    if (cnt%refreshInterval == 0)
		pm.setProgress(cnt, size);
	    if (isequal(getByte(p),ba[0],icase)) {
		for(int i=1;i<ba.length;i++) {
		    if (!isequal(getByte(p+i),ba[i],icase)) {
			p++;
			continue loop;
		    }
		}
		return p;
	    }
	    p++;
	}
	p=0;
	loop2:
	while (p<from) {
	    if (pm.isCanceled()) return -1;
	    cnt++;
	    if (cnt%refreshInterval == 0)
		pm.setProgress(cnt, size);
	    if (getByte(p)==ba[0]) {
		for(int i=1;i<ba.length;i++) {
		    if (getByte(p+i) != ba[i]) {
			p++;
			continue loop2;
		    }
		}
		return p;
	    }
	    p++;
	}
	return -1;
    }
    
    private boolean isequal(byte b1, byte b2, boolean icase) {
	if (!icase)
	    return b1==b2;
	else
	    return Character.toUpperCase((char)b1) ==
		Character.toUpperCase((char)b2);
    }
    
    public void setSplitMarks(TreeSet splitMarks) {
	this.splitMarks=splitMarks;
    }

    public TreeSet getSplitMarks() {
	return splitMarks;
    }

    public String getName() {
	return brf.getName();
    }

    public void writeByteBlock(long start, long end, BufferedOutputStream out)
	throws IOException {
	byte[] buff = new byte[65536];
	brf.seek(start);
	long pos = start;
	int len;
	while (pos < end) {
	    long lenL = end - pos;
	    if (lenL > buff.length) {
		len = buff.length;
	    } else {
		len = (int) lenL;
	    }
	    int realLen = brf.read(buff, 0 ,len);
	    out.write(buff, 0, realLen);
	    pos+=realLen;
	}
    }
	
    public boolean isReadOnly() {
	return isReadOnly;
    }
}
