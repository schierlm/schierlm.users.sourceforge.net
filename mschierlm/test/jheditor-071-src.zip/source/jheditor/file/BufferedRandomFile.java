// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

import java.io.*;

public interface BufferedRandomFile {

    public void revert();
    public void save() throws IOException;
			// similar to flush, you won't be able to
			// revert after that

    public void insertBytes(long count);
    public void deleteBytes(long count);
    public void undoAt(long addressFrom, long addressTo);
    public boolean isChangedAt(long address);
    public boolean isChanged();
    public boolean isInsertedHere();
    public boolean isDeletedBeforeHere();
    public boolean isSavable();
    public void seek(long pos);
    public long getLength();
    public void write(byte[] b, int off, int len);
    public void write(byte[] b);
    public void write(int b);
    public int read(byte[] b, int off, int len) throws IOException;
    public int read(byte[] b) throws IOException;
    public int read() throws IOException;
    public void close() throws IOException;
    public String getName();

    public long getFirstChange(long from, long to);

}
