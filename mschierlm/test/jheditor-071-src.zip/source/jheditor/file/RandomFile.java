// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

import java.io.*;

public interface RandomFile {

    public void seek(long pos) throws IOException;

    public long getLength() throws IOException;
    public void setLength(long newLength) throws IOException;
    public void write(byte[] b, int off, int len) throws IOException;
    public void write(byte[] b) throws IOException;
    public void write(int b) throws IOException;
    public int read(byte[] b, int off, int len) throws IOException;
    public int read(byte[] b) throws IOException;
    public void readFully(byte[] b) throws IOException;
    public void readFully(byte[] b, int off, int len) throws IOException;
    public int read() throws IOException;
    public boolean isReadOnly();
    public void close() throws IOException;

    public String getName();

}
