// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

public class ChangePoint {

    private long pos, after;
    private boolean insAfter, insBefore;

    public ChangePoint(ChangePoint toCopy, long newPos) {
	this(newPos, toCopy.after, toCopy.insAfter, toCopy.insBefore);
    }
    
    public ChangePoint(long pos, long afterPos, boolean insertAfter,
		       boolean insertBefore) {
	if (pos < afterPos) throw new IllegalArgumentException
				("Invalid Position");
	if (insertBefore && insertAfter) throw new IllegalArgumentException
					     ("Useless point.");
	if (pos == afterPos &&
	    !insertBefore && !insertAfter) throw new IllegalArgumentException
					       ("Useless point.");
	this.pos=pos; after=afterPos; insAfter=insertAfter;
	insBefore = insertBefore;
    }

    public long getPos() {return pos;}
    public long getAfterPos() {return after;}

    public boolean isInsertAfter() {return insAfter;}
    public boolean isInsertBefore() {return insBefore;}

    public boolean equals(Object obj) {
	if (obj instanceof ChangePoint) {
	    return ((ChangePoint)obj).pos == pos;
	} else {
	    return false;
	}
    }

    public String toString() {
	return getClass().getName()+": "+after+".."+pos+(insAfter?" I>":"")+
	    (insBefore?" I<":"");
    }
}
	
