// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

public class ChangePointEx extends ChangePoint {

    private long exPos;

    public ChangePointEx(ChangePoint cp, long exPos) {
	super(cp.getPos(), cp.getAfterPos(), cp.isInsertAfter(),
	      cp.isInsertBefore());
	this.exPos=exPos;
    }
    public long getExPos() { return exPos;}
}
	
