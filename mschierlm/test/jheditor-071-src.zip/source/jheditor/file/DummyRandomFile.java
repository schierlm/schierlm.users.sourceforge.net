// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;
import java.io.*;
import java.util.*;

public class DummyRandomFile extends AbstractRandomFile {
    private long size;
    private long pos;

    public DummyRandomFile(long size) {
	this.size=size;
    }

    public void seek(long pos) {
	this.pos = pos;
    }
    public long getLength() {
	return size;
    }
    
    public void setLength(long newLength) throws IOException{
	size=newLength;
    }
    
    public void write(byte[] b, int off, int len) throws IOException {
	throw new IOException("File is read only");
    }

    public void write(int b) throws IOException {
	throw new IOException("File is read only");
    }

    public void close() {}
    
    public int read(byte[] b, int off, int len) throws IOException {
	if (pos == size) {
	    return -1;
	}
	if (len > size - pos) {
	    len = (int) (size - pos);
	}
	Arrays.fill(b, off, off+len, (byte) 0);
	pos+=len;
	return len;
    }
    
    public int read() throws IOException {
	if (pos == size)  return -1;
	pos++;
	return 0;
    }

    public String getName() {
	return null;
    }

    public boolean isReadOnly() {
	return true;
    }
}
