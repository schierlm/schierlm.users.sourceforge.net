// JHEditor is licensed under GNU General Public License.
// (c) 2002, 2003, 2004 Michael Schierl

package jheditor.file;

/** All kinds of events a HexFile might fire... */
public interface HexFileListener {
    void showError(String message, String title);
    void refreshFileList();
}
