package jheditor;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.util.Arrays;

public class SystemClipboardTest {
    public static void main(String[] args) {
	for(int i=1024; i<10*1024*1024; i*=2) {
	    char[] data = new char[i];
	    Arrays.fill(data, 'a');
	    String txt = new String(data);
	    System.out.print(i+"...");
	    StringSelection ss=new StringSelection(txt);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents
	    (ss,ss);
	    System.out.println("ok");
	}
    }
}
