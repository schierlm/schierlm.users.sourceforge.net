#define UNICODE
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows 
#include <wchar.h>
#include <windows.h>


DWORD runClient(LPWSTR name, LPWSTR path, LPSTARTUPINFOW psi, 

				LPPROCESS_INFORMATION ppi) {
					DWORD exitcode;
					BOOL created = CreateProcess(name, path, NULL, NULL, FALSE, 

						CREATE_NO_WINDOW , NULL, NULL, psi, ppi);
					if (!created) {
						MessageBox(NULL, L"Could not create process", L"OpenWith", 0);
						ExitProcess(1);
					}
					WaitForSingleObject(ppi->hProcess, INFINITE);
					if (!GetExitCodeProcess(ppi->hProcess, &exitcode)) {
						MessageBox(NULL, L"Could not get exit code", L"OpenWith", 0);
						return 1;
					}
					CloseHandle(ppi->hProcess);
					CloseHandle(ppi->hThread);
					return exitcode;
}

int wmain_(int argc, WCHAR* argv[])
{
	wchar_t *ptr, *ptr2;
	STARTUPINFOW si;
	PROCESS_INFORMATION pi;
	TCHAR name[MAX_PATH*2+32], path[MAX_PATH+32], args[MAX_PATH*2+32], 

		emacs[MAX_PATH+32];

	if (argc != 2 || wcslen(argv[0]) >MAX_PATH || wcslen(argv[1]) >MAX_PATH) {
		MessageBox(NULL, L"Invalid arguments", L"OpenWith", 0);
		return 1;
	}
	ptr = path;
	wcscpy(path, argv[0]);
	while(ptr != NULL) {
		ptr2 = ptr;
		ptr = wcschr(ptr2+1, L'\\');
	}
	if (ptr2 == path) {
		*ptr2=L'.';
		ptr2++;
	}
	*ptr2 = 0;
	wsprintf(name, L"%s\\emacsclient.exe", path);
	wsprintf(args,  L"emacsclient %s", argv[1]);
	memset(&si, 0, sizeof(si));
	memset(&pi, 0, sizeof(pi));
	si.cb = sizeof(si);
	si.dwFlags = 0;
	si.wShowWindow = SW_HIDE;
	DWORD exitcode;
	exitcode = runClient(name, args, &si, &pi);
	if (exitcode != 0) {
		int i;
		wsprintf(emacs, L"%s\\emacs.exe", path);

		BOOL created = CreateProcess(emacs, L"emacs", NULL, NULL, FALSE, 

			CREATE_NO_WINDOW , NULL, NULL, &si, &pi);
		if (!created) {
			MessageBox(NULL, L"Could not create Emacs process", 

				L"OpenWith", 0);
			return 1;
		}
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);

		for (i=0; i<20; i++) {
			exitcode = runClient(name, args, &si, &pi);
			Sleep(1000);
			if (exitcode == 0) break;
		}
		if (exitcode != 0) {
			MessageBox(NULL, L"Could not send file", L"OpenWith", 0);
			return 1;
		}
	}
	return 0;
}

int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 char* lpCmdLineX,
					 int       nCmdShow)
{
	WCHAR* cmdline = GetCommandLine();
	WCHAR buffer[MAX_PATH*2+1];
	WCHAR* args[2];
	if (wcslen(cmdline)>MAX_PATH*2) {
		MessageBox(NULL, L"Invalid Arguments", L"OpenWith", 0);
		return 1;
	}
	wcscpy(buffer, cmdline);
	if (cmdline[0] == '"') {
		WCHAR* pos = wcschr(buffer+1, '"');
		if (pos == NULL) {
			MessageBox(NULL, L"Invalid Arguments", L"OpenWith", 0);
			return 1;
		}
		args[0] = buffer+1;
		args[1] = pos+2;
		*pos = L'\0';
	} else {
		WCHAR* pos = wcschr(buffer, ' ');
		if (pos == NULL) {
			MessageBox(NULL, L"Invalid Arguments", L"OpenWith", 0);
			return 1;
		}
		args[0] = buffer;
		args[1] = pos+1;

		*pos = L'\0';
	}
	return wmain_(2, args);
}
