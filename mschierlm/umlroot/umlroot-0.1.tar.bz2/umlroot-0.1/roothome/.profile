export PATH=/host/sbin:/usr/local/sbin:/usr/sbin:/bin:/usr/local/bin:/usr/bin:/uml
export PWD=/root
cd $PWD
ls () { /uml/ls --color=auto "$@";}
cd () { command cd "$@";PWD="`pwd`";PS1="$PWD# ";}
halt() { echo 'use "exit"'; }

exec /bin/bash
