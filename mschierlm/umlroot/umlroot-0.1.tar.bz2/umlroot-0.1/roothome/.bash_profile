. .bash_rc
