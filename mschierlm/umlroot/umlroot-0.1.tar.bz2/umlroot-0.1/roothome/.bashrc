eval `dircolors -b`
alias ls='ls --color=auto'
#alias dir='ls --color=auto --format=vertical'
#alias vdir='ls --color=auto --format=long'

# some more ls aliases
alias ll='ls -l'
alias la='ls -A'
alias l='ls -CF'

# set a fancy prompt
PS1='\u@\h:\w\$ '

alias halt='echo use "exit"'

