Tagfetch V0.11 - fetches Taglines from your news server
==============


(c) 2002 Michael Schierl

http://home.nexgo.de/mschierlm/agttool/

Contact me at: sm-soft@gmx.de

You can get VB runtime from the URL above.


There is a virus in your package!
---------------------------------

Update your anti-virus program. MSWINSCK.OCX is no virus, but a file needed 
by the TagFetch tool. If you do not want to use that tool, you can delete it.

THis file helps to create TCP/IP connection. As it is used by some trojan 
horses to "phone home", it was detected as a virus by former versions of
F-PROT antivirus.