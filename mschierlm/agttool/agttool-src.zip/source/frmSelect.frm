VERSION 5.00
Begin VB.Form frmSelect 
   BorderStyle     =   4  'Festes Werkzeugfenster
   Caption         =   "Select Action"
   ClientHeight    =   4215
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   8670
   Icon            =   "frmSelect.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4215
   ScaleWidth      =   8670
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'Bildschirmmitte
   Begin VB.CommandButton cmdShowMain 
      Caption         =   "Show &AgtTool"
      Height          =   375
      Left            =   7080
      TabIndex        =   14
      Top             =   2880
      Width           =   1455
   End
   Begin VB.Frame Frame2 
      Caption         =   "Hamster Score"
      Height          =   1095
      Left            =   4320
      TabIndex        =   9
      Top             =   1920
      Visible         =   0   'False
      Width           =   1455
      Begin VB.CommandButton cmdHamGlobal 
         Caption         =   "&Global"
         Enabled         =   0   'False
         Height          =   255
         Left            =   120
         TabIndex        =   12
         Top             =   720
         Width           =   1215
      End
      Begin VB.CommandButton cmdHamXP 
         Caption         =   "X-P&ost"
         Enabled         =   0   'False
         Height          =   255
         Left            =   120
         TabIndex        =   11
         Top             =   480
         Width           =   1215
      End
      Begin VB.CommandButton cmdHamLocal 
         Caption         =   "&Local"
         Enabled         =   0   'False
         Height          =   255
         Left            =   120
         TabIndex        =   10
         Top             =   240
         Width           =   1215
      End
   End
   Begin VB.CommandButton cmdPGP 
      Caption         =   "Verify &PGP Sig"
      Enabled         =   0   'False
      Height          =   375
      Left            =   7080
      TabIndex        =   13
      Top             =   2040
      Width           =   1455
   End
   Begin VB.CommandButton cmdSupersede 
      Caption         =   "&Supersede Article"
      Enabled         =   0   'False
      Height          =   375
      Left            =   7080
      TabIndex        =   8
      Top             =   1560
      Width           =   1455
   End
   Begin VB.Frame Frame1 
      Caption         =   "References:"
      Height          =   3615
      Left            =   120
      TabIndex        =   5
      Top             =   480
      Width           =   6855
      Begin VB.ListBox lstMids 
         Height          =   2595
         ItemData        =   "frmSelect.frx":000C
         Left            =   240
         List            =   "frmSelect.frx":0037
         TabIndex        =   7
         Top             =   240
         Width           =   6375
      End
      Begin VB.CommandButton cmdRef 
         Caption         =   "&0"
         Height          =   375
         Index           =   0
         Left            =   240
         TabIndex        =   6
         Top             =   3000
         Width           =   375
      End
   End
   Begin VB.CommandButton cmdXFace 
      Caption         =   "Show &X-Face"
      Height          =   375
      Left            =   7080
      TabIndex        =   1
      Top             =   600
      Width           =   1455
   End
   Begin VB.CommandButton cmdcancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   7080
      TabIndex        =   4
      Top             =   3720
      Width           =   1455
   End
   Begin VB.CommandButton cmdCopyMid 
      Caption         =   "&Copy Message-ID"
      Height          =   375
      Left            =   7080
      TabIndex        =   3
      Top             =   1080
      Width           =   1455
   End
   Begin VB.TextBox txtMid 
      BackColor       =   &H8000000F&
      Height          =   285
      Left            =   1200
      Locked          =   -1  'True
      TabIndex        =   2
      Top             =   120
      Width           =   7335
   End
   Begin VB.Label Label1 
      Caption         =   "Message-ID:"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1095
   End
End
Attribute VB_Name = "frmSelect"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Dim midlist$(9), noforce As Boolean

Private Sub cmdcancel_Click()
Unload Me
End Sub

Private Sub cmdCopyMid_Click()
On Error Resume Next
Clipboard.Clear
Clipboard.SetText txtMid.Text
Unload Me
End Sub

Private Sub cmdPGP_Click()
Dim rawflag As Boolean, headerflag As Boolean
Dim cl$, tde As Boolean, t!, i As Integer
Dim schonmal As Boolean
noforce = True
Me.Hide
ForceForegroundWindow2 F12AgentWnd
On Error Resume Next
For i = 1 To 100
Err.Clear
Clipboard.Clear
If Err.Number = 0 Then Exit For
t! = Timer: Do: Loop Until t + 0.1 < Timer
Next
CriticalErrorOn i = 101, "Unable to access system clipboard (cmdPGP_Click:1)"
On Error GoTo 0
tde = frmmain.tmrDo.Enabled
frmmain.tmrDo.Enabled = False
If isMenuChecked(F12AgentWnd, AgentProperties(F12Version).mnuRawView) <> 1 Then ' keine Rohansicht
sendcommand F12AgentWnd, AgentProperties(F12Version).mnuRawView
rawflag = True
End If
If isMenuChecked(F12AgentWnd, AgentProperties(F12Version).mnuShowAllHeaders) <> 1 Then ' keine Headers
headerflag = True
sendcommand F12AgentWnd, AgentProperties(F12Version).mnuShowAllHeaders
End If
SendKeys "3^a^chh", True
If headerflag Then sendcommand F12AgentWnd, AgentProperties(F12Version).mnuShowAllHeaders
If rawflag Then sendcommand F12AgentWnd, AgentProperties(F12Version).mnuRawView
t! = Timer
Do: DoEvents: Loop Until t + 0.1 < Timer
Do: DoEvents
cl$ = Clipboard.GetText
Loop Until cl$ <> "" Or t + 5 < Timer
If InStr(UCase$(cl$), "X-PGP-SIG: ") = 0 And InStr(UCase$(cl$), "-----BEGIN PGP SIGNED MESSAGE-----") = 0 Then
MsgBox "No PGP signature received."
End If
frmmain.tmrDo.Enabled = tde
If cl$ = "" Then MsgBox "Timing error": Exit Sub
frmPGP.Show
Unload Me
End Sub

Private Sub cmdRef_Click(Index As Integer)
Me.Hide: DoEvents
ForceForegroundWindow2 F12AgentWnd: DoEvents
goToReference Index
'Beep
Unload Me
End Sub

Sub goToReference(Index As Integer)
Dim ex$
Dim tim As Single
If isMenuChecked(F12AgentWnd, AgentProperties(F12Version).mnuShowAllHeaders) = 1 Then ex$ = "" Else ex$ = "h"
Clipboard.Clear
Clipboard.SetText noeck$(midlist$(Index))
SendKeys ex$ + "^F", True: DoEvents
Do: Loop Until GetForegroundWindow <> F12AgentWnd
SendKeys "^V{Enter}", True: DoEvents
Do: Loop Until GetForegroundWindow = F12AgentWnd
SendKeys "^j", True: DoEvents
tim = Timer:
Do: Loop Until Timer - tim > 0.1 And GetForegroundWindow = F12AgentWnd
If ex$ <> "" Then SendKeys ex$, True: DoEvents
End Sub

Private Sub cmdShowMain_Click()
Unload Me
parsespecial "sh"
End Sub

Private Sub cmdSupersede_Click()
Dim art$, i As Integer, he$, bo$, lang$, x$
Me.Hide
ForceForegroundWindow2 F12AgentWnd
noforce = True
art$ = Clipboard.GetText
i = InStr(art$, vbNewLine + vbNewLine)
If i = 0 Then MsgBox "No article in Clipboard", vbInformation, "AgtTool": Exit Sub
he$ = Left$(art$, i - 1)
bo$ = Mid$(art$, i + 4)
lang$ = languageKeys(instanceInfoForHwnd(F12AgentWnd, "Supersede error (1)").language)
SendKeys "f", True
If isMenuChecked(F12AgentWnd, AgentProperties(F12Version).mnuAllFields) = 0 Then 'All Fields not selected
sendcommand F12AgentWnd, AgentProperties(F12Version).mnuAllFields
End If
Clipboard.Clear
Clipboard.SetText (getheader2(he$, "Newsgroups"))
SendKeys "%" + Left$(lang$, 1) + "^v", True
Clipboard.Clear
Clipboard.SetText (getheader2(he$, "Subject"))
SendKeys "%" + Mid$(lang$, 2, 1) + "^v", True
x$ = getheader2(he$, "Followup-To")
If x$ <> "" Then
Clipboard.Clear
Clipboard.SetText x$
SendKeys "%" + Mid$(lang$, 4, 1) + "fo{tab}^v", True
End If
Clipboard.Clear
Clipboard.SetText (txtMid.Text)
SendKeys "%" + Mid$(lang$, 4, 1) + "supe{tab}^v", True
Clipboard.Clear
Clipboard.SetText bo$
SendKeys "%" + Mid$(lang$, 6, 1) + "{end}" + _
         "%" + Mid$(lang$, 7, 1) + "^a^v^{Home}", True
Unload Me
End Sub

Function getheader2(he$, nam$)
getheader2 = Mid$(GetHeader(he$, nam$), Len(nam$) + 3)
End Function
Private Sub cmdXFace_Click()
doxface
Unload Me
End Sub

Sub doxface()
Dim x$, i As Integer
x$ = Clipboard.GetText
i = InStr(UCase$(x$), "X-FACE: ")
If i <> 0 Then
x$ = Mid$(x$, i + 8)
x$ = Replace(Replace(x$, vbNewLine + " ", ""), vbNewLine + vbTab, "")
i = InStr(x$, vbNewLine)
If i = 0 Then i = Len(x$) + 1
x$ = Left$(x$, i - 1)
HandleXFace (x$)
ElseIf frmXFace.Visible = True Then
frmXFace.Hide
End If
End Sub
Private Sub Form_KeyPress(KeyAscii As Integer)
Select Case UCase(Chr$(KeyAscii))
Case "A": If cmdShowMain.Enabled = True Then cmdShowMain.Value = True
Case "S": If cmdSupersede.Enabled = True Then cmdSupersede.Value = True
Case "X": If cmdXFace.Enabled = True Then cmdXFace.Value = True
Case "C": cmdCopyMid.Value = True
Case "P": If cmdPGP.Enabled = True Then cmdPGP.Value = True
Case "0" To "9": If cmdRef(KeyAscii - Asc("0")).Enabled = True Then cmdRef(KeyAscii - Asc("0")).Value = True
Case Else
End Select
End Sub

Private Sub Form_Load()
Dim i As Integer, cl$, x$, ii As Integer
noforce = False
For i = 1 To 9
Load cmdRef(i)
cmdRef(i).Left = cmdRef(0).Left + i * 500 + 120
cmdRef(i).Top = cmdRef(0).Top
cmdRef(i).Caption = "&" & i
cmdRef(i).Visible = True
midlist(i) = ""
Next
midlist(0) = ""
SetWindowPos Me.hwnd, -1, 0, 0, 0, 0, 3
ForceForegroundWindow2 Me.hwnd
cl$ = Clipboard.GetText
i = InStr(UCase(cl$), vbNewLine + "-----BEGIN PGP SIGNED MESSAGE-----" + vbNewLine)
If i <> 0 Then cmdPGP.Enabled = True
If xface = False Then cmdXFace.Enabled = False
i = InStr(cl$, vbNewLine + vbNewLine)
cl$ = Left$(cl$, i + 1)
cl$ = Replace(cl$, vbNewLine + " ", " ")
cl$ = Replace(cl$, vbNewLine + vbTab, " ")
i = InStr(UCase$(cl$), vbNewLine + "FROM: " + UCase(SupersedesFrom) + vbNewLine)
If i <> 0 Then cmdSupersede.Enabled = True
i = InStr(UCase$(cl$), vbNewLine + "X-PGP-SIG: ")
If i <> 0 Then cmdPGP.Enabled = True
i = InStr(UCase(cl$), vbNewLine + "MESSAGE-ID: ")
If i <> 0 Then
x$ = Mid$(cl$, i + 14)
x$ = Left$(x$, InStr(x$, vbNewLine) - 1)
txtMid.Text = x$
End If
i = InStr(UCase(cl$), vbNewLine + "REFERENCES: ")
If i <> 0 Then
x$ = Mid$(cl$, i + 14)
x$ = Left$(x$, InStr(x$, vbNewLine) - 1)
i = InStr(x$, " ")
If i = 0 Then i = Len(x$) + 1
midlist$(0) = Left$(x$, i - 1)
For i = 1 To 9
ii = InStrRev(x$, " ")
If ii = 0 Then
midlist$(i) = x$: x$ = ""
Else
midlist$(i) = Mid$(x$, ii + 1)
x$ = RTrim$(Left$(x$, ii - 1))
End If
Next
End If
lstMids.Clear
For i = 0 To 9
lstMids.AddItem i & "  " & midlist$(i)
If i = 0 Then lstMids.AddItem ""
If midlist$(i) = "" Then cmdRef(i).Enabled = False
Next
End Sub


Function noeck$(ByVal x$)
If Left$(x$, 1) = "<" Then x$ = Mid$(x$, 2)
If Right$(x$, 1) = ">" Then x$ = Left$(x$, Len(x$) - 1)
noeck$ = x$
End Function

Sub doAction(actionnumber As Integer)
Load Me
If actionnumber = 32 Or actionnumber = Asc("*") Then
Me.Show
Else
Form_KeyPress actionnumber
Unload Me
End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
If noforce = False Then ForceForegroundWindow2 F12AgentWnd
End Sub
