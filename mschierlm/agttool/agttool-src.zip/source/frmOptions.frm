VERSION 5.00
Begin VB.Form frmOptions 
   BorderStyle     =   3  'Fester Dialog
   Caption         =   "Options"
   ClientHeight    =   4800
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7935
   Icon            =   "frmOptions.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4800
   ScaleWidth      =   7935
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'Fenstermitte
   Begin VB.TextBox txtActionChar 
      Height          =   285
      Left            =   4920
      MaxLength       =   1
      TabIndex        =   51
      Text            =   "#"
      Top             =   1800
      Width           =   375
   End
   Begin VB.CheckBox chkF2 
      Caption         =   "F2"
      Height          =   255
      Left            =   3360
      TabIndex        =   48
      Top             =   5160
      Visible         =   0   'False
      Width           =   615
   End
   Begin VB.CheckBox chkF11 
      Caption         =   "F11"
      Height          =   255
      Left            =   4080
      TabIndex        =   47
      Top             =   5160
      Visible         =   0   'False
      Width           =   615
   End
   Begin VB.CheckBox chkF12 
      Caption         =   "F12"
      Height          =   255
      Left            =   4800
      TabIndex        =   46
      Top             =   5160
      Visible         =   0   'False
      Width           =   615
   End
   Begin VB.ComboBox cmbFxAction 
      Height          =   315
      Index           =   2
      Left            =   720
      Style           =   2  'Dropdown-Liste
      TabIndex        =   42
      Top             =   840
      Width           =   2295
   End
   Begin VB.ComboBox cmbFxAction 
      Height          =   315
      Index           =   1
      Left            =   720
      Style           =   2  'Dropdown-Liste
      TabIndex        =   41
      Top             =   480
      Width           =   2295
   End
   Begin VB.ComboBox cmbFxAction 
      Height          =   315
      Index           =   0
      Left            =   720
      Style           =   2  'Dropdown-Liste
      TabIndex        =   40
      Top             =   120
      Width           =   2295
   End
   Begin VB.Frame Frame1 
      Height          =   1695
      Left            =   120
      TabIndex        =   26
      Top             =   2280
      Width           =   3975
      Begin VB.CheckBox chk_OLC 
         Caption         =   "Get New Groups"
         Height          =   255
         Index           =   4
         Left            =   240
         TabIndex        =   32
         Top             =   1200
         Width           =   3255
      End
      Begin VB.CheckBox chk_OLC 
         Caption         =   "Get New Headers in Subscribed Groups"
         Height          =   255
         Index           =   3
         Left            =   240
         TabIndex        =   31
         Top             =   960
         Width           =   3135
      End
      Begin VB.CheckBox chk_OLC 
         Caption         =   "Get Marked Message Bodies"
         Height          =   255
         Index           =   2
         Left            =   240
         TabIndex        =   30
         Top             =   720
         Width           =   2535
      End
      Begin VB.CheckBox chk_OLC 
         Caption         =   "Check for New Email"
         Height          =   255
         Index           =   1
         Left            =   240
         TabIndex        =   29
         Top             =   480
         Width           =   2655
      End
      Begin VB.CheckBox chk_OLC 
         Caption         =   "Post Usenet and Email Messages"
         Height          =   255
         Index           =   0
         Left            =   240
         TabIndex        =   28
         Top             =   240
         Width           =   2775
      End
      Begin VB.CheckBox chkWinO 
         Caption         =   "Use Window+O for online activities:"
         Height          =   255
         Left            =   120
         TabIndex        =   27
         Top             =   0
         Width           =   2895
      End
   End
   Begin VB.PictureBox pctNotImpl 
      BackColor       =   &H80000018&
      BorderStyle     =   0  'Kein
      Height          =   255
      Left            =   600
      ScaleHeight     =   255
      ScaleWidth      =   135
      TabIndex        =   24
      Top             =   4680
      Visible         =   0   'False
      Width           =   135
      Begin VB.Shape Shape1 
         BorderColor     =   &H000000FF&
         Height          =   735
         Left            =   120
         Top             =   0
         Width           =   4815
      End
      Begin VB.Label Label11 
         Alignment       =   2  'Zentriert
         BackStyle       =   0  'Transparent
         Caption         =   "Not implemented yet."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000017&
         Height          =   495
         Left            =   120
         TabIndex        =   25
         Top             =   120
         Width           =   4575
      End
   End
   Begin VB.TextBox txtAgentWait 
      Height          =   195
      Left            =   1560
      TabIndex        =   23
      Text            =   "5"
      Top             =   5160
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtAFClipPrefix 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Left            =   4920
      TabIndex        =   22
      Top             =   1440
      Width           =   2775
   End
   Begin VB.CheckBox chkPGP 
      Caption         =   "PGP: Press Ctrl+Shift+D"
      Height          =   255
      Left            =   240
      TabIndex        =   20
      Top             =   1680
      Width           =   2175
   End
   Begin VB.TextBox txtHamScoring 
      Enabled         =   0   'False
      Height          =   285
      Left            =   480
      TabIndex        =   19
      Text            =   "+100"
      Top             =   5040
      Visible         =   0   'False
      Width           =   735
   End
   Begin VB.TextBox txtHamster 
      Enabled         =   0   'False
      Height          =   285
      Left            =   1320
      TabIndex        =   17
      Top             =   4920
      Visible         =   0   'False
      Width           =   735
   End
   Begin VB.TextBox txtSuper 
      Height          =   285
      Left            =   2280
      TabIndex        =   15
      Top             =   4200
      Width           =   2415
   End
   Begin VB.TextBox txtSleep 
      Height          =   285
      Left            =   4920
      MaxLength       =   4
      TabIndex        =   12
      Top             =   1080
      Width           =   615
   End
   Begin VB.TextBox txtRefresh 
      Height          =   285
      Left            =   4920
      MaxLength       =   4
      TabIndex        =   10
      Top             =   720
      Width           =   615
   End
   Begin VB.TextBox txtHintNum 
      Height          =   285
      Left            =   6360
      MaxLength       =   2
      TabIndex        =   8
      Top             =   240
      Width           =   495
   End
   Begin VB.ComboBox cmbHints 
      Height          =   315
      ItemData        =   "frmOptions.frx":000C
      Left            =   4440
      List            =   "frmOptions.frx":001C
      Style           =   2  'Dropdown-Liste
      TabIndex        =   7
      Top             =   240
      Width           =   1815
   End
   Begin VB.CheckBox chkMinimizeAtStartup 
      Caption         =   "Minimize at startup"
      Height          =   255
      Left            =   240
      TabIndex        =   3
      Top             =   1440
      Width           =   2175
   End
   Begin VB.CheckBox chkHideAtStartup 
      Caption         =   "Hide at startup"
      Height          =   255
      Left            =   240
      TabIndex        =   2
      Top             =   1200
      Width           =   2175
   End
   Begin VB.CommandButton cmdcancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   4920
      TabIndex        =   1
      Top             =   4200
      Width           =   1335
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   6360
      TabIndex        =   0
      Top             =   4200
      Width           =   1455
   End
   Begin VB.Frame Frame2 
      Caption         =   "Troubleshooting Options"
      Height          =   1815
      Left            =   4200
      TabIndex        =   33
      Top             =   2280
      Width           =   3615
      Begin VB.CheckBox chkDisableWasStripping 
         Caption         =   "Disable ""was:""-stripping"
         Height          =   255
         Left            =   120
         TabIndex        =   39
         Top             =   1200
         Width           =   2175
      End
      Begin VB.CheckBox chkDisableAutoFupMode 
         Caption         =   "Disable AutoFup mode"
         Height          =   255
         Left            =   120
         TabIndex        =   38
         Top             =   1440
         Width           =   2175
      End
      Begin VB.CheckBox chkAgtLanguage 
         Caption         =   "Show Agent Language at startup"
         Height          =   255
         Left            =   120
         TabIndex        =   37
         Top             =   960
         Width           =   2775
      End
      Begin VB.CheckBox chkRandSig 
         Caption         =   "Disable ""random signatures"""
         Height          =   255
         Left            =   120
         TabIndex        =   36
         Top             =   720
         Width           =   2895
      End
      Begin VB.CheckBox chkDisableXFaces 
         Caption         =   "Disable X-Faces"
         Height          =   255
         Left            =   120
         TabIndex        =   35
         Top             =   240
         Width           =   2175
      End
      Begin VB.CheckBox chkDisableTagLines 
         Caption         =   "Disable taglines (newsgroup descriptions)"
         Height          =   255
         Left            =   120
         TabIndex        =   34
         Top             =   480
         Width           =   3255
      End
   End
   Begin VB.Label Label14 
      Caption         =   "Action Char:"
      Height          =   255
      Left            =   3240
      TabIndex        =   50
      Top             =   1800
      Width           =   1095
   End
   Begin VB.Label Label12 
      Caption         =   "Disable:"
      Height          =   255
      Left            =   2520
      TabIndex        =   49
      Top             =   5160
      Visible         =   0   'False
      Width           =   975
   End
   Begin VB.Label Label13 
      Caption         =   "F12:"
      Height          =   255
      Left            =   240
      TabIndex        =   45
      Top             =   840
      Width           =   375
   End
   Begin VB.Label Label10 
      Caption         =   "F11:"
      Height          =   255
      Left            =   240
      TabIndex        =   44
      Top             =   480
      Width           =   375
   End
   Begin VB.Label Label1 
      Caption         =   "F2:"
      Height          =   255
      Left            =   240
      TabIndex        =   43
      Top             =   120
      Width           =   375
   End
   Begin VB.Label Label9 
      Caption         =   "AutoFupClipPrefix: "
      Height          =   255
      Left            =   3240
      TabIndex        =   21
      Top             =   1440
      Width           =   1575
   End
   Begin VB.Label Label8 
      Caption         =   "Hamster Default Score:"
      Enabled         =   0   'False
      Height          =   255
      Left            =   600
      TabIndex        =   18
      Top             =   4680
      Visible         =   0   'False
      Width           =   135
   End
   Begin VB.Label Label7 
      Caption         =   "Hamster Path:"
      Enabled         =   0   'False
      Height          =   255
      Left            =   1440
      TabIndex        =   16
      Top             =   4560
      Visible         =   0   'False
      Width           =   975
   End
   Begin VB.Label Label5 
      Caption         =   "Supersedes From Header:"
      Height          =   255
      Left            =   240
      TabIndex        =   14
      Top             =   4200
      Width           =   1935
   End
   Begin VB.Label lblsleep 
      Caption         =   "seconds/ms."
      Height          =   255
      Left            =   5760
      TabIndex        =   13
      Top             =   1080
      Width           =   1095
   End
   Begin VB.Label Label6 
      Caption         =   "ms."
      Height          =   255
      Left            =   5760
      TabIndex        =   11
      Top             =   720
      Width           =   735
   End
   Begin VB.Label lblHints 
      Caption         =   "solutions."
      Height          =   255
      Left            =   6960
      TabIndex        =   9
      Top             =   240
      Width           =   735
   End
   Begin VB.Label Label4 
      Caption         =   "Sleep mode delay:"
      Height          =   255
      Left            =   3240
      TabIndex        =   6
      Top             =   1080
      Width           =   1575
   End
   Begin VB.Label Label3 
      Caption         =   "Refresh delay:"
      Height          =   255
      Left            =   3240
      TabIndex        =   5
      Top             =   720
      Width           =   1095
   End
   Begin VB.Label Label2 
      Caption         =   "Hints:"
      Height          =   255
      Left            =   3240
      TabIndex        =   4
      Top             =   240
      Width           =   1095
   End
End
Attribute VB_Name = "frmOptions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit

Private Sub cmbHints_Click()
If cmbHints.ListIndex = 0 Then
txtHintNum.Text = "-1"
txtHintNum.Enabled = False
lblHints.Enabled = False
ElseIf cmbHints.ListIndex = 1 Then
txtHintNum.Text = "0"
txtHintNum.Enabled = False
lblHints.Enabled = False
ElseIf cmbHints.ListIndex = 2 Then
If Val(txtHintNum.Text) < 1 Then txtHintNum.Text = "3"
txtHintNum.Enabled = True
lblHints.Enabled = True
ElseIf cmbHints.ListIndex = 3 Then
txtHintNum.Text = "-2"
txtHintNum.Enabled = False
lblHints.Enabled = False
End If

End Sub

Private Sub cmdcancel_Click()
Unload Me
End Sub

Private Sub cmdOK_Click()
Dim x$, i As Integer
WritePrivateProfileString "Settings", "AgttoolIniVersion", "20", App.Path + "\agttool.ini"
If txtHintNum.Text = "" Then txtHintNum.Text = "3"
If txtRefresh.Text = "" Then txtRefresh.Text = "100"
If txtSleep.Text = "" Then txtSleep.Text = "1"
obsoleted "EnableWasStripping"
obsoleted "EnableAutoFupMode"
obsoleted "F12Mode"
obsoleted "DisableF2"
obsoleted "DisableF11"
obsoleted "DisableF12"
obsoleted "HamsterScore"
obsoleted "DisableTagLines"
obsoleted "DisableXFaces"
setinichkbox "DisableTagLines", chkDisableTagLines, "Debugging"
setinichkbox "DisableWasStripping", chkDisableWasStripping, "Debugging"
setinichkbox "DisableXFaces", chkDisableXFaces, "Debugging"
setinichkbox "DisableAutoFupMode", chkDisableAutoFupMode, "Debugging"
setinichkbox "MinimizeAtStartup", chkMinimizeAtStartup
setinichkbox "HideAtStartup", chkHideAtStartup
obsoleted "SupersedeAsReply"
setinichkbox "UsePGP-Ctrl-Shift-D", chkPGP
setinichkbox "OnlineHotkey", chkWinO
setinichkbox "DisableRandomSigs", chkRandSig
setinichkbox "ShowLanguageID", chkAgtLanguage, "Debugging"
x$ = Trim(Str(Val(txtHintNum.Text)))
WritePrivateProfileString "Settings", "Hints", x$, App.Path + "\agttool.ini"
x$ = Trim(Str(Val(txtSleep.Text)))
WritePrivateProfileString "Settings", "Sleep", x$, App.Path + "\agttool.ini"
x$ = Trim(Str(Val(txtRefresh.Text)))
WritePrivateProfileString "Settings", "Refresh", x$, App.Path + "\agttool.ini"
If getini("SupersedesFrom", "") = "" And txtSuper.Text <> "" Then
If MsgBox("Note: Superseding only works if you have patched your Agent. Do you really want to enable Superseding?", vbQuestion + vbYesNo + vbDefaultButton2, "AgtTool") = vbNo Then
txtSuper.Text = ""
End If
End If
WritePrivateProfileString "Settings", "SupersedesFrom", txtSuper.Text, App.Path + "\agttool.ini"
WritePrivateProfileString "Settings", "HamsterPath", txtHamster.Text, App.Path + "\agttool.ini"
WritePrivateProfileString "Settings", "HamsterScore", txtHamScoring.Text, App.Path + "\agttool.ini"
WritePrivateProfileString "Settings", "AFClipPrefix", txtAFClipPrefix.Text, App.Path + "\agttool.ini"
WritePrivateProfileString "Settings", "AgentWait", txtAgentWait.Text, App.Path + "\agttool.ini"
If txtActionChar.Text = "" Then txtActionChar.Text = "#"
WritePrivateProfileString "Settings", "ActionChar", txtActionChar.Text, App.Path + "\agttool.ini"
x$ = ""
For i = 0 To 2
x$ = x$ + Left$(cmbFxAction(i).List(cmbFxAction(i).ListIndex), 1)
Next
WritePrivateProfileString "Settings", "KeyActions", x$, App.Path + "\agttool.ini"

x$ = ""
For i = 0 To 4
If chk_OLC(i).Value = 1 Then x$ = x$ + Mid$("PMBHN", i + 1, 1)
Next
WritePrivateProfileString "Settings", "OnlineHotkeyModes", x$, App.Path + "\agttool.ini"
Unload Me
parseINI False
End Sub

Private Sub Form_Load()
Dim x$, i As Integer, j As Integer, y$
setchkbox "DisableWasStripping", chkDisableWasStripping, "Debugging"
setchkbox "DisableTagLines", chkDisableTagLines, "Debugging"
setchkbox "DisableXFaces", chkDisableXFaces, "Debugging"
setchkbox "DisableAutoFupMode", chkDisableAutoFupMode, "Debugging"
setchkbox "MinimizeAtStartup", chkMinimizeAtStartup
setchkbox "HideAtStartup", chkHideAtStartup
setchkbox "UsePGP-Ctrl-Shift-D", chkPGP
setchkbox "OnlineHotkey", chkWinO
setchkbox "DisableRandomSigs", chkRandSig
setchkbox "ShowLanguageID", chkAgtLanguage, "Debugging"
x$ = UCase(Trim(getini("Hints", "3")))
txtHintNum = x$
If Val(x$) = -1 Then
cmbHints.ListIndex = 0
ElseIf Val(x$) = 0 Then
cmbHints.ListIndex = 1
ElseIf Val(x$) = -2 Then
cmbHints.ListIndex = 3
Else
cmbHints.ListIndex = 2
End If
cmbHints_Click
x$ = UCase(Trim(getini("OnlineHotkeyModes", "PMBHN")))
For i = 0 To 4
chk_OLC(i).Value = 0
Next
For i = 1 To Len(x$)
j = InStr("PMBHN", Mid$(x$, i, 1))
If j <> 0 Then chk_OLC(j - 1).Value = 1
Next
txtSleep = Trim(getini("Sleep", "1"))
txtRefresh = Trim(getini("Refresh", "100"))
txtSuper.Text = SupersedesFrom
txtHamScoring.Text = HamScore
txtHamster.Text = HamPath
txtAFClipPrefix = AFClipPrefix
txtAgentWait = getini("AgentWait", "5")
txtActionChar = getini("ActionChar", "#")
x$ = UCase$(getini("KeyActions", "**X"))
For i = 0 To 2
With cmbFxAction(i)
.Clear
.AddItem "* (Display Dialog)"
.AddItem "X (Display X-Face)"
.AddItem "P (Verify PGP Signature)"
.AddItem "1 (Go one article up)"
.AddItem "0 (Go to ancestor article)"
.AddItem "- (No Action)"
.ListIndex = InStr("XP10-", Mid$(x$, i + 1, 1))
End With
Next
End Sub



Sub setchkbox(setting$, chkbox As CheckBox, Optional block$ = "Settings")
Dim x$
x$ = Trim(getini$(setting$, "0", block$))
If x$ <> "0" And UCase(x$) <> "NO" Then chkbox.Value = 1 Else chkbox.Value = 0
End Sub

Private Sub txtActionChar_KeyPress(KeyAscii As Integer)
Select Case KeyAscii
 Case Asc("0") To Asc("9"), Asc(" "), _
      Asc("a") To Asc("z"), Asc("."), Asc(","), Asc("-"), Asc("+"), _
      Asc("A") To Asc("Z"): KeyAscii = 0
End Select
End Sub

Private Sub txtHintNum_KeyPress(KeyAscii As Integer)
onlynumbers KeyAscii
End Sub

Private Sub txtRefresh_KeyPress(KeyAscii As Integer)
onlynumbers KeyAscii
End Sub

Private Sub txtSleep_Change()
If Val(txtSleep.Text) > 60 Then lblsleep.Caption = "ms." Else lblsleep.Caption = "seconds."
End Sub

Private Sub txtSleep_KeyPress(KeyAscii As Integer)
onlynumbers KeyAscii
End Sub

Sub setinichkbox(setting$, chkbox As CheckBox, Optional block$ = "Settings")
Dim x$
x$ = IIf(chkbox.Value = 1, "1", "0")
WritePrivateProfileString block$, setting, x$, App.Path + "\agttool.ini"
End Sub

Sub onlynumbers(KeyAscii As Integer)
If InStr("0123456789" + Chr$(8), Chr$(KeyAscii)) = 0 Then KeyAscii = 0
End Sub

Sub obsoleted(setting$, Optional block$ = "Settings")
If getini(setting$, "-", block$) = "-" And getini(setting$, "+", block$) = "+" Then Exit Sub
WritePrivateProfileString block$, setting, "obsolete", App.Path + "\agttool.ini"
End Sub
