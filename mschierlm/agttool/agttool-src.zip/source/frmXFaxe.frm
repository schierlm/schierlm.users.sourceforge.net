VERSION 5.00
Begin VB.Form frmXFace 
   BorderStyle     =   4  'Festes Werkzeugfenster
   Caption         =   "X-Face:"
   ClientHeight    =   930
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   945
   Icon            =   "frmXFaxe.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   62
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   63
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows-Standard
   Begin VB.PictureBox pct 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'Kein
      ForeColor       =   &H00000000&
      Height          =   720
      Left            =   120
      ScaleHeight     =   48
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   48
      TabIndex        =   0
      Top             =   120
      Visible         =   0   'False
      Width           =   720
   End
End
Attribute VB_Name = "frmXFace"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Private Sub Form_Load()
Me.Top = 10
Me.Left = Screen.Width - 2000
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
Me.Hide
'Set img.Picture = Nothing
pct.Visible = False
End Sub

