VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmmain 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "TagFetch (c) 2002 Michael Schierl"
   ClientHeight    =   2160
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4680
   Icon            =   "frmmain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   2160
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows-Standard
   Begin VB.CommandButton cmdok 
      Caption         =   "Start"
      Default         =   -1  'True
      Height          =   375
      Left            =   3240
      TabIndex        =   5
      Top             =   1680
      Width           =   1335
   End
   Begin VB.CommandButton cmdcancel 
      Cancel          =   -1  'True
      Caption         =   "Exit"
      Height          =   375
      Left            =   1800
      TabIndex        =   6
      Top             =   1680
      Width           =   1335
   End
   Begin MSWinsockLib.Winsock ws 
      Left            =   1080
      Top             =   1680
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin VB.Frame FraSettings 
      Caption         =   "Settings"
      Height          =   1455
      Left            =   120
      TabIndex        =   10
      Top             =   120
      Width           =   4455
      Begin VB.TextBox txtpass 
         Height          =   285
         IMEMode         =   3  'DISABLE
         Left            =   2040
         PasswordChar    =   "*"
         TabIndex        =   4
         Text            =   "geheim"
         Top             =   960
         Width           =   1575
      End
      Begin VB.TextBox txtuser 
         Height          =   285
         Left            =   240
         TabIndex        =   3
         Text            =   "user"
         Top             =   960
         Width           =   1575
      End
      Begin VB.CheckBox chkAuth 
         Caption         =   "&Authentification required"
         Height          =   255
         Left            =   120
         TabIndex        =   2
         Top             =   600
         Width           =   2535
      End
      Begin VB.TextBox txtPort 
         Height          =   285
         Left            =   3600
         TabIndex        =   1
         Text            =   "119"
         Top             =   240
         Width           =   615
      End
      Begin VB.TextBox txtServer 
         Height          =   285
         Left            =   120
         TabIndex        =   0
         Text            =   "127.0.0.1"
         Top             =   240
         Width           =   3375
      End
   End
   Begin VB.Frame FraDoing 
      Height          =   1455
      Left            =   120
      TabIndex        =   7
      Top             =   120
      Visible         =   0   'False
      Width           =   4455
      Begin VB.Label lblconstate 
         Caption         =   "connection closed"
         ForeColor       =   &H000000FF&
         Height          =   255
         Left            =   2640
         TabIndex        =   11
         Top             =   240
         Width           =   1575
      End
      Begin VB.Label lblname 
         Height          =   495
         Left            =   120
         TabIndex        =   9
         Top             =   840
         Width           =   4215
      End
      Begin VB.Label lblstate 
         Caption         =   "not connected"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   8
         Top             =   480
         Width           =   4215
      End
   End
End
Attribute VB_Name = "frmmain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit

Dim state As Integer, num As Long, buffer As String

Private Sub cmdcancel_Click()
If FraSettings.Visible = True Then
Unload Me
Else
ws.Close
lblconstate = "connection closed"
FraDoing.Visible = False
FraSettings.Visible = True
cmdok.Caption = "Start"
cmdok.Enabled = True
lblname.Caption = ""
cmdcancel.Caption = "Exit"
state = 0
num = 0
buffer = ""
Close #1
End If
End Sub

Private Sub cmdok_Click()
If FraDoing.Visible = True Then
If Dir("taglines.old") <> "" Then Kill "taglines.old"
If Dir("taglines.dat") <> "" Then Name "taglines.dat" As "taglines.old"
Name "taglines.tmp" As "taglines.dat"
Unload Me: Exit Sub
End If
cmdcancel.Caption = "Cancel"
cmdok.Enabled = False
FraDoing.Visible = True
FraSettings.Visible = False
lblstate.Caption = "Connecting to " + txtServer.Text + ":" + txtPort.Text
state = 0
On Error Resume Next
ws.Connect txtServer.Text, txtPort.Text
If Err Then
lblstate.Caption = "IP/Port error:"
lblname.Caption = Err.Description
End If
On Error GoTo 0
End Sub

Private Sub Form_Load()
txtServer.Text = GetSetting("TagFetch", "Settings", "Server", "127.0.0.1")
txtPort.Text = GetSetting("TagFetch", "Settings", "Port", "119")
txtuser.Text = GetSetting("TagFetch", "Settings", "User", "")
txtpass.Text = ""
chkAuth.Value = Val(GetSetting("TagFetch", "Settings", "Auth", "0"))
If chkAuth.Value = 1 Then Me.Show: DoEvents: txtpass.SetFocus
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
SaveSetting "TagFetch", "Settings", "Server", txtServer.Text
SaveSetting "TagFetch", "Settings", "Port", txtPort.Text
SaveSetting "TagFetch", "Settings", "Auth", Str(chkAuth.Value)
SaveSetting "TagFetch", "Settings", "User", txtuser.Text
End Sub

Private Sub ws_Close()
ws.Close
If state = 2 Then
lblstate.Caption = "Retrieved " & num & " Groups."
lblname.Caption = "Finished."
Close #1
cmdok.Caption = "Save groups"
cmdok.Enabled = True
cmdok.SetFocus
End If
lblconstate = "connection closed"
End Sub

Private Sub ws_Connect()
lblconstate = "connection open"
End Sub

Private Sub ws_DataArrival(ByVal bytesTotal As Long)
Dim x$, i As Integer
x$ = Space(bytesTotal)
ws.GetData x$
buffer = buffer + x$
If state <> 1 Then
Do
i = InStr(buffer, vbNewLine)
If i Then
x$ = Left$(buffer, i - 1)
buffer = Mid$(buffer, i + 2)
auswert x$
If state = 1 Then Exit Do
Else
Exit Do
End If
Loop
End If
If state = 1 Then
Do
i = InStr(buffer, vbNewLine)
If i <> 0 Then
x$ = Left$(buffer, i - 1)
buffer = Mid$(buffer, i + 2)
If x$ = "." Then
state = 2
Close #1
ws.SendData "QUIT" + vbNewLine
Exit Do
End If
Print #1, x$
Debug.Print x$
num = num + 1
Else
Exit Do
End If
Loop
lblstate.Caption = "Retrieved: " & num & " Groups"
If InStr(x$, vbTab) Then x$ = Left$(x$, InStr(x$, vbTab) - 1)
lblname.Caption = x$
End If
End Sub

Private Sub ws_Error(ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal Source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)
lblstate.Caption = "Winsock error " & Number & ":"
lblname.Caption = Description
ws.Close
lblconstate = "connection closed"
End Sub

Sub auswert(x$)
lblname.Caption = x$

Select Case Left$(x$, 3)
Case "281"
lblstate.Caption = "login successful, retrieving list..."
lblname.Caption = ""
ws.SendData "LIST NEWSGROUPS" + vbNewLine
Case "381"

If chkAuth.Value = 1 Then
lblstate.Caption = "connected, logging in (2)"
lblname.Caption = ""
ws.SendData "AUTHINFO PASS " + txtpass.Text + vbNewLine
Else
lblstate.Caption = "NNTP error 381: Authentification required"
End If
Case "480"
lblstate.Caption = "NNTP error 480: Authentification required"
Case "481"
lblstate.Caption = "NNTP error 481: Authentification rejected"
Case "502"
lblstate.Caption = "NNTP error 502: No permission"
Case "215"
lblstate.Caption = "Retrieved: 0 Groups"
state = 1
Open "taglines.tmp" For Output As #1
Case "205"
lblname.Caption = "Closing connection..."
Case "200", "201"
If chkAuth.Value = 1 Then
lblstate.Caption = "connected, logging in (1)"
ws.SendData "AUTHINFO USER " + txtuser.Text + vbNewLine
Else
lblstate.Caption = "connected, retrieving list"
ws.SendData "LIST NEWSGROUPS" + vbNewLine
End If
Case Else
lblstate.Caption = "NNTP error"
End Select
End Sub
