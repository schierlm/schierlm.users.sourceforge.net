Attribute VB_Name = "mdlVersions"
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Type AgentPropertiesType
    mnuShowAllHeaders As Long
    mnuRawView As Long
    mnuAllFields As Long 'Composition Window: All Fields
    mnuForLanguage As Long ' Help->Contents
    txtMainWindowClassName As String
    txtMDIChildClassName As String
    didNewsgroups As Long
    didValueFor As Long
    didMailTo As Long
    didCC As Long
    didSubject As Long
    didSignature As Long
    didFindBoxText As Long
    olcPost As Long
    olcMail As Long
    olcBody As Long
    olcHead As Long
    olcNew As Long
End Type

Public AgentProperties(1 To 2) As AgentPropertiesType

Public Sub InitAgentProperties()
With AgentProperties(1) '' Agent 1.9x
    .mnuShowAllHeaders = 4329
    .mnuRawView = 4416
    .mnuAllFields = 5276
    .mnuForLanguage = 4418
    .txtMainWindowClassName = "ForteAgent:Main"
    .txtMDIChildClassName = "#32770"
    .didNewsgroups = &H67
    .didValueFor = &H8D
    .didMailTo = 115
    .didCC = 118
    .didSubject = &H65
    .didSignature = &H7A
    .didFindBoxText = 101
    .olcPost = 4380
    .olcMail = 4941
    .olcBody = 4379
    .olcHead = 4373
    .olcNew = 4372
End With
With AgentProperties(2) '' Agent 2.0
    .mnuShowAllHeaders = 10165
    .mnuRawView = 10261
    .mnuAllFields = 10195
    .mnuForLanguage = 10278
    .txtMainWindowClassName = "wxMDIFrameClassNR"
    .txtMDIChildClassName = "wxMDIChildFrameClassNR"
    .didNewsgroups = 7022
    .didValueFor = 7046
    .didMailTo = 7025
    .didCC = 7028
    .didSubject = 7020
    .didSignature = 7032
    .didFindBoxText = 7484
    .olcPost = 10221
    .olcMail = 10320
    .olcBody = 10220
    .olcHead = 10214
    .olcNew = 10213
End With
End Sub
