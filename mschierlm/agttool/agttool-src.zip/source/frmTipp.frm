VERSION 5.00
Begin VB.Form frmTipp 
   BackColor       =   &H80000018&
   BorderStyle     =   0  'Kein
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3900
   FillColor       =   &H80000017&
   Icon            =   "frmTipp.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3195
   ScaleWidth      =   3900
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows-Standard
   Begin VB.Timer Timer1 
      Interval        =   20000
      Left            =   1560
      Top             =   1560
   End
   Begin VB.Label lblnr 
      Alignment       =   2  'Zentriert
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   0
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Visible         =   0   'False
      Width           =   135
   End
   Begin VB.Label lblgrp 
      BackStyle       =   0  'Transparent
      Caption         =   "Gruppenname"
      Height          =   255
      Index           =   0
      Left            =   480
      TabIndex        =   0
      Top             =   120
      Visible         =   0   'False
      Width           =   3255
   End
End
Attribute VB_Name = "frmTipp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Private Sub Form_Load()
Dim rc As RECT, cnt As Integer, i As Long
cnt = 0
GetWindowRect hwnds(h_parent), rc
Me.Left = rc.Left * Screen.TwipsPerPixelX
Me.Width = (rc.Right - rc.Left) * Screen.TwipsPerPixelX
Me.Top = rc.Bottom * Screen.TwipsPerPixelY
For i = tipwinfirst To tipwinlast
If Left$(groups(i - 1), tipwinlength) <> Left$(groups(i), tipwinlength) Then
cnt = cnt + 1
If cnt > 10 Then Stop
Load lblnr(cnt)
lblnr(cnt).Left = lblnr(0).Left
lblnr(cnt).Top = lblnr(0).Top + (cnt - 1) * 240
lblnr(cnt).Caption = Right$(Str(cnt), 1)
Load lblgrp(cnt)
lblgrp(cnt).Left = lblgrp(0).Left
lblgrp(cnt).Top = lblgrp(0).Top + (cnt - 1) * 240
lblgrp(cnt).Caption = IIf(Len(groups(i)) <= tipwinlength, groups(i), Left$(groups(i), tipwinlength) + "#")
lblnr(cnt).Visible = True
lblgrp(cnt).Visible = True
End If
Next
Me.Height = lblnr(cnt).Top + 240
Me.Show: DoEvents
SetWindowPos Me.hwnd, -1, 0, 0, 0, 0, 3
tiphwnd = hwnds(h_parent)
tipshere = True
End Sub

    '    Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    '    '
    '    End Sub
    '
    '    Private Sub lblgrp_MouseMove(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    '    Form_MouseMove 0, 0, 0, 0
    '    End Sub
    '
    '    Private Sub lblnr_MouseMove(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    '    Form_MouseMove 0, 0, 0, 0
    '    End Sub

Private Sub Timer1_Timer()
Timer1.Interval = 500
On Error Resume Next
Unload Me
On Error GoTo 0
lasttip = False
tipshere = False
End Sub
