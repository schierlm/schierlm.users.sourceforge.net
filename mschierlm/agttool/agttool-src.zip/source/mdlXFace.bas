Attribute VB_Name = "mdlXFace"
'' Special Version for AgtTool - shortened as far as possible
Option Explicit
Private Declare Function uncompface Lib "cface_vb.dll" Alias "_uncompface@4" (ByVal s As String) As Long
Dim xfacebuffer As String * 1024
Const C_OUT = "cface_vb.dll unsupported output: "

Function PaintXFace(x$, dest As PictureBox)
Dim bu$, i As Integer, j As Integer, ii As Integer, jj As Integer
Dim v As Integer, r As Long
xfacebuffer = x$ + Chr$(0)
r = uncompface(xfacebuffer)
dest.Cls
PaintXFace = False
If r <> 0 Then Exit Function
bu$ = Left$(xfacebuffer, InStr(xfacebuffer, Chr$(0)) - 1)
bu$ = Replace(Replace(bu$, "0x", ""), ",", "")
bu$ = Trim(Replace(bu$, vbLf, ""))
If Len(bu) <> 48 * 48 / 4 Then MsgBox C_OUT + bu$: Exit Function
For jj = 0 To 47
For ii = 0 To 47 Step 8
v = Val("&H" + Left$(bu$, 2))
bu$ = Mid$(bu$, 3)
For i = 0 To 7
If (v And 2 ^ i) <> 0 Then
dest.PSet (ii + 7 - i, jj)
End If
Next
Next
Next
PaintXFace = True
End Function

Sub HandleXFace(x$)
Dim result As Boolean
Load frmXFace
result = PaintXFace(x$, frmXFace.pct)
If result = True Then
frmXFace.pct.Visible = True
frmXFace.Visible = True
SetWindowPos frmXFace.hwnd, -1, 0, 0, 0, 0, 3
ForceForegroundWindow2 F12AgentWnd
Else
frmXFace.pct.Visible = False
frmXFace.Hide
End If
End Sub

