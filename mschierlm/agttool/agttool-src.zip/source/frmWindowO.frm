VERSION 5.00
Begin VB.Form frmWindowO 
   BorderStyle     =   0  'Kein
   Caption         =   "AgtTool Hotkey Target"
   ClientHeight    =   1200
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2955
   Icon            =   "frmWindowO.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1200
   ScaleWidth      =   2955
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows-Standard
   Visible         =   0   'False
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   1440
      Top             =   480
   End
End
Attribute VB_Name = "frmWindowO"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Private bCancel As Boolean, seccount As Long, secwait As Long, ison As Boolean

''' FIXME: Do a proper "subclassing" here instead of peeking for messages
Public Sub ProcessMessages()
    Dim Message As Msg
    Do While Not bCancel
        WaitMessage
        If PeekMessage(Message, Me.hwnd, WM_HOTKEY, WM_HOTKEY, PM_REMOVE) Then
            Action True
        End If
        DoEvents
    Loop
End Sub


Private Sub Form_Load()
bCancel = False
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
Unload Me 'fix tempfile bug
End Sub

Private Sub Form_Unload(Cancel As Integer)
bCancel = True
off
End Sub

Private Sub Action(key As Boolean)
Dim hwnd As Long, s As String, l As Integer, els As Variant
Dim elem As String, j As Integer, i As Integer
hwnd = GetForegroundWindow
s = Space$(66)
l = GetClassName(hwnd, s, 64)
For i = 1 To UBound(AgentProperties)
    With AgentProperties(i)
    If Left$(s, l) = .txtMainWindowClassName Then
        If (OnlineCommands And OLC_POST) <> 0 Then sendcommand hwnd, .olcPost
        If (OnlineCommands And OLC_MAIL) <> 0 Then sendcommand hwnd, .olcMail
        If (OnlineCommands And OLC_BODY) <> 0 Then sendcommand hwnd, .olcBody
        If (OnlineCommands And OLC_HEAD) <> 0 Then sendcommand hwnd, .olcHead
        If (OnlineCommands And OLC_NEW) <> 0 Then sendcommand hwnd, .olcNew
    End If
    End With
Next
End Sub



Sub onn()
Dim ret As Long
If ison = False Then
    ison = True
    ret = RegisterHotKey(Me.hwnd, &HBFFB&, MOD_WIN, vbKeyO)
End If
End Sub

Sub off()
If ison = True Then
ison = False
Call UnregisterHotKey(Me.hwnd, &HBFFB&)
End If
End Sub


Private Sub Timer1_Timer()
Dim hwnd As Long, s As String, l As Integer
Timer1.Enabled = False
hwnd = GetForegroundWindow
s = Space$(66)
l = GetClassName(hwnd, s, 64)
If Left$(s, l) <> AgentProperties(1).txtMainWindowClassName And Left$(s, l) <> AgentProperties(2).txtMainWindowClassName Then
MsgBox "Please close your Find-window after running #wino#.", vbInformation + vbSystemModal, "AgtTool"
Exit Sub
End If
Action True
End Sub
