Attribute VB_Name = "mdlMain"
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

'======================================================================
'  ForceForegroundWindow2 is based on code from ForceFore.Bas.
'  Here is the original header of this file:
'
' *********************************************************************
'  Copyright �1998 Karl E. Peterson, All Rights Reserved
'  http://www.mvps.org/vb
' *********************************************************************
'  You are free to use this code within your own applications, but you
'  are expressly forbidden from selling or otherwise distributing this
'  source code without prior written consent.
' *********************************************************************

Option Explicit

Function EnumWindowsProc(ByVal hwnd As Long, ByVal lParam As Long) As Long
Dim ret As Long, c$, ret2 As Long, i As Integer, t As Single
Dim version As Integer, typ As Integer
version = lParam Mod 10
typ = lParam \ 10
buffer = Space(1000)
ret = GetClassName(hwnd, buffer, 1000)
c$ = Left$(buffer, ret)
If typ = 1 Then
    version = 0
    For i = 1 To UBound(AgentProperties)
        If c$ = AgentProperties(i).txtMainWindowClassName Then
            version = i
        End If
    Next
    If version <> 0 Then
        lastAgentHwnd = hwnd
        instances = instances + 1
        For i = 1 To instanceInfoAnz
         If InstanceInfo(i).hwnd = hwnd Then
            InstanceInfo(i).found = True
            Exit For
         End If
        Next
        If i = instanceInfoAnz + 1 Then
         instanceInfoAnz = i
         CriticalErrorOn instanceInfoAnz >= MAX_CUMUL_INSTANCES, "Too many agent instances (EnumWindowsProc:2)"
         InstanceInfo(i).found = True
         InstanceInfo(i).hwnd = hwnd
         InstanceInfo(i).language = getLanguage(hwnd, version)
         If InstanceInfo(i).language = -2 Then
            t = Timer: Do: Loop Until t + 3 < Timer
            InstanceInfo(i).language = getLanguage(hwnd, version)
            If InstanceInfo(i).language = -2 Then
                InstanceInfo(i).language = -1
            End If
         End If
         InstanceInfo(i).version = version
         InstanceInfo(i).created = Timer
         If InstanceInfo(i).language = -1 Then
          MsgBox "An Error occurred while detecting the Agent language. Please contact sm-soft@gmx.de for further information", vbSystemModal + vbOKOnly + vbInformation, "AgtTool"
         ElseIf InstanceInfo(i).language = 0 Then
          MsgBox "The language of your Forte Agent is unknown. Please contact sm-soft@gmx.de for further information", vbSystemModal + vbOKOnly + vbInformation, "AgtTool"
         End If
        End If
        EnumChildWindows hwnd, AddressOf EnumChildProc, 20 + version
    ElseIf c$ = "#32770" Then
        ret = GetParent(hwnd)
        If ret <> 0 Then
        buffer = Space(1000)
        ret2 = GetClassName(ret, buffer, 1000)
        For i = 1 To UBound(AgentProperties)
        If Left$(buffer, ret2) = AgentProperties(i).txtMainWindowClassName Then
            EnumChildWindows hwnd, AddressOf EnumChildProc, 40 + i
        End If
        Next
        End If
    End If
ElseIf typ = 2 Then
    If c$ = AgentProperties(version).txtMDIChildClassName Then
        fl_parent = False
        EnumChildWindows hwnd, AddressOf EnumChildProc, 30 + version
    End If
ElseIf typ = 3 Then
    If c$ = "Edit" Then
        ret = GetWindowLong(hwnd, GWL_ID)
        With AgentProperties(version)
        If ret = .didNewsgroups Or ret = .didValueFor Or ((ret = .didMailTo Or ret = .didCC) And emilanz > 0) Then
            hwndanz = hwndanz + 1
            fupother(hwndanz) = 0
            CriticalErrorOn hwndanz >= ARRAYLIMIT, "Window stack overflow"
            hwnds(hwndanz) = hwnd
            hwndagent(hwndanz) = lastAgentHwnd
        End If
        If wasmode = True Then
        If ret = .didSubject Then
            sanz = sanz + 1
            CriticalErrorOn sanz >= ARRAYLIMIT, "Window stack overflow"
            subjects(sanz) = hwnd
        End If
        End If
        If autofup = True Then
            If ret = .didNewsgroups Then
            If fl_parent = False Then
               h_parent = hwndanz: fl_parent = True
            Else
               fupother(hwndanz) = h_parent
               CriticalErrorOn True, "Unhandled: Other textbox order"
            End If
            ElseIf ret = .didValueFor Then  'FUP
            If fl_parent = True Then
                fupother(h_parent) = hwnd
            Else
                h_parent = hwnd
            End If
            End If
        End If
        End With
    ElseIf c$ = "ComboBox" And randomsigs = True Then
        ret = GetWindowLong(hwnd, GWL_ID)
        If ret = AgentProperties(version).didSignature Then
            checkforautosig hwnd
        End If
    End If
ElseIf typ = 4 Then
    If c$ = "Edit" Then
        ret = GetWindowLong(hwnd, GWL_ID)
        If ret = AgentProperties(version).didFindBoxText Then
            hwndanz = hwndanz + 1
            CriticalErrorOn hwndanz >= ARRAYLIMIT, "Window stack overflow..."
            hwnds(hwndanz) = hwnd
        End If
    End If
End If
EnumWindowsProc = CLng(True)
End Function

Function EnumChildProc(ByVal hwnd As Long, ByVal lParam As Long) As Long
EnumChildProc = EnumWindowsProc(hwnd, lParam)
End Function


Function change$(ByVal txt$)
Dim f$, i As Integer
If Right$(txt$, 2) = "�#" Then '' FIXME! dirty hack to allow automatic autofup
    change$ = Left$(txt$, InStr(txt$, "�") - 1)
    Dim fup$
    fup$ = Mid$(txt$, InStr(txt$, "�") + 1)
    fup$ = Left$(fup$, InStr(fup$, "�") - 1)
    If autofup And fupother(h_parent) <> 0 Then
    SendMessage hwnds(h_parent), WM_SETTEXT, 0, ByVal (change$ + "-#")
    fupauto
    change$ = change$ + fup$
    Else
    change$ = change$ + fup$
    End If
    Exit Function
ElseIf Right$(txt$, 4) = ",..." Or Right$(txt$, 4) = ",,,," Then
groupsresult = Left$(txt$, Len(txt$) - 4)
frmGroups.Show 1
change$ = groupsresult$
If Right$(groupsresult$, 2) = "�#" Then change$ = change$(groupsresult$)
Exit Function
End If
i = InStrRev(txt$, ",")
If i <> 0 Then
f$ = Left$(txt$, i):
txt$ = Mid$(txt$, i + 1)
txt$ = change$(txt$)
If txt$ = Chr$(0) Then f$ = Left$(f$, i - 1): txt$ = ""
change$ = f$ + txt$: Exit Function
End If
If txt$ = "..." Then
groupsresult$ = ""
frmGroups.Show 1
change$ = groupsresult$
If Right$(groupsresult$, 2) = "�#" Then change$ = change$(groupsresult$)
Exit Function
End If
For i = 1 To emilanz
If emil1(i) + char$ = txt$ Then change$ = emil2(i): Exit Function
Next
If InStr(txt$, " ") Then change$ = txt$: Exit Function
If Left$(txt$, 1) = char$ Then
txt$ = parsespecial(Mid$(txt$, 2, Len(txt$) - 2))
Else
txt$ = Left$(txt$, Len(txt$) - 1)
For i = 0 To acount - 1
If txt$ = aliases(i) Then txt$ = aliases2(i)
Next
txt$ = search$(txt$)
End If
change$ = txt$
End Function

Function search(ByVal t$) As String
Dim i As Long, j As Long, m As Long, n As Long
Dim ok As Boolean
If t$ = "poster" Then lasthit = t$: search = t$: Exit Function
If t$ = "+" Then search$ = search(lasthit): Exit Function
If autofup And fupother(h_parent) <> 0 And t$ = "-" Then fupauto: search = "": Exit Function
If autofup And fupother(h_parent) <> 0 And t$ = "--" Then fup2p: search = Chr$(0): Exit Function
If t$ = "-" Or t$ = "--" Then search = search("poster"): Exit Function
i = 0: j = gcount - 1
Do While i <= j
m = (i + j) \ 2
If Left$(groups(m), Len(t$)) = t$ Then Exit Do
If Left$(groups(m), Len(t$)) > t$ Then j = m - 1
If Left$(groups(m), Len(t$)) < t$ Then i = m + 1
Loop
If i > j Then
forcetipps = True
t$ = search(Left$(t$, Len(t$) - 1))
forcetipps = False
Else
For i = m - 1 To 0 Step -1
If Left$(groups(i), Len(t$)) < t$ Then Exit For
Next
m = i + 1
For i = m + 1 To gcount - 1
If Left$(groups(i), Len(t$)) > t$ Then Exit For
Next
n = i - 1
For i = Len(t$) + 1 To Len(groups(m))
For j = m To n
If Left$(groups(j), i) <> Left$(groups(m), i) Then ok = True: Exit For
Next
If ok = True Then Exit For
Next
If (i = Len(t$) + 1 And m <> n And i - 1 < Len(groups(m)) Or forcetipps) Then
If lasttip = False Then Beep
If tipps <> -1 And m <> n Then maketipp Left$(groups(m), i - 1), m, n
End If
If i = Len(groups(m)) + 1 Then lasthit = groups(m)
CriticalErrorOn i < Len(t$) + 1, "Unhandled exception: Completion too short"
t$ = Left$(groups(m), i - 1)
End If
search = t$
End Function

Sub Main()
Dim x$, i%, c$
InitAgentProperties
c$ = Command$ + " "
If Left$(c$, 1) = ":" Then
Shell Mid$(c$, 2), vbNormalFocus
c$ = ""
AutoQuit = True
AgentWait = Val(getini("AgentWait", "5"))
End If
ChDrive Left$(App.Path, 2)
ChDir App.Path
If App.PrevInstance = True And c$ <> "" Then MsgBox "AgtTool is already running", vbExclamation: End
If App.PrevInstance = True Then End
If Dir(App.Path + "\GROUPS.DAT") = "" Then MsgBox "Groups.Dat not found. Please read the �QuickStart� section of README.TXT.", vbInformation: End
If Dir(App.Path + "\GROUPS.IDX") <> "" Then
    MsgBox "Do *not* copy AgtTool into Agent's DATA directory. For more information see README.TXT", vbInformation
    End
End If
Open App.Path + "\GROUPS.DAT" For Input As #1
Do Until EOF(1)
Line Input #1, groups(gcount)
If InStr(groups(gcount), Chr$(10)) Then MsgBox "Please run prepare: UNIX file GROUPS.DAT", vbInformation: End
If gcount > 0 Then
If groups(gcount - 1) >= groups(gcount) Then MsgBox "please run prepare: " + groups(gcount) + ">" + groups(gcount - 1), vbInformation: End
End If
gcount = gcount + 1
Loop
Close #1
If Left$(c$, 8) = "/NOALIAS" Then
c$ = Mid$(c$, 10)
ElseIf Dir(App.Path + "\ALIAS.INI") <> "" Then
Open App.Path + "\ALIAS.INI" For Input As #1
Do Until EOF(1)
Line Input #1, x$
If InStr(x$, Chr$(10)) Then MsgBox "Please run prepare: UNIX file ALIAS.INI", vbInformation: End
i = InStr(x$, "=")
CriticalErrorOn i = 0, "Error in ALIAS.INI: " + x$
aliases(acount) = Left$(x$, i - 1)
aliases2(acount) = Mid$(x$, i + 1)
acount = acount + 1
Loop
Close #1
End If
If Dir(App.Path + "\cface_vb.dll") <> "" Then xface_ = True Else xface_ = False
If Left$(c$, 7) = "/NODESC" Then
c$ = Mid$(x$, 9)
ElseIf Dir(App.Path + "\TAGLINES.DAT") <> "" Then
Open App.Path + "\TAGLINES.DAT" For Input As #1
Do Until EOF(1)
Line Input #1, x$
If InStr(x$, Chr$(10)) Then MsgBox "Please run prepare: UNIX file TAGLINES.DAT", vbInformation: End
i = InStr(x$, Chr$(9))
CriticalErrorOn i = 0, "Invalid data: " + x$
taggroup(tlanz) = Left$(x$, i - 1)
tagline(tlanz) = Mid$(x$, i + 1)
If tlanz > 0 Then
If taggroup(tlanz - 1) > taggroup(tlanz) Then MsgBox "Please run prepare: " + taggroup(tlanz - 1) + ">" + taggroup(tlanz): End
End If
tlanz = tlanz + 1
Loop
Close #1
taglines_ = True
End If
If Dir(App.Path + "\EMAIL.INI") <> "" Then
Open App.Path + "\EMAIL.INI" For Input As #1
Do Until EOF(1)
Line Input #1, x$
If InStr(x$, Chr$(10)) Then MsgBox "Please run prepare: UNIX file EMAIL.INI", vbInformation: End
i = InStr(x$, "=")
CriticalErrorOn i = 0, "Error in EMAIL.INI: " + x$
emilanz = emilanz + 1
emil1(emilanz) = Left$(x$, i - 1)
emil2(emilanz) = Mid$(x$, i + 1)
Loop
Close #1
End If
DoShowing = True
Load frmmain
Load frmWindowO
initLanguages
parseINI True
If Trim(c$) <> "" Then
Do Until c$ = ""
i = InStr(c$, " ")
If i <> 1 Then
x$ = Left$(c$, i - 1)
If Left$(c$, 1) <> char$ And Mid$(c$, i - 1, 1) <> char$ Then MsgBox "Invalid command line option: " + x$, vbInformation: End_
If change(Left$(c$, i - 1)) <> "" Then MsgBox "unable to parse command line option:" + x$, vbInformation: End_
c$ = Mid$(c$, i + 1)
End If
Loop
frmmain.showstate
End If
If DoShowing = True Then frmmain.Show
DoEvents
frmmain.tmrFind_Timer
frmWindowO.ProcessMessages
End Sub

Sub maketipp(t$, p1 As Long, p2 As Long)
Dim i As Integer, j As Long, c As Integer, x$, max As Integer
Dim hhh As Long
lasttip = False
If t$ = "" Then Exit Sub
For j = p1 To p2
If Len(groups(j)) > max Then max = Len(groups(j))
Next
For i = max To Len(t$) + 1 Step -1
c = 1
For j = p1 + 1 To p2
If Left$(groups(j), i) <> Left$(groups(j - 1), i) Then c = c + 1
Next
If c <= tipps Then Exit For
Next
c = i - Len(t$)
If c = 0 Then
x$ = "["
For j = p1 To p2
If Len(groups(j)) = i Then x$ = x$ + "$"
If j = p1 Or Mid$(groups(j), i + 1, 1) <> Mid$(groups(j - 1), i + 1, 1) Then x$ = x$ + Mid$(groups(j), i + 1, 1)
Next
tipp$ = x$ + "]"
Else
If tipwin = True Then
tipp = "�"
lasttip = True
tipwinfirst = p1
tipwinlast = p2
tipwinlength = c + Len(t$)
hhh = GetForegroundWindow
Unload frmTipp
frmTipp.Show
ForceForegroundWindow2 hhh
Else
x$ = "("
i = Len(t$)
For j = p1 To p2
If j = p1 Or Mid$(groups(j), i + 1, c) <> Mid$(groups(j - 1), i + 1, c) Then
x$ = x$ + Mid$(groups(j), i + 1, c)
If i + c < Len(groups(j)) Then x$ = x$ + char$
x$ = x$ + "|"
End If
Next
tipp$ = Left$(x$, Len(x$) - 1) + ")"
End If
End If
End Sub

Sub fupauto()
Dim txt$, ret As Long, i As Integer
fup_active = False
fup_hwnd1 = hwnds(h_parent)
fup_hwnd2 = fupother(h_parent)
fup_last = ""
fup_source = ""
Dim ii As InstanceInfoType
With instanceInfoForHwnd(hwndagent(h_parent), "InstanceInfo not found (fupauto:1)")
    fup_lang = languageKeys(.language)
    fup_vers = .version
End With
ret = SendMessage(fup_hwnd1, WM_GETTEXT, 1000, ByVal buffer)
txt$ = Left$(buffer, ret)
fup_pos = Len(txt$) - Len("-#") + 1
txt$ = ""
If Mid$(fup_lang, 1, 1) = " " Or Mid$(fup_lang, 4, 1) = " " Then
     MsgBox "Language does not support AutoFup", vbInformation + vbOKOnly + vbSystemModal, "AgtTool": Exit Sub
End If
Dim allfieldshidden As Boolean
CriticalErrorOn fup_vers <> 1 And fup_vers <> 2, "AutoFup version info uninitialized (fupauto:1)"
If isMenuChecked(hwndagent(h_parent), AgentProperties(fup_vers).mnuAllFields) = 0 Then 'All Fields not selected
allfieldshidden = True
sendcommand hwndagent(h_parent), AgentProperties(fup_vers).mnuAllFields
End If
SendKeys "%" + Mid$(fup_lang, 4, 1) + "{home}fo%" + Mid$(fup_lang, 1, 1), True
'DoEvents
ret = SendMessage(fup_hwnd2, WM_SETTEXT, 0, ByVal txt$)
ret = SendMessage(fup_hwnd2, WM_KILLFOCUS, fup_hwnd1, 0)
If allfieldshidden Then sendcommand hwndagent(h_parent), AgentProperties(fup_vers).mnuAllFields
fup_active = True
End Sub

Sub fup2p()
Dim ret As Long, txt$, i As Integer, ver As Integer
txt$ = "poster"
With instanceInfoForHwnd(hwndagent(h_parent), "Could not find InstanceInfo (fup2p:1)")
    fup_lang = languageKeys(.language)
    ver = .version
End With
If Mid$(fup_lang, 1, 1) = " " Or Mid$(fup_lang, 4, 1) = " " Then
     MsgBox "Language does not support AutoFup", vbInformation + vbOKOnly + vbSystemModal, "AgtTool": Exit Sub
End If
Dim allfieldshidden As Boolean
If isMenuChecked(hwndagent(h_parent), AgentProperties(ver).mnuAllFields) = 0 Then
allfieldshidden = True
sendcommand hwndagent(h_parent), AgentProperties(ver).mnuAllFields
End If
SendKeys "%" + Mid$(fup_lang, 4, 1) + "{home}fo%" + Mid$(fup_lang, 1, 1), True

ret = SendMessage(fupother(h_parent), WM_SETTEXT, 0, ByVal txt$)
ret = SendMessage(fupother(h_parent), EM_SETSEL, 0, 6)
ret = SendMessage(fup_hwnd2, WM_KILLFOCUS, 0, 0)
If allfieldshidden Then
sendcommand hwndagent(h_parent), AgentProperties(ver).mnuAllFields
Else
If Mid$(fup_lang, 5, 1) = " " Then
SendKeys "%" + Mid$(fup_lang, 4, 1) + "{tab}", True
Else
SendKeys "%" + Mid$(fup_lang, 5, 1), True
End If
End If
If Len(AFClipPrefix) Then
i = InStr(AFClipPrefix, "\|")
If i <> 0 Then
txt$ = Mid$(AFClipPrefix, i + 2)
If txt$ = "" Then txt$ = Left$(AFClipPrefix, i - 1)
txt$ = Replace(txt$, "\n", vbNewLine)
txt$ = Replace(txt$, "\x", "")
txt$ = Replace(txt$, "\f", "poster")
txt$ = Replace(txt$, "\\", "\")
On Error Resume Next
Clipboard.Clear
Clipboard.SetText txt$
On Error GoTo 0
End If
End If
End Sub

Function parsespecial(txt$) As String
Dim tt$, x$, i As Integer
tt$ = ""
If Left$(txt$, 1) = char$ Then Stop
Select Case LCase(txt$)
Case "i":
tt = SupersedesFrom
If tt = "" Then tt = "?": Beep
If InStr(tt, " <") Then tt = Left$(tt, InStr(tt, " <") - 1)
Case "quit", "fuckoff", "foad": Unload frmmain: End
Case "tipwin", "hintwin": tipwin = True: tipps = 10
Case "minimize", "min": frmmain.WindowState = vbMinimized
Case "hide", "hd": frmmain.Visible = False: reshow = True
    frmmain.tmrFind.Enabled = True: DoShowing = False
Case "show", "sh", "s":
frmmain.WindowState = vbNormal: frmmain.Show: reshow = False
Case "options", "opt", "o"
frmmain.WindowState = vbNormal: frmmain.Show: reshow = False
frmmain.cmdOpts_Click
Case "wino", "w"
frmWindowO.Timer1.Enabled = True
Case "hint-", "ht-": tipps = -1: tipwin = False
Case "copperfield", "david", "dvd", "cpf":
frmmain.Visible = False: reshow = False: DoShowing = False
Case "pgp": frmPGP.Show
Case "xfa": frmSelect.doxface
Case Else
If Left$(txt$, 4) = "hint" Then
tipps = Val(Mid$(txt$, 5)): tipwin = False
ElseIf Left$(txt, 2) = "ht" Then
tipps = Val(Mid$(txt$, 3)): tipwin = False
Else
tt = "?": Beep
End If
End Select
parsespecial = tt$
End Function

Sub End_()
Dim i As Long
For i = 0 To tlanz
taggroup(i) = vbNullString
tagline(i) = vbNullString
Next
For i = 0 To gcount
groups(i) = vbNullString
Next
If xface = True And Dir(App.Path + "\xface.tmp") <> "" Then Kill App.Path + "\xface.tmp"
If xface = True And Dir(App.Path + "\xface2.tmp") <> "" Then Kill App.Path + "\xface2.tmp"
End
End Sub

Sub parseINI(isatstartup As Boolean)
Dim x$
init
If Val(getini("AgttoolIniVersion", "20")) > 20 Then MsgBox "Your AGTTOOL.INI is too recent. Delete it and try again.", vbInformation, "AgtTool": End
If isenabled("DisableWasStripping", "Debugging") Then wasmode = False
If isenabled("DisableTagLines", "Debugging") Then taglines = False: frmmain.removetgl
If isenabled("DisableXFaces", "Debugging") Then xface = False
If isenabled("DisableAutoFupMode", "Debugging") Then autofup = False: fup_active = False
If isatstartup Then
If isenabled("MinimizeAtStartup") Then frmmain.WindowState = vbMinimized
If isenabled("HideAtStartup") Then
    frmmain.Visible = False: reshow = True
    frmmain.tmrFind.Enabled = True: DoShowing = False
End If
End If
If isenabled("UsePGP-Ctrl-Shift-D") Then pgpCtrlShiftD = True
x$ = UCase(Trim(getini("OnlineHotkeyModes", "PMBHN")))
OnlineCommands = 0
If InStr(x$, "P") Then OnlineCommands = OnlineCommands + OLC_POST
If InStr(x$, "M") Then OnlineCommands = OnlineCommands + OLC_MAIL
If InStr(x$, "B") Then OnlineCommands = OnlineCommands + OLC_BODY
If InStr(x$, "H") Then OnlineCommands = OnlineCommands + OLC_HEAD
If InStr(x$, "N") Then OnlineCommands = OnlineCommands + OLC_NEW
If isenabled("OnlineHotkey") Then
    Load frmWindowO
    frmWindowO.onn
End If
If isenabled("DisableRandomSigs") Then randomsigs = False
If isenabled("ShowLanguageID", "Debugging") Then showLanguage = True
x$ = UCase(Trim(getini("Hints", "3")))
If Val(x$) = -1 Then
tipps = -1
ElseIf Val(x$) = -2 Then
tipwin = True: tipps = 10
Else
tipps = Val(x$)
End If
frmmain.tmrSleep.Interval = Int(Val(Left$(Trim(getini("Sleep", "1")), 4)))
If frmmain.tmrSleep.Interval <= 60 Then frmmain.tmrSleep.Interval = frmmain.tmrSleep.Interval * 1000
frmmain.tmrDo.Interval = Int(Val(Left(Trim(getini("Refresh", "100")), 4)))
If frmmain.tmrDo.Interval = 0 Then frmmain.tmrDo.Interval = 100
SupersedesFrom = getini("SupersedesFrom", "")
x$ = getini("KeyActions", "**X")
Dim i As Integer
For i = 0 To 2
FxActions(i) = Asc(Mid$(x$, i + 1, 1))
If FxActions(i) = Asc("-") Then FxActions(i) = 0
Next
HamPath = getini("HamsterPath", "")
HamScore = getini("HamsterScore", "+100")
AFClipPrefix = getini("AFClipPrefix", "")
char$ = getini("ActionChar", "#")
End Sub

Function isenabled(setting$, Optional block$ = "Settings") As Boolean
Dim x$
x$ = Trim(getini$(setting$, "0", block$))
If x$ <> "0" And UCase(x$) <> "NO" Then isenabled = True Else isenabled = False
End Function

Function getini$(desc$, default$, Optional block$ = "Settings")
Dim buff As String * 1024, ret As Long
ret = GetPrivateProfileString(block$, desc$, default$, buff, Len(buff), App.Path + "\agttool.ini")
getini$ = Left$(buff, ret)
End Function

Function getLanguage(hwnd As Long, version As Integer)
Dim hMen As Long, mii As MENUITEMINFO, buffer As String, res As Long
Dim helpabout$, i As Integer, j As Long
hMen = GetMenu(hwnd)
j = GetMenuItemCount(hMen)
If hMen = 0 Then getLanguage = -2: Exit Function
mii.cbSize = Len(mii)
buffer = String$(129, 0)
mii.dwTypeData = StrPtr(buffer)
mii.cch = Len(buffer) - 1
mii.fMask = MIIM_TYPE
res = GetMenuItemInfo(hMen, AgentProperties(version).mnuForLanguage, 0, mii)
If res = 0 Then
getLanguage = -1: Exit Function
End If
helpabout$ = Left$(StrConv(buffer, vbUnicode), mii.cch)
If InStr(helpabout$, Chr$(9)) Then helpabout$ = Left$(helpabout$, InStr(helpabout$, Chr$(9)) - 1)
For i = 1 To languageCount
If helpabout$ = languageText(i) Then Exit For
Next
If i = languageCount + 1 Then i = 0
getLanguage = i
End Function

Sub initLanguages()
Dim buff As String * 1024, ret As Long, langspec$, i As Integer
Dim l As Integer
languageID(-1) = "ERROR"
languageID(0) = "UNKNOWN"
For l = 1 To 20
ret = GetPrivateProfileString("Languages", "Language" & l, "<end>", buff, Len(buff), App.Path + "\language.dat")
langspec$ = Left$(buff, ret)
If langspec$ = "<end>" Then Exit For
i = InStr(langspec$, ",")
CriticalErrorOn i = 0, "Incorrect Language Spec #" & l
languageID(l) = Left$(langspec$, i - 1)
langspec$ = Mid$(langspec$, i + 1)
i = InStr(langspec$, ",")
CriticalErrorOn i <> 8, "Incorrect Language Spec #" & l
languageKeys(l) = Left$(langspec, i - 1)
languageText(l) = Mid$(langspec$, i + 1)
Next
languageCount = l - 1:
CriticalErrorOn l = 1, "No language definitions found"
languageKeys(0) = "      "
End Sub

Sub checkforautosig(hwnd As Long)
Dim ret As Long, cnt As Long, txt$, indizes(1 To 1000) As Long, indianz As Integer
Dim weight As Integer, x$, ii As Long, i As Integer
buffer = Space(1000)
tipp$ = ""
ret = SendMessage(hwnd, WM_GETTEXT, 1000, ByVal buffer)
txt$ = Left$(buffer, ret)
If Left$(txt$, 1) = "[" And Right$(txt$, 1) = "]" And InStr(txt$, ": ") <> 0 Then
i = InStr(txt$, ": ")
txt$ = Mid$(txt$, i + 2, Len(txt$) - i - 2)
End If
If Right$(txt$, 1) <> "#" Then Exit Sub
txt$ = Left$(txt$, Len(txt$) - 1)
cnt = SendMessage(hwnd, CB_GETCOUNT, 0, ByVal 0&)
If cnt = 0 Then Exit Sub
indianz = 0
For ii = 0 To cnt - 1
buffer = Space(1000)
ret = SendMessage(hwnd, CB_GETLBTEXT, ii, ByVal buffer)
x$ = Left$(buffer, ret)
If Left$(x$, Len(txt$)) = txt$ And x$ <> txt$ + "#" Then
For i = Len(x$) To 1 Step -1
If InStr("1234567890", Mid$(x$, i, 1)) = 0 Then Exit For
Next
If Mid$(x$, i, 1) = "#" Then weight = Val(Mid$(x$, i + 1)) Else weight = 1
For i = 1 To weight
indianz = indianz + 1
indizes(indianz) = ii
Next
End If
Next
If indianz = 0 Then Exit Sub ' keine passenden Ersatzsignaturen :-(
i = Int(Rnd * indianz) + 1
ii = indizes(i)
SendMessage hwnd, CB_SETCURSEL, ii, ByVal 0&
End Sub


Public Function ForceForegroundWindow2(ByVal hwnd As Long) As Boolean
   Dim ThreadID1 As Long
   Dim ThreadID2 As Long
   Dim nRet As Long
   If hwnd = GetForegroundWindow() Then
      ForceForegroundWindow2 = True
   Else
      ThreadID1 = GetWindowThreadProcessId(GetForegroundWindow, ByVal 0&)
      ThreadID2 = GetWindowThreadProcessId(hwnd, ByVal 0&)
      '
      ' By sharing input state, threads share their concept of
      ' the active window.
      '
      If ThreadID1 <> ThreadID2 Then
         Call AttachThreadInput(ThreadID1, GetCurrentThreadId, True)
         Call AttachThreadInput(ThreadID1, ThreadID2, True)
         nRet = SetForegroundWindow(hwnd)
                
         Call AttachThreadInput(ThreadID1, ThreadID2, False)
         Call AttachThreadInput(ThreadID1, GetCurrentThreadId, False)
      Else
         nRet = SetForegroundWindow(hwnd)
      End If
      ForceForegroundWindow2 = CBool(nRet)
   End If
End Function

Sub init()
frmWindowO.off
taglines = taglines_
char$ = "#"
tipps = 3
autofup = True
xface = xface_
wasmode = True
frmmain.tmrDo.Interval = 100
frmmain.tmrSleep.Interval = 1000
pgpCtrlShiftD = False
tipwin = False
randomsigs = True
FxActions(0) = 32
FxActions(1) = 32
FxActions(2) = Asc("X")
End Sub

Sub CriticalErrorOn(condition As Boolean, Msg As String)
If condition Then
    MsgBox "An internal error occurred:" + vbNewLine + _
           """" + Msg + """" + vbNewLine + vbNewLine + _
           "Please contact sm-soft@gmx.de with exact error message " + vbNewLine + _
           "and how to reproduce. Thank you!" + vbNewLine + vbNewLine + _
           "Closing AgtTool now...", _
        vbCritical + vbSystemModal + vbOKOnly, "AgtTool internal error"
    End
End If
End Sub

Function instanceInfoForHwnd(hwnd As Long, Optional errormsg As String = "") As InstanceInfoType
Dim res As InstanceInfoType, i As Integer
For i = 1 To instanceInfoAnz
 If InstanceInfo(i).hwnd = hwnd Then
    instanceInfoForHwnd = InstanceInfo(i)
    lastinstindex = i
    Exit Function
 End If
Next
CriticalErrorOn errormsg <> "", errormsg
res.hwnd = -1
instanceInfoForHwnd = res
End Function
