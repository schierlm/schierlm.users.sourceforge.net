Attribute VB_Name = "mdlMenu"
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit

Function isMenuChecked(hwnd As Long, menuID As Long) As Integer
Dim hMen As Long, has As Long, mic As Long, i As Long, mic2 As Long
Dim hMen2 As Long, mii As MENUITEMINFO, j As Long, ok As Boolean
hMen = GetMenu(hwnd)
mic = GetMenuItemCount(hMen)
For i = 0 To mic - 1
hMen2 = GetSubMenu(hMen, i)
If hMen2 <> 0 Then
mic2 = GetMenuItemCount(hMen2)
For j = 0 To mic2 - 1
mii.cbSize = Len(mii)
mii.fMask = MIIM_ID
mii.wID = 0
GetMenuItemInfo hMen2, j, 1, mii
If mii.wID = menuID Then ok = True: Exit For
Next
If ok = True Then Exit For
End If
Next
If ok = False Then isMenuChecked = 2: Exit Function
SendMessage hwnd, WM_INITMENUPOPUP, hMen2, ByVal 0&
mii.fMask = MIIM_STATE
If GetMenuItemInfo(hMen, menuID, 0, mii) = 0 Then isMenuChecked = 2: Exit Function
If mii.fState And MFS_CHECKED Then
isMenuChecked = 1
Else
isMenuChecked = 0
End If
End Function


Function MenuItemCount(hwnd As Long)
MenuItemCount = GetMenuItemCount(GetMenu(hwnd))
End Function

Sub sendcommand(hwnd As Long, id As Long)
Dim hMen As Long, mii As MENUITEMINFO, res As Long
Dim helpabout$, j As Long
hMen = GetMenu(hwnd)
If hMen = 0 Then Exit Sub
mii.cbSize = Len(mii)
mii.dwTypeData = 0
mii.cch = 0
mii.fMask = MIIM_STATE + MIIM_ID
res = GetMenuItemInfo(hMen, id, 0, mii)
If res = 0 Then
Exit Sub
End If
If mii.wID <> id Then Stop
If (mii.fState And MFS_GRAYED) <> 0 Then
Else
SendMessage hwnd, WM_COMMAND, id, ByVal 0&
End If
End Sub

