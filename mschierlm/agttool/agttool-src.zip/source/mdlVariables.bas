Attribute VB_Name = "mdlVariables"
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit

Public Const ARRAYLIMIT = 1000, MAX_CUMUL_INSTANCES = 200

'' instances found in last run of EnumWindows
Public instances As Integer

'' arrays of hwnds
Public hwndanz As Integer, hwnds(1 To ARRAYLIMIT) As Long
Public hwndagent(0 To ARRAYLIMIT) As Long, fupother(1 To ARRAYLIMIT) As Long

'' group data, aliases
Public gcount As Long, groups(-1 To 100000) As String
Public acount As Integer, aliases(-1 To 1000) As String
Public aliases2(1000) As String

'' taglines
Public tlanz As Long, taggroup(0 To 100000) As String
Public tagline(0 To 100000) As String

'' HWNDs of subject entry fields
Public subjects(ARRAYLIMIT) As Long, sanz As Integer

'' all instances ever seen with information about them
Public Type InstanceInfoType
    hwnd As Long
    language As Integer
    created As Single
    found As Boolean
    version As Integer
End Type

Public InstanceInfo(MAX_CUMUL_INSTANCES) As InstanceInfoType
Public instanceInfoAnz As Integer

'' languages
Public languageCount As Integer, languageID(-1 To 20) As String
Public languageText(20) As String, languageKeys(120) As String

'' email address aliases
Public emilanz As Integer, emil1(1000) As String, emil2(1000) As String

'' autofup stuff
Public autofup As Boolean
Public fup_hwnd1 As Long, fup_hwnd2 As Long, fup_last As String
Public fup_active As Boolean, fup_pos As Integer
Public fup_lang As String, fup_vers As Integer
Public fup_source As String

'-------- unsorted stuff ---------

Public randomsigs As Boolean, lastAgentHwnd As Long, lastinstindex As Integer
Public buffer As String, char$, tipps As Integer
Public tipp$, forcetipps As Boolean, showLanguage As Boolean

Public taglines As Boolean, reshow As Boolean, xface As Boolean
Public lasthit As String, h_parent As Long, fl_parent As Boolean


Public wasmode As Boolean, xface_ As Boolean, taglines_ As Boolean
Public DoShowing As Boolean, F12AgentWnd As Long, F12Version As Integer
Public Fnumber As Integer
Public SupersedesFrom As String, HamPath As String, HamScore As String
Public AutoQuit As Boolean, pgpCtrlShiftD As Boolean
Public AgentWait As Integer, AFClipPrefix As String, tipwin As Boolean
Public tipwinfirst As Long, tipwinlast As Long, tipwinlength As Long
Public tipshere As Boolean, tiphwnd As Long, lasttip As Boolean
Public FxActions(2) As Integer
Public groupsresult$

Enum OnlineCommandEnum
OLC_POST = 1
OLC_MAIL = 2
OLC_BODY = 4
OLC_HEAD = 8
OLC_NEW = 16
End Enum

Public OnlineCommands As OnlineCommandEnum
