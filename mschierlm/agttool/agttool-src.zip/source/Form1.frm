VERSION 5.00
Begin VB.Form frmmain 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "AgtTool (c) 2002-2004 Michael Schierl"
   ClientHeight    =   3930
   ClientLeft      =   1050
   ClientTop       =   1335
   ClientWidth     =   4440
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   3930
   ScaleWidth      =   4440
   Begin VB.CommandButton cmdOpts 
      Caption         =   "&Options..."
      Height          =   375
      Left            =   240
      TabIndex        =   9
      Top             =   3480
      Width           =   1215
   End
   Begin VB.Timer tmrSleep 
      Interval        =   1000
      Left            =   600
      Top             =   -120
   End
   Begin VB.Frame Frame1 
      Height          =   975
      Left            =   120
      TabIndex        =   2
      Top             =   1800
      Width           =   4215
      Begin VB.TextBox txtChar 
         BackColor       =   &H8000000F&
         Height          =   285
         Left            =   3720
         Locked          =   -1  'True
         MaxLength       =   1
         TabIndex        =   6
         TabStop         =   0   'False
         Text            =   "?"
         Top             =   240
         Width           =   375
      End
      Begin VB.Label lblhints 
         Caption         =   "hint level: ?"
         Height          =   255
         Left            =   120
         TabIndex        =   3
         Top             =   240
         Width           =   1215
      End
      Begin VB.Label lblAutoQuit 
         Caption         =   "AutoQuit: ?"
         Height          =   255
         Left            =   1800
         TabIndex        =   10
         Top             =   240
         Width           =   1215
      End
      Begin VB.Label lblInfo 
         Alignment       =   2  'Zentriert
         Caption         =   "? Agent instances, ? text boxes"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   5
         Top             =   600
         Width           =   3975
      End
      Begin VB.Label Label1 
         Caption         =   "Char:"
         Height          =   255
         Left            =   3120
         TabIndex        =   4
         Top             =   240
         Width           =   615
      End
   End
   Begin VB.CommandButton cmdHide 
      Caption         =   "&Hide"
      Height          =   375
      Left            =   3120
      TabIndex        =   1
      Top             =   3480
      Width           =   1215
   End
   Begin VB.Timer tmrDo 
      Interval        =   100
      Left            =   2040
      Top             =   -120
   End
   Begin VB.Timer tmrFind 
      Interval        =   1000
      Left            =   1440
      Top             =   -120
   End
   Begin VB.TextBox txtTest 
      Height          =   285
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4215
   End
   Begin VB.Label Label3 
      Caption         =   "Enter #show# (or whatever you have set the special char to) into any watched field to reshow AgtTool."
      Height          =   495
      Left            =   240
      TabIndex        =   8
      Top             =   2880
      Width           =   3855
   End
   Begin VB.Label Label2 
      Caption         =   $"Form1.frx":030A
      Height          =   1215
      Left            =   120
      TabIndex        =   7
      Top             =   480
      Width           =   4095
   End
End
Attribute VB_Name = "frmmain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Dim lastclip$, ownuse As Boolean, instinfo As InstanceInfoType

Private Sub cmdHide_Click()
    If instances = 0 Then MsgBox "No Fort� Agent instance found.", vbExclamation: Exit Sub
    Me.Visible = False
    reshow = True
    tmrFind.Enabled = True
End Sub

Sub cmdOpts_Click()
    tmrDo.Enabled = False
    tmrFind.Enabled = False
    tmrSleep.Enabled = False
    frmOptions.Show 1, Me
    tmrDo.Enabled = True
    tmrFind.Enabled = True
    tmrSleep.Enabled = True
    showstate
End Sub

Private Sub Form_Load()
    showstate
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    Dim i As Long
    tmrDo.Enabled = False
    tmrFind.Enabled = False
    removetgl
    For i = 0 To tlanz
        taggroup(i) = vbNullString
        tagline(i) = vbNullString
    Next
    For i = 0 To gcount
        groups(i) = vbNullString
    Next
    Unload frmXFace
    Unload frmSelect
    Unload frmTipp
    Unload frmWindowO
    Unload Me
End Sub

Private Sub Form_Resize()
    If Me.WindowState = vbNormal Then reshow = False
End Sub

Private Sub TmrDo_Timer()
    Static f_prell As Boolean
    Static in_it As Boolean
    
    Dim i As Integer, hh As Long, x$
    Dim ret As Long, txt$
    
    Fnumber = 3 '' FIXME: what for?
    
    If in_it = True Then Exit Sub
    in_it = True
    If h_parent = 1000 Then
        hwnds(1000) = txtTest.hwnd
        handlewnd txtTest.hwnd
        h_parent = 0
    End If
    If taglines Then
        For i = 1 To instanceInfoAnz
            If InstanceInfo(i).found Then
                instinfo = InstanceInfo(i)
                maketgl InstanceInfo(i).hwnd, True
            End If
            If taglines = False Then
                InstanceInfo(i).found = False  ' that one failed, so don't remove!
                removetgl
                in_it = False
                Exit Sub
            End If
        Next
    End If
    For i = 1 To hwndanz
        h_parent = i
        handlewnd hwnds(i)
    Next
    If wasmode = True Then
        For i = 1 To sanz
            handlesubject subjects(i)
        Next
    End If
        
    If autofup = True And fup_active = True Then dofups
    If tiphwnd <> 0 Then handletips
        
    Fnumber = 3
    If (GetAsyncKeyState(vbKeyF12) < 0 And FxActions(2) <> 0) Then Fnumber = 2
    If (GetAsyncKeyState(vbKeyF2) < 0 And FxActions(0) <> 0) Then Fnumber = 0
    If (GetAsyncKeyState(vbKeyF11) < 0 And FxActions(1) <> 0) Then Fnumber = 1
    
    If Fnumber <> 3 Then
        If f_prell = False Then
            f_prell = True
            hh = GetForegroundWindow
            Dim ii As InstanceInfoType
            ii = instanceInfoForHwnd(hh)
            If ii.hwnd <> -1 Then
            F12Version = ii.version
            CriticalErrorOn F12Version <> 1 And F12Version <> 2, "tmrDo_Timer: InstanceInfo().version uninitialized"
            Dim mic As Long
            mic = MenuItemCount(hh) '' FIXME: why test so late?
            If mic = 10 Or mic = 14 Then
                Dim ttt As Single
                F12AgentWnd = hh
                On Error Resume Next
                For i = 1 To 100
                    Err.Clear
                    Clipboard.Clear
                    ttt = Timer: Do: DoEvents: Loop Until ttt + 0.1 < Timer
                    If Err.Number = 0 Then Exit For
                Next
                On Error GoTo 0
                CriticalErrorOn i = 101, "Could not access Clipboard (tmrDo_Timer:1)"
                mic = isMenuChecked(F12AgentWnd, AgentProperties(F12Version).mnuShowAllHeaders)  'Show All Headers
                If mic = 1 Then
                    SendKeys "3^a^chh", True
                Else
                    SendKeys "3h^a^ch", True
                End If
                lastclip$ = ""
                Dim t2 As Single
                t2 = Timer
                Do
                    DoEvents
                    On Error Resume Next
                    For i = 1 To 100
                        Err.Clear
                        txt$ = Clipboard.GetText
                        ttt = Timer: Do: DoEvents: Loop Until ttt + 0.1 < Timer
                        If Err.Number = 0 Then Exit For
                    Next
                    On Error GoTo 0
                    CriticalErrorOn i = 101, "Could not access Clipboard (trmDo_Timer:2)"
                Loop Until txt$ <> "" Or t2 + 1 < Timer
                lastclip$ = txt$
                clipcheck
            End If
            End If
        End If
    Else
        f_prell = False
    End If
    in_it = False
End Sub

Sub clipcheck(Optional what$ = "")
    Dim x$, i As Long
    If (what <> "") Or (instances <> 0) Then
        If what$ <> "" Then lastclip$ = what$
        x$ = lastclip$
        CriticalErrorOn Fnumber = 3, "Internal Error (clipcheck:1)"
        i = InStr(UCase$(x$), "REFERENCES: ")
        If i = 0 Then i = InStr(UCase(x$), "MESSAGE-ID: ")
        If i = 0 Then i = InStr(UCase$(x$), "X-FACE: ")
        If i <> 0 Then
            frmSelect.doAction FxActions(Fnumber)
            x$ = ""
            Fnumber = 3
        End If
    End If
End Sub

'' VB does not allow Types as params, so I use a boolean here
'' to remind that the caller has to set instinfo before calling.
Public Sub maketgl(h As Long, instinfoset As Boolean)
    Dim ret As Long, x$, i As Long, l$, p1 As Long, p2 As Long, j As Long, n As Long
    Dim langid$
    buffer = Space$(1048)
    ret = GetWindowText(h, buffer, Len(buffer))
    x$ = Left$(buffer, ret)
    If Right$(x$, 1) <> "]" Then Exit Sub
    If InStr(x$, " --> ") Then
        Exit Sub ' don't show taglines
    End If
    i = InStrRev(x$, "[")
    l$ = Mid$(x$, i + 1, Len(x$) - i - 1)
    p1 = 0
    p2 = tlanz - 1
    Do While p1 <= p2
        n = (p1 + p2) \ 2
        If taggroup(n) = l$ Then Exit Do
        If taggroup(n) < l$ Then p1 = n + 1
        If taggroup(n) > l$ Then p2 = n - 1
    Loop
    If showLanguage Then
        With instinfo
            If .created + 5 < Timer Then
                langid$ = ""
            Else
                langid$ = " {" + languageID(.language) + "}"
            End If
        End With
    Else
        langid$ = ""
    End If
    If p1 > p2 Then
        SetWindowText h, x$ + langid$ + " "
    Else
        SetWindowText h, x$ + " --> " + tagline$(n) + langid$ + " "
    End If
End Sub

Sub removetgl()
Dim ret As Long, x$, i As Long, j As Integer
For i = 1 To instanceInfoAnz
    If InstanceInfo(i).found Then
        buffer = Space$(1048)
        ret = GetWindowText(InstanceInfo(i).hwnd, buffer, Len(buffer))
        x$ = Left$(buffer, ret)
        j = InStr(x$, " --> ")
        If j <> 0 And Right$(x$, 1) = " " Then
            SetWindowText InstanceInfo(i).hwnd, Left$(x$, j - 1)
        End If
    End If
Next
End Sub

Sub handletips()
Dim ret As Long, txt$, y$, i As Integer, buf2 As String
buffer = Space(1000)
tipp$ = ""
ret = SendMessage(tiphwnd, WM_GETTEXT, 1000, ByVal buffer)
txt$ = Left$(buffer, ret)
buf2 = txt$
If tipshere = False Then
txt$ = Replace(txt$, "�", "")
End If
If Right$(txt$, 1) = "�" Then
ElseIf InStr(txt$, "�") Then
i = InStr(txt$, "�")
y$ = Mid$(txt$, i + 1)
If Len(y$) > 1 Or InStr("0123456789", y$) = 0 Then
txt$ = Replace(txt$, "�", "") + "##"
tipshere = False
Unload frmTipp
Else
If InStr(txt$, ",") Then
txt$ = Left$(txt$, InStrRev(txt$, ","))
Else
txt$ = ""
End If
txt$ = txt$ + frmTipp.lblgrp(InStr("1234567890", y$))
txt$ = Replace(txt$, "#", "##")
tipshere = False
Unload frmTipp
End If
Else
tipshere = False
lasttip = False
Unload frmTipp
End If
If buf2 <> txt$ Then
SendMessage tiphwnd, WM_SETTEXT, 0, ByVal (txt$)
SendMessage tiphwnd, EM_SETSEL, Len(txt$), ByVal Len(txt$)
End If
If tipshere = False Then tiphwnd = 0
End Sub

Sub handlewnd(h As Long)
Dim ret As Long, txt$, y$
buffer = Space(1000)
tipp$ = ""
ret = SendMessage(h, WM_GETTEXT, 1000, ByVal buffer)
txt$ = Left$(buffer, ret)
If (Right$(txt$, 1) = char$ And Len(txt$) > 1 And Right$(txt$, 2) <> "," + char$) Or txt$ = "..." Or Right$(txt$, 4) = ",..." Or Right$(txt$, 4) = ",,,," Then
txt$ = change$(txt$)
y$ = txt$ + tipp$
If tipp$ = "�" Then txt$ = txt$ + tipp$
showstate
SendMessage h, WM_SETTEXT, 0, ByVal (y$)
SendMessage h, EM_SETSEL, Len(txt$), ByVal Len(y$)
End If

End Sub

Sub handlesubject(h As Long)
Dim ret As Long, txt$, y$, i As Integer
buffer = Space(1000)
tipp$ = ""
ret = SendMessage(h, WM_GETTEXT, 1000, ByVal buffer)
txt$ = Left$(buffer, ret)
y$ = ""
If InStr(txt$, char$ + "Re: ") Then
i = InStr(txt$, char$ + "Re: ")
y$ = RTrim$(Left$(txt$, i - 1)) + " (was: " + Mid$(txt$, i + 5) + ")"
ElseIf InStr(txt$, char$ + " Re: ") Then
i = InStr(txt$, char$ + " Re: ")
y$ = RTrim$(Left$(txt$, i - 1)) + " (was: " + Mid$(txt$, i + 6) + ")"
ElseIf Left$(txt$, 4) = "Re: " And Right$(txt$, 1) = ")" And InStr(LCase(txt$), "(was:") Then
y$ = RTrim$(Left$(txt$, InStr(LCase(txt$), "(was:") - 1))
ElseIf Left$(txt$, 4) = "Re: " And Right$(txt$, 1) = ")" And InStr(LCase(txt$), "(war:") Then
y$ = RTrim$(Left$(txt$, InStr(LCase(txt$), "(war:") - 1))
ElseIf Left$(txt$, 4) = "Re: " And Right$(txt$, 1) = "]" And InStr(LCase(txt$), "[was:") Then
y$ = RTrim$(Left$(txt$, InStr(LCase(txt$), "[was:") - 1))
ElseIf Left$(txt$, 4) = "Re: " And Right$(txt$, 1) = "]" And InStr(LCase(txt$), "[war:") Then
y$ = RTrim$(Left$(txt$, InStr(LCase(txt$), "[war:") - 1))
End If

If y$ <> "" Then

SendMessage h, WM_SETTEXT, 0, ByVal (y$)
SendMessage h, EM_SETSEL, Len(y$), ByVal Len(y$)
End If

End Sub



Sub tmrFind_Timer()
Dim i As Integer, found As Boolean
instances = 0: hwndanz = 0: sanz = 0
For i = 1 To instanceInfoAnz
    InstanceInfo(i).found = False
Next
EnumWindows AddressOf EnumWindowsProc, 10
Do While instances < instanceInfoAnz
    found = False
    For i = 1 To instanceInfoAnz
        If InstanceInfo(i).found = False Then
        found = True
        If i < instanceInfoAnz Then
            InstanceInfo(i) = InstanceInfo(instanceInfoAnz)
        End If
        instanceInfoAnz = instanceInfoAnz - 1
        Exit For
        End If
    Next
    CriticalErrorOn found = False, "Could not find obsolete InstanceInfoEntry (tmrFind_Timer:1)"
Loop
If instances = 0 And AutoQuit = True Then
If AgentWait <= 0 Then
Unload Me: Exit Sub
Else
AgentWait = AgentWait - 1
End If
End If
If instances > 0 And AutoQuit = True Then AgentWait = 0
If AutoQuit = False Then
If instances = 0 And reshow = True Then
Me.WindowState = vbMinimized: Me.Visible = True
End If
If instances > 0 And reshow = True Then Me.Visible = False
End If
showstate
If instances > 0 Then ownuse = False
If instances = 0 And ownuse = False Then
tmrFind.Enabled = False
tmrDo.Enabled = False
Else
tmrFind.Enabled = True
tmrDo.Enabled = True
End If
End Sub



Private Sub tmrSleep_Timer()
tmrFind_Timer
End Sub

Private Sub txtChar_GotFocus()
txtTest.SetFocus
End Sub

Private Sub txtTest_Change()
h_parent = 1000
ownuse = True
tmrDo.Enabled = True
tmrFind.Enabled = True
End Sub


Sub showstate()
txtChar = char$
lblInfo = instances & " Agent instances, " & hwndanz & " text boxes"
If tipps = -1 Then lblhints = "hints off" Else lblhints = "hint level: " & tipps
lblAutoQuit = "AutoQuit: " + IIf(AutoQuit = True, "on", "off")
End Sub

Sub dofups()
Dim t1$, t2$, ret As Long
ret = SendMessage(fup_hwnd1, WM_GETTEXT, 1000, ByVal buffer)
t1$ = Left$(buffer, ret)
If t1$ = fup_source Then Exit Sub
fup_source = t1$
If Len(t1$) < fup_pos - 1 Then fup_active = False: Exit Sub
t1$ = Mid$(t1$, fup_pos)
ret = SendMessage(fup_hwnd2, WM_GETTEXT, 1000, ByVal buffer)
t2$ = Left$(buffer, ret)
If t2$ <> fup_last Then fup_active = False: Exit Sub
SendMessage fup_hwnd2, WM_SETTEXT, 0, ByVal (t1$)
fup_last = t1$
ret = SendMessage(fup_hwnd2, WM_KILLFOCUS, fup_hwnd1, 0)
If Len(AFClipPrefix) Then doafcp fup_source, Mid$(fup_source, fup_pos)
End Sub

Sub doafcp(xp$, fup$)
Dim i As Integer, c$
i = InStr(AFClipPrefix, "\|")
If i = 0 Then
c$ = AFClipPrefix
Else
c$ = Left$(AFClipPrefix, i - 1)
End If
c$ = Replace(c$, "\x", xp$)
c$ = Replace(c$, "\f", fup$)
c$ = Replace(c$, "\n", vbNewLine)
c$ = Replace(c$, "\\", "\")
On Error Resume Next
Clipboard.Clear
Clipboard.SetText c$
On Error GoTo 0
End Sub
