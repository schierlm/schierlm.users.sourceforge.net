Attribute VB_Name = "mdlPGP"
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit

Function PGPTransform(ByVal article$) As String
Dim i As Long, j As Long, he$, bo$, sig$
Dim x$, y$, vers$, arr As Variant, res$
i = InStr(article$, vbNewLine + "-----BEGIN PGP SIGNED MESSAGE-----" + vbNewLine)
If i <> 0 Then
PGPTransform = "*** PGP in Body ***" + vbNewLine + vbNewLine + article$
Exit Function
End If
i = InStr(article$, vbNewLine + vbNewLine)
If i = 0 Then
PGPTransform = "*** No header found ***" + vbNewLine + vbNewLine + article$
Exit Function
End If
he$ = vbNewLine + Left$(article$, i - 1)
bo$ = Mid$(article$, i + 4)
sig$ = GetHeader(he$, "X-PGP-Sig")
sig$ = Replace(Replace(sig$, vbTab, " "), vbNewLine, " ")
If UCase(sig$) = "X-PGP-SIG:" Then
PGPTransform = "*** No X-PGP-Sig found ***" + vbNewLine + vbNewLine + article$
Exit Function
'''
End If
For i = 1 To 10
sig$ = Replace(sig$, "  ", " ")
Next
sig$ = Mid$(sig$, 12)

i = InStr(sig$, " ")
If i = 0 Then PGPTransform = "*** Invalid X-PGP-Sig (Space1) ***" + vbNewLine + sig$: Exit Function
j = InStr(i + 1, sig$, " ")
If j = 0 Then PGPTransform = "*** Invalid X-PGP-Sig (Space2) ***" + vbNewLine + sig$: Exit Function

x$ = Left$(sig$, j - 1)
y$ = Mid$(sig$, j + 1)
y$ = Replace(y$, " ", vbNewLine)
vers$ = Left$(x$, i - 1)
x$ = Mid$(x$, i + 1)
arr = Split(x$, ",")
res$ = "-----BEGIN PGP SIGNED MESSAGE-----" + vbNewLine + vbNewLine
res$ = res$ + "X-Signed-Headers: " + x$ + vbNewLine
For i = LBound(arr) To UBound(arr)
res$ = res$ + GetHeader(he, (arr(i))) + vbNewLine
Next
res$ = res$ + vbNewLine + Replace(bo$, vbNewLine + "-", vbNewLine + "- -") + vbNewLine + vbNewLine
res$ = res$ + "-----BEGIN PGP SIGNATURE-----" + vbNewLine + "Version: " + vers$ + vbNewLine + vbNewLine
res$ = res$ + y$
res$ = res$ + vbNewLine + "-----END PGP SIGNATURE-----"
PGPTransform$ = res$
End Function

Function GetHeader(he$, was$) As String
Dim i As Integer, x$
i = InStr(UCase$(he$), UCase$(vbNewLine + was$ + ": "))
If i = 0 Then GetHeader = was$ + ":": Exit Function
x$ = Mid$(he$, i + 2)
i = 0
Do
i = InStr(i + 1, x$, vbNewLine)
If i = 0 Then i = Len(x$) + 1: Exit Do
Loop Until Mid$(x$, i + 2, 1) <> " " And Mid$(x$, i + 2, 1) <> vbTab
GetHeader$ = Left$(x$, i - 1)
End Function
