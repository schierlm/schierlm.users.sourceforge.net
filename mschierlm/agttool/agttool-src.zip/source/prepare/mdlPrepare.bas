Attribute VB_Name = "mdlPrepare"
'''' Prepare for AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Dim filebuff(0 To 100000) As String, fbanz As Long, changed As Boolean
Dim dotless As Boolean

Sub Main()
Dim i As Long, j As Integer
Open App.Path + "\prepare.log" For Output As #3
Print #3, "---- PREPARE log - " & Format(Date, "yyyy-mm-dd") & " " & Format(Time, "hh:mm") & " ----"
If Dir(App.Path + "\GROUPS.IDX") <> "" Then
MsgBox "WARNING: Prepare changes your GROUPS.DAT so that it fits for AgtTool. " + _
       "Do ***not*** run Prepare on your original GROUPS.DAT! Always create a copy " + _
       "of that file in the AgtTool directory and let PREPARE.EXE work on that " + _
       "copy. (Do *not* copy GROUPS.IDX!) Quitting PREPARE.EXE...", vbCritical, "Prepare"
Print #3, "Groups.IDX unexspecedly found -- quitting..."
End
End If
If InStr(UCase(Command), "/DOTLESS") Then dotless = True Else dotless = False
frmPrepare.Show
DoEvents
prepareFile App.Path + "\groups.dat", "GROUPS.DAT"
Print #3, "Groups.Dat pass 2..."
For i = 1 To fbanz
If i Mod 1000 = 0 Then state "Removing folders - " & i
If filebuff(i) = filebuff(i - 1) Then removeline i - 1
If InStr(filebuff(i), ".") = 0 And dotless = False Then removeline i
Next
writefile App.Path + "\groups.dat", "GROUPS.DAT"
prepareFile App.Path + "\taglines.dat", "TAGLINES.DAT"
Print #3, "Taglines.dat pass 2..."
For i = 1 To fbanz
If i Mod 1000 = 0 Then state "Removing empty taglines - " & i
If filebuff(i) = filebuff(i - 1) Then removeline i - 1
If InStr(filebuff(i), "oderated") = 0 And _
(InStr(filebuff(i), Chr$(9) + "no desc") <> 0 Or Right$(filebuff(i), 2) = Chr$(9) + "?") Then
 removeline i
End If
If filebuff(i) <> Chr$(0) Then
j = InStr(filebuff(i), Chr$(9))
If j <> 0 Then
If InStr(Left$(filebuff(i), j - 1), " ") Then
If MsgBox("Incorrect tagline: " + vbNewLine + filebuff(i) + vbNewLine + vbNewLine + "Continue?", vbYesNo + vbDefaultButton2 + vbQuestion) = vbNo Then End
End If
Else
j = InStr(filebuff(i), " ")
If j = 0 Or j = 1 Then
If MsgBox("Incorrect tagline: " + vbNewLine + filebuff(i) + vbNewLine + vbNewLine + "Continue?", vbYesNo + vbDefaultButton2 + vbQuestion) = vbNo Then End
Else
Mid$(filebuff(i), j, 1) = Chr$(9)
changed = True
End If
End If
End If
Next
writefile App.Path + "\taglines.dat", "TAGLINES.DAT"
state "Done."
MsgBox "Done.", vbInformation
Print #3, "=========="
Print #3, "Finished."
Close #3
Unload frmPrepare
End Sub
Sub removeline(no)
filebuff(no) = Chr$(0)
If changed = False Then
Print #3, "Line changed!"
End If
changed = True
End Sub
Sub resetfb()
Dim i As Long
For i = 0 To fbanz
filebuff(i) = ""
Next
fbanz = 0
changed = False
End Sub

Sub writefile(f$, ff$)
Dim i As Long
If changed = False Then
Print #3, "File " + ff$ + " not changed, skipped saving..."
Exit Sub
End If
Print #3, "Saving file " + ff$ + "..."
state "Saving: " + ff$
Open f$ For Output As #1
For i = 1 To fbanz
If filebuff(i) <> Chr$(0) Then Print #1, filebuff(i)
Next
Close #1
Print #3, "File " + f$ + ": " & fbanz & " records saved. <<<<<<<<<<"
changed = False
End Sub
Sub prepareFile(f$, ff$)
Dim sort As Boolean
resetfb
Print #3, "==========="
Print #3, "File " + ff$ + ", loading & Pass 1..."
sort = False
If Dir(f$) = "" Then
MsgBox "Warning: File " + ff$ + " not found", vbInformation
Print #3, "***** File not found: " + ff$ + " *****"
Exit Sub
End If
Open f$ For Input As #1
Do Until EOF(1)
If fbanz Mod 1000 = 0 Then state "Reading: " + ff$ + " - " & fbanz
fbanz = fbanz + 1
If fbanz = 100000 Then MsgBox "File too large: " + ff$: End
Line Input #1, filebuff(fbanz)
If InStr(filebuff(fbanz), Chr$(10)) Then
Print #3, "Note: File is in Unix format - Converting to Windows format and restarting..."
MsgBox "File " + ff$ + " is converted UNIX2Windows...", vbInformation
Close #1
ux2win f$, ff$
prepareFile f$, ff$
Exit Sub
End If
If filebuff(fbanz) < filebuff(fbanz - 1) Then sort = True
Loop
Close #1
Print #3, "File " + ff$ + ": " & fbanz & " records imported.  <<<<<<<<<<"
If sort Then
Print #3, "Sorting of " + ff$ + " is necessary, sorting..."
state "Sorting: " + f$
qsort 1, fbanz
changed = True
Else
Print #3, "No reason found for resorting " + ff$
End If
End Sub

Sub ux2win(f$, ff$)
Dim x$
state "ux2win: " + ff$
Open f$ For Binary As #1
x$ = Space(LOF(1))
Get #1, 1, x$
x$ = Replace(x$, Chr$(10), vbNewLine)
x$ = Replace(x$, Chr$(13) + vbNewLine, vbNewLine)
Put #1, 1, x$
Close #1
End Sub

Sub qsort(von, bis)
Dim i As Long, j As Long, m As Long, help$, pivot$
If von >= bis Then Exit Sub
m = (von + bis) / 2
i = von
j = bis
pivot$ = filebuff(m)
Do While i <= j
 Do While filebuff(i) < pivot$: i = i + 1: Loop
 Do While filebuff(j) > pivot$: j = j - 1: Loop
 If i <= j Then
 help$ = filebuff(j)
 filebuff(j) = filebuff(i)
 filebuff(i) = help$
 i = i + 1
 j = j - 1
 End If
Loop
qsort von, j
qsort i, bis
End Sub

Sub state(x$)
frmPrepare.l.Caption = x$
DoEvents
End Sub
