VERSION 5.00
Begin VB.Form frmPGP 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "PGP Signature Verify"
   ClientHeight    =   5730
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   9465
   Icon            =   "frmPGP.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5730
   ScaleWidth      =   9465
   StartUpPosition =   2  'Bildschirmmitte
   Begin VB.Timer tmr 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   2160
      Top             =   2400
   End
   Begin VB.CommandButton cmdcancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   8040
      TabIndex        =   3
      Top             =   5280
      Width           =   1335
   End
   Begin VB.CommandButton cmdCopy 
      Caption         =   "&Copy"
      Default         =   -1  'True
      Height          =   375
      Left            =   8040
      TabIndex        =   2
      Top             =   4800
      Width           =   1335
   End
   Begin VB.TextBox txt 
      BackColor       =   &H8000000F&
      Height          =   4575
      Left            =   120
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Beides
      TabIndex        =   0
      Top             =   120
      Width           =   9255
   End
   Begin VB.Label Label1 
      Caption         =   $"frmPGP.frx":000C
      Height          =   735
      Left            =   120
      TabIndex        =   1
      Top             =   4800
      Width           =   7815
   End
End
Attribute VB_Name = "frmPGP"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Private Sub cmdcancel_Click()
Unload Me
ForceForegroundWindow2 F12AgentWnd
End Sub

Private Sub cmdCopy_Click()
Clipboard.Clear
Clipboard.SetText txt.Text
Unload Me
ForceForegroundWindow2 F12AgentWnd
End Sub

Private Sub Form_Load()
Dim cl$
cl$ = Clipboard.GetText
cl$ = PGPTransform(cl$)
txt.Text = cl$
If pgpCtrlShiftD Then tmr.Enabled = True
End Sub

Private Sub tmr_Timer()
tmr.Enabled = False
keybd_event vbKeyShift, 0, 0, 0: DoEvents
keybd_event vbKeyControl, 0, 0, 0: DoEvents
keybd_event vbKeyD, 0, 0, 0: DoEvents
keybd_event vbKeyD, 0, 2, 0: DoEvents
keybd_event vbKeyControl, 0, 2, 0: DoEvents
keybd_event vbKeyShift, 0, 2, 0: DoEvents
'Do: DoEvents: Loop Until GetForegroundWindow <> Me.hwnd
'cmdcancel_Click
End Sub
