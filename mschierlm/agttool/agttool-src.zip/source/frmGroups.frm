VERSION 5.00
Begin VB.Form frmGroups 
   BorderStyle     =   4  'Festes Werkzeugfenster
   Caption         =   "Select Groups"
   ClientHeight    =   6000
   ClientLeft      =   4575
   ClientTop       =   2760
   ClientWidth     =   8685
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6000
   ScaleWidth      =   8685
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'Bildschirmmitte
   Begin VB.CommandButton cmdAdd 
      Caption         =   "&Search/Add"
      Height          =   255
      Left            =   7200
      TabIndex        =   1
      Top             =   120
      Width           =   1335
   End
   Begin VB.TextBox txtSearch 
      Height          =   285
      Left            =   720
      TabIndex        =   0
      Top             =   120
      Width           =   6375
   End
   Begin VB.TextBox txtFlags 
      BackColor       =   &H8000000F&
      Height          =   285
      Left            =   120
      Locked          =   -1  'True
      TabIndex        =   20
      Top             =   120
      Width           =   495
   End
   Begin VB.CheckBox chkFup 
      Caption         =   "&Followup-To"
      Height          =   255
      Left            =   7080
      TabIndex        =   8
      Top             =   4560
      Width           =   1455
   End
   Begin VB.CheckBox chkTaglines 
      Caption         =   "Search &Taglines"
      Height          =   255
      Left            =   7080
      TabIndex        =   7
      Top             =   4200
      Width           =   1455
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   7080
      TabIndex        =   6
      Top             =   4920
      Width           =   1455
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   7080
      TabIndex        =   5
      Top             =   5400
      Width           =   1455
   End
   Begin VB.Frame Frame1 
      Caption         =   "&Current Selection"
      Height          =   1815
      Left            =   120
      TabIndex        =   3
      Top             =   4080
      Width           =   6855
      Begin VB.CommandButton cmdRemove 
         Caption         =   "&Remove selected"
         Height          =   255
         Left            =   240
         TabIndex        =   19
         Top             =   1440
         Width           =   1455
      End
      Begin VB.ListBox lstSelected 
         Height          =   1035
         ItemData        =   "frmGroups.frx":0000
         Left            =   120
         List            =   "frmGroups.frx":0002
         MultiSelect     =   2  'Erweitert
         TabIndex        =   4
         Top             =   240
         Width           =   6615
      End
      Begin VB.Label Label3 
         Caption         =   "You can control all options only by typing into the text box."
         Height          =   255
         Left            =   2400
         TabIndex        =   18
         Top             =   1440
         Width           =   4215
      End
   End
   Begin VB.PictureBox pctView 
      BorderStyle     =   0  'Kein
      Height          =   3495
      Index           =   0
      Left            =   0
      ScaleHeight     =   3495
      ScaleWidth      =   8655
      TabIndex        =   9
      TabStop         =   0   'False
      Top             =   480
      Width           =   8655
      Begin VB.CheckBox chkAutoSearch 
         Caption         =   "A&utoSearch"
         Height          =   255
         Left            =   7080
         TabIndex        =   21
         Top             =   2880
         Width           =   1575
      End
      Begin VB.CheckBox chkAbbrev 
         Caption         =   "&Abbreviate"
         Height          =   255
         Left            =   7080
         TabIndex        =   16
         Top             =   1440
         Width           =   1455
      End
      Begin VB.Frame Frame2 
         Caption         =   "Search groups"
         Height          =   1335
         Left            =   7080
         TabIndex        =   11
         Top             =   0
         Width           =   1455
         Begin VB.OptionButton optInitials 
            Caption         =   "&havg. initials"
            Enabled         =   0   'False
            Height          =   255
            Left            =   120
            TabIndex        =   15
            Top             =   720
            Width           =   1215
         End
         Begin VB.OptionButton optContaining 
            Caption         =   "c&ontaining"
            Height          =   255
            Left            =   120
            TabIndex        =   13
            Top             =   480
            Width           =   1095
         End
         Begin VB.OptionButton optBeginning 
            Caption         =   "&Beginning w."
            Height          =   255
            Left            =   120
            TabIndex        =   12
            Top             =   240
            Width           =   1215
         End
         Begin VB.Label Label1 
            Caption         =   "the search text."
            Height          =   255
            Left            =   120
            TabIndex        =   14
            Top             =   960
            Width           =   1215
         End
      End
      Begin VB.ListBox lstResults 
         Height          =   3375
         Left            =   120
         TabIndex        =   2
         Top             =   0
         Width           =   6855
      End
      Begin VB.Label Label2 
         Caption         =   "hierarchies"
         Height          =   255
         Left            =   7440
         TabIndex        =   17
         Top             =   1680
         Width           =   1095
      End
   End
   Begin VB.PictureBox pctView 
      BorderStyle     =   0  'Kein
      Height          =   3495
      Index           =   1
      Left            =   0
      ScaleHeight     =   3495
      ScaleWidth      =   8655
      TabIndex        =   10
      TabStop         =   0   'False
      Top             =   480
      Visible         =   0   'False
      Width           =   8655
      Begin VB.TextBox txtTagView 
         BackColor       =   &H8000000F&
         Height          =   285
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   23
         Top             =   3120
         Width           =   8415
      End
      Begin VB.ListBox lstTagResults 
         Height          =   2985
         Left            =   120
         TabIndex        =   22
         Top             =   0
         Width           =   8415
      End
   End
End
Attribute VB_Name = "frmGroups"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'''' AgtTool (c) 2002 - 2004 Michael Schierl
'' This program is free software according to the GNU GPL.

Option Explicit
Dim options As String, setting As Boolean
Dim groupmatch_style As Integer, groupmatch_txt As String, groupmatch_txt_len As Integer

Private Sub chkAbbrev_Click()
    If setting Then Exit Sub
    setOption "*"
End Sub

Private Sub chkAutoSearch_Click()
    If setting Then Exit Sub
    setOption "+", False
End Sub

Private Sub chkFup_Click()
    If setting Then Exit Sub
    clearsortoptions
    setOption "-", False
End Sub

Private Sub chkTaglines_Click()
    If setting Then Exit Sub
    setOption "="
End Sub

Private Sub addselection(group$)
    lstSelected.AddItem group$ + IIf(InStr(options, "-") <> 0, " (F)", "")
    dedupselection
End Sub

Private Sub cmdAdd_Click()
    If InStr(options, "=") = 0 Then
        If lstResults.ListCount = 1 And Left$(lstResults.list(0), 1) = "(" Then
            updatesearchresults
            Exit Sub
        End If
        If lstResults.ListCount = 1 And Right$(lstResults.list(0), 1) <> "*" Then
            addselection lstResults.list(0)
            txtSearch.Text = ""
        End If
    Else
        updatetaglines True
    End If
End Sub

Private Sub cmdcancel_Click()
    groupsresult$ = ""
    tipp = ""
    Unload Me
End Sub

Private Sub cmdOK_Click()
    Dim s As String, s2 As String, t As String, i As Integer
    For i = 0 To lstSelected.ListCount - 1
        t = lstSelected.list(i)
        If Right$(t, 4) = " (F)" Then '' followup
            s2 = s2 + Left$(t, Len(t) - 4) + ","
        Else
            s = s + lstSelected.list(i) + ","
        End If
    Next
    If s <> "" Then s = Left$(s, Len(s) - 1)
    If s2 <> "" Then
        s2 = Left$(s2, Len(s2) - 1)
        If autofup Then
            s = s + ",�" + s2 + "�" + char
        Else
            s = s + "," + s2
        End If
    End If
    groupsresult$ = s
    tipp = ""
    Unload Me
End Sub

Private Sub cmdRemove_Click()
    Dim i As Integer
    For i = lstSelected.ListCount - 1 To 0 Step -1
        If lstSelected.Selected(i) Then
            lstSelected.RemoveItem (i)
        End If
    Next
End Sub

Private Sub Form_GotFocus()
    txtSearch.SetFocus
End Sub

Private Sub Form_Load()
    Dim g As Variant
    SetWindowPos Me.hwnd, -1, 0, 0, 0, 0, 3
    ForceForegroundWindow2 Me.hwnd
    options = "+"
    setOption "*"
    For Each g In Split(groupsresult, ",")
        lstSelected.AddItem (g)
    Next
End Sub


Private Sub clearsortoptions()
    If InStr(options, ".") <> 0 Then setOption "."
    If InStr(options, "?") <> 0 Then setOption "?"
End Sub

Private Sub setOption(opt As String, Optional repaint As Boolean = True)
    Dim i As Integer, b As Boolean
    CriticalErrorOn setting, "Circular changes (frmGroups.setOption:1)"
    setting = True
    i = InStr(options, opt)
    If i <> 0 Then
        options = Left$(options, i - 1) + Mid$(options, i + Len(opt))
    Else
        options = options + opt
    End If
    b = (InStr(options, "=") <> 0)
    chkTaglines.Value = IIf(b, 1, 0)
    pctView(0).Visible = Not b
    pctView(1).Visible = b
    b = InStr(options, "*") <> 0
    chkAbbrev.Value = IIf(b, 1, 0)
    b = InStr(options, "-") <> 0
    chkFup.Value = IIf(b, 1, 0)
    b = InStr(options, "+") <> 0
    chkAutoSearch.Value = IIf(b, 1, 0)
    If InStr(options, ".") <> 0 Then
        optInitials.Value = True
    ElseIf InStr(options, "?") <> 0 Then
        optContaining.Value = True
    Else
        optBeginning.Value = True
    End If
    txtFlags = options
    setting = False
    If repaint Then updatesearchresults
End Sub



Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If UnloadMode <> QueryUnloadConstants.vbFormCode Then cmdcancel_Click
End Sub

Private Sub lstResults_DblClick()
    If lstResults.ListIndex = -1 Then Exit Sub
    Dim s As String
    s = lstResults.list(lstResults.ListIndex)
    If Left$(s, 1) = "(" Then Exit Sub
    If Right$(s, 1) = "*" Then
        txtSearch.Text = Left$(s, Len(s) - 1)
        updatesearchresults
    Else
        addselection s
    End If
    txtSearch.SetFocus
End Sub

Private Sub lstTagResults_Click()
    If lstTagResults.ListIndex = -1 Then Exit Sub
    Dim s As String, i As Integer
    s = lstTagResults.list(lstTagResults.ListIndex)
    If Left$(s, 1) = "(" Then
        txtTagView.Text = ""
    Else
        i = InStr(s, " --> ")
        txtTagView.Text = Mid$(s, i + 5)
    End If
End Sub

Private Sub lstTagResults_DblClick()
    If lstTagResults.ListIndex = -1 Then Exit Sub
    Dim s As String, i As Integer
    s = lstTagResults.list(lstTagResults.ListIndex)
    If Left$(s, 1) = "(" Then Exit Sub
    i = InStr(s, " --> ")
    addselection Left$(s, i - 1)
End Sub

Private Sub optBeginning_Click()
    If setting Then Exit Sub
    clearsortoptions
End Sub

Private Sub updatesearchresults(Optional oneopen As Boolean = False)
Dim i As Integer, j As Integer, abbrev As Boolean, cnt As Integer
Dim gr As String, gr2 As String, gr3 As String, lastadd As String
If InStr(options, "=") <> 0 Then updatetaglines False: Exit Sub
Screen.MousePointer = 11
lstResults.Visible = False
lstResults.Clear
'' hot spot here, so optimize!
abbrev = InStr(options, "*") <> 0
lastadd = ""
If InStr(options, ".") Then
    groupmatch_style = 1
ElseIf InStr(options, "?") Then
    groupmatch_style = 2
Else
    groupmatch_style = 3
End If
groupmatch_txt = txtSearch.Text
groupmatch_txt_len = Len(groupmatch_txt)

For i = 0 To gcount - 1
gr = groups(i)
If groupmatch(gr) Then
If abbrev Then
    If Right$(lastadd, 2) = ".*" Then
        '' this goto saves 75% of time in interpreted mode
        If Left$(gr, Len(lastadd) - 2) + ".*" = gr2 Then GoTo donthandle
    End If
    gr2 = gr
    Do While groupmatch(gr)
        gr3 = gr2
        gr2 = gr
        If Right$(gr, 2) = ".*" Then gr = Left$(gr, Len(gr) - 2)
        j = InStrRev(gr, ".")
        If j = 0 Then Exit Do
        gr = Left$(gr, j - 1) + ".*"
    Loop
    If oneopen Then gr2 = gr3
    If lastadd <> gr2 Then
        lstResults.AddItem gr2
        cnt = cnt + 1
        lastadd = gr2
    End If
donthandle:
Else
    lstResults.AddItem gr
    cnt = cnt + 1
End If
If cnt > 1024 Then
    lstResults.AddItem "(and more...)"
    Exit For
End If
End If
Next
'' end of hot spot
lstResults.Visible = True
Screen.MousePointer = 0
If oneopen Then Exit Sub
If lstResults.ListCount = 1 Then
If Right$(lstResults.list(0), 2) = ".*" Then updatesearchresults True
End If
End Sub


' this func is called inside the hot spot, so optimize!
Private Function groupmatch(group As String) As Boolean
    Select Case groupmatch_style
        Case 1: groupmatch = False '' FIXME: "Has initials" check unimplemented
        Case 2: groupmatch = (InStr(group, groupmatch_txt) <> 0)
        Case 3: groupmatch = (Left$(group, groupmatch_txt_len) = groupmatch_txt)
    End Select
End Function

Private Sub updatetaglines(list As Boolean)
    Dim searchtext As String
    searchtext = UCase(txtSearch.Text)
    If list Then
        Dim i As Integer
        lstTagResults.Clear
        For i = 0 To tlanz - 1
            If InStr(UCase(tagline(i)), searchtext) Then
                lstTagResults.AddItem taggroup(i) + " --> " + tagline(i)
                If lstTagResults.ListCount > 1024 Then
                    lstTagResults.AddItem "(and more...)"
                    Exit For
                End If
            End If
        Next
    Else
        lstTagResults.Clear
        lstTagResults.AddItem "(Hit Return to search)"
    End If
End Sub

Private Sub optContaining_Click()
    If setting Then Exit Sub
    clearsortoptions
    setOption "?"
End Sub

Private Sub optInitials_Click()
    If setting Then Exit Sub
    clearsortoptions
    setOption "."
End Sub

Private Sub txtSearch_Change()
    If InStr(options, "=") Then
        Do While Len(txtSearch.Text) >= 1 And InStr("=", Left$(txtSearch.Text, 1)) <> 0
            setOption Left$(txtSearch.Text, 1), False
            txtSearch.Text = Mid$(txtSearch.Text, 2)
        Loop
    Else
        Do While Len(txtSearch.Text) >= 1 And InStr(".?*-=+", Left$(txtSearch.Text, 1)) <> 0
            setOption Left$(txtSearch.Text, 1), False
            txtSearch.Text = Mid$(txtSearch.Text, 2)
        Loop
        If Right$(txtSearch.Text, 1) = "*" Then
            setOption "*", False
            txtSearch.Text = Left$(txtSearch.Text, Len(txtSearch.Text) - 1)
            txtSearch.SelStart = Len(txtSearch.Text)
        End If
    End If
    If Len(txtSearch.Text) = 0 Then
        cmdAdd.Enabled = False
        cmdOK.default = True
    Else
        cmdAdd.Enabled = True
        cmdAdd.default = True
    End If
    If InStr(options, "=") Then
        updatetaglines False
    Else
        If Len(txtSearch.Text) = 0 Or InStr(options, "+") <> 0 Then
            updatesearchresults
        Else
            lstResults.Clear
            lstResults.AddItem "(Hit Return to search)"
        End If
        If Right$(txtSearch.Text, 1) = char Then
            hwnds(1000) = txtSearch.hwnd
            frmmain.handlewnd txtSearch.hwnd
        End If
    End If
End Sub

Private Sub txtSearch_GotFocus()
    txtSearch.SelStart = Len(txtSearch.Text)
End Sub

Private Sub dedupselection()
    '' FIXME
End Sub
