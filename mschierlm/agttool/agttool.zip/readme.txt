AgtTool v0.25
=============

(c) 2002-2004 Michael Schierl

http://home.nexgo.de/mschierlm/agttool/

Contact me at: sm-soft@gmx.de

Licensed under GPL (see COPYING file)

Changelog
---------

++ Version 0.25 ++

- This version jump is not justified, but Fort�'s one is not
  either ;)
- AgtTool is open source (GPL) now
- Improved "critical" error messages
- Support for Agent 2.0 (and 1.9x at the same time)
- New group list with filters
- Button to show main window in "Select action" window
- Bugfixes
  * Agent-Sprache has been detected wrongly sometimes
  * tagline display error if subject contains "-->"

++ Version 0.20 ++

- F2/F11/F12 only active in Browser windows
- Clipboard is only checked for x-Faces after F2/F11/F12 keystroke
- new command #xfa# to display x-Faces in clipboard
- state of headers and raw view is taken from the menu instead of 
  being probed.
- AutoFup also works with "All Fields" hidden
- Fixed some minor bugs
- Agent Language indicator in the title bar is now off by default
- was stripping and AutoFup mode now enabled by default
- Actions for keys F2, F11, F12 can be specified more precisely
- you can supersede your own articles (if you have patched Agent)
- removed lots of commands that became useless

++ Version 0.17.2 ++

- removed some unneccessary code lines
- Problem with large Groups.Dat file (more than 32768 groups) fixed.

++ Version 0.17 ++

- new taglines (2002-08-26)
- new design for the options dialog
- you can disable F2/F11/F12 now
- a bug with clipboard handling fixed
- X-Face-Code does no longer create temporary file
- added random signatures
- added online hotkey Win+O

++ Version 0.16 ++

- fixed incompatibility with Agent 1.92

++  Version 0.15.10 ++

- Support for German Agent Version
- F2 is an alias for F11
- PGP sigs in the body are detetcted
- newsgroup hints as "popup list" (EXPERIMENTAL)

++ Version 0.15 ++
- XP&fup note created in clipboard when using AutoFup mode


Features:
---------

- Expand newsgroup names entered into the Newsgroup, Followup-To
  or Find field
- Features to simplify setting X-Post and Followup to the same group
- automatically compose Crosspost&Fup note
- Display Taglines (Newsgroup descriptions) in Agent's title bar
- Fetch new taglines from your news server (tagfetch.exe)
- Show X-Faces in an external window when copied into clipboard
- Hotkey F12 to look for X-Faces in current article
- Hotkeys F11 and F2 for additional Article commands (jump to 
  first/last reference etc.)
- strip "was:" subjects from replies
- start Agent and quit when Agent is closed.
- Verify PGP-Signatures (X-PGP-Sig; needs PGP installed)
- Randomly choose your .sig (since 0.17)
- one hotkey for retrieving/sending everything (since 0.17)
- superseding articles is as easy as never before (since 0.20)
- newsgroup list, searchable by e. g. taglines

MSVBVM60.DLL
------------

if you get a message that this file is missing, you probably need the VB 6 
Runtime. For a German version look at http://smsoft.ixy.de/

A plain version of VB runtime (w/o controls) is enough.


There is a virus in your package!
---------------------------------

Update your anti-virus program. MSWINSCK.OCX is no virus, but a file needed 
by the TagFetch tool. If you do not want to use that tool, you can delete it.

This file helps to create TCP/IP connection. As it is used by some trojan 
horses to "phone home", it was detected as a virus by former versions of
F-PROT antivirus.

*NOTE* MSWINSCK.OCX is no longer shipped with AgtTool. It is now shipped with 
TagFetch.

Quick start
-----------

Extract all files into any directory on your system. Next copy the file 
groups.dat from your data directory into this directory.

Run Prepare.exe. It might show you a message that groups.dat ist adjusted.

Start Agent if it does not already run.

Run Agttool.exe and click onto "hide".

Now you can complete group names in the Find dialog and in the "Newsgroups" 
and "Value for special field" textbox of the Composition window by pressing 
the # key.

Taglines of at.*, ch.*, de.*, fido.ger.*, ger.*, hamster.*, maus.* and 
z-netz.* are shown on the title bar. (Newsgroups file of 2002-08-26)


Monitoring features:
--------------------

As already described above, AgtTool monitors all Fort� Agent windows it can 
find (at least the ones from 1.8 bis 2.0...)

It searches for new windows and dialogs every second.About every 100 
milliseconds it checks these found windows: If the title bar contains a 
known newsgroup name, the tagline of this group is added (as long as 
Tagline mode is enabled).

If the last character of one of the monitored textboxes is the so-called 
"action char" ("#" by default), this line is examined. If it contains 
spaces, nothin is done with htis line (for not confusing the user when 
searching "normal" text). Otherwise everythin up to the last comma (if any)
is kept untouched. if the last part is equivalent to a ng alias described
in alias.ini, it is replaced by the long form (so "nnq#" is changed into
"news.newusers.questions"). 

If this part is equivalent to - or --, the text is replaced by "poster" 
(for followups); if the text is "+", it is replaced by the last complete 
suggestion AgtFup has made.

An empty string before the action char is left as it was.

If the string starts with an action char, it will be seen as a command - 
see the listing below.

Otherwise AgtFup scans through the GROUPS.DAT file to 
find the group(s) matching to the text entered. If no group matches, one 
character is omitted at the end of the string until there is at least one 
match. Then the text is completed as far as all the entries are similar.

If no more text can be added and if the group is not complete, there will
be shown "hints" if "hint mode" is enabled. To show hints to a group that
exists, add an extra character to the end so that AgtFup has to remove it
again.

e.g. if you enter "alt.ascii-art#", you do not get hints, as this group is
complete (at least on my server), but if you enter "alt.ascii-artx#", you 
get "alt.ascii-art(|.animation)".

Since 0.25: If the textbox contents end with ",..." (or are equal to "..."),
the group list will be shown. Groups selected there will be added to the
text box (or used for AutoFup mode).

Files
-----

GROUPS.DAT

A file similar to the GROUPS.DAT of Agent. it contains an alphabetically 
ordered list of newsgroups names. As the meaning of "aphabetical" used
by Agent is a bit strange sometimes (as hyphens and dots are ignored), 
you SHOULD run Prepare.Exe if you have copied a new Groups.dat.
Prepare.exe removes all lines that do not contain dots (as they are most 
likely folders) and sorts the remaining lines.

ALIAS.INI

This file contains aliases for groups, as e.g. nnq for 
news.newusers.questions. So you can type nnq# into the newsgroups field
if you want to x-post or f'up into news.newusers.questions.
the format is very simple: 
abbreviation=news.group.name

it need not be sorted alphabetically.

TAGLINES.DAT

This file contains the taglines for newsgroups. It looks like checkgroup 
control messages or the NEWSGROUPS file of a news server:
each line contains a newsgroup name, a tab character and then the tagline.
As this file must be sorted alphabetically, too, you SHOULD run Prepare.exe
after you have changed this file, too. Another point is that Prepare tries
to repair "broken" newsgroups files i.e where ther is a space instead of
a tab at the end of the line. All groups that have taglines "no description"
or "?" and do not have "Moderated" in them, are stripped by Prepare.exe to
save disk space and make AgtTool (slightly!) faster.

AGTTOOL.INI

This file is created when you use the Options window. It is loaded at 
startup and its options are set. You can change it via the Options window. 
Setting options by using the commands listed below will *not* affect the 
.INI file. Those settings are temporarily.

LANGUAGE.DAT

Contains information about localized versions of Fort� Agent.

Commands
--------

* is a number.
$: can be set over options dialog
# is the action char. You can change it in the options.

Most commands have Abbreviations for them:

$ #hd# #hide#        hides the AgtTool window, reshows it when all agent
                     instances are closed.

#sh# #show# #s#      shows the AgtTool window

#copperfield# #cpf#  hides AgtTool but does not reshow it when all agent
                     instances are closed

#david# #dvd#        the same

$ #minimize# #min#   minimizes the AgtTool window
 
$ #hint-# #ht-#      disables hint mode
$ #hint*# #ht*#      switsches hint mode to level *
$ #hintwin#          shows a popup window giving (up to 10) hints

#quit# #foad#        Close all AgtTool instances (if there are problems 
                     to locate them, usually only one instance should 
                     run at the same time)

#pgp#                PGP-verifies the article in the clipboard.

--- new in Version 0.20 ---
#xfa#                displays the x-face in the clipboard.
#i#                  is replaced by the name in your Supersedes From
                     to simplify finding your own postings
#options# #opt# #o#  shows the options dialog
#wino# #w#           does the same as win+o after one second
                     (close the Find window!)

Tagline mode
------------

tagline mode simply reads the group name from the title bar and adds its
tagline.


Getting new/more taglines
-------------------------

you can use TAGFETCH.EXE to get new 
taglines from your news server.

Download it from

http://home.nexgo.de/mschierlm/agttool/


Hint mode
---------

Hint mode is somehow more complex:
The hint mode level says how many "branches" are displayed:
if only less than or equal groups match, their rests od the name is shown 
in brackets, e.g.
"de.admin.net-abuse.m(ail|isc)"

if there are too many groups, only the first few characters are given,
the rest ist displayed by an action char:
"de.a(dmi#|lt.#|nsw#)"

and, if even one character would allow more solutions that there are, all 
available first chars are displayed in square brackets:
"rec.[abcdefghjkmnoprstvw]"

in popup mode, ou can go on typing - as soon as there is only one match, it is 
taken and the popup window disappears. You can also use the digits to select a
name shown in the popup window.

Command line
------------

You can specify every command you can enter into a monitored textbox in
the command line, too. Separate multiple commands by spaces.
e.g. AgtTool #hide#   starts AgtTool hidden
     AgtTool #ht9# #af# #rf10# #copperfield#
                      starts AgtTool in Hint level 9, AutoFup on, refresh
                      delay 10ms, hidden.


AutoFup mode
------------

If autofup is enabled and you enter -# into the newsgroups field,
everything you enter into this field after that (until you disable AutoFup
mode by e.g. changing the Filed view or changin the F'up manually)
is automatically entered into the F'up2 field. To switch to this field, it
AFAIK necessary to send keystrokes to that window. (As the fields list
is a custom control). Autofup only works in one composition window at the 
same time.

Another feature if autofup is enabled: if you add ,--# to the end of the NG
field, it is stripped and f'up2 poster is set. The focus is on that field
then, so you can set another followup.

You can also set a string as �AutoFupClipPrefix� in the options. 
It automatically puts a string into the clipboard when you use AutoFup mode.
This string contains 2 parts, separated by �\|�. The first part specifies 
the string used for Crossposts and followup-tos, the second one is used for 
followup-to-poster.

You can use this "special" sequences within them:
\x  Names of the X-Posted groups
\f  Name(s) of the followup-to group(s)
\|  separator between the two parts
\n  newline
\\  backslash

was: stripping mode
-------------------

if this mode is enabled all subjects beginning with "Re: " and containing 
"(was:" are stripped before this "was" when this message is visible in the 
composition window. Additionally, if you use "#Re: " in a subject, it is 
changed into "(was:" properly. So simply type xour new subject at the 
beginning of the "Subject:" field and type"#" (the action char) to change
the subject "correctly".

X-Face mode
-----------

When this mode is started (by #xfa# or by F12) the clipboard is examined.
If the string "X-Face: " is 
found in it, the following line (after unfolding then next few lines) is 
interpreted as an "X-Face" according to the "compface" utility of James 
Ashton. This X-Face is then shown in a small window. If there is no X-Face
in the clipboard, the window is closed again. This mode requires the file
CFACE_VB.DLL to be in the same directory as AgtTool.

AutoRun mode
------------

You can use AutoRun mode to start AgtTool and Agent together and quit 
AgtTool when Agent is quit. For that you have to change your Shortcuts to Agent:
Add the path and filename of AgtTool to the beginning of the command line
and add a space and a colon between them. The first Agent loaded will load 
AgtTool then and when all Agent instances are closed, AgtTool will be closed, too.


F11/F12 shortcuts
-----------------

The action of this keys can be set in the options dialog.

PGP-Verification
----------------

For PGP Verification PGP6 or 7 is recommended. Otherwise you have to save the ASCII ARMOR
manually into a file and use this for PGP.

Either press F11-P or copy the raw article (including headers) to clipboard and enter 
"#pgp#" as command. A window appears that contains the ASCII ARMOR for this article.
Press Return to copy it to clipboard (you can use Clipboard-Decrypt/Verify from the 
PGPTray then) or press a hotkey you have assigned to Decrypt/Verify current window.
Press Esc to cancel. If you have selected the default hotkey 
(Ctrl+Shift+D) for Decrypt/verify, you can enable an option to automatically "press"
this hotkey when you user PGP Verification.

When using F11-P you may not have raw mode active as it toggles raw mode for copying 
the article.

Random signatures
-----------------

If a signature name ends with # (e. g. "foobar_#"), and you compose a message 
with this signature, it will automatically changed to one that has the same 
prefix as the #-signature. If a signature name ends with a # and a number 
(e. g. "foobar_often#21") the number is seen as a weight, e. g. if there are 
also signatures named "foobar_ads" and "foobar_double#3", the sig "foobar_#" 
is changed to

foobar_often#21    (84%)
foobar_ads         ( 4%)
foobar_double#3    (12%)

with the given probabilities.


Online hotkey
-------------

You can enable the online hotkey in the Options dialog. When you have actovated it 
and press Control+O, the selected actions (Fetch headers, bodies, groups, mail, 
Post Messages) are performed.
 
Supersedes
----------

Usually when you want to supersede an article, you have to copy&paste the text (or find the article in your outbox folder and select "Post/New Copy of Message") and check that you set all the headers right. Then you have to paste the Message-ID of your old article into the "Supersedes" field.

AgtTool can simplify that a bit. You still need an Agent where Distribution is patched to Supersedes, but you don't have to set the headers manually and copy all the text. Simply press F2 on your article and select "Supersede Article." AgtTool will create a followup with all text (I hope it's all, better check again yourself) in it already. The Supersedes Header is also set.

Note that in the present version it is not possible to send the supersede as a "parallel" posting - it is sent as a followup.

Options dialog
--------------

[x] and [ ] show what is enabled on my PC

Die [x] und [ ] geben an, was ich aktiviert habe.

Alle Troubleshooting Options [ ].

F2:  [Display Dialog]
F11: [Display Dialog]
F12: [Display X-Face]

[x] Hide at startup
[ ] Minimize at startup
[x] PGP: Press Ctrl+Shift+D

Hints: Long if less than 5 solutions 
Refresh delay: 20 ms 
Sleep mode delay: 5 Sek.
AutoClipFupPrefix: xp&f'up2 \f\|f'up2p
ActionChar: #

[X] Use Window+O...
   [X] Post
   [ ] Get Mail
   [X] Get Bodies
   [X] Get Headers
   [ ] Get Groups

Supersedes From Header: Michael Schierl <schierlm-usenet@gmx.de>