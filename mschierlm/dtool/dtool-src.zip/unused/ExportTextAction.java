import javax.swing.event.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;


/** Akktion die in den Toolbar eingefuegt werden kann.
 * Ruft export in ERFrame auf.
 * Wird z.Zt. nicht verwendet */
public class ExportTextAction extends AbstractAction
{  Start parent;

   public ExportTextAction(Start p)
   {  super("");
      parent = p;
 
   }

   public void actionPerformed(ActionEvent ae)
   {  JInternalFrame inf = parent.getActiveFrame();
      if (inf instanceof ERFrame)
        { ERFrame ef = (ERFrame) inf;
          ef.export(ConvertExample.class);
        }

   }


}
