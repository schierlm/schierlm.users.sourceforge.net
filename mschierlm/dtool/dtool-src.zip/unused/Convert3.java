public class Convert3 implements Convert
{



/** nuer zu test Zwecken */
public String convert(ERFrame erf)
{

 return "Convert Nr.3 selected";

}






}