import java.util.Hashtable;



/** Hashtable mit zwei Methoden  */ 
public class HashWrapper
{
int n = 0;
Hashtable ht = new Hashtable();


/** ueberprueft , ob der s schon in der Tabelle ist. Falls nicht wird s eingefuegt.
 *  Andernfalls wird ein "newString" + n eingefuegt 
 * vereinfacht fuer convert2 / alte Version als Kommentar*/

public String  checkName(String s)
{
  // return ht.contains(s);

  boolean b =  ht.contains(s);
  if (b==false) 
  {  ht.put(s,s);
     return s;
  }

  else
  { 
    String s1 = s + n;
    ht.put(s1,s1);
    n++;
    return s1;
  }
}


/** fuegt einen String in die Tabelle ein */
public void addName(String s)
{
  ht.put(s,s);
}




}