public class IntWrapper
{
  int n=0;

  public int get()
  {
     return n;
   }


  public void inc()
  {
    n++;
  }

}