import java.util.Vector;
import javax.swing.DefaultComboBoxModel;


/** Dies ist eine Demo Klasse , die zeigt wie man Informationen aus
  * einem ERFrame zieht , sein ER-Model zu konvertieren (nach SQL , PS oder wasauchimmer)
  * Diese Klasse generiert einen Text(String s) , der das Model beschreibt.  
  * Mangels benutzbarerer Klassen ist das Konvertieren momentan deaktiviert.
  * Zum reaktivieren muss man folgendes tun :
  *  1. In Start.initactions einen Button / Menueintrag anlegen und mit der Klasse Translate.java verknuepfen.
  *  2. ERFrame.translate() dafuer sorgen , dass die Richtige Klasse gewaehlt wird. (alles weitere ist dort erklaert 
*/

public class ConvertExample implements Convert
{ 

/** Diese Methode wird von Start.translate() gerufen
  * erf ist das Model , das konvertiert werden soll
  * der zurueckgegebene String wird in einem neuen TextFrame dargestellt
  */
public String convert(ERFrame erf)
{

   int ne = erf.Entities.size() ;   // Die Anzahlen von Entities , RelShips und ISAs
   int ni = erf.Isa.size(); 
   int nr = erf.Rels.size();

   String s = "Dateiname : " + erf.getFileName() + "\n" + "\n";  // der Name des Modells
   s = s + "*****************************************************\n";

     /** jetzt werden nacheinder untige Methoden fuer jede Entity / RelShip & ISA gerufen : */

    for (int i = 1; i<ne; i++)  //kein Fehler , an 0 steht der String "keine"
       {  Entity e =(Entity) erf.Entities.elementAt(i);
          s = s + "\n" +  checkEntity(e);
       }
 
    s = s + "\n*****************************************************\n";


    for (int i = 0; i<nr; i++)
       {  RelShip r =(RelShip) erf.Rels.elementAt(i);
          s = s + "\n" +  checkRel(r);
       }

   s = s + "\n*****************************************************\n";


    for (int i = 0; i<ni ; i++)
       {  s = s + "\n" + checkIsa( (ISA) erf.Isa.elementAt(i));
       }

// das wars , der String wird jetzt von ERFrame.translate() in einem neuen TextFrame angezeigt
 return s; 

}




public String checkEntity(Entity e)
{ String s="";
  String name = e.getName();
  if (name.equals("")) name = "hierkoennteIhrNamestehen";
  s = s + "Entity " + name + "\n";         // der Name der Entity
  s = s + "Attribute : \n";                       // nur Deko 

  s = s + checkAtm(e.Attm);                       // ausgelagert weil RelShips auch Attribute haben
  
 
  return s;
}


////////////////////////////////////////////////////////
public String checkAtm(AttributTableModel atm)
{
  int noa = atm.getRowCount();                    // die Anzahl der Attribute
          
  String s = " "; 

  for(int i = 0; i<noa; i++) 
  {
    AttributRowModel arm = atm.getRowAt(i);
    String name = arm.getName();                  // Name des Attributs 
    String domain = arm.getDomainName();          // der DatenTyp
    String rest = "";
    if (arm.getPk().isSelected()) rest += "pk ";  // Primary Key , Unique , Optional , Mehrwertig
    if (arm.getUn().isSelected()) rest += "un ";
    if (arm.getOp().isSelected()) rest += "op ";
    if (arm.getMw().isSelected()) rest += "mw ";

    s = s + name + " " + domain + " " + rest + "\n";  

  }

  return s+ "\n";
}
/////////////////////////////////////////////////////////////



public String checkRel(RelShip r)
{  ERPanelTableModel eptm = r.eptm;   // enthaelt Info , welche Entities wie verknuepft sind
   AttributTableModel atm = r.atm;    // enthaelt die Attribute der RelShip 
   String s = ""; 


   String name = r.getName();         //dito 
   if (name.equals("")) name = "ohneNamen";  

   s += "RelShip : " + name + " verbindet \n" ;

  for (int i = 1; i<=3; i++)          // max drei 
   { Entity ent = eptm.getEntity(i);
     if (ent==null) continue;         // i.e. keine Entity hier , also Maximal binaere RelShip
   
     
     String enty = ent.toString();    // nochmal der Name der Entity und dann die ganzen Attribute
     if (eptm.isMany(i))     enty += " many";    else enty += " one";     
     if (eptm.isOptional(i)) enty += " opt";     else enty += " mand";
     if (eptm.isWeak(i)    ) enty += " weak";    
     if (eptm.isStrong(i))   enty += " strong";  

     s += enty + "\n"; 
   }
   
    s = s + "\n Attribute : \n" + checkAtm(atm);   // zum Schluss noch die Attribute   
  
return s;
}

public String checkIsa(ISA i)
{ String s = "";
  Entity e= null;                          //Wird die Super-Entity
     
     /** Vererbungen haben keinen Namen */

  Object o = i.dcm.getSelectedItem();   // die aktuelle SuperEntity ist in einem ComboBoxModel in ISA.java gespeichert
  if (! (o instanceof Entity)) s = s + "keine SuperEntity bei ISA angegeben\n";  // d.h. der Eintrag "keine" (ein String                                                                          
 													   // ist selektiert
  else { e = (Entity) o;  
               
         s+= "Eine Vererbung : \n Super Entitaet : " + e.toString() + "\n"+ "UnterEntities : \n"; 
       }

  ISATableModel itm = i.itm;         // in dieser Tabelle stehen die UnterEntitaeten
  //int rc = itm.getRowCount();      // in jeder der rc Reihen steht ein ComboBoxModel
                                     // das Selektierte Objekt ist entweder eine Entity oder ein String ("keine")
  Vector ve = new Vector();
  itm.getVector(ve,o);                // danach stehen alle SubEntities in v , leere Eintraege und Eintraege die auf 
                                     // o zeigen werden nicht beruecksichtigt 
  int vsize = ve.size();
  for(int run=0;run<vsize;run++) {
    s+= ve.elementAt(run).toString() + "\n" ; }

 /** oops , ich hab vergessen zu ueberpruefen , ob die Vererbung disjunkt ist , 
   * das geht mit i.getX() (liefert true , wenn disjunkt ) */


  return s + "\n";
}



}