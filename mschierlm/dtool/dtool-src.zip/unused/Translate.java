import javax.swing.event.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;


/** Akktion die in den Toolbar eingefuegt werden kann.
 * Ruft translate in ERFrame auf.
 * Wird z.Zt. nicht verwendet */
public class Translate extends AbstractAction
{  Start parent;

   public Translate(Start p)
   {  super("",new ImageIcon("Transl.gif"));
      parent = p;

   }

   public void actionPerformed(ActionEvent ae)
   {  JInternalFrame inf = parent.getActiveFrame();
      if (inf instanceof ERFrame)
        { ERFrame ef = (ERFrame) inf;
          ef.translate();
        }

   }


}
