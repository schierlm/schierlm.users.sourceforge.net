import java.awt.Dimension;

/** Container , die dieses Interface erfuellen
 * koennen von JspLManager verwaltet werden 
 * @see JspLManager */
public interface JspLayout
{
   /** diese Methode sollte die Dimension
     * zurueckgeben , die an die ScrollPane 
     * weitergegeben werden soll */
  
   Dimension getS();



}
