import javax.swing.JComponent;
import javax.swing.UIManager;

/** das Rechteck , mit dem Komponenten auf der 
  * Zeichenflaeche markiert werden.
  * siehe BasicMarkRectangleUI und ERPaneMouse
  */
public class MarkRectangle extends JComponent 
{

 

/** Konstruktor ruft nur updateUI */
public MarkRectangle()
    {          

               updateUI() ;       
    }



/** ruft setUI der Oberklasse*/
public void setUI(MarkRectangleUI ui) {super.setUI(ui);}


/** ruft setUI */
public void updateUI()
     { setUI( (MarkRectangleUI) UIManager.getUI(this));
       invalidate();
     }


/** gibt MarkRectangleUI zurueck*/
public String getUIClassID() { return "MarkRectangleUI";}

  



}

