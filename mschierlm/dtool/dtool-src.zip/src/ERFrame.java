import java.util.Vector;
import java.io.File;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import java.awt.event.ActionEvent;
import javax.swing.JMenuItem;
import java.util.Hashtable;
import javax.swing.JOptionPane;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Container;
import javax.swing.JScrollPane;
import javax.swing.JInternalFrame;


/** Ein interner Rahmen (JInternalFrame) , 
 *  der zur Darstellung bzw. Bearbeitung eines Entity-RelationShip-Modells
 *  verwendet wird.
 * 
 * 
 */

public class ERFrame extends ChangableInternalFrame implements JspLayout {
    /** Verweis auf this f�r innere Klassen (im Konstruktor) */
    public ERFrame erf = this;
 
    /** Eintrag ins Fenster-Menu f�r dieses Fenster */
    public JMenuItem MenuMarker;

    /**  wird momentan nicht verwendet 
     * bei Bedarf koennte man hiermit fuer Eindeutigkeit aller Namen sorgen 
     * allerdings muesste dann das Programm selbst die vom Benutzer eingegebenen
     * Namen aendern (will ich nicht)
     * Und dauernd auftauchende MessageBoxen nerven auch
     * Meiner Meinung nach kann man das bei der Uebersetzung nach SQL regeln
     * evt. gibt es da auch Unterschiede von Datenbank zu Datenbank ?
     */
    public Hashtable hash = new Hashtable();
 
    /** Der komplette Dateiname (mit Pfad) , 
     * in den gespeichert wird ( steht in der Titelleiste des ERFrame) */
    private String filename ;

    /** ist true , wenn gerade ein Rechteck zum Markieren aufgezogen wird 
     * wird wieder false , nachdem der User die Maustaste loslaesst 
     * @see MarkRectangle */
    public boolean marking;
 
    /** in diesen Vector werden handles auf ISA-Objekte eingefuegt 
     * Somit weis der ERFrame immer , wieviele Verbungen in im enthalten sind*/
    public Vector Isa = new Vector();

    /** hier werden alle Objekte vom Typ RelShip gespeichert */
    public Vector Rels = new Vector();  

    /** enthaelt alle Entities , die in diesem ERFrame enthalten sind */
    public Vector Entities  = new Vector();

    /** enthaelt die Namen aller Attributtypen , diese Namen werden
     * in StringWrappern gespeichert , die im Gegensatz zu Strings
     * richtige Objekte sind 
     * @see MyVector
     * @see StringWrapper */
    private MyVector types = new MyVector(Variables.types);


    /** Hier werden alle momentan markierten Objekte gespeichert*/
    private Vector markVector = new Vector();

    /** Diese JLayeredPane wird als einzige Komponente direkt in den die JScrollPane eingefuegt.
     * In sie werden alle Komponenten eingefuegt. Sie ist public , da sie von einigen Klassen
     * direkt addressiert wird . Geht imho schneller , als jedesmal einen Accessor zu rufen , 
     * der eigentlich nichts macht. (JLayeredPane deshalb , damit ich festlegen kann , 
     * welche Komponente ueber andere gezeichnet wird)
     * @see JLP */
    public JLP p;

    /** Enth�lt die JLayeredPane p , damit werden (fast) automatisch Scroll Balken 
     * angelegt , wenn jlp groesser als jsp ist. 
     * Allerdings bekommt die ScrollPane Infos vom LayoutManager.
     * Denn hatte ich Anfangs auf null gesetzt , damit man die Komponenten frei
     * verschieben kann. Damit jsp funktioniert habe ich dann einen eigenen
     * Layoutmanager geschrieben , der nichts macht als jsp ueber die Groesse 
     * von jlp zu informieren 
     * @see JspLManager*/
    protected JScrollPane jsp;

    /** An diese Klasse werden die MAusereignisse von jlp weitergeleitet */
    public ERPaneMouse erpm;

    /** zum Benennen der Entities */
    private int entityCreatedCount;
    
/** Der Konstruktor benoetigt den Dateinamen und das Hauptfenster (vom Typ Start) .
 * Er erledigt nur Standardkram wie zuweisen von MausListenern und 
 * einfuegen von Objekten in den InternalFrame   
  
*/
    public ERFrame(String name,Start s)
    {   
	super(s,name,true,true,true,true);
	Entities.addElement("keine"); // dieses Element steht immer ganz oben  
	addInternalFrameListener(parent.ifl);
	//setBounds(50,50,300,150);
	//types.addElement(new StringWrapper("Numeric"));*/

	// dies funktioniert nicht wegen eines bugs in java , wird von mir selbst gehandelt 
	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

	p=new JLP();
	p.setLayout(new JspLManager(this));
	jsp = new JScrollPane(p);
	p.setSize(Variables.panelSizeX,Variables.panelSizeY);
	erpm = new ERPaneMouse(this);
	p.addMouseListener(erpm);
	p.addMouseMotionListener(erpm);

	getContentPane().add(jsp,BorderLayout.CENTER); // nicht direkt in den InternalFrame einfuegen
	filename = name;

	File ff = new File(name);
	String name22 = ff.getName(); // Dateiname ohne Pfad 

	MenuMarker = new JMenuItem(name22);
	MenuMarker.addActionListener( new ActionListener() {
		public void actionPerformed(ActionEvent ev) {
               
		    parent.jdp.getDesktopManager().activateFrame(erf);
		    erf.toFront();  erf.moveToFront();
		    try {
			erf.setIcon(false);
			erf.setSelected(true);
		    } catch (Exception e) {
			e.printStackTrace();
		    }
		} } );

	parent.jmFenster.add(MenuMarker);
	changed=true;
        
    }

 
/** laedt die in einer Datei gespeicherten Komponenten in den ERFrame 
 * (Objekte , die schon eingefuegt wurden
 * bleiben erhalten , obwohl dies momentan nicht verwendet wird ).
 * Dazu werden Methoden der Klasse ERFileReader verwendet
 * @see ERFileReader 
 */ 
    public void Load(String name)
    {       setFileName(name);
    ERFileReader erfr = new ERFileReader(this,filename,types);

    if (erfr.shouldStop() == true) { return; } // d.h. wenn es keine DBF Datei ist 

    // wie oft die untigen Schleifen ausgefuehrt werden
    int noe = erfr.getNumOfEntities();
    int nor = erfr.getNumOfRelShips();
    int noi = erfr.getNumOfIsas();
         
    erfr.readTypes(types); // danach stehen die neuen Typen in dem Vector types
         
    /** jetzt werden die Entities geladen */
    for (int i = 1 ; i< noe;i++)
	{

            Entity e = erfr.readEntity();

            if (e==null) {System.out.println("Entity null , fehler beim Laden ERFrame.java Load"); return;}

            e.setVisible(true);
            p.add(e,new Integer(10));
            Entities.addElement(e);
            p.invalidate();  // stellt sicher , dass die Entity komplett gezeichnet wird
            e.invalidate();  // da hatte ich anfangs Probleme
            p.validate();
            e.repaint();
	}
       
    /** bei RelShips hatte ich weniger Probleme mit dem Zeichnen */
    for (int i = 1 ; i<=nor;i++)
	{
	    RelShip r = erfr.readRelShip(p,Entities);
	    if (r==null) { System.out.println("RelShip null , ERFrame.java , Load" + i);return;}
	    Rels.addElement(r);
	    p.validate();
	}
         
    /** und zum Schluss die ISAs */
    for (int i = 1 ; i<=noi; i++)
	{
	    ISA isa = erfr.readIsa(p,Entities);
	    if (isa==null) { System.out.println("ISA null , ERFrame.java , Load" + i);return;}
	    // diese Fehlermeldungen koennen eigentlich nur auftreten , wenn 
	    // eine Datei korrupt ist . (Am Anfang wurde der Datei Header auf DBF format
	    // getestet).
	    Isa.addElement(isa);

	}

    erfr.closeStream(); // schliesst die Datei wieder
    }

 
/** reagiert auf das Ausloesen der Save bzw. SaveAs Action und 
 *  speichert den Inhalt des ERFrame in eine neue Datei name 
 * Fuehrt die inversen Aktionen zu Load aus 
 * @see ERFileSaver 
 */
    public void Save(String name)
    {

	if ( name.indexOf(".") == -1 ) name = name + ".dbf";


	setFileName(name);
     
	File ff = new File(name);
	String gh = ff.getName();
     
	MenuMarker.setText(gh);

	int ne = Entities.size() ;
	int ni = Isa.size(); int nr = Rels.size();

        Dimension d = p.getSize();

	// legt eine Instanz von ERFileSaver an und schreibt gleich die
	// ersten Daten (Header und die uebergebenen integer) in die neue Datei.
	ERFileSaver erfs = new ERFileSaver(filename,ne,nr,ni,d.width,d.height);
    

	erfs.writeTypes(types); // speichert die Domaenentypen ab 

	// als Hauptsache : zuerst Entities , dann RelShips , dann ISAs 
	for (int i = 1; i<ne; i++)
	    {  Entity e =(Entity) Entities.elementAt(i);
	    erfs.writeEntity(e);

	    }

	for (int i = 0; i<nr; i++)
	    {  RelShip r =(RelShip) Rels.elementAt(i);
	    erfs.writeRelShip(r);

	    }


	for (int i = 0; i<ni ; i++)
	    {
		erfs.writeIsa( (ISA) Isa.elementAt(i),Entities);
	    }


	erfs.closeStream(); // und fertig
    }


/** Speichert die markierten Objekte im ClipBoard Vector von parent
 * und loescht sie danach von der Zeichenflaeche (laut debugger sind sie ganz weg,
 * jedenfalls wird wieder einiges an Speicher frei  */

    public void Cut() { Copy(); Del(); }
 

/** klont die im ClipBoard gespeicherten Objekte und fuegt sie in die JLayeredPane ein 
 * Es ist egal , von wo die Objekte stammen , dieser ERFrame ist aktiv , und hier 
 * werden sie eingefuegt. Wenn ein Datentyp in diesem ERFrame noch nicht vorhanden
 * ist wird er neu angelegt 
 * Die neu eingefuegten Objekte werden markiert. 
 */
    public void Paste() 
    {  Vector cv = new Vector();
    int enumold = Entities.size();
    setMarked(0,0,0,0,0); // loescht eine alte Markierung

    int n = parent.getClipBoardSize();
    
    if (n==0) return;
    // je nach Art des Objects wird anderer Code ausgefuehrt
    for (int i=0; i<n; i++)
	{
	    Object o = parent.getClipBoardObjectAt(i);
	    if (o instanceof Entity) { cv.addElement(o);
	    Entity e = ( (Entity) o).klone(this,types);
                                   
	    e.setVisible(true);
	    p.add(e,new Integer(10));
	    Entities.addElement(e);
	    p.invalidate();
	    e.invalidate(); //keine Ahnung warum das manuell ausgefuehrt werden muss 
	    p.validate();   // irgendeine Zeile ist ueberfluessig
	    e.repaint();
	    e.setMarked(true);
	    }

    
	    if (o instanceof RelShip) 
		{
		    RelShip r = ( (RelShip) o).klone(cv,this,Entities,enumold,types);
		    Rels.addElement(r);
		    r.setMarked(true);

		}

       
	    if (o instanceof ISA) 
		{                ISA ii = ( (ISA) o).klone(cv,this,Entities,enumold);
		Isa.addElement(ii);
		ii.setMarked(true);
		}


       


	}  
    parent.activSelect(true);
   
    }
 

/** loescht das ClipBoard und speichert die markierten Objekte darin.
 * d.h. danch sind nur die Objekte die in dem aktiven ERFrame markiert
 * waren im ClipBoard. */
    public void Copy() 
    { 
	int n = Entities.size(); int mm=0;
	int nr = Rels.size();
	int ni = Isa.size();

	if(n==0 && nr==0 && ni==0) return;

	parent.resetClipBoard();
   
	/* jetzt werden alle Komponenten , die in den Vektoren 
	   Entity , RelShip und ISA gespeichert sind abgeklappert
	   vermutlich nicht besonders effektiv */
	for (int i=1;i<n;i++)
	    {
      
		Entity e = (Entity) Entities.elementAt(i);
		if (e.isMarked()) {parent.addToClipBoard(e);   mm=1; }
  
	    }

	for (int i=0;i<nr;i++)
	    {
		RelShip r = (RelShip) Rels.elementAt(i);
		if (r.isMarked()) {parent.addToClipBoard(r);  mm=1; }
	    }
    
	for (int i=0;i<ni;i++)
	    {
		ISA ii = (ISA) Isa.elementAt(i);
		if (ii.isMarked()) {parent.addToClipBoard(ii);  mm=1; }
	    }

	if (mm==1) {parent.clipER=1;parent.activPaste(true);}

    }

/** loescht die markierten Objekte , mangels Undo Funktion sind die dann wirklich 
 * weg  */
    public void Del() { 
	int n = Entities.size();
	int nr = Rels.size();
	int ni = Isa.size();
	if(n==0 && nr==0 && ni==0) return;
	Vector deletedEntities=new Vector();

	for (int i=n-1;i>0;i--)  //rueckwaerts , da evtl. Elemente entfernt werden . 
	    // d.h. die Numerierung im noch relevanten Teil des
	    // Vectors bleibt erhalten 
	    {
      
		Entity e = (Entity) Entities.elementAt(i);
		if (e.isMarked()) { e.setVisible(false);
		p.remove(e);    Entities.removeElement(e);
		deletedEntities.add(e);
		}   
	    }

	for (int i=nr-1;i>=0;i--)
	    {
		RelShip r = (RelShip) Rels.elementAt(i);
		if (r.isMarked()) {
		    r.remove(); Rels.removeElement(r);
		}
		for (int ii=0;ii<3;ii++) {
		    if (deletedEntities.contains(r.ent[ii])) {
			r.clearEntity(ii+1);
		    }
		}
	    }

	for (int i=ni-1;i>=0;i--)
	    {
		ISA isa = (ISA) Isa.elementAt(i);
		if (isa.isMarked()) {isa.remove(); Isa.removeElement(isa);}

 		if (deletedEntities.contains(isa.getSuperEntity())) {
		    isa.clearSuperEntity();
  		}
		for (int ii=0;ii < isa.getSubEntityCount(); ii++) {
		    if (deletedEntities.contains(isa.getSubEntity(ii))) {
			isa.clearSubEntity(ii);
		    }
		}
	    }
	parent.activSelect(false);
    }


/** fuegt eine neue RelShip ein */
    public void addRel()   
    { RelShip R = new RelShip(this,Entities,types);
    Rels.addElement(R);

    }


/** legt eine neue Generalisierung an */
    public void addIsa()
    { 

	ISA isa = new ISA(this,Entities);
	Isa.addElement(isa);   
  
    }


/** reagiert auf AddEntityAction und legt eine neue Entity an  */
    public void addEntity()
    {

	Entity e = new Entity(this,types);

	// "sinnvollen" Namen geben
	e.setName("Entity" + (++entityCreatedCount));
	// Diese Zeilen sorgen dafuer , dass die Entity immer links oben auf
	// dem Bildschirm erscheint , egal wo die ScrollPosition ist
	Point vp = jsp.getViewport().getViewPosition();
	e.setLocation(vp.x + 40,vp.y + 40);

	e.setVisible(true);
	p.add(e,new Integer(10));
	Entities.addElement(e);
	p.invalidate();
	e.invalidate();
	p.validate();
	e.repaint();
	p.moveToFront(e);
	e.focusName(); // Name fokussieren und markieren
    }

/** implementiert das JspLayout Interface , informiert den Layout Manager ueber die
    aktuelle Groesse von p (p ist die JLayeredPane/jlp/das gruene halt) */
    public Dimension getS()
    { return p.getSize();}


/** markiert alle Objekte im angegebenen Rechteck 
 *  eine Entity wird dann markiert wenn ihre linke obere Ecke im Rechteck ist
 *  eine RelShip wird dann markiert , wenn die linke obere Ecke von Diamond drinnen ist
 * analog fuer ISA mit IsaCenter */
  
    public void setMarked(int x1,int y1,int x2,int y2,int ii)
    {  boolean b;Entity e;RelShip r;ISA isa;
    int n = Entities.size();
    if (ii==0) markVector.removeAllElements();
    int empty=0;
      
    for (int i=1;i<n;i++)
	{     
	    e = (Entity) Entities.elementAt(i);
	    b = e.isIn(x1,y1,x2,y2);  // alle drei Klassen stellen die Methode isIn zur Verfuegung
	    // wenn man deren Implementierung aendert , aendert sich
	    // das Verhalten bei Selektion 
	    if (b==true) {e.setMarked(true) ; empty = 1;markVector.addElement(e);}
	    else if (ii==0) e.setMarked(false);

	    e.repaint(); 
      
	}
 
    n = Rels.size();
    for (int i=0;i<n;i++)
	{     
	    r = (RelShip) Rels.elementAt(i);
	    b = r.isIn(x1,y1,x2,y2);
	    if (b==true) { r.setMarked(true) ; empty = 1;markVector.addElement(r);}
	    else if (ii==0) r.setMarked(false);

	    r.d.repaint(); 
      
	}
    n = Isa.size();
    for (int i=0;i<n;i++)
	{
	    isa = (ISA) Isa.elementAt(i);
	    b = isa.isIn(x1,y1,x2,y2);
	    if (b==true) { isa.setMarked(true); empty = 1;markVector.addElement(isa);}
	    else if (ii==0) isa.setMarked(false);
	    isa.isc.repaint();
	}


// kuemmert sich darum , dass cut , copy und del abgestellt werden  , wenn nichts gewaehlt ist
    if (ii==0) 
	{ if (empty==1) { parent.selectER=1; parent.activSelect(true);}
	else { parent.selectER=0; parent.activSelect(false);}
    
	}
    else if (empty==1) { parent.selectER=1; parent.activSelect(true);}
 

    }

/** liefert den vollen Pfad des aktuellen Dateinamens , der steht in der Variable filename*/
    public String getFileName()
    {
	return filename;
    }


/** aendert den Dateinamen und setzt die Titelzeile entsprechend */
    public void setFileName(String name)
    {
	filename = name;
	setTitle(name);
	repaint();
    }

/** liefert die JScrollPane des ERFrame */
    public JScrollPane getJsp()
    {
	return jsp;
    }

/** Vergr��ert die Zeichenfl�che um 100 Pixel in x und y Richtung 
 * es gibt keine maximale Groesse*/
    public void incPanel()
    {
	Dimension d = p.getSize();
	p.setSize(d.width + 100 , d.height + 100 );
	jsp.invalidate(); jsp.revalidate(); jsp.repaint();
  

    }

/** Verkleinert die Zeichenfl�che um Variables.sizeChange Pixel in x und y Richtung 
 * Die minimale Groesse wird ebenfalls in Variables definiert 
 * @see Variables 
 */
    public void decPanel()
    {
	Dimension d = p.getSize();
	if (d.width < Variables.minSizeX  || d.height < Variables.minSizeY ) return;
	p.setSize(d.width - Variables.sizeChange , d.height - Variables.sizeChange );

    }


/** setzt die Zeichenflaeche nach dem Laden auf die angegebene Groesse */
    public void setPanelSize(int nx,int ny)
    {
	p.setSize(nx,ny);
    }

/** gibt den sichtbaren Bereich der Zeichenflaeche zurueck */
    public Rectangle getViewPort()
    {
	if (jsp==null) return null;
	return jsp.getViewport().getViewRect();
    }

/** Scrollt um je x bzw. y  Pixel */
    public void scroll(int x , int y)
    { 
	Rectangle p1 =  jsp.getViewport().getViewRect(); //x,y Koordinate und Groesse des sichtbaren Telils der Zeichenflaeche

	Dimension d = p.getSize();   // Groesse der Zeichenflaeche

	if (p1.x + x > d.width - p1.width) {return;}   //nicht ueber Raender scrollen
	if (p1.y + y > d.height - p1.height) {return;}
	if (p1.x + x < 0 ) {return;}
	if (p1.y + y < 0 ) {return;}



	Point pn = new Point(p1.x + x , p1.y + y);
	jsp.getViewport().setViewPosition(pn);
    }

/** zum Bearbeiten der Datentypen , oeffnet einen TypesDialog
 * @see TypesDlg 
 */
    public void alterTypes()
    { 
	TypesDlg tdlg = new TypesDlg(parent.jfr,this,types);
	//tdlg.toFront();
    }

/** Faengt das Schliessen des InternalFrames ab 
 * und fragr mittels einer MessageBox vorher nochmal nach , das uebliche halt */
    public void setClosed(boolean b)
    {

	if (shouldClose()) {
	    parent.removeInternalFrame(this);
	    // try {   super.setClosed(true);} catch (Exception e) {} //keine Listener !
	}
    }


/* unused -- mihi, 2003-12-06
 * 
 */
/** uebersetzt das Modell nach SQL unter Verwendung einer ausgewaehlten Klasse
 * Es wird diejenige Klasse verwendet , die in dem ComboBoxModel Start.convertDfm
 * selektiert ist . Sie muss das Interface Convert erfuellen.
 * Nach der Konvertierung wird der Resultierende String in einen neuen TextFrame 
 * eingefuegt 
 * Das ComboBoxModel wird bei Start des Programms angelegt.
 * Die Items stehen in Variables.convertArray
 * Zur Auswahl einer Klasse kann man es einfach in eine ComboBox(z.b. in einem Dialog oder im Toolbar) einfuegen
 * 
 * @see Convert
 * @see Start 
 */
/*    public void translate() 
    {  
	TextFrame tf = new TextFrame("noname",parent); // 1. neuen TextFrame anlegen
	parent.Frames.addElement(tf);                  // und anzeigen
	parent.jdp.add(tf);
	tf.setVisible(true);
	tf.setSize(400,200);
	tf.setLocation(10,10);
	tf.toFront();
	Object o=null;
	Class tra = (Class) parent.convertDfm.getSelectedItem(); // 2. Konvertierklasse festlegen
	try {
	    o = tra.newInstance();    // und eine Instanz erzeugen
	} catch (Exception e) {System.out.println("Convert Exception ");return;}
	Convert con = (Convert) o;

	String nr1="\n" ;
	String n = con.convert(this);  // 3. Das Ergebnis der Konvertierung steht in diesem String
	nr1 = nr1 + n + "\n";

	tf.setText(nr1); // 4. den String in den TextFrame schreiben
    } 
*/


/** Benutzt die Klasse tra , um das Model zu konvertieren und 
 * in einem neuen Fenster anzuzeigen */
    public void export(Class tra )
    {  
	TextFrame tf = new TextFrame("noname" + parent.noNameCount,parent); // 1. neuen TextFrame anlegen
	parent.noNameCount++;
	parent.Frames.addElement(tf);                  // und anzeigen
	parent.jdp.add(tf);
	tf.setVisible(true);
	tf.setSize(400,200);
	tf.setLocation(10,10);
	tf.toFront();
	Object o=null;
      
	try {
	    o = tra.newInstance();    // und eine Instanz erzeugen
	} catch (Exception e) {System.out.println("Convert Exception ");return;}
	Convert con = (Convert) o;

	String nr1="" ;
	String n = con.convert(this);  // 3. Das Ergebnis der Konvertierung steht in diesem String
	nr1 = nr1 + n + "\n";

	tf.setText(nr1); // 4. den String in den TextFrame schreiben
    }

/**Wird von den BasicUI gerufen, wenn das markierte Objekt o um ny und nx bewegt wurde*/
    public void markedMoved(Object o,int nx,int ny)
    {
	int i = markVector.size();

	for (int j=0;j<i;j++)
	    {
		Object oo = markVector.elementAt(j);
		if (o==oo) continue;

		if (o instanceof Entity)
		    {
			Entity ee = (Entity) o;
			Point p = ee.getLocation();
			ee.setLocation(nx+p.x,ny+p.y);
		    }


	    }
    }


} // eof Class
