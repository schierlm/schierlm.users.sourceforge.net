import java.awt.Point;
import java.awt.Polygon;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.event.*;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;

/** Das UI-Delegate der Verbindungslinien bei Vererbung , verarbeitet keine Mausereignisse */
public class BasicIsaLineUI extends IsaLineUI implements MouseListener,MouseMotionListener

{  
 
     int x3,y3; double addTo=0.0; boolean onLine=false;

    public static ComponentUI createUI(JComponent c)
    { return new BasicIsaLineUI();}

    public void installUI(JComponent c)
    { IsaLine e = (IsaLine) c;
      e.addMouseListener(this);
      e.addMouseMotionListener(this);

    }

    public void uninstallUI(JComponent c)
    { IsaLine e = (IsaLine) c;
      e.removeMouseListener(this);
      e.removeMouseMotionListener(this);


    }



   /** Zeichnet je nach Art der Komponente  einen Pfeil oder nur eine Linie in eine bestimmte Richtung */
    public void paint(Graphics g,JComponent c)
    { 
      IsaLine isl = (IsaLine) c;
     
       Dimension d = isl.getDim();
       Dimension dd = isl.getSize();
      
       boolean r = isl.nachRechts; boolean h = isl.nachOben; boolean p = isl.pfeil;
             
      g.setColor(Variables.IsaLineColor);


        long longlen = java.lang.Math.round(java.lang.Math.sqrt((double) d.width*d.width + d.height*d.height));
        int len = (int) longlen; 
        double nnew = ( (double) Variables.SpecialD) / ((double)len);
       
        
       
       if (r==true)  // nachRechts
       {
          if (h==true)  //nachOben
          {  
             g.drawLine(Variables.SpecialD,d.height + Variables.SpecialD,d.width + Variables.SpecialD,Variables.SpecialD);
           
          }

          if (h==false) // nachUnten
          {    
              g.drawLine(Variables.SpecialD,Variables.SpecialD,d.width+ Variables.SpecialD,d.height+ Variables.SpecialD);
             
          } 
       } 

       if (r==false)
       {
          if (h==false)
          {
             g.drawLine(Variables.SpecialD,d.height+Variables.SpecialD,d.width+Variables.SpecialD,Variables.SpecialD);
           
              
          }

          if (h==true)
          {
              g.drawLine(Variables.SpecialD,Variables.SpecialD,d.width+Variables.SpecialD,d.height+Variables.SpecialD);
          
         
          } 
       } 

          if (p==false) return;  
      Polygon poly = isl.getPoly();      
      g.fillPolygon(poly);



    }

  
 public void mousePressed(MouseEvent e)
 {  
   IsaLine d = (IsaLine) e.getComponent();
          
    
   Point px = e.getPoint();
   Dimension d2 = d.getDim();
   float m =  ((float) d2.height) / ((float) d2.width); 
   int yy = (int) (m * ((float) px.x) + Variables.SpecialD - m * Variables.SpecialD); 
     int yyy = (int) (-m * ((float) px.x) + Variables.SpecialD +  d2.height + m * Variables.SpecialD);
   if ((yy-5-0.2*m < px.y && yy + 5+ 0.2*m > px.y) || (yyy-5-0.2*m < px.y &&  yyy+5+0.2*m > px.y) )
   { 
            onLine=true; x3 = px.x; y3 = px.y;
    }

   else 
   { 
       onLine=false;
   Point p = d.getLocation();
   e.translatePoint(p.x,p.y);
   d.parent.parent.erpm.mousePressed(e);
   }   


  }

    public void mouseReleased(MouseEvent e)
    {
     IsaLine d = (IsaLine) e.getComponent();
     Point p = d.getLocation();
     e.translatePoint(p.x,p.y);

     d.parent.parent.erpm.mouseReleased(e);


    }

    public void mouseEntered(MouseEvent e)
    {
         IsaLine d = (IsaLine) e.getComponent();
         Point p = d.getLocation();
         e.translatePoint(p.x,p.y);

         d.parent.parent.erpm.mouseEntered(e);

    }

    public void mouseExited(MouseEvent e)
    {
         IsaLine d = (IsaLine) e.getComponent();
         Point p = d.getLocation();
         e.translatePoint(p.x,p.y);
         d.parent.parent.erpm.mouseExited(e);

    }

    public void mouseClicked(MouseEvent e)
    {
        IsaLine d = (IsaLine) e.getComponent();
       
        Point p = d.getLocation();
        e.translatePoint(p.x,p.y);

        d.parent.parent.erpm.mouseClicked(e);
         
    }


    public void mouseDragged(MouseEvent e)
    {   IsaLine d = (IsaLine) e.getComponent();
        Point p = d.getLocation();
      

           if (onLine==false) {
        e.translatePoint(p.x,p.y);
        d.parent.parent.erpm.mouseDragged(e); 
        }

     else
     {
        if (d.waagrecht==false)
        {
              if (e.getX() > x3) {addTo=0.005; x3 = e.getX() ;}
              if (e.getX() < x3) {addTo=-0.005; x3 = e.getX() ;}

        }
        
        if (d.waagrecht==true)
        {
            if (e.getY()  > y3) {addTo=0.005; y3 = e.getY();}
            if (e.getY()  < y3)   {addTo=-0.005;y3 = e.getY();}


        }
              d.dockPer = d.dockPer + 2*addTo;

      }


         d.alterLine(d.ent);
    }


    public void mouseMoved(MouseEvent e)
    {
      IsaLine d = (IsaLine) e.getComponent();
      Point p = d.getLocation();
      e.translatePoint(p.x,p.y);
      d.parent.parent.erpm.mouseMoved(e);

    }



  

}
