import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;


/** ein Frame , der vorgefertigte java Funktionen verwendet , um 
  * einen simplen TextEditor zur Verfuegung zu stellen ) */
public class TextFrame extends ChangableInternalFrame {
 
 /** Der Name der TExtdatei */
 public String filename;
 
  /** Eintrag ins Fenster-Menu f�r dieses Fenster */
 public JMenuItem MenuMarker;
 
 /** Hier steht der Text drin */
 public MyTextArea ta;

/** Kontruktor , fuegt die Textarea in den internen Rahmen ein*/
 public TextFrame(String name,Start s) {
     super(s,name,true,true,true,true);
     addInternalFrameListener(parent.ifl);
     setBounds(150,50,300,150);

     Container cP = getContentPane();
     ta = new MyTextArea();
     JScrollPane jsp = new JScrollPane(ta);
     cP.add(jsp,BorderLayout.CENTER);
     setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);     
     filename = name;
 
     File ff = new File(name);
     String name22 = ff.getName(); // Dateiname ohne Pfad 

     MenuMarker = new JMenuItem(name22);
     MenuMarker.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               
	        parent.jdp.getDesktopManager().activateFrame(TextFrame.this);
                TextFrame.this.toFront();  TextFrame.this.moveToFront();
                try {
		    TextFrame.this.setIcon(false);
		    TextFrame.this.setSelected(true);
		} catch (Exception e) {
		    e.printStackTrace();
		}
           } } );

     parent.jmFenster.add(MenuMarker);
     changed=false;
     ta.getDocument().addDocumentListener(new TextDocumentListener(this));
 }

/** Oeffnet einen Dialog beim schliessen des internen Rahmens */
public void setClosed(boolean b) {
    if (shouldClose()) {
	parent.removeInternalFrame(this);
	//try {   super.setClosed(true);} catch (Exception e) {} //keine Listener !
    }
}

    

/** laedt eine Textdatei in die Textarea*/
 public void Load(String name)
 {
   setFileName(name);
 try
   {
    FileReader fr = new FileReader(filename);
    ta.read(fr,null);
    fr.close();
    ta.getDocument().addDocumentListener(new TextDocumentListener(this));
    changed=false;
   }
   catch (Exception e) { }
 }

    /** Laedt eine Textdatei aus einem InputStream. Der InputStream
     * wird nachher geschlossen.
     */
    public void loadStream(InputStream in) {
	try {
	    BufferedReader fr = new BufferedReader(new InputStreamReader(in));
	    ta.read(fr, null);
	    fr.close();
	    ta.getDocument()
		.addDocumentListener(new TextDocumentListener(this));
	    changed=false;
	} catch (IOException ex) {
	    ex.printStackTrace();
	}
    }


/** speichert den Text in der Textarea nach filename*/
 public void Save(String name)
 {  
      if ( name.indexOf(".") == -1 )
      {  if (ta.getText().startsWith("#FIG")) name = name + ".fig";
         else  name = name + ".txt";
       
      }

     if (! (name.equals(filename))) setFileName(name);

     File ff = new File(name);
     String gh = ff.getName();
     
     MenuMarker.setText(gh);
  try
   {
    FileWriter fw = new FileWriter(filename);
    ta.write(fw);
    fw.close();
    changed=false;
   }
   catch (Exception e) { }
   

 }

/** ruft cut in der Textarea */
 public void Cut() {ta.cut(); }
 /** ruft paste in der Textarea */
 public void Paste() {ta.paste(); }
 /** ruft copy in der Textarea */
 public void Copy(){ ta.copy(); parent.clipTxt = 1; }
 /** ruft del in der Textarea */
 public void Del() {ta.replaceSelection(""); }

/** Accessor fuer filename */
  public String getFileName()
  {
     return filename;
  }

/** Accessor fuer filename, aendert die Ueberschrift des Rahmens */
  public void setFileName(String name)
  {
     filename = name;
     setTitle(filename);

  }

/** setzt den Inhalt der Textarea auf s */
public void setText(String s)
{
  ta.setText(s);
  setChanged();
}

    public void setChanged() {
	changed=true;
	System.out.println("Changed!");
    }
}
