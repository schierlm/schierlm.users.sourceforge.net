public class HTPair {
    public int ent;
    public AttributRowModel arm;
    public int r;
  
    public HTPair(int e,AttributRowModel arm2) {
	r = -1;
	ent = e;
	arm = arm2;
    }

    public HTPair(AttributRowModel arm2,int rel) {
	r = rel;
	ent = -1;
	arm = arm2;  
    }
}
