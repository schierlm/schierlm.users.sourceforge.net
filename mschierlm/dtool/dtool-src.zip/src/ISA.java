import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import java.awt.Point;
import java.awt.Dimension;
import javax.swing.JScrollPane;


/**  Diese Klasse fasst die einzelnen Komponenten einer Generalisierung
 * zusammen.
 */
public class ISA
{  
/** Gibt an, ob dieses Objekt markiert wurde */

    public boolean marked;
    
/** Das ER-Modell , zu dem die Vererbung geh�rt 
 *  @see ERFrame */
    public ERFrame parent;
     
/** 'Link' auf alle Entities von parent */
    public Vector Entities;  // alle Entities im Model

/** Speichert alle IsaLines der SubEntitaeten */
    public Vector lines = new Vector();
   
/** Die IsaLine der SuperEntitaet 
 * @see IsaLine */  
    public IsaLine supr = new IsaLine(this);
    
/** Modell zur ComboBox der SuperEntity */
    public FakeComboBoxModel dcm;
   
/** Modell der SubEntities 
* @see ISATableModel */
     
    public ISATableModel itm;
   
/** Diese Komponente stellt den Halbkreis dar */
    public IsaCenter isc;  
        
/** Vektor mit allen SubEntities , ( zusaetzlich zu ISATableModell) */
    public Vector subs = new Vector();

/** gibt an ob die Vererbung disjunkt ist */ 
    public JCheckBox isX = new JCheckBox("");
    
/** keine Ahnung , Tippfehler , Copy-Paste zuviel ?? */
    Vector DrawSamples = new Vector();


/** antwortet mit true , wenn sich die linke obere Ecke von isc im Rechteck befindet */
public boolean isIn(int x1 , int y1 , int x2 , int y2) {  
        Point p = isc.getLocation() ;
	Dimension d =  isc.getSize();
	
	//swap
        if (x1 > x2 ) { int s = x1; x1 = x2; x2 = s;}
        if (y1 > y2 ) { int t = y1; y1 = y2; y2 = t;}

        

        if (p.x<x1) return false;
        if (p.x+d.width>x2) return false;
        if (p.y<y1) return false;
        if (p.y+d.height>y2) return false;

        return true;

}


public ISA(ERFrame e,Vector Ent) {
  this(e,Ent,0);
}




/** Konstruktor 
 * @param e Das ER-Modell / der JInternalFrame , der die Vererbung angelegt hat 
 * @param Ent der EntitaetenVektor von e 
 */
public ISA(ERFrame e,Vector Ent,int i) {
    parent = e;
    Entities = Ent;
    
    itm = new ISATableModel();

    dcm = new FakeComboBoxModel(Entities);

   parent.p.add(supr,new Integer(1));   
   JScrollPane jsp = parent.getJsp();
   Point vp = jsp.getViewport().getViewPosition();
   

    isc = new IsaCenter(this,vp.x,vp.y);
    parent.p.add(isc,new Integer(2));

    if (i==0) openDialog();

    Object o = dcm.getSelectedItem();
    if (o instanceof String) return;
    Entity en = (Entity) o;

    Dimension d = en.getSize();
    Point p = en.getLocation();

    isc.setLocation(p.x + d.width/2 , p.y + d.height + 40);
    repaintAllLines();

}


/** wird gerufen , wenn SubEntities hinzugefuegt oder geloescht wurden */

public void createNewLines(int n)
{  int m = lines.size();
   
 if (m<n) 
 {
   for ( ; m<n ; m++)
   {
     IsaLine isl = new IsaLine(this);
     lines.addElement(isl);
     parent.p.add(isl,new Integer(1));
     isl.setVisible(true);

   }
 
 }


if (n<m)
{  
   for (int i = m-1 ; i>n-1 ; i--)
      {
         IsaLine isl = (IsaLine) lines.elementAt(i);
         isl.setVisible(false);
         parent.p.remove(isl);
         lines.removeElement(isl);
         Entity e = isl.getEntity(); if (e!=null) e.remIsaLine(isl);

     }
   
}

paintLines();


}


/** zeichnet die IsaLines neu , wird von createNewLines gerufen ,
 * d.h. repaint das Ver�nderungen im Modell beruecksichtigt*/
protected void paintLines()
{  int n = subs.size();
   int m = lines.size();
 
   if (n!=m) { System.out.println("paintLines : n != m  " + n + " " + m); return;}

   for (int i = 0; i<m; i++)
    {
       IsaLine isl = (IsaLine) lines.elementAt(i);
       Entity e2 = isl.getEntity();
       if (e2!=null) e2.remIsaLine(isl);     
       Entity e = (Entity) subs.elementAt(i);
       isl.alterLine(e,false);e.addIsaLine(isl);isl.setEntity(e);

   }
 

Object o = dcm.getSelectedItem();
if (o == null || o instanceof String)
{
    supr.setVisible(false);
    //Entity e = supr.getEntity();
    

}

if (o instanceof Entity) 
{
   Entity e = supr.getEntity(); 
   if (e!=null) e.remIsaLine(supr);
   
   supr.alterLine( (Entity) o,true);
   supr.setVisible(true);
  ((Entity) o).addIsaLine(supr);
   supr.setEntity((Entity) o);

}


else { supr.setVisible(false);}

}




/** nur 'repaint' fuer alle IsaLines */
public void repaintAllLines() {
  int n = lines.size();
  for (int i = 0; i<n; i++)
  {
     IsaLine isl = (IsaLine) lines.elementAt(i);
     Entity e = isl.getEntity(); // haette auch den 2ten Vector (s.o.) nehmen koennen
     isl.alterLine(e);
   
  } 

   Entity e = supr.getEntity();
   supr.alterLine(e);
 
}


/** wird nach dem Laden eines ERFrames gerufen */
public void afterLoad()
{
     itm.getVector(subs,dcm.getSelectedItem()); // danach stehen die aktuellen SubEntities in Subs
     int n = subs.size();



     createNewLines(n);     


}


/** oeffnet den Dialog zum bearbeiten der Vererbung 
* @see ISADlg 
*/
public void openDialog()
{ 

     
     ISADlg id = new ISADlg(parent.parent.jfr,parent,itm,this,Entities,dcm,isX);
     itm.makeproper(dcm.getSelectedItem());     
     itm.getVector(subs,dcm.getSelectedItem()); // danach stehen die aktuellen SubEntities in Subs

     int n = subs.size();
     isc.repaint();
     createNewLines(n);     

}


/** Accessor fuer den isX - Wert */
public boolean getX()
{
  return isX.isSelected();

}

/** Accessor fuer den isX - Wert */
public void setX(boolean b)
{

  isX.setSelected(b);
}


/** legt eine aehnliche Vererbung neu an */
public ISA klone(Vector cv , ERFrame newFrame,Vector destents,int enumold)
{
   ISA nnew = new ISA(newFrame,destents,1);
   Point p = isc.getLocation();
   nnew.isc.setLocation(p.x,p.y);


   Entity newsuperent=null; Vector newSubs = new Vector();


   Entity ent1 = (Entity) dcm.getSelectedItem();

   if (cv.contains(ent1))   {
          newsuperent =(Entity) destents.elementAt(enumold+cv.indexOf(ent1));
                                       }

   else if(parent == newFrame) { newsuperent = ent1;         }


  int n = subs.size();

  for (int i=0; i < n ; i++)
  {
    ent1 = (Entity) subs.elementAt(i);
    if (cv.contains(ent1)) newSubs.addElement(destents.elementAt(enumold+cv.indexOf(ent1)));
    else if (parent == newFrame)  newSubs.addElement(ent1);
   }


  boolean XX = getX();
  nnew.setX(XX);
  nnew.dcm.setSelectedItem(newsuperent);

  n = newSubs.size();

 for(int j = 0;j<n;j++)
      {         
         DefaultComboBoxModel dfmm = new DefaultComboBoxModel(destents);
         
         dfmm.setSelectedItem(newSubs.elementAt(j));
   
         nnew.itm.addRow(dfmm); 
      }
       
  nnew.afterLoad();



  return nnew;
}




/** Accessor fuer marked */
public boolean isMarked()
{
return marked;
}

/** Accessor fuer marked */
public void setMarked(boolean t)
{
marked = t; 
isc.setMarked(t);

}



/** entfernt alle Komponenten von der Zeichenflaeche */
public void remove()
{ IsaLine isl;
   isc.setVisible(false);
  parent.p.remove(isc);
  int n = lines.size(); supr.setVisible(false); 
  parent.p.remove(supr);

  for (int i = 0; i<n;i++)
  {
    isl = (IsaLine) lines.elementAt(i);
    isl.setVisible(false);
    parent.p.remove(isl);
  }
}


/** verschiebt alle Komponenten um dx und dy  oder auch nicht ?? nur Entities !!!!!! */
public void move(int dx , int dy)
{

  Point p = isc.getLocation();
  isc.setLocation(p.x+dx , p.y + dy);

  p = supr.getLocation();
  supr.setLocation(p.x+dx , p.y + dy);


}

/** true , wenn e subentity von dieser Vererbung ist*/
public boolean isSubEntity(Entity e)
{
  return subs.contains(e);
}

/**true , wenn e Oberentity von dieser Vererbung ist*/
public boolean isSuperEntity(Entity e)
{
  Entity te = (Entity) dcm.getSelectedItem();
  return (e==te);
}

/** Ermittelt die Oberidentit�t dieser Vererbung */
public Entity getSuperEntity() {
    Object o = dcm.getSelectedItem();
    if (o instanceof Entity) {
	return (Entity) o;
    } else {
	return null;
    }
}

/** Entfernt die Oberidentit�t dieser Vererbung */
public void clearSuperEntity() {
    dcm.data.setSelectedItem(dcm.getElementAt(0));

    // das scheint zu reichen, um das Objekt mit dem Model zu
    // synchronisieren                      -- mihi, 2003-12-03
    itm.makeproper(dcm.getSelectedItem());     
    itm.getVector(subs,dcm.getSelectedItem()); 
    int n = subs.size();
    isc.repaint();
    createNewLines(n);     
}

public int getSubEntityCount() {
    return subs.size();
}

public Entity getSubEntity(int num) {
    return (Entity) subs.get(num);
}

public void clearSubEntity(int num) {
    
    DefaultComboBoxModel dcm = (DefaultComboBoxModel) itm.data.elementAt(num);

    dcm.setSelectedItem(dcm.getElementAt(0));
    // das scheint zu reichen, um das Objekt mit dem Model zu
    // synchronisieren                      -- mihi, 2003-12-03
    itm.makeproper(dcm.getSelectedItem());     
    itm.getVector(subs,dcm.getSelectedItem()); 
    int n = subs.size();
    isc.repaint();
    createNewLines(n);     
}


} //Class ISA End 







