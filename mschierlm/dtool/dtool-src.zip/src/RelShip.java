import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Point;
import java.awt.Dimension;
import javax.swing.DefaultComboBoxModel;
import java.util.*;

/** Diese Klasse fasst alle Komponenten einer RelationShip zusammen
 * Einige Funktionen , insbesondere zum Berechnen der Verbindungslinien 
 * sind ziemlich ausgeufert. 
 * - Der Konstruktor fuer neue RelShips ruft drawRelShip auf
 * - DrawRelShip ruft fuer jede Entity (3x) dockEntity auf 
 * - dockEntity sucht einen freien AndockPunkt und ruft 
 * -  1. setLineV(ertical)/H(orizontal) oder 
 * -  2. dockAnyWay                        
 */
public class RelShip {
    /** gibt an , ob die RelShip markiert ist */
    public boolean marked;
   
    /** handle auf den ERFrame zu dem die RelShip gehoert */
    public ERFrame parent;
   
    /** link auf den DatentypenVektor (parent.types) */
    public Vector Types;
   
    /** link auf den Entity Vector von parent */
    public Vector Entities;  // alle Entities im Model
   
    /** Diese Komponente wird an den RelShipDlg uebergeben , sie enthaelt den Namen der RelShip*/
    public JTextField Name = new JTextField(" ");
   
    /** Wie Name , wird jedoch auf der Zeichenflaeche dargestellt */
    public JLabel NameLabel = new JLabel();
   
    /** Enthaelt die Attribute der RelShip */
    public AttributTableModel atm;
  
    /** Enthaelt drei Reihen , d.h. bis zu tenaere RelShips werden unterstuetzt.
     * In jeder Reihe kann eine Entity und einige Optionen(opt,many..) ausgewaehlt werden */
    public ERPanelTableModel eptm;
  
    /** Diese Komponente zeichnet sich als Raute auf die Zeichenflaeche */
    public Diamond d;  //Verbindung zu DrawAbles , 
        
    /** Hilfsvariablen , damit ich weiss , welche Punkte von Diamond belegt sind
     * oben , unten , links , rechts , 0 : frei 1-3 Nummer der Entity 
     * ist vermutlich nicht besonders elegant */
    public int oco=0,ocu=0,ocr=0,ocl=0;

    /** links auf Entities, die zu der RelShip gehoeren , null heisst kein Verweis */
//    public Entity ent1,ent2,ent3;

    // ent[0] entspricht ent1, ... ent[2] entspricht ent3
    public Entity[] ent = new Entity[3]; 

    /** drei Linien pro Entity */
    public Line[][] lin= new Line[3][3];

    /** in jedem DrawSample werden drei Lines zusammengefasst */
    public DrawSample[] ds = new DrawSample[3];


/** klont die RelShip . Wird von dem ERFrame gerufen , in den die RelShip 
 * gepastet wird . */
    public RelShip klone(Vector cv , ERFrame parent , Vector destents, int enumold,Vector desttypes) {
	Entity[] es = new Entity[3];
	int x1=-1 , x2=-1 , x3=-1;

	for (int i=0;i<3;i++) {
	    if (ent[i]!=null)
		if (cv.contains(ent[i])) { // nur wenn ent[i] auch gepastet wurde wird es[i] gesetzt
		    es[i] =(Entity) destents.elementAt(enumold+cv.indexOf(ent[i]));
		} else if (parent==this.parent) { 
		    es[i] = ent[i];    
		}
	}

	// das klonen der ERPanelTableModels ist problemlos
	ERPanelTableModel ep2 = new ERPanelTableModel();
	for (int i=0;i<3;i++) {
	    ERPanelRow erow = eptm.kloneRow(es[i],i+1,destents);
	    ep2.addRow(erow);
	}

// atm wird von seiner eigenen Methode geklont (dabei werden die DatenTypen beruecksichtigt)
	AttributTableModel a = atm.klone(desttypes);

	RelShip rr = new RelShip(parent,destents,Types,es,ep2,getName(),a);

	return rr;
    }

/** Wird beim klonen verwendet */
    public RelShip(ERFrame e,Vector ents,Vector tps,Entity[] es,ERPanelTableModel e23,String na,AttributTableModel a) {
	NameLabel.setForeground(Variables.drawColor);
	parent = e;
	Entities = ents;
	Types = tps;
	atm = a;
	eptm = e23;
	setName(na);
	ent[0] = es[0]; ent[1] = es[1]; ent[2] = es[2];
	drawRelShip();
    }

/** Wird zum Laden der RelShip aus einer Datei verwendet*/
    public RelShip(ERFrame e,Vector Ent,Vector tps,int xall,int yall,String na,int o,int r,int u,int l)
    {
	parent = e;
	Entities = Ent;
	Types = tps;
	NameLabel.setForeground(Variables.drawColor);
	atm = new AttributTableModel();

	oco = o; ocr = r; ocl = l; ocu = u;
  
	NameLabel.setText(na); NameLabel.setSize(60,20);
	NameLabel.setVisible(true);
	NameLabel.setLocation(xall+Variables.NameLabelDX-Variables.DiamondX/2,yall+Variables.NameLabelDY-Variables.DiamondY/2);
	parent.p.add(NameLabel,new Integer(3));
	setName(na);

	d = new Diamond(this,xall,yall); d.setVisible(true);
	for(int i=0;i<3;i++) {	    
	    ds[i] = new DrawSample(this);
	    d.setSample(i+1,ds[i]);
	    ds[i].addDrawAble(d);
	    ds[i].setNum(i+1);
	}
	parent.p.add(d,new Integer(5)); d.repaint();
	
	for(int i=0;i<3;i++) {
	    for(int j=0;j<3;j++) {
		lin[i][j] = new Line(ds[i]);
		ds[i].addDrawAble(lin[i][j]);
	    }
	}
    }


/** wird beim laden der RelShip aus einer Datei gerufen , 
 * (nach dem Konstruktor) , um eptm einzurichten */
    public void setEptm(ERPanelTableModel em) {
	eptm = em;
	Line dummy = new Line(ds[0]);
	for(int i=0;i<3;i++) {
	    ent[i] = eptm.getEntity(i+1);
	    
	    if (ent[i]!=null) {
		ds[i].addDrawAble(ent[i]);
		ent[i].addDrawSample(ds[i]);ds[i].setActivated(true);
	    }else {
		ds[i].addDrawAble(dummy);
	    }
	}
	checkSpecials();
    }


/** beim Anlegen einer neuen RelationShip
 *  d.h. nicht beim Laden einer Datei , sondern
 *  wenn eine (ganz) neue RelShip per Button
 *  eingefuegt wird */
    public RelShip(ERFrame e,Vector Ent,Vector tps)
    {
	parent = e;
	Entities = Ent;
	Types = tps;
	atm = new AttributTableModel();
	eptm = new ERPanelTableModel();
	NameLabel.setForeground(Variables.drawColor);

	for (int i=0;i<3;i++) {
	    DefaultComboBoxModel dfm = new DefaultComboBoxModel(Entities);
	    ERPanelRow erow = new ERPanelRow(dfm);
	    eptm.addRow(erow);
	}	

	// bringt den Dialog(modal) zum Vorschein
	RelShipDlg rsd = new RelShipDlg(parent.parent.jfr,parent
					,atm,Entities,
					eptm,Types,Name);
	// wird nach schliessen des Dialogs ausgefuehrt :
	ent[0] = eptm.getEntity(1);
	ent[1] = eptm.getEntity(2);
	ent[2] = eptm.getEntity(3);

	drawRelShip();
    }

/** wird von den Konstruktoren gerufen , um das Objekt zu zeichnen 
 * enthaelt einige (schlechte) Methoden zum Berechnen des Aussehens */
    public void drawRelShip()
    { 
	int num= 0,xall,yall;

	for(int i=0;i<3;i++) {
	    ds[i] = new DrawSample(this);
	}
    
    
	Point p = Methods.calcMidPoint(ent); xall = p.x; yall= p.y;
	Methods.setNameLabel(parent,NameLabel,xall,yall,getName());
   
	d = new Diamond(this,p.x,p.y);
	if (ent[0]!=null) checkOver(ent[0]);
	if (ent[1]!=null) checkOver(ent[1]);
	if (ent[2]!=null) checkOver(ent[2]);

	d.setVisible(true);
	for(int i=0;i<3;i++) {
	    d.setSample(i+1,ds[i]);
	    ds[i].addDrawAble(d);
	}
	parent.p.add(d,new Integer(5)); d.repaint();

	Line dummy = new Line(ds[0]); //Dummy Linie fuer leere DrawSamples (s.u.)
	for(int i=0;i<3;i++) {
	    for (int j=0;j<3;j++) {
		lin[i][j] = new Line(ds[i]);
		ds[i].addDrawAble(lin[i][j]);
	    }
	    if (ent[i]!=null) {
		ds[i].addDrawAble(ent[i]);
	    } else {
		ds[i].addDrawAble(dummy);
	    }
	}
	
	int i_[] = Methods.getOrder(d,ent);
   
	for (int i=0;i<3;i++) {
	    if (ent[i]!=null && i_[i] != 9) {
		ent[i].addDrawSample(ds[i]);
		dockEntity(i+1,d,lin[i],
			   ent[i],ds[i],i_[i]);
		ds[i].setActivated(true);ds[i].setNum(i+1);
	    }
	}
	// Hmm, ist es wichtig, dass die Aufrufe der dockEntities der
	// beiden Schleifen entkoppelt sind? Ich hab es jetzt einfach
	// mal so gelassen              -- mihi, 2003-12-04
	for (int i=0;i<3;i++) {
	    if (ent[i]!=null && i_[i] == 9) {
		ent[i].addDrawSample(ds[i]);
		dockEntity(1+i,d,lin[i],
			   ent[i],ds[i]);
		ds[i].setActivated(true);ds[i].setNum(i+1);
	    }
	}
    
	// ueberprueft ob irgenwelche Kreise , Dreiecke etc gezeichnet werden muessen
	checkSpecials();

    }


    private void dock(int i) {
	int o=i-1;
	if (ent[o]!=null) {
	    ent[o].addDrawSample(ds[o]);
	    dockEntity(i,d,lin[o],ent[o],ds[o]);
	    ds[i].setActivated(true);
	    ds[o].setNum(i);
	}
    }


    public void  setName(String s)
    {
	Name.setText(s); NameLabel.setText(s);
    }

    public String getName()
    {
	return Name.getText();
    }

/** zeichnet einen 'vertikalen' Linienzug (i.e eine vertikale Linie , dann eine horizontale , dann noch eine vertikale) 
 * die bools geben an , wie die gezeichnet wird ( _|- ist nachRechts und nach Oben (oder links unten
 *                                                    je nach Sichtweise )
 *                                                   nach links heisst , l1 rechts gezeichnet wird und nicht ganz links
 *   die integer geben die Laenge der Linien an (der Linienzug liegt in einem 2*dx langen Rechteck
 *       fder hoehe dy  )*/
    private void setLineV(boolean nachOben,boolean nachRechts,int dx , int dy,Line[] ls) {                     
	// FIXME: Schleife und Switch bauen?
	Point dpos = d.getLocation(); // die Position der DiamondKomponente
	int x, y, l;
	boolean b, dir, bdir ;
	// init 0
	bdir=false;
	b=!nachOben; dir=nachOben;
	x = dpos.x+Variables.DiamondX/2 - Variables.SpecialD;
	if (nachOben) {
	    y = dpos.y - dy; 
	} else {
	    y = dpos.y+ Variables.DiamondY;
	}
	// use 0
	ls[0].setLine(x,y,dy,bdir,b,dir);
	ls[0].setVisible(true);
	parent.p.add(ls[0], new Integer(4));
	ls[0].repaint();
	// init 1
	bdir=true;
	b=nachRechts;
	dir=nachRechts;
	if (!nachRechts) {
	    x = x - dx + Variables.SpecialD;
	} else {
	    x = x + Variables.SpecialD;
	}
	if (!nachOben) {
	    y = y + dy -  Variables.SpecialD;
	} else {
	    y = y - Variables.SpecialD;
	}
	// use 1
	ls[1].setLine(x,y,dx,bdir,b,dir);
	ls[1].setVisible(true);
	parent.p.add(ls[1],new Integer(4));
	ls[1].repaint();
	// init 2
	bdir=false;
	b=true;
	if (nachOben) {
	    dir = true;
	    y = y - dy + Variables.SpecialD;
	    b=false;
	} else {
	    y = y +  Variables.SpecialD;
	    dir = false;
	}
	if (nachRechts) {
	    x = x + dx-  Variables.SpecialD;
	} else {
	    x = x  -  Variables.SpecialD;
	}
	// use 2
	ls[2].setLine(x,y,dy,bdir,b,dir);
	ls[2].setVisible(true);
	parent.p.add(ls[2],new Integer(4));
	ls[2].repaint();
     
    }


/** wie setLineV nur horizontal */
    private void setLineH(boolean nachOben,boolean nachRechts,int dx , int dy,Line[] ls)
    {                       
	// FIXME: Schleife und Switch bauen?
	// FIXME: Mit SetLineV kombinieren?

	Point dpos = d.getLocation();
	int x, y, l;
	boolean b=false, dir = false;

	if (nachRechts==true) {
	    x = dpos.x+Variables.DiamondX; 
	    b=true;dir = true;
	} else {
	    x = dpos.x - dx; 
	    b = false;
	    dir = false;
	}
	y = dpos.y + Variables.DiamondY/2-Variables.SpecialD;
	
	ls[0].setLine(x,y,dx,true,b,dir);
	ls[0].setVisible(true);
	parent.p.add(ls[0],new Integer(4));
	ls[0].repaint();

	b=true;
	if (nachRechts) {
	    x = x + dx - Variables.SpecialD;
	} else {
	    x = x -  Variables.SpecialD;
	}

	if (nachOben) {
	    dir = true;y = y - dy +  Variables.SpecialD;
	    b = false;
	} else {
	    y = y +  Variables.SpecialD;
	    dir = false;
	}

	ls[1].setLine(x,y,dy,false,b,dir);
	ls[1].setVisible(true);
	parent.p.add(ls[1],new Integer(4));
	ls[1].repaint();

	b=true;
	if (!nachOben) {
	    y = y + dy -  Variables.SpecialD;
	} else {
	    y = y - Variables.SpecialD;
	}
	if (!nachRechts) {
	    dir = false;x = x - dx +  Variables.SpecialD;b=false;
	} else {
	    x = x +  Variables.SpecialD;dir = true;
	}

	ls[2].setLine(x,y,dx,true,b,dir);
	ls[2].setVisible(true);
	parent.p.add(ls[2],new Integer(4));
	ls[2].repaint();
    }



/** Sorgt daf�r , da� e den Diamond d nicht  �berlappt
 *  
 */
    public void checkOver(Entity e)
    {
	Dimension enD = e.getSize(); Point enP = e.getLocation();
	Dimension dD = d.getSize(); Point dP = d.getLocation();
	Point p = new Point(0,0);
	if (enD.width + enP.x > dP.x
	    && enD.height + enP.y > dP.y
	    && enP.x < dP.x + dD.width
	    && enP.y< dP.y + dD.height) { 
	    d.setLocation(dP.x + 10 , dP.y + 10);
	    checkOver(e); //FIXME: dumme rekursion -- mihi, 2003-12-04
	}
    }


    /** dockt ent an dd an , where gibt die Position am Diamond an */
    public void dockEntity(int num,Diamond dd,Line[] ls,Entity ent,DrawSample drsm,int where)
    {  Point pe = ent.getLocation();
    Point pd = dd.getLocation();

    int dy=0, dx = 0, ex = 0, ey = 0, ddx = 0,ddy = 0;


    // 1. oben

    ddx = pd.x + Variables.DiamondX/2; ddy = pd.y ; 
    ex = (int) (pe.x + (Variables.EntityX * drsm.dockPer)); 
    ey = pe.y + ent.getSize().height;
    if (/*(ddy > ey) &&*/ (oco == 0) && where==1) // dann wird oben angedockt
	{  oco = num;
	dy = ddy - ey;
	dx = ddx - ex;

	if (dx > 0) setLineV(true,false,dx,dy/2,ls); // weiter zu setLineV
	else setLineV(true,true,-dx,dy/2,ls);
	return;

	}
 
    // 3. unten
 
    {
	ddx = pd.x+Variables.DiamondX/2; ddy = pd.y + 40; ex = (int) (pe.x+ (Variables.EntityX * drsm.dockPer)); ey = pe.y;
	if (/*(ddy<ey) && */(ocu == 0) && where==3)
	    {  ocu = num;
	    dy = ey - ddy;
	    dx = ddx - ex;

	    if (dx > 0) setLineV(false,false,dx,dy/2,ls);
	    else setLineV(false,true,-dx,dy/2,ls);
	    return;
	    }
    }
    // 2. rechts
    ddx = pd.x +  Variables.DiamondX; ddy = pd.y + 20; ex = pe.x; ey = (int) (pe.y + (ent.getSize().height*drsm.dockPer)) ;
    if (/*(ex > ddx) &&*/ (ocr ==0) && where == 2)
	{   ocr = num;
	dy = ddy - ey;
	dx = ex - ddx;

	if (dy>0) setLineH(true,true,dx/2,dy,ls);
	else setLineH(false,true,dx/2,-dy,ls);
	return;
	}

    // 4. links
    ddx = pd.x; ddy = pd.y + 20; ex = pe.x + Variables.EntityX; ey = (int) (pe.y + (ent.getSize().height*drsm.dockPer)) ;
    if (/*(ex < ddx) && */(ocl == 0) && where == 4)
	{  ocl = num;
	dx = ddx - ex;
	dy = ddy - ey;

	if (dy>0) setLineH(true,false,dx/2,dy,ls);
	else      setLineH(false,false,dx/2,-dy,ls);
	return;


	}
    if (where==5) dockAnyWay(num,dd,ls,ent);
    }

    
/** sucht einen freien Andockpunkt , und ruft die nexte Methode auf */
    public void dockEntity(int num,Diamond dd,Line[] ls,Entity ent,DrawSample drsm)
    {  Point pe = ent.getLocation();
    Point pd = dd.getLocation();

    int dy=0; int dx = 0; int ex = 0; int ey = 0; int ddx = 0; int ddy = 0;


    // 1. oben
    ddx = pd.x + Variables.DiamondX/2; ddy = pd.y ; 
    ex = (int) (pe.x + (Variables.EntityX * drsm.dockPer)); 
    ey = pe.y + ent.getSize().height;
    if ((ddy > ey) && (oco == 0)) // dann wird oben angedockt
	{  oco = num;
	dy = ddy - ey;
	dx = ddx - ex;

	if (dx > 0) setLineV(true,false,dx,dy/2,ls); // weiter zu setLineV
	else setLineV(true,true,-dx,dy/2,ls);
	return;

	}
 
    // 2. unten

    ddx = pd.x+Variables.DiamondX/2; ddy = pd.y + 40; ex = (int) (pe.x+ (Variables.EntityX * drsm.dockPer)); ey = pe.y;
    if ((ddy<ey) && (ocu == 0))
	{  ocu = num;
	dy = ey - ddy;
	dx = ddx - ex;

	if (dx > 0) setLineV(false,false,dx,dy/2,ls);
	else setLineV(false,true,-dx,dy/2,ls);
	return;
	}

    // 3. rechts
    ddx = pd.x +  Variables.DiamondX; ddy = pd.y + 20; ex = pe.x; ey = (int) (pe.y + (ent.getSize().height*drsm.dockPer)) ;
    if ((ex > ddx) && (ocr ==0))
	{   ocr = num;
	dy = ddy - ey;
	dx = ex - ddx;

	if (dy>0) setLineH(true,true,dx/2,dy,ls);
	else setLineH(false,true,dx/2,-dy,ls);
	return;
	}

    // 4. links
    ddx = pd.x; ddy = pd.y + 20; ex = pe.x + Variables.EntityX; ey = (int) (pe.y + (ent.getSize().height*drsm.dockPer)) ;
    if ((ex < ddx) && (ocl == 0))
	{  ocl = num;
	dx = ddx - ex;
	dy = ddy - ey;

	if (dy>0) setLineH(true,false,dx/2,dy,ls);
	else      setLineH(false,false,dx/2,-dy,ls);
	return;


	}
    dockAnyWay(num,dd,ls,ent);

    }


/** oeffnet einen Dialog , in dem die RelShip bearbeitet werden kann */
    public void openDialog()
    {
	RelShipDlg rsd = new RelShipDlg(parent.parent.jfr,parent
					,atm,Entities,
					eptm,Types,Name);

	Entity[] es = new Entity[3];
	for (int i=0;i<3;i++) {   
	    es[i] = eptm.getEntity(i+1);
	}
	NameLabel.setText(getName());


	/** hier habe ich Code aus drawRelShip (leicht^H^H^H^H^H^Hstark abgeaendeert) eingefuegt */
	// FIXME: Wenn das so ist, kann man da nicht noch was
	// besser proggen?                -- mihi, 2003-12-04
	for (int i=0;i<3;i++) {
	    if ((es[i] != ent[i]) ) {
		if (ocl==i+1) ocl = 0; // oc? legt Andockpunkt am Diam fest
		if (ocr==i+1) ocr = 0;
		if (oco==i+1) oco = 0;
		if (ocu==i+1) ocu = 0;

		if (ent[i] != null) {
		    ent[i].removeDrawSample(ds[i]);
		}

		if (es[i]!=null)
		    {
			ds[i].setActivated(true);
			es[i].addDrawSample(ds[i]);
			ds[i].setEntity(es[i]);
			ent[i] = es[i];
			dockEntity(i+1,d,lin[i],ent[i],ds[i]);
			ds[i].setNum(i+1); 
		    }

		if (es[i] == null) {
		    ent[i] = null;
		    lin[i][0].setVisible(false);
		    lin[i][1].setVisible(false);
		    lin[i][2].setVisible(false);
		    parent.p.remove(lin[i][0]);
		    parent.p.remove(lin[i][1]);
		    parent.p.remove(lin[i][2]);
		}
	    }
	}
	checkSpecials();
    }


    /** sehr sinnvoller Accessor */
    public void setNameLabelLoc(int x,int y)
    {
	NameLabel.setLocation(x,y);
    }


    /** wird nach einem RelShipDialog gerufen . Ueberprueft , 
     * welche CheckBoxen von eptm (optional , many ... ) aktiviert sind
     * und sorgt dafuer , dass alles korrekt gezeichnet wird */
    public void checkSpecials() {
	for(int i=0; i<3; i++) {
	    if (eptm.isOptional(i+1)) lin[i][1].setSpecial(1);
	    else lin[i][1].setSpecial(0);
	    if (eptm.isMany(i+1)) lin[i][2].setSpecial(1);
	    else lin[i][2].setSpecial(0);
	    lin[i][0].setSpecial(0);
	    if (eptm.isStrong(i+1)) lin[i][0].setSpecial(2);
	    if (eptm.isWeak(i+1)) lin[i][0].setSpecial(1);
	}
    }


    /** die Anzahl der tatsaechlich zu dieser RelShip gehoerenden
     * Entities (0-3) */
    public int getNOfEnt()
    {
	int n = 0;

	if (ent[0] != null) n++;
	if (ent[1] != null) n++;
	if (ent[2] != null) n++;

	return n;
    }

    public Diamond getDiamond()
    {
	return d;
    }



    public int getNumOfARows()
    {
	return atm.getRowCount();
    }


/** Verzweiflungs Routine : wenn 4 Andockversuche (links , oben , unten , rechts )
 * am Diamand gescheitert sind wird diese Methode gerufen , was zu haesslichem Ergebnis 
 * fuehrt . ) */
    public void dockAnyWay(int num,Diamond dd,Line[] ls,Entity ent)
    {  int dx,dy,ex,ey,d1,d2,d3;
    boolean right;
    boolean up;

    Point pe = ent.getLocation();
    Point pd = dd.getLocation();

    if (oco==0) {  dx = pd.x + Variables.DiamondX/2;
    dy = pd.y ;
    ex = pe.x + Variables.EntityX/2;
    ey = pe.y;
    oco = num;

    if (dx<ex) { right = true; d2 = ex  - dx;}
    else { right = false; d2  = dx - ex;}

          
    if (dy<ey) { d1 =  (ey - dy) + 10 ; d3 =  10;}  
    else { d3 = (dy - ey) + 10; d1 = 10;}
    setLineH2(false,right,d3,d2,d1,ls);
    return;
    }


    if (ocu==0) {  dx = pd.x + Variables.DiamondX/2;
    dy = pd.y + Variables.DiamondY;
    ex = pe.x + Variables.EntityX/2;
    ey = pe.y + Variables.EntityY;
    ocu = num;  

    if (dx<ex) { right = true; d2 = ex  - dx;}
    else { right = false; d2  = dx - ex;}

          
    if (dy<ey) { d3 =  (ey - dy) + 10; d1 = 10;}  
    else { d1 = dy - ey + 10; d3 = 10;}
    setLineH2(true,right,d3,d2,d1,ls);

    return;
    }

    if (ocl==0) {    
	dx = pd.x;
	dy = pd.y + Variables.DiamondX/2;
	ex = pe.x;
	ey = pe.y + Variables.EntityY/2;
	ocl = num;
	if (dy<ey) { up = false; d2 = ey  - dy;}
	else { up = true; d2  = dy - ey;}

	if (dx<ex) { d3 =  (ex - dx) + 10; d1 = 10;}  
	else { d1 = dx - ex +10 ; d3 = 10;}
	setLineV2(up,false,d3,d2,d1,ls);
	return;
    }

    if (ocr==0) {    
	dx = pd.x + Variables.DiamondX;
	dy = pd.y + Variables.DiamondY/2;
	ex = pe.x + Variables.EntityX;
	ey = pe.y + Variables.EntityY/2;
	ocr = num;
                   
	if (dy<ey) { up = false; d2 = ey  - dy;}
	else { up = true; d2  = dy - ey;}

	if (dx<ex) { d3 =  (ex - dx) +10; d1 = 10;}  
	else { d1 = dx - ex +10; d3 = 10;}
	setLineV2(up,true,d3,d2,d1,ls);
                 
    }
    }


/** wie setLineH , die letzte Linie wird allerdings in
 *  die entgegengesetzte Richtung gezeichnet
 */ 
    private void setLineH2(boolean u,boolean nachRechts,int d1,int d2,int d3,Line[] ls)
    {  
	Point dpos = d.getLocation();

	int x; int y ; int l; boolean b=false; boolean dir = false;

	if (u==false)
	    { x = dpos.x+Variables.DiamondX/2 - Variables.SpecialD;
	    y = dpos.y - d1; dir = true;
	    b=false;
	    }

	else
	    { x = dpos.x+ Variables.DiamondX/2 - Variables.SpecialD;
	    y = dpos.y+ Variables.DiamondY;
	    b = true;  dir = false;
	    }
	ls[0].setLine(x,y,d1,false,b,dir);
	ls[0].setVisible(true);
	parent.p.add(ls[0],new Integer(4));
	ls[0].repaint(); 

	b=true;
	if (nachRechts == false) { x = x - d2 + Variables.SpecialD;
	b=false;
	dir = false;
	}
	else { x = x + Variables.SpecialD; dir = true;}

	if (u == true) { y = y + d1 -  Variables.SpecialD;

	}
	else { y = y - Variables.SpecialD;}


	ls[1].setLine(x,y,d2,true,b,dir);
	ls[1].setVisible(true);
	parent.p.add(ls[1],new Integer(4));
	ls[1].repaint();

             
	if (u == false) { dir = false;b=false;y = y + Variables.SpecialD;}
	else { y = y - d3 + Variables.SpecialD;dir = true;b = true;}

	if (nachRechts ==true) { x = x + d2 -  Variables.SpecialD;}
	else { x = x  -  Variables.SpecialD;}

	ls[2].setLine(x,y,d3,false,!b,dir);
	ls[2].setVisible(true);

	parent.p.add(ls[2],new Integer(4));
	ls[2].repaint();
                      
    }

/** wie setLineV , die letzte Linie wird allerdings in
 *  die entgegengesetzte Richtung gezeichnet
 */ 
    private void setLineV2(boolean nachOben,boolean c,int d1,int d2,int d3,Line[] ls)
    {  
	Point dpos = d.getLocation();
	int x; int y ; int l; boolean b=false;boolean dir = false;
	if (c==false)
	    { x = dpos.x+Variables.DiamondX; 
	    b=true;dir = true;
	    }
	else
	    { x = dpos.x - d1; 
	    b = false;     dir = false;
	    }
	y = dpos.y + Variables.DiamondY/2-Variables.SpecialD;
             
	ls[0].setLine(x,y,d1,true,b,dir);
	ls[0].setVisible(true);
	parent.p.add(ls[0],new Integer(4));ls[0].repaint();
	b=true;
	if (c == false) { x = x + d1 - Variables.SpecialD;}
	else {x = x -  Variables.SpecialD;}

	if (nachOben == true) { dir = true;y = y - d2 +  Variables.SpecialD; b = false; } 
	else { y = y +  Variables.SpecialD;dir = false;}

	ls[1].setLine(x,y,d2,false,b,dir);
	ls[1].setVisible(true);

	parent.p.add(ls[1],new Integer(4));ls[1].repaint();

	b=false;
	if (nachOben == false) { y = y + d2 -  Variables.SpecialD; }
	else { y = y - Variables.SpecialD;}

	if (c== false) { dir = false;x = x - d3 +  Variables.SpecialD;b=true;}
	else {x = x +  Variables.SpecialD;dir = true;}

	ls[2].setLine(x,y,d3,true,!b,dir);
	ls[2].setVisible(true);

	parent.p.add(ls[2],new Integer(4));  ls[2].repaint();

    }


/**
 * Setzt die Attribute von line j in DrawSample i auf px,py, le ...........
 * @see DrawSample
 * @see Line 
 */
    public void setLine(int px,int py,int le,boolean wr,boolean conn,boolean dir,int i,int j) {
	Line l = lin[i-1][j-1];
	l.setLine(px,py,le,wr,conn,dir);
	l.setVisible(true);
	parent.p.add(l,new Integer(4));l.repaint();
    }


/** liefert true , wenn der  rechte obere Eckpunkt des Diamond
 * innerhalb der Koordinaten liegt
 */
    public boolean isIn(int x1 , int y1 , int x2 , int y2)
    {
	Point p = d.getLocation();
	Dimension dd =  d.getSize();
	
	//swap
        if (x1 > x2 ) { int s = x1; x1 = x2; x2 = s;}
        if (y1 > y2 ) { int t = y1; y1 = y2; y2 = t;}

        if (p.x<x1) return false;
        if (p.x+dd.width>x2) return false;
        if (p.y<y1) return false;
        if (p.y+dd.height>y2) return false;

        return true;

    }

/* return marked */ 
    public boolean isMarked()
    {
	return marked;
    }

/* setzt marked auf b*/
    public void setMarked(boolean b)
    {
	marked = b;
	d.setMarked(b);
    }


/** wird gerufen , wenn die RelShip markiert ist und user auf del oder cut drueckt */
    public void remove() {
	for (int i=0;i<3;i++) {
	    if (ent[i]!=null) ent[i].removeDrawSample(ds[i]);
	    ds[i].remove();
	}
	d.setVisible(false); parent.p.remove(d);
	NameLabel.setVisible(false); parent.p.remove(NameLabel);
    }


    /** nachtraeglich eingefuegt , zum Laden/Speichern der Gleitkommazahl 
     *    , die festlegt  , wo die RelShip sich an die Entity andockt
     *    (zw. 0 und 1 , 0.5 ist die Mitte )
     *    @see DrawSample
     */
    public void setDoubles(double ds1 , double ds2 , double ds3)
    {
	ds[0].dockPer = ds1; ds[1].dockPer = ds2; ds[2].dockPer = ds3;
    }

    /** Wird beim Uebersetzen nach SQL verwendet.
	Gibt null zurueck , wenn die Entity und die RelShip
	nicht zusammengehoeren . Ansonsten die Klasse , 
	die die Daten (optional ....) enthalten */
    public ERPanelRow checkEntity(Entity e)
    {
	for (int i=0;i<3;i++) {
	    if (e==ent[i]) {
		return eptm.getRow(i);
	    }
	} 
	return null;
    }
    
    /**f�gt die Pks der Starken  Entities in ta ein und ruft  tracePks aus ConvertSqlNew*/
    public void addStrongPk(Table ta,Vector not,int iii)
    {
	addStrongPk(ta,not,0,iii);  
	addStrongPk(ta,not,1,iii);  
	addStrongPk(ta,not,2,iii);  
    }


    private void refStrongPk(int i,ConvertSql conv,String rName,int pos)
    {
	ERPanelRow erp = eptm.getRow(i);
	if (erp==null) return;
	boolean st = erp.getSt().isSelected();
	if (st==true)
	    {
		Entity strong = (Entity) erp.getEntity().getSelectedItem(); 
		int StrPos = strong.parent.Entities.indexOf(strong);
    
		Table str = conv.getTable(StrPos);
    
		if (str==null) {System.out.println("B�ser Fehler  : Tabelle " + str + " nicht vorhanden (relship.java:ads[0])");
		return;} 
    
		refWeakPk(0,conv,strong,StrPos,str,rName,pos); refWeakPk(2,conv,strong,StrPos,str,rName,pos); 
		refWeakPk(1,conv,strong,StrPos,str,rName,pos); 
    
	    }    
   
    }

    private void refWeakPk(int i,ConvertSql conv,Entity strong,int strPos,Table str,String rName,int pos)
    {
	ERPanelRow erp = eptm.getRow(i);
	if (erp==null) return;
	boolean we = erp.getWe().isSelected();
	if (we==true)
	    {
		Entity weak = (Entity) erp.getEntity().getSelectedItem(); 
		int wePos = weak.parent.Entities.indexOf(weak);
    
		Table wk = conv.getTable(wePos);
    
		if (str==null) {System.out.println("B�ser Fehler  : Tabelle " + str + " nicht gefunden (relship.java)");
		return;} 
		wk.addFkIf(strPos,str); 
    
	    }    
    }
    
    private boolean checkMany(int i)
    {
	ERPanelRow erp = eptm.getRow(i);
	if (erp==null) return false;
 
	return erp.getMa().isSelected();
 
    }

/**true , wenn mindestens ein Ast der Relship mehrwertig /N ist */
    public boolean checkMany() {
	return checkMany(0) || checkMany(1) || checkMany(2);
    }
    
/**Sucht starke Entities zu dieser RelShip, und referenziert alle PKs in ta , die auch pk in den
 * starken Entities sind als ForeignKey*/
    public void refStrongEnts(ConvertSql conv,String rName,int cx) {
	refStrongPk(0,conv,rName,cx);  
	refStrongPk(1,conv,rName,cx);  
	refStrongPk(2,conv,rName,cx);  
    }

/** erledigt die Arbeit von addStrongPk f�r die ERpanelRows i=0..2*/
    private void addStrongPk(Table ta,Vector not,int i,int iii) {
	ERPanelRow erp = eptm.getRow(i);
	if (erp==null) return;
	boolean st = erp.getSt().isSelected();
	if (st==true)
	    {
		Entity strong = (Entity) erp.getEntity().getSelectedItem(); 
		//System.out.println("Strong Entity " + strong + " found"); 
		if (not.contains(strong)) return;
		ConvertSql.addPKs(ta,strong,iii);
		ConvertSql.tracePKs(ta,iii,strong,not);
  
	    }
    }
/**gibt den Typ der Relship zur�ck :
   2 : bin�r 
   3 : tern�r
   1 : ?? gibts doch eigentlich nicht 
   0 : ?? */ 
    public int getNumOfEnts()
    {
	int i = 0;
	if (ent[0]!=null) i++;
	if (ent[1]!=null) i++;
	if (ent[2]!=null) i++;
	return i;
    }
/**gibt zur�ck wieviele Zweige der Relship optional sind 
 */ 
    public int getNumOfOpts() {
	int i = 0;
	for (int j=0;j<3;j++) {
	    if (ent[j]!=null) {
		ERPanelRow erp = eptm.getRow(j);
		if (erp.getOp().isSelected()) i++;
	    }
	}
	return i;
    }

    /**gibt zur�ck, ob alle Entities die nicht null sind, identisch sind*/
    public boolean isId() {
	boolean ret = true;
	Entity  comp = null;
	// int i = getNumOfEnts();
	for (int i=0;i<3;i++) {
	    if (ent[0]!=null) {
		if (comp != null) ret = (comp==ent[i]);
		comp = ent[i];
	    }
	}
	return ret;
    }

    public void clearEntity(int num) {
	eptm.clearEntity(num);
	int i = 1-num;
	if (ent[i] != null) ent[i].removeDrawSample(ds[i]);
	ent[i] = null;
	for (int j=0;j<3;j++) {
	    lin[i][j].setVisible(false);
	    parent.p.remove(lin[i][j]);
	}
    }

} //Class End
