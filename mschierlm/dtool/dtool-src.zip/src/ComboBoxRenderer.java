import java.awt.Component;
import javax.swing.table.TableCellRenderer;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import java.awt.Font;

/** Diese Klasse wird zur Darstellung (nicht zum bearbeiten ! ) von ComboBoxen in Tabellen verwendet.
  * Jedesmal , wenn die Tabelle neu gezeichnet wird (ca 20x / sec) wird fuer jede Zele get..Renderer 
  * aufgerufen , und die Komponente in die Zelle eingefuegt. */
public class ComboBoxRenderer extends JComboBox implements TableCellRenderer
{
   
   /**public ComboBoxRenderer()
   { 
      super();
   }*/

   

/** liefert die Komponente , die in die Tabelle gezeichnet wird */
public Component getTableCellRendererComponent(JTable jt,Object value,boolean isSelected,
            boolean hasFocus, int row , int column)

    {   if (value instanceof DefaultComboBoxModel)
        {  
            setFont(new Font("Helvetica", Font.PLAIN, 10));
              
           DefaultComboBoxModel cbm = (DefaultComboBoxModel) value;
           
           Object ccc =  cbm.getSelectedItem();
           setModel(cbm);
          
           setSelectedItem(ccc);
         }


     return this;
    }


}
