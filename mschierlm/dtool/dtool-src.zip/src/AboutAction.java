import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/** fuegt neuen JInternalFrame zum Bearbeiten von Textdateien ein */
public class AboutAction implements ActionListener
{  
   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */
private Start parent;


   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
public AboutAction(Start p)
   {   parent = p;
   }


  /** Wird ausgefuehrt , wenn jemand auf den Knopf bzw.
    * Menueeintrag zum Anlegen einer neuen Textdatei druekt.
    * Ruft die Methode addTextFrame von Start auf.
    * @see Start */
public void actionPerformed(ActionEvent ae)
   {  parent.About();}


}
