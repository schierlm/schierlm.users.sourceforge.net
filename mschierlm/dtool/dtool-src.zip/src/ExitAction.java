import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;


/** Wenn man einen Button / MenuEintrag ausloest , 
 *  mit dem diese Action verknuepft ist , wird
 *  das Programm beendet
 */
public class ExitAction extends AbstractAction
{ Start parent;

   public ExitAction(Start p)
   {  super("",new ImageIcon("Erframe.gif")); // Dateiname hier wird nicht mehr verwendet ,
      parent = p;                             // nur noch actionPerformed wichtig 

   }

   /** ruft leave in ERFrame */    
   public void actionPerformed(ActionEvent ae)
   {  
      
      parent.leave();
     
   }

}
