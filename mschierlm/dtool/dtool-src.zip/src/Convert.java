
/** Klassen die dieses Interface erfuellen 
  * werden zum Konvertieren verwendet.
  * Das ist deshalb noetig , damit ich all diese
  * Klassen gleich ansprechen kann . */
public interface Convert
{

/** Diese Methode nimmt sich die benoetigten
  * Informationen aus dem ERFrame und wandelt
  * sie in einen String um.(wieauchimmer)
  * Dieser String wird dann von der Methode 
  * <mark> in einen neuen Textframe eingefuegt */
public String convert(ERFrame erf);




}