import javax.swing.*;

/** Gemeinsame Oberklasse von ERFrame und TextFrame. Beinhaltet
 * abstrakte Methoden, die die "�nderungsfunktionen" (Cut, Copy,
 * Paste, Load, Save, ...) abstrahieren.
 * @author Michael Schierl
 */

public abstract class ChangableInternalFrame extends JInternalFrame {

    /** Verweis auf die Klasse Start , die z.B. das ClipBoard bereitstellt */
    public Start parent;

    /** Ob der Inhalt schon veraendert wurde */
    protected boolean changed;

    /** Konstruktor */
    public ChangableInternalFrame(Start parent, String s, boolean b1,
				  boolean b2, boolean b3, boolean b4) {
	super(s,b1,b2,b3,b4);
	this.parent=parent;
    }

    public boolean shouldClose() {
	if (!changed) return true;
	int i = JOptionPane.showOptionDialog
	    (parent, "Fenster  " + getTitle() +"  speichern?","Save?",
	     JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE,
	     null,null,null);
	if (i==0) {  
	    String name = getFileName();
	    if (name.startsWith("noname")) name = parent.SaveDialog();
	    if (name == null) return false;
	    Save(name);
	    return true;
	}
	if (i==1) {   
	    return true;
	}
	return false;
    }

    

    public abstract void Cut();
    public abstract void Copy();
    public abstract void Paste();
    public abstract void Del();
    public abstract void Save(String name);
    public abstract String getFileName();


}
