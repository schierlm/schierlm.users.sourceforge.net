import javax.swing.plaf.ComponentUI;

public abstract class LineUI extends ComponentUI
{


}
