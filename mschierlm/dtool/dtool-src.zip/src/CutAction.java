import java.awt.event.ActionEvent;
import javax.swing.JInternalFrame;
import java.awt.event.ActionListener;

 
/** Diese Klasse ist 100 prozent analog zu
  * CopyAction aufgebaut. Nur das(s) statt 
  * Copy() Cut() aufgerufen wird. 
  * @see CopyAction */
public class CutAction implements ActionListener
{  private Start parent;

   public CutAction(Start p) {  
      parent = p;
   }

   public void actionPerformed(ActionEvent ae) {
       JInternalFrame inf = parent.getActiveFrame();
       if (inf instanceof ChangableInternalFrame) {
	   ((ChangableInternalFrame) inf).Cut();
       }
   }
}
