import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JInternalFrame;


/** Verringert (decrease) den Umfang der Zeichenflaeche
  * (das haessliche Gruene da) 
  * @see ERFrame */
public class DecPanelAction implements ActionListener 
{  

   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */
private Start parent;

   
   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
public DecPanelAction(Start p)
   {  
      parent = p;
   }

   
   /** Wird dann (und hoffentlich nur dann) ausgefuehrt, 
     * wenn jemand(oder auch irgendjemand anders) den
     * Knopf zum Verringern der Groesse der Zeichenflaeche
     * betaetigt hat. Nach Ermitteln des aktiven internen 
     * Rahmens(aka JInternalFrame) wird , nach Identifizierung des
     * selbigen als ERFrame , dessen Methode decPanel ausgefuehrt.
     * Dies fuehrt insbesondere zur Verringerung der Groesse der 
     * Zeichenflaeche des oben angefuehrten ERFrames .
     * @see ERFrame */ 
public void actionPerformed(ActionEvent ae)
   {  JInternalFrame inf = parent.getActiveFrame();
      if (inf instanceof ERFrame)
        { 
          ((ERFrame) inf).decPanel();

        }

     
   }


}
