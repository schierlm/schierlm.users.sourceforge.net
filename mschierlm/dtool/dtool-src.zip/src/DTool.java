import javax.swing.UIManager;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.BorderLayout;
import javax.swing.WindowConstants;


/** Die Klasse enthaelt nur die main Routine der Anwendung. */
public class DTool 
{
 


 /**  Zuerst wird dem UI-Manager mitgeteilt , dass das Programm 
   *    eigene Komponenten verwendet, und welche Klassen fuer diese
   *    Komponenten zustaendig sind . 
   *  ( Zur Zeit werden keine Kommandozeilenparameter verarbeitet. )
   *. Dann wird ein JFrame geoeffnet. Die zugehoerigen Parameter stehen
   *    in der Klasse Variables.
   * Zum Schluss werden Toolbar , Menubar und das Panel Start eingefuegt */
public static void main(String xyz[])
  {  UIManager.put("EntityUI","BasicEntityUI");
     UIManager.put("DiamondUI","BasicDiamondUI");
     UIManager.put("LineUI","BasicLineUI");
     UIManager.put("IsaCenterUI","BasicIsaCenterUI");
     UIManager.put("IsaLineUI","BasicIsaLineUI");
     UIManager.put("MarkRectangleUI","BasicMarkRectangleUI");

      
     UIManager.put("InternalFrameTitlePane.font",new Font("Arial",Font.BOLD,14));
     UIManager.put("CheckBox.font",new Font("Arial",Font.PLAIN,12));
     UIManager.put("CheckBoxMenuItem.font",new Font("Arial",Font.PLAIN,12));
     UIManager.put("ComboBox.font",new Font("Arial",Font.PLAIN,12));
     UIManager.put("EditorPane.font",new Font("Arial",Font.PLAIN,12));
    
//     UIManager.put("InternalFrame.titlefont",new Font("Arial",Font.PLAIN,12));
     UIManager.put("Label.font",new Font("Arial",Font.ITALIC,12));
     UIManager.put("Menu.font",new Font("Arial",Font.PLAIN,12));
         
     UIManager.put("MenuItem.font",new Font("Arial",Font.PLAIN,13));
     
     UIManager.put("Panel.font",new Font("Arial",Font.PLAIN,12));
     UIManager.put("ScrollPane.font",new Font("Arial",Font.PLAIN,12));
    
     UIManager.put("Table.font",new Font("Arial",Font.PLAIN,12));
     UIManager.put("TableHeader.font",new Font("Arial",Font.PLAIN,12));
    
     UIManager.put("TextArea.font",new Font("Arial",Font.PLAIN,12));
     UIManager.put("TextField.font",new Font("Arial",Font.PLAIN,12));
    
     UIManager.put("ToolTip.font",new Font("Arial",Font.PLAIN,12));
//     UIManager.put("TextArea.font",new Font("Arial",Font.PLAIN,12));
    
     JFrame jfr = new JFrame(Variables.AppName);

          // Legt Start an und fuegt den Menu- und Toolbar und die Startklasse ein
     Start s = new Start(jfr);
     jfr.setJMenuBar(s.jmbar);
     jfr.getContentPane().add(s,BorderLayout.CENTER);
     jfr.getContentPane().add(s.jtb,BorderLayout.NORTH);

     // sorgt dafuer , nach Ende der Anwendung System.exit() ausgefuehrt wird 
     jfr.addWindowListener(new BWM(s));
     

          // sorgt dafuer , dass der Rahmen nicht einfach geschlossen wird , wenn
          // jemand auf [X] drueckt  
     jfr.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

          // legt die Groesse des Rahmens fest. 
     jfr.setSize(Variables.StartX,Variables.StartY);
     jfr.setLocation(10,10);
     jfr.setVisible(true);


  }

}
