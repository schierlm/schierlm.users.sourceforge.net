import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.table.*;
import java.util.*;

/** Dialog zum verwalten der Datentypen/domaenen eines ERFrame 
  * enthaelt eine Tabelle und drei Knoepfe : OK , Add , Remove *
  */
public class TypesDlg extends JDialog
{ ERFrame parent;


  /** Tabelle , in der einzigen Spalte stehen Textfelder , in die man den Namen eingeben kann */
  JTable jt1;
   /** hier werden die Daten von jt1 gespeichert */
  TypesTableModel ttm;
 /** der Typesvektor aus ERFrame */
  Vector types; 

 

  /** Konstruktor , der den gesamten Dialog aufbaut */
   public TypesDlg(JFrame st,ERFrame erf,
                       Vector t )

   { super(st,"Datentypen bearbeiten",true);
     parent = erf;
     types=t;
     setSize(300,200);
     
     ttm = new TypesTableModel(types);
     jt1 = new JTable(ttm);
     JScrollPane jsp1 = new JScrollPane(jt1);

     jt1.setVisible(true); jsp1.setVisible(true); jsp1.setSize(200,124);
     jsp1.setLocation(20,10); 
     getContentPane().add(jsp1,BorderLayout.CENTER);

     jt1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);



     JButton OKButton = new JButton("OK");
     OKButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
                 if (jt1.isEditing()) 
                 {
                  TableCellEditor cellEditor = jt1.getCellEditor();           
                  if (cellEditor != null) 
                  {
                      cellEditor.stopCellEditing();
                  }
                 }             

                setVisible(false);
                dispose();
           } } );
     JButton AddButton = new JButton("Add");
     AddButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               String s = "neuer Typ";
               ttm.addRow(s);
           } } );

     JButton RemButton = new JButton("Remove");
     RemButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               int i = jt1.getSelectedRow();
               if (i<0 || i>=ttm.getRowCount()) return;
               

                 if (jt1.isEditing()) 
              {
                  TableCellEditor cellEditor = jt1.getCellEditor();           
                  if (cellEditor != null) 
                  {
                      cellEditor.stopCellEditing();
                  }
              }             

               ttm.removeRow(i);
              
           } } );



   JPanel butP = new JPanel();
   butP.add(OKButton);
   butP.add(AddButton);
   butP.add(RemButton);

   getContentPane().add(butP,BorderLayout.SOUTH);

    setLocationRelativeTo(st);
    setVisible(true);



   }



}



