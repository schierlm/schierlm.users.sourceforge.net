import javax.swing.*;
import java.awt.*;

public class Methods 
{

    /** Berechnet eine gute Position f�r den Diamond 
     * bez�glich dieser 3 Entities */
    public static Point calcMidPoint(Entity[] ents) {
	int xall=30,num = 0;
	int yall= 30;

	for (int i=0;i<3;i++) {
	    if (ents[i]!=null) {
		xall = xall + ents[i].getLocation().x; 
		yall = yall + ents[i].getLocation().y;        
		num++;
	    }
	}

	if (num>1){ xall = xall / num + Variables.EntityX/2;
	yall = yall/num+ Variables.EntityY/2;}

	if (num == 1 ) {
	    xall +=  Variables.EntityX + 100;
	    yall +=  Variables.EntityY/2 ;
	}

	return new Point(xall,yall);
    }

    
    
//    1   
//   /\ 
//  /  \ 
//4 \  /  2
//   \/ 
//   3     
    
    private static int[] getNumbers(Diamond d, Entity e) {
	Point pd = d.getLocation();
	Point pe = e.getLocation();
	Point de = new Point(1,1);
	de.x = e.getSize().width; de.y = e.getSize().height;
	
	int[] i = {1,2,3,4};
	
	
	if (pd.y > pe.y + de.y) i[0] = 1;
	else if ( pd.x > pe.x + de.x || pd.x + Variables.DiamondX < pe.x ) i[0] = 2;
	else  i[0] = 3;
	
	
	if (pd.x + Variables.DiamondX < pe.x) i[1] = 1;
	else if (pd.y > pe.y + de.y || pd.y + Variables.DiamondY < pe.y ) i[1] = 2;
	else i[2] = 3;
	
	if (pd.y + Variables.DiamondY < pe.y ) i[2] = 1;
	else if ( pd.x > pe.x + de.x || pd.x + Variables.DiamondX < pe.x ) i[2] = 2;
	else  i[2] = 3;
	
	if (pd.x > pe.x+ de.x) i[3] = 1;
	else if (pd.y > pe.y + de.y || pd.y + Variables.DiamondY < pe.y ) i[3] = 2;
	else i[3] = 3;
	
//   System.out.println( e + " " + i[0] + " " + i[1] + " " + i[2]+ " " + i[3] );
	return i;
    }

    public static int[] getOnes(int [] i) {
	int [] ii = {9,9};
	int j = 0;
	for(int k = 0; k<4;k++) {
	    if (i[k]==1) { ii[j] = k+1; j++;}
	}
	return ii;
    }


/** */
    public static int[] getOrder(Diamond d , Entity[] es) {
	int [][] ons =new int[3][];
	int[] i = {9,9,9};
	for (int k=0;k<3;k++) {
	    int [] is = {9,9,9,9};
	    if (es[k] != null)   is = getNumbers(d,es[k]);
	    ons[k]=getOnes(is);
	}  

	int block1 = 0;
	int block2 = 0;

//System.out.println( ons[0][0] + " " + ons[0][1] + " | " + ons[1][0] + " " + ons[1][1]  + " | " + ons[2][0] + " " + ons[2][1]);
	if (ons[0][1] == 9 ) {i[0]= ons[0][0];block1=ons[0][0];}

	else {

	    if(blocked(ons[0][0],ons[1],ons[2])) {i[0]= ons[0][1];block1 = ons[0][1];}
	    else {i[0]= ons[0][0];block1 = ons[0][0];}
	}


	if (ons[1][1] == 9 && block1 != ons[1][0]) {i[1]= ons[1][0];block2 = ons[1][0] ;}

	else  {

	    if (blocked2(ons[1][0],block1,ons[2]) && block1 != ons[1][1])  {i[1]= ons[1][1];block2=ons[1][1];}  

	    else if (block1!=ons[1][0]) {i[1]= ons[1][0];block2 = ons[1][0];}
    
	}

	if (block1 != ons[2][0] && block2 != ons[2][0] ) {i[2]= ons[2][0];}

	else if ( block1 != ons[2][1] && block2 != ons[2][1] ) {i[2]= ons[2][1];}
     
//System.out.println( i[0]  + " " + i[1] + " "  +  i[2]);
	return i;
    }

    private static boolean blocked(int num , int [] n1 , int  [] n2) {
	if (num != n1[0] && num != n1[1] && num != n2[0] && num != n2[1] ) return false;

	if (num == n1[0])
	    {
		if (  ((n2[0] != n1[1] ) && (num != n2[0]) ) || //
		      ((n2[1] != n1[1] ) && (num != n2[1]) ) ) return false; else return  true; 

	    }

	if (num == n1[1])
	    {
		if (  ((n2[0] != n1[0] ) && (num != n2[0]) ) || //
		      ((n2[1] != n1[0] ) && (num != n2[1]) ) ) return false; else return  true; 

	    }

	if (num == n2[0])
	    {
		if (  ((n1[0] != n2[1] ) && (num != n1[0]) ) || //
		      ((n1[1] != n2[1] ) && (num != n1[1]) ) ) return false; else return  true; 

	    }

	if (num == n2[1])
	    {
		if (  ((n1[0] != n2[0] ) && (num != n1[0]) ) || //
		      ((n1[1] != n2[0] ) && (num != n1[1]) ) ) return false; else return  true; 

	    }

	System.out.println("Sollte nie erreicht werden in Methods");
	return true;

    }

    private static boolean  blocked2(int num , int block , int [] n1) {
	if (num == block ) return true;
  
	if (num != n1[0]  &&  num != n1[1]) return false;
  
	if (num == n1[0] &&  n1[1] != block) return false;

	if (num == n1[1] &&  n1[0] != block) return false;
  
	return true;
    }

    public static void setNameLabel(ERFrame parent,JLabel NameLabel,int xall,int yall,String name) {
	NameLabel.setText(name); NameLabel.setSize(60,20);
	NameLabel.setVisible(true);
	NameLabel.setLocation(xall+Variables.NameLabelDX-Variables.DiamondX/2,yall+Variables.NameLabelDY-Variables.DiamondY/2);
	parent.p.add(NameLabel,new Integer(3));

    }

    public static boolean isRightClick(java.awt.event.MouseEvent evt) {
	return (((evt.getModifiers() & evt.BUTTON3_MASK) !=0) ||
		((evt.getModifiers() & evt.SHIFT_MASK) != 0));
    }
 
}
