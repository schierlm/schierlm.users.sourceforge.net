import javax.swing.JInternalFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/** oeffnet Dialog zum Editieren der Datentypen des aktiven
  * ER-Modells */
public class AlterTypesAction implements ActionListener
{  


   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */

private Start parent;

  

   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
public AlterTypesAction(Start p)
   { 
      parent = p;
   }


/** wird ausgefuehrt , wenn der Benutzer seinen Willen
  * zum Bearbeiten der Datentypen verkuendet.
  * Ermittelt den aktiven JInternalframe.
  * Wenn es sich bei Selbigem um
  * einen  ERFrame (d.h. kein TextFrame oder null)
  * handelt , wird dessen Methode alterTypes aufgerufen. */  
public void actionPerformed(ActionEvent ae)
   {  JInternalFrame inf = parent.getActiveFrame();
      if (inf instanceof ERFrame)
        { 
          ((ERFrame) inf).alterTypes();
        }
   }


}
