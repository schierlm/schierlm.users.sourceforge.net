import javax.swing.JInternalFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


/** Zum Speichern des aktiven JInternalFrame.
  * Wenn die Datei noch keinen Namen hat oder saveAs wahr ist, wird
  * vorher ein Dialog aufgerufen */
public class SaveAction implements ActionListener
{ 
  /** Verweis auf die Klasse Start */ 
    private Start parent;
    private boolean saveAs;

 /** Der Standardkonstruktor aller Action-Klassen*/
    public SaveAction(Start p) {
	this(p, false);
    }

    /** wenn saveAs == true, wird immer nach einem Dateinamen gefragt */
    public SaveAction(Start p, boolean saveAs) {
	parent = p;
	this.saveAs=saveAs;
    }

 /** Fuehrt je nach Art des aktiven Rahmens einen 
   * Block von Befehlen aus , der zuerst den Namen des
   * Rahmens ermittelt , und dann eine Text- bzw. ER-Speicher-Datei
   * anlegt. Fuer mehr Informationen ueber das Dateiformat :
   * @see ERFileSaver 
   * @see ERFileReader */
    public void actionPerformed(ActionEvent ae) {
	JInternalFrame inf = parent.getActiveFrame();
	if (inf instanceof ChangableInternalFrame) { 
	    
	    ChangableInternalFrame cif = (ChangableInternalFrame) inf;
	    String name = cif.getFileName();
	    if (saveAs || name.startsWith("noname")) {
		name = parent.SaveDialog();
	    }
	    if (name!=null) {// name==null , wenn Dialog gecancelt wurde.
		cif.Save(name);
	    }
	}
   }
}
