import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import javax.swing.DefaultComboBoxModel;
import java.awt.Point;
import java.util.Vector;



/** Diese Klasse enthaelt alle Funktionen zum Speichern eines ERFrame
 *  Eine Instanz dieser Klasse wird von der ERFrame Funktion save angelegt ,
 *  die den Speichervorgang steuert.
 *  @see ERFrame
 *  @see ERFileReader
 *
 * 
 * Dateiformat : 13 8 76 als Datei Identifikator 
                 Anzahl der Entities / RelShips und Isas 
                 Groesse der Zeichenflaeche 


 */                                                                                

public class ERFileSaver
{
    
    private DataOutputStream out;
    private BufferedOutputStream bos;
    private FileOutputStream fos;



 /* Der Konstruktor legt die Streams an und speichert bereits die ersten Daten :
 *  Zuerst werden die Integerwerte 13,08,76 zur Identifikation des Dateiformats
 *  gespeichert . Dann 5 weitere Integer : Die Dimension der Zeichenfl�che und die
 *  Anzahlen der vorhandenen Entities , Relationships und Vererbingen .*/

 public ERFileSaver(String name,int ne , int nr , int ni , int nx , int ny )
 {
  try {
         fos =  new FileOutputStream(name);
         bos =  new BufferedOutputStream(fos);
         out  =  new DataOutputStream(bos);  // jetzt koennen Daten in out geschrieben werden

         // gleich nach dem Anlegen werden die ersten Daten geschrieben :

         out.writeInt(13); 
         out.writeInt(8);
         out.writeInt(76);     // zur Identifikation des Datei Typs

         out.writeInt(nx);
         out.writeInt(ny);   // die Groesse der Zeichenflaeche 
         out.writeInt(ne) ;
         out.writeInt(nr);
         out.writeInt(ni);   // die Anzahlen der Entities , RelShips & ISAs

      }
 
  catch(Exception e) {System.out.println("File Write Exception");}
 }



/** Wird von der Funktion save der Klasse ERFrame gerufen , um eine Entity zu
 *  speichern. Als erstes werden die x und die y Koordinate abgespeichert.
 *  Dann der Name der Entity. (Zuerst die Anzahl der Buchstaben , dann die Chars.
 *  Zum Schlu� wird die Anzahl der Attribute abgelegt , die danach von der Funktion
 *  writeATable gespeichert werden */

  public void writeEntity(Entity e)
  {  
    try
    {
     Point p = e.getLocation();
     out.writeInt(p.x);
     out.writeInt(p.y); // die Position der Entity


     String name = e.getName();
     int nSize = name.length();
     out.writeInt(nSize); 
     out.writeChars(name); // nSize Chars fuer den Namen der Entity


     out.writeInt(e.getSize().height);  // nachtraeglich eingefuegt : die Hoehe und Breite der Entity
     out.writeInt(e.getSize().width);

     AttributTableModel atm = e.getTableModel();

     int nOfRows = atm.getRowCount();
     out.writeInt(nOfRows);        // die Anzahl der Attrinute

     for (int j = 0; j<nOfRows; j++)  
     {
       writeATable(atm,j);    // speiechert jeweils ein Attribut


     }

     

     }
     catch(Exception ee) { System.out.println("Entity Write Exception");}

      return ;

  }


/** Wird am Ende des Speichervorgangs aufgerufen */
  public void closeStream()
  {

    try
     {out.close();}  
    catch (Exception e) {System.err.println("Error closing OutputStream");}

  }




/** Speichert die RelShip r in den aktuellen DataOutputStream out */
  public void writeRelShip(RelShip r)
  {  try {  
       Point p = r.d.getLocation();
       out.writeInt(p.x);
       out.writeInt(p.y);    // die Position der Diamond Komponente

      
        out.writeInt(r.oco);
        out.writeInt(r.ocr);
        out.writeInt(r.ocu);
        out.writeInt(r.ocl);  // vier Hilfsvariablen , die anzeigen wo die Linien andocken
                                     // koennten auch berechnet werden
       String s = r.getName();
       int sSize = s.length();
       out.writeInt(sSize);
       out.writeChars(s);    // der Name der RelShip (sSize chars )

       for (int i=0;i<3;i++) {
	   writeRelPanel(r.ent[i],r.lin[i][0],r.lin[i][1],r.lin[i][2],
			 r.eptm,1+i);
       } // die drei Reihen des ERPanelTableModels

       int nx = r.getNumOfARows();
       out.writeInt(nx);

       for (int i = 0; i<nx;i++) // analog zu writeEntity die Attribute
       {
          writeATable(r.atm,i);
       }
       

             out.writeDouble(r.ds[0].dockPer);
             out.writeDouble(r.ds[1].dockPer);
             out.writeDouble(r.ds[2].dockPer);  // nachtraeglich einefuegt , seit man Linien relativ
                                            //zur Entity verschieben kann , 0 links/oben 
                                            // ganz rechts/unten (wenn ich mich richtig erinnere)
      }
       catch (Exception e) { System.out.println("RelShip Save Exception");}
  }



/** speichert eine Zeile des ERPanelTableModels , wird von writeRelSip gerufen */
private void writeRelPanel(Entity ent,Line l1,Line l2,Line l3,ERPanelTableModel eptm,int num)
{   try {
     int n = eptm.getEntityNum(num);
     out.writeInt(n); // die Entity auf die verwiesen wird , wird als Nummer gespeichert
                      // die Nummer bezieht sich auf die Position der Entity im Entity Vector
                      // das geht , da die Entities vorher geladen/speichert werden  

     out.writeBoolean(eptm.isOptional(num));
     out.writeBoolean(eptm.isMany(num));
     out.writeBoolean(eptm.isWeak(num));
     out.writeBoolean(eptm.isStrong(num));  // 4 booleans , 

     writeLine(l1);
     writeLine(l2);
     writeLine(l3);   // writeLine speichert die Daten der Linienzuege auf der Zeichenflaeche
                      //damit koennen sie beim Laden exakt gleich gezeichnet werden
     }
     catch (Exception e) { System.out.println("RelPanelWrite Exception");}
}

/** Speichert eine Reihe eines AttributTableModels , wird von writeEntity bzw. writeRelShip gerufen
 * @see AttributTableModel , AttributRowModel */
private void writeATable(AttributTableModel atm,int j)
    {
       try {

         AttributRowModel arm = atm.getRowAt(j);
         String s = arm.getName();
         int size = s.length();
         out.writeInt(size);
         out.writeChars(s);   // der Name des Attributs

         DefaultComboBoxModel dcm = arm.getDomain();
         Object o = dcm.getSelectedItem();
         int d = dcm.getIndexOf(o); // der Datentyp wird als Integer gespeichert
               out.writeInt(d);     // die Nummer verweist auf einen Entrag im DatenVektor

         if (d==-1)
         {  String str = (String) o;
            int sss = str.length();
            out.writeInt(sss);
            out.writeChars(str);    // alternativ koennte man hiermit den ganzen Namen speichern
         }                          // kommt nicht vor , da man den DatenTyp nur ueber den Vektor aendern kann

           out.writeBoolean(arm.getPk().isSelected() );
           out.writeBoolean(arm.getUn().isSelected() );
           out.writeBoolean(arm.getMw().isSelected() );
           out.writeBoolean(arm.getOp().isSelected() ); // die ueblichen booleans

     }

  catch (Exception e) { System.out.println("ATable Write Exception");}
}

/** Speichert die Attribute einer Linie
 * @see Line */
private void writeLine(Line l)
{  try
   {
     Point p = l.getLocation();
     out.writeInt(p.x);
     out.writeInt(p.y);              // position
     out.writeInt(l.length);         // laenge
     out.writeBoolean(l.waagrecht);  // waagrecht oder senkrecht
     out.writeBoolean(l.connection); // 
     out.writeBoolean(l.direction);  // 


   }
   catch (Exception e) { System.out.println("LineWrite Exception" + l);}


}

/** Speichert eine Generalisierung(aka Vererbung) */
public void writeIsa(ISA i,Vector ent)
{
    try
    { 

       out.writeBoolean(i.getX());           //disjunkt ?
       
       FakeComboBoxModel dcm = i.dcm;      
       Object o = dcm.getSelectedItem();
       int d = dcm.getIndexOf(o);
       out.writeInt(d);             // die SuperEntity (wieder als Integerverweis auf den EntityVektor)
       
       out.writeDouble(i.supr.dockPer);  // analog zu writeRelShip

       Point p = i.isc.getLocation();
       out.writeInt(p.x);
       out.writeInt(p.y);             // die Position der DiamondKomponete

        Vector v = new Vector(); 
        i.itm.getVector(v,o);

       int n = v.size();
       out.writeInt(n);            // die Anzahl der SubEntities

      

       
      for(int j = 0;j<n;j++)
      {  IsaLine isaline = (IsaLine) i.lines.elementAt(j);
         out.writeDouble(isaline.dockPer);      // wo an die Entity <<angedockt>> wird
         Entity e = (Entity) v.elementAt(j);    
         int nn = ent.indexOf(e);
         out.writeInt(nn);                 // der int Verweis auf den Entity Vektor

      }
         
       
   }
   catch (Exception e) {System.out.println("Isa write Exception");}
}

/**Speichert die verwendeten DatenTypen aus dem types vektor  */
public void writeTypes(Vector v)
{
try {
  int s = v.size();
  out.writeInt(s);  //  die Anzahl der Datentypen

  for(int i = 0; i<s ; i++)
  { 
    String str = ((StringWrapper) v.elementAt(i)).toString();
    int size = str.length(); 
    out.writeInt(size);
    out.writeChars(str);    // wie ueblich zuerst der integer und dann size chars
  }

} catch (Exception e) {System.out.println("Writing Types Exception");}

}

} //Class END




