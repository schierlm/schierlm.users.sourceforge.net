import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;


/** das dynamische TableModel zu IsaTable , die im IsaDialog verwendet wird .
    Hier werden nur die SubEntities gespeichert */
public class ISATableModel extends AbstractTableModel
{    
     /** Der Vector mit den SubEntities */
     protected Vector data = new Vector();

     /** Vector mit allen selektierten Objekten (jedes hoechstens 1mal) */
     public Vector select = new Vector();

     String [] headers = {"Entity"};
     Class [] columnClasses = {DefaultComboBoxModel.class };


     /** klont this 
       * @param v der Vector , der alle Entities enth�lt aus ERFrame */
     
      public ISATableModel klone(Vector v)
      {
          int r = getRowCount();
         ISATableModel isa = new ISATableModel();

          for (int i = 0; i<r;i++)
          { 
            DefaultComboBoxModel dfm = (DefaultComboBoxModel) data.elementAt(i);
          
            DefaultComboBoxModel newdfm = new DefaultComboBoxModel(v);
            newdfm.setSelectedItem(dfm.getSelectedItem());
            isa.addRow(dfm);
                

          }     

           return isa;
      }


      /** die Groesse des DatenVektors */
      public int getRowCount() { return data.size();}

     /** es gibt nur eine Spalte */
      public int getColumnCount() { return 1;}

     /** Gibt den in Spalte c (1) gespeicherten Datentyp zurueck */
      public Class getColumnClass(int c)
      { return columnClasses[c];}

      /** Die Ueberschrift von Spalte c */
      public String getColumnName(int c) { return headers[c];}

     /** Alle Zellen sind immer editierbar  */
      public boolean isCellEditable(int r , int c )
      { 
         return true;        
      }

  
      /** Das Objekt in Zeile r wird zurueckgegeben (c immer 1 ) */
      public Object getValueAt(int r  , int c)
      {  return  data.elementAt(r);
      }



       /** Das Objekt in Zeile r wird auf value gesetzt */
      public void setValueAt(Object value,int r , int c)
      { 
         
          DefaultComboBoxModel dcm = (DefaultComboBoxModel) value;
         data.setElementAt(dcm,r);       
         fireTableDataChanged();
         
         
      }


  /** f�gt eine neue Reihe am Ende der Tabelle ein */
      public void addRow(DefaultComboBoxModel dcm)
      {  
           data.addElement(dcm);
           fireTableDataChanged();
      }


     /** wie getValueAt */
      public DefaultComboBoxModel getRowAt(int i)
      {
          return (DefaultComboBoxModel) data.elementAt(i);

      }
   
   
  /** l�scht eine Reihe */
  public void removeRow(int i)
      {
           data.removeElementAt(i);
           fireTableDataChanged();
      }

   /** gibt alle Subentities zur�ck 
    * @param v  Dieser Vector wird zur�ckgesetzt und neu gef�llt */
  public void getVector(Vector v,Object supr)
      { int i = getRowCount(); 
        v.removeAllElements();
        
        for (int j=0;j<i;j++)
        { 
          DefaultComboBoxModel dcm = (DefaultComboBoxModel) data.elementAt(j); 
          Object o = dcm.getSelectedItem();
          if (o instanceof Entity && !(v.contains(o))) v.addElement(o);
            
        }  

     }


/** loescht alle ungueltigen und unnoetigen Eintraege */
public void makeproper(Object supr)
{
  Vector tmp = new Vector();
  int i = getRowCount(); 
 
  for (int j=i-1;j>=0;j--)
        { 
          DefaultComboBoxModel dcm = (DefaultComboBoxModel) data.elementAt(j); 
          Object o = dcm.getSelectedItem();
          if (o==supr  || tmp.contains(o)) removeRow(j);

          tmp.addElement(o);
            
        }  




}

}
