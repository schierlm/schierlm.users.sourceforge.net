import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JInternalFrame;


/** Analog zu DecPanelAction 
  * @see DecPanelAction */

public class IncPanelAction implements ActionListener
{  private Start parent;

   public IncPanelAction(Start p)
   {  
      parent = p;

   }

   public void actionPerformed(ActionEvent ae)
   {  JInternalFrame inf = parent.getActiveFrame();
      if (inf instanceof ERFrame)
        { ERFrame ef = (ERFrame) inf;
          ef.incPanel();

        }

     
   }


}
