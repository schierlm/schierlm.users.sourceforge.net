import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.border.*;


/** hier stehen paint() und mouse routinen fuer die Komponente IsaCenter drin 
  * die mouse routinen sorgen analog zu den anderen UI Delegates dafuer , dass
  * die Komponente verschoben werden kann. 
  * paint zeichnet sie 
 */
public class BasicIsaCenterUI extends IsaCenterUI implements MouseListener,MouseMotionListener
{   private boolean pressed=false;
    int x,y;



/** legt eine neue Instanz dieser Klasse an */
public static ComponentUI createUI(JComponent c)
    { return new BasicIsaCenterUI();}



    /** installiert die MausListener */
public void installUI(JComponent c)
    { IsaCenter d = (IsaCenter) c;
      d.addMouseListener(this);
      d.addMouseMotionListener(this);
    }


   /** deinstalliert die MausListener */
public void uninstallUI(JComponent c)
    { IsaCenter d = (IsaCenter) c;
      d.removeMouseListener(this);
      d.removeMouseMotionListener(this);
    }



/** zeichnet die Komponente */
public void paint(Graphics g,JComponent c)
    { 
         IsaCenter i = (IsaCenter) c;
         g.setColor(Variables.EntityBackGround);
         g.fillArc(0,0,Variables.IsaCenterX,Variables.IsaCenterY,0,180);   // ein Halbkreis

         if (i.isMarked()) g.setColor(Variables.markColor);
         else g.setColor(Color.black);
     
         g.drawArc(0,0,Variables.IsaCenterX,Variables.IsaCenterY,0,180);
         g.drawLine(0,Variables.IsaCenterY/2,Variables.IsaCenterX,Variables.IsaCenterY/2); //der Rand

      
         if (i.parent.getX())    //  x fuer disjunkt
         {
g.drawLine(7*Variables.IsaCenterX/16,Variables.IsaCenterY/4,9*Variables.IsaCenterX/16,3*Variables.IsaCenterY/8);
g.drawLine(7*Variables.IsaCenterX/16,3*Variables.IsaCenterY/8,9*Variables.IsaCenterX/16,Variables.IsaCenterY/4);
}

}


/** Speichert den Punkt auf den geklickt wurde zum Verschieben */
    public void mousePressed(MouseEvent e)
    {   x = e.getX();
        y = e.getY();
        IsaCenter d = (IsaCenter) e.getComponent();
        d.pressed = true;
    }


 /** Rauemt am Ende des Verschiebens auf */
    public void mouseReleased(MouseEvent e)
    {
      IsaCenter d = (IsaCenter) e.getComponent();
      d.pressed = false;
    }

/**leer */
    public void mouseEntered(MouseEvent e)
    {
    }
/** leer */
    public void mouseExited(MouseEvent e)
    {
    }


    /** auf MausClick wird Dialog geoeffnet */
    public void mouseClicked(MouseEvent e)
    { IsaCenter d = (IsaCenter) e.getComponent();
      d.parent.openDialog();
         
    }

    /** zum hin und auch zum herschieben der Komponente  */
    public void mouseDragged(MouseEvent e)
    {  int nx = e.getX();
       int ny = e.getY();
       IsaCenter d =(IsaCenter) e.getComponent();
       nx = nx - x;
       ny = ny - y;

       Point p = d.getLocation();
       
       if (p.x + nx > -Variables.DiamondX/2 && p.y + ny > -Variables.DiamondY/4 )  
            d.setLocation(p.x+nx,p.y+ny);
      
       
       d.parent.repaintAllLines();
      
    }

/** leer */
    public void mouseMoved(MouseEvent e)
    {
    }


}
