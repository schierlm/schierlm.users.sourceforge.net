import java.awt.LayoutManager;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;


/** Diesen Manager verwende ich als Ersatz fuer 
  * null (setLayout(null)) . Damit kann ich JScrollPanes verwenden,
  * die auf Informationen des LayoutManagers angewiesen sind.
  * Diese Klasse kann nur Container verwalten , die
  * das Inteface JspLayout erfuellen */
public class JspLManager implements LayoutManager
{ private JspLayout parent;

 /** Konstruktor , setzt nur einen Verweis auf JspLayout. Da ERFrame die einzige Klasse
  *  ist , die JspLayout implementiert also eigentlich auf den ERFrame   */
  public JspLManager(JspLayout l)
  { parent = l;}

 /** leer */
 public void addLayoutComponent(String s , Component c)
  {}

 /** leer */
  public void removeLayoutComponent(Component c )
  {}

 /** leer */
  public void layoutContainer(Container c)
  {}

/** gibt die Aktuelle Groesse der JLayeredPane wieder */
  public Dimension preferredLayoutSize(Container c)
  {  return parent.getS(); // diese Methode wird in JspLayout festgelegt 
                           // ihr return Wert wird an die ScrollPane weitergegeben
  }

/** gibt die Aktuelle Groesse der JLayeredPane wieder */
  public Dimension minimumLayoutSize(Container c)
  {
     return parent.getS(); 
  }
}
 