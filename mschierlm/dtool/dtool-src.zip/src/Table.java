import java.util.*;


/** Beim Konvertieren nach SQL  wird zuerst
  * jede Entity bzw. RelShip in eine Tabelle umgewandelt.
  * Danach wird aus allen Tabellen der Text (create Table...) generiert
  * Sun Jul 16 21:51:02 2000
  */
public class Table
{
   /** eine Reihe entspricht einer Befehlszeile im create Table statement
     z.B. name string primary key references Otto
   */
  public Vector Rows;
  
  /** Enth�lt Fehlermeldungen zu dieser Tabelle*/
  public String errors = "";
  


  /** Die Position der Entity bzw. Relship zu der diese Tabelle geh�rt im
      Entity bzw. Relship Vektor von ERFrame und von ConvertSql . Identifiziert 
      die Tabelle eindeutig.( z.B. bei Foreign Keys)
   */
  public int Position;
  
  /**link auf die ConvertSql Klasse , von der diese Tabelle angelegt wurde*/
  public ConvertSql parent;
  
  
  /** Gibt an ob die Tabelle zu einer RelationShip oder zu einer Entity geh�rt
      (true wenn relship)
   */
  public boolean relship;
  
  /**Die Anzahl der Primary Keys in dieser Tabelle */
  public int pKey=0;

  /**Der Name der  Tabelle*/
  public String Name;

  private int uniq=0;
  

  /** init. den Vector*/
  public Table(ConvertSql par,String name,boolean rel,int pos)
  { Name = name;relship=rel;Position = pos;
    Rows = new Vector(); parent = par;
  }


  /** Hilfsvar f�r addRow. 
    * wenn true befinden wir uns in einem rekursiven Aufruf von addRow*/
  private boolean dplt=false;

  /** fuegt r in den Vector Rows ein, und gibt den evt. ge�nderten Namen der Reihe zur�ck*/
  public String addRow(TableRow r,int from)
  { 
    String na = r.getName();

    boolean doppelt = checkRows(na);
    if (dplt==false) r.realName = na;

    if (doppelt)
    { dplt = true;
      r.Name = na  + uniq;
      uniq ++;
      //System.out.println("Returning doppelt " + r.Name + " Table : " + Name);
      String sa = addRow(r,from);
      dplt = false;
      return sa;
    }

    if (r.isPk()) pKey++;
    Rows.addElement(r);

    r.parent = this;
    r.fromTable = from;
    
    if (dplt) 
    {
     //System.out.println("Returning dplt " + r.Name + " Table : " + Name);
     return r.Name;
    } 
    else {//System.out.println("Returning empty " + " Table : " + Name);
           return r.Name; }
  }
  
  /*�berpr�ft, ob qq schon ein AttributName in dieser Tabelle ist
    langsam implementiert , vielleicht hashen??
   **/
  public boolean checkRows(String qq)
  {
   int k = getRowCount();
   for (int l=0;l<k;l++)
   {
    TableRow tr = (TableRow) Rows.elementAt(l);    
    if (qq.equals(tr.getName())) return true;
   }
   return false;
  }
  
  /**inline , bitte !!!!!!!!!!*/
  public int getRowCount()
  {
   return Rows.size();
  }
  
  /** --- */
  public TableRow getRowAt(int j)
  {
    int i = Rows.size();
    if (j>=i) return null;
    
    TableRow tr = (TableRow) Rows.elementAt(j);
    return tr;  
  }



  /** toString ohne delayed foreign keys (zum debuggen)*/
  public String toString()
  {
    Hashtable htab = null; Vector a = null;
    return toString(htab,a);
  }


  /** generiert den SQL create Table Befehl zu dieser Tabelle
    * Die beiden Argumente werden an den toString Befehl von TableRow weitergegeben
    * @see TableRow
    */

  public String toString(Hashtable ht,Vector aaa)
  {
    boolean doPk = false;
  
    if(pKey == 0)
    { 
      addError("Tabelle "+ Name+ " ohne Primary Key (redundante Fehlermeldung)"); 
      doPk = true;
    }

    if (pKey ==1)
    {
     doPk = true;
    }
    
    if (pKey > 1)
    {
      doPk = false;
    }
    
    
    String s = "CREATE TABLE " + Name + " (\n";
    String prk = "PRIMARY KEY (";
    
    int i = Rows.size();
    
    for  (int j=0;j<i;j++)
    {
      TableRow tr = (TableRow) Rows.elementAt(j);
      s = s + tr.toString(ht,getName(),aaa,doPk);          
      if (doPk==false && tr.pk==true) prk=prk + tr.getName() + ",";  
      
    }
    
    
    if (pKey > 1)
    {
      prk = prk.substring(0,prk.length()-1);
      prk = prk + "),\n";
      s = s + prk;
    } 
    
    String s1 = s.substring(0,s.length()-2);
    return s1 + "\n);\n\n";
  }

  /** legt fest , da� das Attribut mit Namen s aus Tabelle tt e refernziert
   * Zum Mitschreiben : Wenn es in dieser Tabelle (this) ein Attribut namens s gibt,
   * das aus tt �bernommen wurde, dann referenziert es ab sofort die Tabelle e (als foreign key)
   */
  public void addFk(String s,/*Entity*/int e,int tt)
  { boolean done=false;
  
    int i = Rows.size();
    for  (int j=0;j<i;j++)
    { // if (e==0) System.out.println(" e ist 0 (1)");
       TableRow tr = (TableRow) Rows.elementAt(j);
       String qq = tr.realName;
//        System.out.println("Table ::: " + e + " " + s + " " + qq + "  " + tt + " " + tr.fromTable);
       if (qq.equals(s) || tt==tr.fromTable)
       {
         if (done==true) {System.out.println("ERROR Table.java , Attribute mit gleichem Namen "+s+ " in " + Name +"\n"); break;}
         done = true;
	 tr.addFk(e);
       }
    }
    
    
    
    if (done==false) {System.out.println("ERROR Table.java , Attribut Namen "+s+"in " + Name +"nicht gefunden\n");}
  }

  /** legt fest da� alle PrimaryKey Rows e referenzieren*/
  public void addFk(/*Entity*/int e)
  { //if (e==0) System.out.println(" e ist 0 (2)");
     int i = Rows.size();
    
    for  (int j=0;j<i;j++)
    {
       TableRow tr = (TableRow) Rows.elementAt(j);
       tr.addFkeyIfPk(e);
    }
  }
 
  
  
  /** Pr�ft , ob ein Attribut mit Namen s in this vorkommt*/
  public boolean contains(String s)
  {
   int i = Rows.size();
    
    for  (int j=0;j<i;j++)
    {
       TableRow tr = (TableRow) Rows.elementAt(j);
       if (s.equals(tr.Name)) return true;
    }
     return false;
  }
 
 
  
 /** legt fest da� alle PrimaryKey Rows e referenzieren, falls diese  Reihe auch in ta vorkommt*/
  public void addFkIf(/**Entity*/int e,Table ta)
  {   //if (e==0) System.out.println(" e ist 0 (3)");
     int i = Rows.size();
    
    for  (int j=0;j<i;j++)
    {
       TableRow tr = (TableRow) Rows.elementAt(j);
       if (ta==null) {System.out.println("ta ist null");return;}
//       System.out.println("Confirm " + e + " to " + Name +  " bec " + tr.Name + " is in " + ta.getName()); 
       boolean b = ta.contains(tr.Name);
       if (b==false) continue;
       tr.addFkeyIfPk(e);
    }
  }
  
  /**um einen Fehler auszugleichen : e wird ignoriert , stattdesen rName verwendet */
  //public void addFkIf(Entity e,Table ta,String rName)
 
 /**Schreibt den DDL Befehl zu dieser Tabelle nach stdout*/ 
 public void dump()
 {
   System.out.println(this);
 
 }

 public String print(Hashtable ht,Vector alts)
 { selfCheck();
   return errors + "\n" + toString(ht,alts);
 }

/**Liefert alle TableRows  die PK sind zur�ck */
 public Vector getPk()
 {  Vector ret = new Vector();
    int i = Rows.size();
    
    for  (int j=0;j<i;j++)
    {
       TableRow tr = (TableRow) Rows.elementAt(j);
       if (tr.isPk())  ret.addElement(tr);
    }
  return ret;
 }

 public  void  setName(String s)
 {
   Name = s;
 }

 public  String  getName()
 {
   return Name;
 }

 /**Legt irgendwie fest, da� ein Attribut in einem Bestimmten Bereich liegen mu�.
  * (Die extreme Sinnleere des letzten Satzes liegt darin begr�ndet, da� ich im Augenblick der 
  *  Entstehung desselbigen keine Ahnung hatte, wie das [gG]anze funktioniert. Hat aber
  *  irgendwas mit Check ptyp in ... bei disj. Vererbungen zu tun.)
  */
 public void addCheck(String nam,String che,int ref)
 {
   TableRow tr = new TableRow(nam,Variables.StringType,true,false,false);
   if (!che.equals("")) tr.addCheck(che);
   if (ref!=-1) tr.addFk(ref);
   if (che.equals("")) tr.addCheck("'" + Name  + "'");
   addRow(tr,-1);
 }
 
 /**f�hrt einige Tests durch, ob die Tabelle korrekt ist */
 public void selfCheck()
 { if (Name.equals("") || Name.equals(" ")) addError("Tabelle ohne Namen");
   
   String s = CheckString(Name);
   if (!s.equals("")) addError("Der Tabellenname enth�lt die illegalen Zeichen "+ s);
   boolean pk= false;
   int i = Rows.size();
   for (int j=0;j<i;j++)
   {
     TableRow tr =  getRowAt(j);
     if (tr.pk==true) pk = true;    
     tr.getErrors();
       
   }
   if(getRowCount()==0) addError("Tabelle " + getName() + " ohne Attribute");
   if (pk==false) addError("Tabelle " + getName() + " ohne Primary Key");
 }

/**Alle Pks in this die auch in e sind werden not not null gesetzt*/
 public void setNotNotNull(Table ta)
 {
     int i = Rows.size();
    
    for  (int j=0;j<i;j++)
    {
       TableRow tr = (TableRow) Rows.elementAt(j);
       boolean b = ta.contains(tr.Name);
       if (b==false) continue;
       tr.NotNotNullIfPk();
    }
 }

 /** f�gt eine Fehlermeldung ein
   * Alle Fehlermeldungen werden am Anfang eines create Table Befehls ausgegeben
   */
 public  void addError(String s)
 {
   errors = errors + Variables.Comment + " " + s + "\n";
 }


 /**Ueberpr�ft, ob s illegale Zeichen enth�lt. Falls ja wird ein String mit diesen Zeichen 
    zur�ckgegeben 
    */
 public String CheckString(String s)
 {
  String ret = "";
   boolean b = false;
   String checks = Variables.illegals;
   int l = checks.length();
   for(int j=0;j<l;j++)
   {
    char c = checks.charAt(j);
    if (s.indexOf(c) != -1 ) ret = ret + c;   
   
   }
   return ret;
 }

 /** ruft getTableName in ConvertSql*/
 public String getTableName(int refto)
 {
   return parent.getTableName(refto);
 }

}