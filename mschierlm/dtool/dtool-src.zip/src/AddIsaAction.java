import javax.swing.JInternalFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/** Die Action bewirkt , dass eine Vererbung in den aktiven 
  * ERFrame eingefuegt wird
  * @see ERFrame */
public class AddIsaAction implements ActionListener
{

   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */
private Start parent;

   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
public AddIsaAction(Start p)
   {  parent = p; }



  /** Wird ausgefuehrt , wenn jemand auf den Knopf bzw.
    * Menueeintrag zum Einfuegen einer Vererbung drueckt. */
public void actionPerformed(ActionEvent ae)
   {  JInternalFrame inf = parent.getActiveFrame();
      if (inf instanceof ERFrame)
        { 
          ((ERFrame) inf).addIsa();

        }


   }


}
