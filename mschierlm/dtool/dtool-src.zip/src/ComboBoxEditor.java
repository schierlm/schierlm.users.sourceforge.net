import java.awt.Component;
import javax.swing.table.TableCellEditor;
import javax.swing.JComboBox;
import java.util.Vector;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import java.util.EventObject;
import javax.swing.JTable;
import java.awt.Color;//////////////////
import javax.swing.DefaultComboBoxModel;


/** Um eine JCOmboBox in einer Tabelle verwenden zu koennen ist ein Editor und 
    ein Renderer erforderlich : 
     Beide Klassen enthalten als wichtigste Methode get*Component . Diese liefert dann eine
     passend initialisierte  JComboBox zurueck , die in die Tabelle eingefuegt wird.
   - Der renderer ist einfach gehalten , und kann nur zum Zeichnen , nicht zum Editieren der Box verwendet werden
   - Der editor bietet zusaetzlich Methoden , Aenderungen in der ComboBox an das DatenModel der Tabelle weiterzugeben */

public class ComboBoxEditor extends JComboBox implements TableCellEditor
{
    /** Hier steht ein beliebiger Vektor drin , der zum Anlegen eines neuen ComboBoxModels verwendet wird */
    private Vector v;

    protected transient Vector listeners;
    protected boolean editAble;
    private DefaultComboBoxModel cbm;
    
    /** hier wird gespeichert , welches Objekt am Anfang selektiert war , zum Canceln des editierens */
    private Object oldSelection;

    /** ruft denn zweiten Konstruktor mit null als dritten Parameter */
    public ComboBoxEditor(Vector vv,boolean eable)
    {
     this( vv, eable,null);
     
    }

    
    /**  legt einen neuen Editor an */
    public ComboBoxEditor(Vector vv,boolean eable,Vector dd) 
    {       super();  v = vv;                                

      editAble = eable;
      listeners = new Vector(); 
    }



   /** wird von der Tabelle gerufen , wenn eine ComboBox editiert werden soll */
    public Component getTableCellEditorComponent(JTable jt,Object value,
                                                        boolean isSelected,int row,int column)
    { 
        
      if (value instanceof DefaultComboBoxModel)
      {  cbm = (DefaultComboBoxModel) value;
         Object o = cbm.getSelectedItem(); 
    
    
         setModel(cbm);
         setSelectedItem(o);
         oldSelection = o;
          
      }

       jt.setRowSelectionInterval(row,row);
      
      
      return this;

    }


    /** wird beim Canceln des EditingModes gerufen (keine Ahnung wo genau der 
     * Unterschied zu stop ist */ 
    public void cancelCellEditing()
    { fireEditingCanceled();}


    /** wird am Ende des editierens gerufen , um das DatenModel upzudaten */
    public Object getCellEditorValue()
    { 
         DefaultComboBoxModel dcm = new DefaultComboBoxModel(v);
         Object o =  cbm.getSelectedItem();
       
         dcm.setSelectedItem(o);
       return dcm ;
      
    }


    /** gibt immer true zurueck */
    public boolean isCellEditable(EventObject eo) { return true;}

    /** auch immer true */ 
    public boolean shouldSelectCell(EventObject eo)
    { return true;}


    /** aehnlich wie cancel */
    public boolean stopCellEditing()
    { fireEditingStopped(); return true;}


   public void addCellEditorListener(CellEditorListener cel)
   {
      listeners.addElement(cel);
      
   }

   public void removeCellEditorListener(CellEditorListener cel)
   {  listeners.removeElement(cel);

   }

   protected void fireEditingCanceled()
   {
      ChangeEvent ce = new ChangeEvent(this);
      for (int i = listeners.size();i>=0;i--)
        ( (CellEditorListener) listeners.elementAt(i)).editingCanceled(ce);
   }

   protected void fireEditingStopped()
   {
      ChangeEvent ce = new ChangeEvent(this);
      for (int i = listeners.size()-1 ;i>=0;i--)
        { CellEditorListener cel = (CellEditorListener) listeners.elementAt(i);
          cel.editingStopped(ce);

        }
       
   }


}
