import java.util.*;

/**Zum Konvertieren nach SQL (funktioniert jetzt) : 
 * Die Hauptmethode ist convert(ERFrame). 
 * Sie ruft alle anderen Funktionen auf und gibt dann die 
 * SQL Befehle als String zur�ck. 
 */
public class ConvertSql implements Convert
{ 
  /** Die Create Table Befehle f�r mehrwertige Attribute werden hier zwischengespeichert*/
  private Vector mwPairs = new Vector();

  /** In diesen String werden die Create Table Befehle f�r die mehrwertigen Attribute geschrieben*/
  private String many = "";


  /** Diese Nummer wird an den Namen eines ptyp Attributs (bei disj. Vererbungen) angeh�ngt und
    * dann um 1 erh�ht*/
  private int Num =0;


 /**Generiert Code f�r das Attribut arm2 als mehrwertiges  Attr. der Entity e*/
 private void  mwEntity(AttributRowModel arm2 , /*Entity*/ int e,int r)
 {
  String n;
  Table ta;
  String prk ="";
 
  if (r==-1) ta = getTable(e);else  ta = getTable(r);
  String s1 = "";
  n = ta.getName(); 
  
  if (ta==null) {System.out.println("Tabelle zu HTPair rel=" + r + " ,ent=" + e + " nicht gefunden" );return;}
 

  many = many + "CREATE TABLE mw_" + arm2.getName() + "_" + n + " (\n";
  int i = ta.getRowCount(); 
  
  for(int j=0;j<i;j++)
   {
     TableRow ta1 = ta.getRowAt(j);
    
     if (ta1.pk) 
        {  s1 = s1 +  ta1.Name + " " + ta1.Type + " ";
           s1 = s1 + " NOT NULL REFERENCES " + n + " ,\n";
           prk = prk + ta1.Name  + ",";
        }
   }
   prk = prk + arm2.getName();
   prk = "PRIMARY KEY (" + prk + ")\n";

   many = many + s1 + arm2.getName() + " " + arm2.getDomain().getSelectedItem() + " ";
   many = many + " NOT NULL,\n" + prk + ");\n";


}

/** Startet das Konvertieren der in mwPairs gespeicherten mehrwertigen Attribute*/
public void  createMany()
{
// mwPairs.addElement(new HTPair(e,arm));
  int i = mwPairs.size();
  for(int j=0;j<i;j++)
  {
  
    HTPair htp = (HTPair) mwPairs.elementAt(j);
    int e = htp.ent;
    AttributRowModel arm = htp.arm;
    int r  = htp.r;
    
    mwEntity(arm,e,r);
  
  }
}

  /** Hier werden die Tables zu den Relships gespeichert*/
  public Vector relVec = new Vector();

  /** Hier werden die Tables zu den Entities gespeichert*/
  public Vector entVec = new Vector();


 /** Konvertiert den ERFrame erf nach SQL. Dazu werden die Klassen Table und 
   * TableRow, sowie einige Methoden von RelShip verwendet.
   * Die Konvertierung erfolgt in zwei Schritten : Zuerst wird das Modell in 
   * Tabellen (tables) umgewandelt, in denen Attribute als TableRows gespeichert 
   * werden. Jede TableRow besteht aus Namen,Datentyp,PK,UN,... und Infos �ber
   * checks und foreign keys. Danach werden die Tables,  in den zwei Vektoren
   * entVec und relVec gespeichert.
   * Sie sollen �ber die Methoden getTable(num) und getTableName(num) angesprochen werden.
   * Wenn num>9999 wird in relVec nachgeschaut, sonst in entVec.(d.h. Relships haben Nummern von 10000+)
   * Die Nummer der Tabellen entspricht der Nummer der jeweiligen Objekte in den Entity und RelShip Vektoren
   * in ERFrame. Vorsicht : der EntityVector in ERFrame startet bei 1!!! Deshalb hat entVec ein Dummyelement 
   * an Position 0. 
   * 
   * Am Ende werden die Tables in SQL-DDL-Befehle umgewandelt.
   *
   *
   * Die erste Methode die gerufen wird ist createTables. Sie legt die Tabellen
   * zu den Entities an, speichert mehrwertige Attribute f�r sp�ter und sucht den
   * gesamten "Graphen" nach weiteren Primary Keys (durch Vererbungen oder schwache E.)
   * f�r jede Entity ab.
   *
   * Als n�chstes legt walkOverIsas() die n�tigen foreign keys und checks zu allen
   * Vererbungen an. Dass alle PKs bereits bekannt sind macht die Sache einfacher.
   *
   * Relships() legt die Tabellen zu den Relships an und erledigt auch die foreign keys
   * sowohl in den Entities als auch bei der Relationship selber. Dazu werden Hilfsmethoden
   * aus RelShip verwendet. Schwache Entities werden hier ebenfalls abgehandelt.
   *
   * createMany() legt die Befehle zu den vorher gespeicherten mehrwertigen Attributen an.
   *
   * Danach wird print() gerufen. Die Tables in der Hashtabelle werden in create table 
   * SQL Befehle umgewandelt. Problematische Foreign Keys werden als AlterTable in einem
   * Vector zwischengespeichert. Eventuelle Fehlermeldungen werden dem jeweiligen 
   * Create Table Befehl als Kommentar vorangestellt.
   *
   * Als letztes werden die gespeicherten AlterTables in alter table SQL Befehle umgewandelt.
   * Die gespeicherten SQL Befehle werden dann als String returned.
   */


public String convert(ERFrame erf)
{
    String dumdum = "dummy";
    entVec.addElement(dumdum);
    
    int nr = erf.Rels.size();
    int ne = erf.Entities.size() ;   // Die Anzahlen von Entities , RelShips und ISAs
 
    createTables(erf);
   String s = Variables.Comment +  " Dateiname : " + erf.getFileName() + "\n" + "\n";  // der Name des Modells
   s = s + Variables.Comment +  "*****************************************************\n";

    walkOverIsas(erf.Isa);
    Relships(erf.Rels);
 //Dump();
 createMany();
 s = s + print();
 s = s + AlterTables();
 return s + many; 



}


/**Wenn diese Methode  gerufen wird , sind alle Tabellen aufgebaut und alle  PKeys bekannt.
   Jetzt werden noch die foreign keys nachgetragen und bei disj.Heit eine weiteres Attribut eingef�gt*/
public void walkOverIsas(Vector isas)
{ Table tsup = null;
  int i = isas.size();
  
  for (int  j=0;j<i;j++)
  { 
    String xs = "";
    String checks = "";
    ISA isa = (ISA)  isas.elementAt(j);
    boolean  x = isa.getX();
    if (x) { xs = xs + "ptyp" + Num;Num ++;}
    
    Entity supr = (Entity) isa.dcm.getSelectedItem();
    Vector erEntVec = supr.parent.Entities;
    int iiiSup = erEntVec.indexOf(supr);
     tsup = getTable(iiiSup);
     
     if (tsup==null) System.out.println("Object " + iiiSup + "nicht gefunden (walkOverIsas)");

    Vector subs = isa.subs;
    
    int ss = subs.size();
    
    if (x)  //  die namen aller subentit. sammeln, f�r check in
    {
     for (int k=0;k<ss;k++) 
     {
        Entity en = (Entity) subs.elementAt(k);
	String subcheck = en.getName();
	subcheck = "'" +  subcheck + "'";
	checks = checks + subcheck + ",";
       
     }
     
     checks = checks.substring(0,checks.length()-1); String key = supr.getName();
    
     
     tsup.addCheck(xs,checks,-1);
    }
    
    
    for (int k=0;k<ss;k++)
    {
      Entity en = (Entity) subs.elementAt(k);
      int iiiLow = erEntVec.indexOf(en);
   
      String s = en.getName();
      // Tabelle zu Entity en aus HashTab htab holen
      Table ta = getTable(iiiLow);
      if (ta==null) {System.out.println("Object " + s+ " nicht gefunden (2)   ");} //darf nicht passieren
      else 
      { //System.out.println("Adding Ref to Entity # " + iiiSup + " to Table " + ta.getName() );
        ta.addFkIf(iiiSup,tsup); 
	if (x) ta.addCheck(xs,"",iiiSup);
      }
    }
   /* 
           s2 = "ptyp String NOT NULL CHECK (ptyp in (" +s1+ ")),\n";
   */
  }
}


/** Liefert die mit num numerierte Tabelle zur�ck(Entities 1-9999,Relships > 9999*/
public Table getTable(int num)
{
 if (num<10000) 
 {
   return (Table) entVec.elementAt(num);
 }
 
 if (num>=10000)
 {
  return (Table) relVec.elementAt(num-10000);
 }


 return null;

}

/**Legt alle Tabellen zu den Entities in diesem ERFrame (erf) an und speichert sie in entVec
  * 
 */
public void createTables(ERFrame erf)
{
    int nr = erf.Rels.size();
    int ne = erf.Entities.size();
    
    for(int i=1;i<ne;i++)
    {  
      Entity ent = (Entity) erf.Entities.elementAt(i);
      Table val = CreateTable(ent,i);
      
      entVec.addElement(val);
    }
}

/**
 Legt die Tabellen zu allen RelShips an und f�gt wenn n�tig
 Foreign Keys in andere Entities ein
*/
public void  Relships(Vector r)
{
  int i = r.size();
  for (int z = 0; z<i;z++)
  { 
    RelShip rel = (RelShip) r.elementAt(z);
    String s = rel.getName();
    
    //if  (s.equals(" ")) {s= "ohneNamen" + uniq;uniq++;}
    Table val = new Table(this,s,true,z+10000);
    if (rel.getNumOfEnts()==0) val.addError("Fehler : Relationship ohne Entities");
    if (rel.getNumOfEnts()==1) val.addError("Fehler : Relationship mit nur einer Entity");
    
    relVec.addElement(val);
              
    CreateTable(val,rel,z+10000);
  
  }  

}

/**F�gt die Prim�rschl�ssel aus der Entity aus epr in ta  ein 
 * un gibt an ob 1-Relships als pk oder nur als unique angelegt werden (nur ein Ast ist der Pk,egal welcher
 * wenn allerdings later==true , wird un ignoriert , dann ist ein sp�terer Ast der Relship N /many
 */
public boolean addEptm2Tab(ERPanelRow epr,Table ta,boolean un,boolean later,RelShip r,int pos)
{ String nuName = "";
  boolean b = false;
  Object o =  epr.getEntity().getSelectedItem();
  if (o instanceof String) return b; // dann war statt einer Entity der String "keine" ausgew�hlt
  int num = r.getNumOfEnts();
  int opts = r.getNumOfOpts();
 
  
  String rName = ta.getName();
  
  Entity e = (Entity) o;
  if (e==null) return false;
  Vector erEntVec = e.parent.Entities;
  int iiiEnt = erEntVec.indexOf(e);
  

  Table from = getTable(iiiEnt);
  String ref = e.getName();      
    if (from==null) {System.out.println("Table " + ref + " nicht gefunden (eptm2tab)");return false;}

  boolean many = epr.getMa().isSelected(); // ob dieser Ast many ist
  
  
  int k = from.getRowCount();
  for (int u=0;u<k;u++)
  {
    TableRow trf = from.getRowAt(u);
    if (trf.pk==false) continue;
    
   if (many)
   {
    TableRow ntr = new TableRow(trf.Name,trf.Type,true,true,false);
    ntr.addFk(iiiEnt);    nuName = ta.addRow(ntr,iiiEnt);
    if (num==2) dualStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
    if (num==3) treStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
   }
  //////Warnung setNotNotNull (in treStuff) wird zu oft ausgef�hrt, ist aber glaubich kein Fehler
  ////// evtl nach hinten schieben
   else
   {
     if (later) //dann weder pk noch unique
     {                                              // nn   pk  unique
       TableRow ntr = new TableRow(trf.Name,trf.Type,true,false,false);
       nuName = ta.addRow(ntr,iiiEnt);  
       ntr.addFk(iiiEnt);
       if (num==2) dualStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
       if (num==3) treStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
     }
     else 
     {
      if (un) //unique
      {
       TableRow ntr = new TableRow(trf.Name,trf.Type,true,false,true);
       nuName = ta.addRow(ntr,iiiEnt);
       ntr.addFk(iiiEnt); 
       if (num==2) dualStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
       if (num==3) treStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
       
      }
      else //als pk
      {
       TableRow ntr = new TableRow(trf.Name,trf.Type,true,true,false);
       nuName = ta.addRow(ntr,iiiEnt); ntr.addFk(iiiEnt);   
       b=true;
       if (num==2) dualStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
       if (num==3) treStuff(r,ta,opts,epr,e,rName,pos,nuName,from,trf);
  
      }
     }
  
  
   } 
  }
  

  //Fehler:
  if (num==1) ta.addError("nur ein Ast in dieser Relship (redundante Meldung)");
  
  
 //if weak ....
 if (epr.getWe().isSelected()) 
          r.refStrongEnts(this,rName,pos); 
	 
 return b;
}

/** Hilffunktion, legt die ForeignKeys von den Entities zu einer bin�ren Relship an
  * Wurde ge�ndert, mu� jetzt f�r jeden Primary Key einzelngerufen werden. 
  * Au�erdem ist die H�lfte der �bergebenen Argumente �berfl�ssig. 
  */
private void dualStuff(RelShip r,Table ta,int opts,ERPanelRow epr,Entity e,String  rName,int pos,String nuName,Table from,TableRow trf)
{// System.out.println("dualStuff");
  boolean op  = epr.getOp().isSelected();


  if (opts==0) // dann keine optionale Entity , --> referenz wird angelegt
  {
     trf.addFk(pos,nuName);
  }



  else if (opts==1 && op==true)
  {
    trf.addFk(pos,nuName);
  }



}

// public void settnameAt(int i,String s)
/**Wie dualStuff aber f�r ten�re Relships */
private void treStuff(RelShip r,Table ta,int opts,ERPanelRow epr, Entity e,String  rName,int pos,String nuName,Table from,TableRow trf)
{
  boolean op  = epr.getOp().isSelected();

  if (opts==0) // dann keine optionale Entity , --> referenz wird angelegt
   trf.addFk(pos,nuName);



  if ( (opts==1 && op==true) || (opts==2 && op==true))
    { trf.addFk(pos,nuName);
      //not not null in ta : alle PKs von e 
      ta.setNotNotNull(from);
    }

  if (opts==1 && op==false)   trf.addFk(pos,nuName);

  

}


/** legt die Tabelle zu r an , alle PKs der Entities m�ssen schon bekannt sein */
public Table CreateTable(Table ta,RelShip r,int z)
{ ERPanelRow erp1 = r.eptm.getRow(0);
  ERPanelRow erp2 = r.eptm.getRow(1);
  ERPanelRow erp3 = r.eptm.getRow(2);
  
  
  AttributTableModel attm = r.atm;
  boolean later  = r.checkMany();
  
  boolean uniqe = false;    
 
  uniqe = addEptm2Tab(erp1,ta,uniqe,later,r,z);
  uniqe = addEptm2Tab(erp2,ta,uniqe,later,r,z);
  uniqe = addEptm2Tab(erp3,ta,uniqe,later,r,z);
 
  int i = r.atm.getRowCount();
    
   for(int j=0;j<i;j++)
   {
     AttributRowModel arm = r.atm.getRowAt(j);
     if 
     (arm.getMw().isSelected()) { mwEntity1(arm,z); }     
     else {
           boolean op = arm.getOp().isSelected();
           boolean pk = arm.getPk().isSelected();
           boolean un = arm.getUn().isSelected();
           TableRow tr = new TableRow(arm.Name,(String) ((StringWrapper)arm.Domain.getSelectedItem()).toString(),!op,pk,un);
	   ta.addRow(tr,-1);
          }
    }

 return ta;
 
}

 /** legt die  rudiment�re Tabelle zu e an. Verfolgt  alle  
   *  Vererbungen  und Relships um die PK zu suchen. Aber  noch
   * keine ForeignKeys,usw. da man sonst dauernd �berall nach Prim�rschl�sseln suchen m��te.*/ 
 public Table CreateTable(Entity e,int iii)
 { 
  String ss = e.getName();
 
  Table ta = new Table(this,ss,false,iii);
  AttributTableModel a= e.Attm;
  
  int i = a.getRowCount();
  for(int j=0;j<i;j++)
  {
   AttributRowModel arm = a.getRowAt(j);
     
   if (arm.getMw().isSelected()) { mwEntity1(iii,arm); }     
   else {
         boolean op = arm.getOp().isSelected();
         boolean pk = arm.getPk().isSelected();
         boolean un = arm.getUn().isSelected();
         TableRow tr = new TableRow(arm.Name,(String) ((StringWrapper)arm.Domain.getSelectedItem()).toString(),!op,pk,un);
         ta.addRow(tr,-1);
        }
    }
  tracePKs(ta,iii,e,new Vector()); 

 return ta;
 
}

/**Speichert  mehrwertige Attribute in einen Vektor , f�r sp�ter, wenn alle  PK bekannt  sind*/
public void mwEntity1(int e,AttributRowModel  arm)
{
   mwPairs.addElement(new HTPair(e,arm));
}

/**Speichert  mehrwertige Attribute in einen Vektor , f�r sp�ter, wenn alle  PK bekannt  sind*/
public void mwEntity1(AttributRowModel  arm,int r)
{
   mwPairs.addElement(new HTPair(arm,r));
}

/** durchsucht alle Vererbungen und Relships und fuegt  alle PKs von e in die Tabelle ta, not verhindert Zykel */
public static void tracePKs(Table ta,int iii,Entity e,Vector not)
{ not.addElement(e);
  ERFrame erf = e.parent;
  Vector r = erf.Rels;
  Vector i = erf.Isa;
  int is = i.size();
  int rs = r.size();
  for (int ii=0;ii<is;ii++)
   {
     ISA vererb = (ISA) i.elementAt(ii);
     if (vererb.isSubEntity(e))
     {
      Entity sup = (Entity) vererb.dcm.getSelectedItem();
      if (not.contains(sup)) continue;
      addPKs(ta,sup,iii);
      // pks der Oberentity suchen
      tracePKs(ta,iii,sup,not);
     }
   }
  
  for (int ij=0;ij<rs;ij++)
   {
     RelShip rel = (RelShip) r.elementAt(ij);
     ERPanelRow erp = rel.checkEntity(e);
       if (erp==null) continue;
     boolean weak = erp.getWe().isSelected();
     if(!weak) continue;
     
     rel.addStrongPk(ta,not,iii); //ruft auch tracePks f�r die starken Entities
     
   
   }
  
}


/**f�gt alle Primary Keys von e in ta ein*/
public static void addPKs(Table ta,Entity e,int iii)
{ //System.out.println("addPks from Entity " + e + " to Table " + ta.getName());
   int z = e.Attm.getRowCount();
  for (int i=0;i<z;i++)
  {
    AttributRowModel arm = e.Attm.getRowAt(i);
    boolean pk = arm.getPk().isSelected();
    if (pk) 
    {
      boolean op = arm.getOp().isSelected();
      boolean un = arm.getUn().isSelected();
      TableRow tr = new TableRow(arm.Name,(String) ((StringWrapper)arm.Domain.getSelectedItem()).toString(),!op,pk,un);
      
      ta.addRow(tr,iii);
    }
  }
}



/** Print all tables  in the Hashtable to stdout ,ohne deferred Foreign Keys */
//public void Dump()
//{
 // Enumeration enu = htab.elements();
  //while (enu.hasMoreElements())
  //{
//    Table tab = (Table) enu.nextElement();
//    tab.dump();  
 // }
//}//

/** Hier werden alle Tabellen eingetragen , die  schon als SQL-Befehl vorliegen, 
  * so da� man wei�, welche Foreign Keys sp�ter mit Alter Table nachgereicht werden
  * m�ssen */
public Hashtable AltHt = new  Hashtable();

/**Hier werden die AlterTables gespeichert*/
public Vector alters = new Vector();


/** Gibt einen String �ber alle AlterTables in alters zur�ck*/ 
public String AlterTables()
{ String s = "\n";
  int k = alters.size();
  
  for(int i=0;i<k;i++)
  {
    AlterTable al = (AlterTable) alters.elementAt(i);
    s = s + al + "\n";
  }


  return s;
}


/**Wie Dump , nur nicht nach stdout und Foreign Keys zu Tabellen die erst sp�ter
  * kommen werden mittels AlterTable nachgereicht*/
public String print()
{ String s = "";
  int ne = entVec.size();
  int nr = relVec.size();
    
  for (int j = 1;j<ne;j++)
  {
    Table tab = (Table) entVec.elementAt(j);
    AltHt.put(""+j,""+j);
    s = s + tab.print(AltHt,alters);  
  }

  for (int j = 0;j<nr;j++)
  {
    Table tab = (Table) relVec.elementAt(j);
    AltHt.put(""+ j + 10000,""+j+10000);
    s = s + tab.print(AltHt,alters);  
  }


  
  return s;
}

 /** Es gibt 2 Vektoren , die die Tabellen speichern.
     Wenn tNum < 10000 wird die Tabelle aus entVec genommen und der Name zur�ckgegeben
     Ansonsten wird die Tabelle tNum-10000 aus relVec genommen
 */
 public String getTableName(int tNum)
 {
    if (tNum<10000)
    { if (tNum==0) {System.out.println("tNum was zero");return "was zero";}
      Table ttt = (Table) entVec.elementAt(tNum);
      return ttt.getName();    
    }
 
    if (tNum>=10000)
    {
      Table ttt = (Table) relVec.elementAt(tNum-10000);
      
      return ttt.getName();
    } 
   return "";
 }

}
