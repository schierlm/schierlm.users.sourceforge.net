import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;

/** Diese Klasse wird von der Komponente in ISADlg verwendet , die der Auswahl der Super Entity dient.
  * Am Anfang war das schlicht und einfach eine ComboBox . Nach einigen Problemen wurde daraus eine
  * Tabelle mit einer Zeile und einer Spalte. Deshalb ist das hier jetzt ein TableModel ,dass einige
  * Methoden von ComboBoxModel zur Verfuegung stellt */
public class FakeComboBoxModel extends AbstractTableModel
{    
     /** Hier stehen die Daten drin  */
     public DefaultComboBoxModel data;

    
     

     String [] headers = {""};
     Class [] columnClasses = {DefaultComboBoxModel.class };

       /** Legt ein neues TableModel mit den Daten in d an */
       public FakeComboBoxModel (Vector d)
       { data = new DefaultComboBoxModel(d); }


      /** 1 Reihe */
      public int getRowCount() { return 1;}

     /** 1 Spalte */
      public int getColumnCount() { return 1;}

      /** gibt die Art der Daten an (hier DefaultComboBoxModel */
      public Class getColumnClass(int c)
      { return columnClasses[c];}

      /** Keine Ueberschrift ("") hier */
      public String getColumnName(int c) { return headers[c];}

      /** Die einzige Zelle ist immer editierbar */
      public boolean isCellEditable(int r , int c )
      { 
         return true;        
      }

       /** Gibt das gespeicherte (an 1/1 ) ComboBoxModel zurueck */
      public Object getValueAt(int r  , int c)
      {  return  data;
      }


      /** Setzt das ComboBoxModel auf value */
      public void setValueAt(Object value,int r , int c)
      { 
         data=(DefaultComboBoxModel) value;
         fireTableDataChanged();
         
         
      }

     /** wird an data weitergereicht */
     public void setSelectedItem(Object o)
     { data.setSelectedItem(o);}

     /** wird an data weitergereicht */
     public int getIndexOf(Object o)
     { return data.getIndexOf( o);}

     /** wird an data weitergereicht */
     public Object getSelectedItem()
     { return data.getSelectedItem();}
   
     /** wird an data weitergereicht */
    public Object getElementAt(int i)
    { return data.getElementAt(i);}

}
