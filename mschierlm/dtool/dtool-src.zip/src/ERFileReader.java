import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLayeredPane;
import java.util.Vector;

/** Das Gegenstueck zu ERFileSaver. Fasst alle Methoden , die beim Laden
  * benoetigt werden zusammen. 
 * @see ERFrame , ERFileSaver */
public class ERFileReader
{
    private DataInputStream in;
    private BufferedInputStream bis;
    private FileInputStream fis;  
 
    /** Anzahl der gespeicherten Entities*/
    public int numOfEntities;

        /** Anzahl der gespeicherten RelShips*/
    public int numOfRelShips;
       /** Anzahl der gespeicherten Vererbungen*/
    public int numOfIsas;
    
    
    boolean stop ;
    Vector types;
    ERFrame parent;

 /** Konstruktor der die Streams anlegt , die zum Lesen der
  * Datei name benoetigt werden. Liesst die Anzahl der Entities , RelSHips und
  * Isas aus und schreibt sie in die globalen Variablen.  
  *  v sollte ein Zeiger auf den Typen Vector von ErFrame sein 
  * 
  */
 public ERFileReader(ERFrame erf,String name,Vector v)
 {

  try {  stop = false;
         fis =  new FileInputStream(name);
         bis =  new BufferedInputStream(fis);
         in  =  new DataInputStream(bis);

         int d1 = in.readInt(); 
         int d2 = in.readInt();
         int d3 = in.readInt();

         if ( (d1!=13) || (d2 !=8) || (d3 != 76) ) //hier ueberfluessig , dateityp wird durch 
                                                   // testreader festgestellt
         {  System.out.println("Unknown file");
            stop = true;
         }

         int nx = in.readInt();
         int ny = in.readInt();
         erf.setPanelSize(nx,ny);

         numOfEntities = in.readInt() ;
         numOfRelShips = in.readInt();
         numOfIsas     = in.readInt();

         

         types = v;               parent = erf;
  
      }
 
  catch(Exception e) {System.out.println("File Read Exception");}
 }


  /** Erwartet , dass der Zeiger innerhalb der Datei
    * auf den Anfang einer Entity zeigt.
    * Liesst alle Daten aus , legt eine neue Entity an 
    * und gibt sie zurueck. Danach steht der Zeiger auf
    * der naechsten Entity , oder der ersten RelShip . */
  public Entity readEntity()
  {   AttributTableModel atm;
      String name;

    try
    {
     int x = in.readInt();
     int y = in.readInt();

     int nSize = in.readInt();
      

     name = "";
     for (int i = 1; i<=nSize;i++)
      { name = name  + in.readChar(); }
        
     int eSizeY = in.readInt();
     int eSizeX = in.readInt();
     
     atm = new AttributTableModel();

     int nOfRows = in.readInt();


     for (int j = 1; j<=nOfRows; j++)
     {       AttributRowModel a = readATableRow();
             atm.addRow(a);

     }

       Entity e =  new Entity(parent,types,name,atm,eSizeY,eSizeX);
       e.setLocation(x,y);

       return e;

       

     }
     catch(Exception e) { System.out.println("Entity Read Exception");return null;}



  }

   /** Accessor fuer numOfEntities */
   public int getNumOfEntities()
   { return numOfEntities;
   }
      /** Accessor fuer numOfRelShips */
   public int getNumOfRelShips()
   { return numOfRelShips;
   }

      /** Accessor fuer numOfIsas */
   public int getNumOfIsas()
   { return numOfIsas;
   }

  /** wird am Ende des Ladens aufgerufen, schliesst die Datei  */
  public void closeStream()
  {

    try
     {in.close();}  
    catch (Exception e) {System.err.println("Error closing InputStream");}

  }

   /** liefert den stop zurueck */
  public boolean shouldStop()
   {
      return stop;
   }
  
 

/** Wird von readEntity und readRelShip verwendet um ein Attribut auszulesen */
public AttributRowModel readATableRow()
{  try
   {  int ns = in.readInt();
       String n = "";
       for (int i = 1; i<=ns;i++)
         { n = n  + in.readChar(); 
     
         }


       int domain = in.readInt();
        DefaultComboBoxModel dcm = new DefaultComboBoxModel(types);

     if (domain==-1)
     {
       String str = "";
       int strs = in.readInt();
       for (int i = 1; i<=ns;i++)  { n = n  + in.readChar(); }
       dcm.setSelectedItem(str);    

     }

     else
      { 
       dcm.setSelectedItem(dcm.getElementAt(domain));
      }


       boolean p = in.readBoolean();
       boolean u = in.readBoolean(); 
       boolean m = in.readBoolean();
       boolean o = in.readBoolean();


       AttributRowModel a = new AttributRowModel(n,dcm,p,u,m,o);
       return a;
}
catch (Exception e) { System.out.println("ATableRow Reader Exception");}
return null;

}

/** liesst eine RelShip aus und gibt sie zurueck. In Entities
  * stehen alle Entities die schon geladen wurden. (Alle Entities
  * werden vor den RElShips ausgelesen und angelegt */
public RelShip readRelShip(JLayeredPane p,Vector Entities)
{
  try
  { int x = in.readInt();
    int y = in.readInt();

   

    int oco =  in.readInt();
    int ocr =  in.readInt();
    int ocu =  in.readInt();
    int ocl =  in.readInt();

    int s = in.readInt();
    String n = "";
       for (int i = 1; i<=s;i++)
         { n = n  + in.readChar(); }

   ERPanelTableModel eptm = new ERPanelTableModel();

   RelShip r = new RelShip(parent,Entities,types,x+Variables.DiamondX/2,y+Variables.DiamondY/2,n,oco,ocr,ocu,ocl);

   for (int i = 1; i<=3;i++)
   {
      int ent = in.readInt();
    
      boolean opt = in.readBoolean();
      boolean man = in.readBoolean();
      boolean wea = in.readBoolean();
      boolean str = in.readBoolean();
     DefaultComboBoxModel dfm = new DefaultComboBoxModel(Entities);
     Object o = dfm.getElementAt(ent);
     dfm.setSelectedItem(o);

     ERPanelRow erpr = new ERPanelRow(dfm,opt,man,wea,str);
     eptm.addRow(erpr);

     int px = in.readInt();
     int py = in.readInt();
     int le = in.readInt();
     boolean wr = in.readBoolean();
     boolean conn = in.readBoolean();
     boolean dir = in.readBoolean();
     r.setLine(px,py,le,wr,conn,dir,i,1);

     px = in.readInt();
     py = in.readInt();
     le = in.readInt();
     wr = in.readBoolean();
     conn = in.readBoolean();
     dir = in.readBoolean();
     r.setLine(px,py,le,wr,conn,dir,i,2);

     px = in.readInt();
     py = in.readInt();
     le = in.readInt();
     wr = in.readBoolean();
     conn = in.readBoolean();
     dir = in.readBoolean();
     r.setLine(px,py,le,wr,conn,dir,i,3);


   }
    r.setEptm(eptm);

    int noar = in.readInt();
     for (int j = 1; j<=noar; j++)
     {       AttributRowModel a = readATableRow();
             r.atm.addRow(a);

     }

      double dd1 = in.readDouble();
      double dd2 = in.readDouble(); 
      double dd3 = in.readDouble();
  
 // System.out.println(dd1 + " " + dd2 + " " + dd3);
     r.setDoubles(dd1,dd2,dd3);
      
   return r;

  }

  catch (Exception e) {System.out.println("Relship Read Exception");return null;}
}

/** liest eine Vererbung aus der Datei aus */
public ISA readIsa(JLP p,Vector Entities)
{
    try
    { 
       ISA nnew = new ISA(parent,Entities,1);
       boolean b = in.readBoolean();
       nnew.setX(b);

      
       
       int d = in.readInt();
       Object o = nnew.dcm.getElementAt(d);
       nnew.dcm.setSelectedItem(o);
            nnew.supr.dockPer=in.readDouble();

      
       int px = in.readInt();
       int py = in.readInt();

        nnew.isc.setLocation(px,py);
       

       
       int n = in.readInt();

       Vector dobles = new Vector();
       
      for(int j = 0;j<n;j++)
      {
         
         double ddd = in.readDouble();
         int nn = in.readInt(); dobles.addElement(new Double(ddd));
         DefaultComboBoxModel dfm = new DefaultComboBoxModel(Entities);
         Object o2 = dfm.getElementAt(nn);
         dfm.setSelectedItem(o2);
                  nnew.itm.addRow(dfm); 
         

      }
         nnew.afterLoad(); 

      for(int j=0;j<n;j++)
      {
           ((IsaLine) nnew.lines.elementAt(j)).dockPer= ((Double) dobles.elementAt(j)).doubleValue();


      }
       nnew.paintLines();
       return nnew;
   }
   catch (Exception e) {System.out.println("Isa read Exception");return null;}
}

/**Laedt die verwendeten DatenTypen und schreibt sie in den Vector v.
  * v wird momentan vorher geloescht */
public void readTypes(Vector v)
{
try {
   v.removeAllElements();
 
  int s = in.readInt();

  for(int i = 0; i<s ; i++)
  {
     int ss = in.readInt();
     String str = "";
       for (int j= 1; j<=ss;j++)
         { str = str  + in.readChar(); }

    v.addElement(new StringWrapper(str));
  }

  

} catch (Exception e) {System.out.println("reading Types Exception");}

}




}
