import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import javax.swing.plaf.ComponentUI;
import javax.swing.JComponent;
import java.awt.Color;


/** Verwaltet die Mausereignisse(verschieben bzw. vergroessern) und zeichnet die Entitaet
  * Die Prozedur beim verschieben ist fuer alle UI Delegates 
  */
public class BasicEntityUI extends EntityUI implements MouseListener,MouseMotionListener
{  
    private int x,y,oldx,oldy,nxs,nys; // Hilfsvariablen , vermutlich wird die Haelfte nicht mehr gebraucht 
    private  boolean sizing = false; // true wenn Entity am unteren Rand gedrueckt wurde 
  private  boolean xsizing = false;

   /** legt eine neue Instanz dieser Klasse an */
   public static ComponentUI createUI(JComponent c)
    { return new BasicEntityUI();}


   /** installiert die MausListener */
    public void installUI(JComponent c)
    { Entity e = (Entity) c;
      e.addMouseListener(this);
      e.addMouseMotionListener(this);
    }

 /** deinstalliert die MausListener */
    public void uninstallUI(JComponent c)
    { Entity e = (Entity) c;
      e.removeMouseListener(this);
      e.removeMouseMotionListener(this);


    }


   /** zeichnet den Rahmen der Entity */
    public void paint(Graphics g,JComponent c)
    { Entity e = (Entity) c;
      boolean b = e.isMarked();

      if (b==true) g.setColor(Variables.markColor); // --> markiert 
      else g.setColor(Color.black);

      Dimension d = c.getSize();    
      g.drawRect(0,0,d.width-1,d.height-1);


    }


     /** Nimmt an , dass die Komponente verschoben
        * werden soll , und speichert den Punkt , auf
        * den gedrueckt wurde als Startpunkt.
        * Wenn auf den unteren Rand der Entity gedrueckt wurde
        * wird stattdessen die Groesse geaendert  
        */
    public void mousePressed(MouseEvent e)
    {   x = e.getX(); nxs = nys = 0;
        y = e.getY();
        Entity n = (Entity) e.getComponent();
        Dimension d = n.getSize();
        if (y>d.height - 5)  // --> groesse aendern ( y Richtung)
          { oldx = d.width;  oldy = d.height;
            sizing = true; return;
	  }
         if (x> d.width - 5)  // the same in x direction
	 {
	    oldx = d.width;  oldy = d.height;
            sizing = true; xsizing = true;
	 }
    }

    /** Wenn eine Maustaste ueber der Entity losgelassen wird , 
      * wird angenommen , dass die Entity verschoben oder ihre
      * Groesse geaendert wurde */
    public void mouseReleased(MouseEvent e)
    {    Entity n = (Entity) e.getComponent();
         n.pressed = false; // pressed nach locked aendern

         n.hasChanged(); 
        
       
         sizing = false; xsizing = false;
         
    }


/** Wenn der Mauszeiger ueber die Entity gefahren wird , wird
  * sie in den Vordergrund gebracht */
 public void mouseEntered(MouseEvent e)
    {
      Entity c =(Entity) e.getComponent();
      if (c.parent.marking == false) c.parent.p.moveToFront(c);
      //System.out.println("entered ");
    }


 /** leer */
 public void mouseExited(MouseEvent e)
    {
     Entity c =(Entity) e.getComponent();
     c.shootAbTable();
    }


  /** leer*/
  public void mouseClicked(MouseEvent e)
    {
    }

  /** zum verschieben oder aendern der Groesse */  
    public void mouseDragged(MouseEvent e)
    {  if (sizing == true) 
            {  if (xsizing == true)
	        {
		   entResizeY(e);  
		   return ;
		} 
	      
	      entResize( e);
	      return;
	    } //--> nur groesse aendern und zurueck
       int nx = e.getX();
       int ny = e.getY();
       Entity en =(Entity) e.getComponent();
       nx = nx - x;
       ny = ny - y;
        Point p = en.getLocation();
        Point m = en.getMiddle();
       if (m.x + nx > 0 && m.y + ny > 0 ) 
       {
         nxs = nxs + nx ; nys = nys + ny;
         en.setLocation(p.x+nx,p.y+ny);
         //if en.isMarked(en.parent.markedMoved(en,nx,ny));
       }      
       
    }

  /** wird von mousedragged zum aendern der Groesse 
     * in vertikaler Richtung gerufen */
   private void entResize(MouseEvent e)
   {
       int ny = e.getY();
       Entity en =(Entity) e.getComponent();
      
        
        Dimension d = en.getSize();
        ny = ny - y; 
       
    
       if (oldy + ny < Variables.EntityY) 
         {
           en.setSize(oldx,Variables.EntityY);
         }
       else     
         { en.setSize(oldx,oldy + ny); }
         en.hasResized();
         en.repaint();
        

   }
  /** wird von mousedragged zum aendern der Groesse 
    *  in waagrechter Richtung gerufen
    *  gerufen */
   private void entResizeY(MouseEvent e)
   {
       int nx = e.getX();
       Entity en =(Entity) e.getComponent();
      
        
        Dimension d = en.getSize();
        nx = nx - x; 
       
    
       if (oldx + nx < Variables.EntityX) en.setSize(Variables.EntityX,oldy);
       
       else en.setSize(oldx + nx,oldy );
         
         en.hasResizedX();
         en.repaint();
        

   }

/** leer */ 
public void mouseMoved(MouseEvent e)
    {
    }


}
