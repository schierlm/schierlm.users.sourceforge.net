import java.awt.event.ActionEvent;
import javax.swing.JInternalFrame;
import java.awt.event.ActionListener;


/** Wenn auf den Copy-Button gedrueckt wird , 
  * sorgt diese Klasse dafuer , dass je nach aktivem
  * JInternalFrame der richtige Befehl zum Kopieren
  * ausgefuehrt wird . */
public class CopyAction implements ActionListener
{ 
   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */
private Start parent;

  
   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
    public CopyAction(Start p) {
	parent = p;
    }

/** Diese Methode ueberprueft , ob der aktive
  * interne Rahmen ein ERFrame oder  ein TextFrame ist.
  * Dies ist eigentlich egal , da die aufzurufende Methode 
  * in beiden Faellen Copy() heisst.
  * Bei nur zwei Klassen war aber zu faul ein Interface zu schreiben.
  * @see ERFrame 
  * @see TextFrame */
    public void actionPerformed(ActionEvent ae) {
	JInternalFrame inf = parent.getActiveFrame();
	if (inf instanceof ChangableInternalFrame) {
	    ((ChangableInternalFrame) inf).Copy();
	}
    }
}
