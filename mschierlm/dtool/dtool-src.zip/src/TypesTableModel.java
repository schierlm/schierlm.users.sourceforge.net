import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;



/** Im TypesDialog zum bearbeiten von Domaenen wird eine 
 *  Tablelle verwendet. Hier werden die Daten dieser Tabelle
 *  verwaltet. Der Datenvektor ist lediglich ein Verweis auf den 
 *  types Vektor des aktiven ERFrames. (Wenn kein ERFrame aktiv ist erscheint der Dialog nicht )
 *  d.h. die Aenderungen werden sofort im aktiven ERFrame wirksam 
 *  Die Methoden dieser Klasse werden in AttributTableModel beschrieben
 *  @see AttributTableModel 
 *  @see TypesDlg 
 *  @see ERFrame
  */

public class TypesTableModel extends AbstractTableModel
{    
     /** Der Konstruktor setzt den Datenvektor auf den types Vektor
      *  des aktiven ERFrame */
     public TypesTableModel(Vector v)
     {
        data = v;
     }

     /** Hier stehen die Daten der Tabelle drin */  
     private  Vector data ;

     /** Die Ueberschriften der Spalten*/
     String [] headers = {"Type"};
     
     /** Die Klasse die in der jeweilign Spalte gespeichert wird */
     Class [] columnClasses = {StringWrapper.class };
 
     /** Die Anzahle der Reihen in der Tabelle  */
      public int getRowCount() { return data.size();}

     /**Die Anzahl der Spalten*/
      public int getColumnCount() { return 1;}

      /** Accessor fuer columnClasses */
      public Class getColumnClass(int c)
      { return columnClasses[c];}

      /** liefert die Ueberschrift von Spalte c */
      public String getColumnName(int c) { return headers[c];}

      /** liefert immer true zurueck */
      public boolean isCellEditable(int r , int c )
      { 
         return true;        
      }

      /** gibt das Objekt in REihe r  , Spalte c der Tabelle zurueck */
      public Object getValueAt(int r  , int c)
      {    StringWrapper sw = (StringWrapper) data.elementAt(r);
           return sw.toString();
      }


      /** Setzt die Zelle r/c auf value */
      public void setValueAt(Object value,int r , int c)
      { 
         //System.out.println("HHHHH" + value.getClass());
	 String s = "";
         if (value instanceof StringWrapper) s=value.toString();
	 else  s = (String) value;
         StringWrapper  sw = (StringWrapper) data.elementAt(r);

         sw.setString(s);

         fireTableDataChanged();        
         
      }


/** fuegt eine neue Reihe unten an die Tabelle abn */
public void addRow(String s)
      {  
           data.addElement(new StringWrapper(s));
           
           fireTableDataChanged();
      }

  
   
/** loescht Zeile i */
  public void removeRow(int i)
      {
           data.removeElementAt(i);
           fireTableDataChanged();
      }



  /** schreibt die DatenTypen als Strings in den uebergebenen Vector v 
    * @param v Hier stehen die Strings dann drin (der Vector wird vorher geloescht) */
  public void getVector(Vector v)
      {
        int i = getRowCount();
        v.removeAllElements();
        
        for (int j=0;j<i;j++)
        { 
          StringWrapper sw =  (StringWrapper) data.elementAt(j); 
          v.addElement(sw.toString());
           
        }  

     }

}
