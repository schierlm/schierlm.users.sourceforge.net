import javax.swing.JDialog;
import javax.swing.JTable;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.border.*;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.TableColumn;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.TableCellEditor;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import java.util.Vector;


/** Dialog zum bearbeiten von RelShips : Beinhaltet die folgenden Komponenten :
   - TextField fuer den Namen
   - Tabelle (3 Reihen) fuer die Verbindungen zu maximal 3 Entities
   - Tabelle fuer beliebig viele Attribute 
   - Buttons um die zweite Tabelle zu bearbeiten und den Dialog zu schliessen
*/
public class RelShipDlg extends JDialog
{ ERFrame parent;

  JTable jt1;
  
  AttributTableModel Attm;  // das Modell der zweiten Tabelle
  ERPanelTableModel erpm;   // das Modell der ersten Tabelle
  Vector Ent,types;         // die vectoren aus ERFrama , die die Entities bzw. DatenTypen enthalten

  


   public RelShipDlg(JFrame st,ERFrame erf,AttributTableModel atm,
                      Vector v,ERPanelTableModel erptm, Vector t ,JTextField jtf)

   { super(st,"RelationShip Edit Dialog",true);
     parent = erf;        Attm = atm; Ent = v; types=t;
     setSize(475,400);
     erpm = erptm; 
     JPanel p = new JPanel(); 
     p.setLayout(new BorderLayout());/* p.setBackground(new Color(100,0,100));*/ p.setLayout(null);
     getContentPane().add(p,BorderLayout.CENTER);

     jt1 = new JTable(Attm);
     JScrollPane jsp1 = new JScrollPane(jt1);
     jt1.setVisible(true); jsp1.setVisible(true); 
     jt1.setDefaultRenderer(DefaultComboBoxModel.class,new ComboBoxRenderer());
     jt1.setDefaultEditor(DefaultComboBoxModel.class,new ComboBoxEditor(t,true));
     //jt1.setDefaultRenderer(CheckBoxModel.class,new CheckBoxRenderer());
     //jt1.setDefaultEditor(CheckBoxModel.class,new CheckBoxEditor());
     jt1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
     jt1.setRowHeight(20);

TableColumn column = null;
for (int i = 0; i <= 5; i++) 
{
    column = jt1.getColumnModel().getColumn(i);
     if (i==0) {   column.setPreferredWidth(150);}
     if (i==1) {   column.setPreferredWidth(150);}
     if (i>1)  {   column.setPreferredWidth(25);}
        
}




// zu viele neue , weniger reicht

     JTable jt2 = new JTable(erpm);
     JScrollPane jsp2 = new JScrollPane(jt2,JScrollPane.VERTICAL_SCROLLBAR_NEVER,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER  );
     jt2.setVisible(true); jsp2.setVisible(true); 
    
     jt2.setDefaultRenderer(DefaultComboBoxModel.class,new ComboBoxRenderer());
     jt2.setDefaultEditor(DefaultComboBoxModel.class,new ComboBoxEditor(v,false));
     //jt2.setDefaultRenderer(CheckBoxModel.class,new CheckBoxRenderer());
     //jt2.setDefaultEditor(CheckBoxModel.class,new CheckBoxEditor());
     jt2.setRowHeight(20);

 column = null;
for (int i = 0; i <= 4; i++) 
{
    column = jt2.getColumnModel().getColumn(i);
     if (i==0) {   column.setPreferredWidth(200);}
     
     if (i>=1)  {   column.setPreferredWidth(50);}
  
         
}


     
     jtf.setVisible(true);
     JButton OKButton = new JButton("OK");
     OKButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               
                boolean b = erpm.canClose() ; //ueberprueft , ob die Verteilung von schwachen und starken Ent. ok ist
                if (b==false) return;
                setVisible(false);
                dispose();
           } } );

    JButton TypesButton = new JButton("Types");
     TypesButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
                 // setModal(false);setVisible(false);
                  parent.alterTypes();
                  //setVisible(true);setModal(true); 

           } } );


     JButton AddButton = new JButton("Add");
     AddButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               AttributRowModel R = new AttributRowModel("",new DefaultComboBoxModel(types));
               Attm.addRow(R);
           } } );

     JButton RemButton = new JButton("Remove");
     RemButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               int i = jt1.getSelectedRow();
               if (i<0 || i>=Attm.getRowCount()) return;
               

                 if (jt1.isEditing()) 
              {
                  TableCellEditor cellEditor = jt1.getCellEditor();           
                  if (cellEditor != null) 
                  {
                      cellEditor.stopCellEditing();
                  }
              }             

               Attm.removeRow(i);
              
           } } );
    
     JLabel vorName=new JLabel("Hier den Namen eingeben : ");
     vorName.setVisible(true);
     JLabel vorEn=new JLabel("Verbinden mit : ");
     vorEn.setVisible(true);
     JLabel vorAtt=new JLabel("Attribute : ");
     vorAtt.setVisible(true);
     

     vorName.setSize(200,25);
     vorName.setLocation(20,10);
     p.add(vorName);
     jtf.setSize(180,25); 
     jtf.setLocation(225,10);
     p.add(jtf);

     vorEn.setSize(200,30);   
     vorEn.setLocation(20,50);
     p.add(vorEn);

     vorAtt.setSize(120,25);
     vorAtt.setLocation(20,170);
     p.add(vorAtt);

     

//Entitys
     jsp2.setSize(400,80+jt2.getTableHeader().getSize().height);
     jsp2.setLocation(20,80); 
     p.add(jsp2);

//Attribs     
     jsp1.setSize(400,128);
     jsp1.setLocation(20,190);
     p.add(jsp1);

   JPanel butP = new JPanel();
   butP.add(OKButton); OKButton.setToolTipText("Fertig");
   butP.add(AddButton); AddButton.setToolTipText("Neues Attribut hinzuf�gen");
   butP.add(RemButton); RemButton.setToolTipText("Markiertes Attribut entfernen");
   butP.add(TypesButton); TypesButton.setToolTipText("Datentypen bearbeiten");

   getContentPane().add(butP,BorderLayout.SOUTH);

    setLocationRelativeTo(st);
    setVisible(true);



   }


/** �ndert die Groesse des Dialogs */
public void setSize(int x , int y)
{
  super.setSize(Variables.RelShipDlgSizeX,Variables.RelShipDlgSizeY);
}

/** setzt komischerweise die Dialoggroesse immer auf , keine Ahnung
  * mehr warum , wird hoffentlich nie verwendet 
  * und deshalb vorsichthalber mal auskommentiert 
  */
public void setSize(Dimension d)
{
  setSize(0,0);

}

}



