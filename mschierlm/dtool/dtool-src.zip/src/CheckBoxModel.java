/** Datenmodell fuer die Checkboxen in Tabellen 
  * legt fest , ob die CheckBox geklickt ist und
  * ob sie geaendert werden darf. Hat zwei private 
  * booleans  und ein paar Accessoren .
  */

public class CheckBoxModel
{
    /** ob die Box ausgewaehlt werden darf */
    private boolean Selected;

    /** ob die Box geaendert werden darf */
    private boolean Enabled; 

   /** ruft den 2ten Konstruktor mit (false,true) */
   public CheckBoxModel()
   { this(false,true);}

   /** Legt eine neue CheckBox an 
     * s legt fest , ob die Box ausgewaehlt ist
     * e ob sie editierbar ist
   */
   
   
   public CheckBoxModel(boolean s , boolean e)
   { Selected = s; Enabled = e;}

   /** ruft den 2ten Konstruktor mit (s,true) */
   public CheckBoxModel(boolean s)
   { this(s,true);}

   /** klickt die Box , wenn s true ist. 
     */
   public void setSelected(boolean s)
   { Selected = s;}

   /** macht die Box editierbar */
   public void setEnabled(boolean e)
   { Enabled = e;}

   public boolean isSelected()
   { return Selected; }

   public boolean isEnabled()
   { return Enabled;}

   public boolean isEditable()
   { return Enabled;}

   //public boolean setEditable()
   //{ return Enabled;}

  /** gibt entweder "true" oder "false" zurueck */
   public String toString()
   { if (isSelected()) return "true";
     else return "false";
   }
}
