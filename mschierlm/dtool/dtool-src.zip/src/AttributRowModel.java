import javax.swing.DefaultComboBoxModel;
import java.util.Vector;

/** speichert eine Reihe eines AttributTableModells (d.h. eine Zeile in einer Tabelle 
  * in einer Entity oder in einem RelShipDlg(AttributTable) ) 
  * wird in den Datenvektor bei AttributTableModel eingefuegt
  * @see AttributTableModel */

public class AttributRowModel
{   /** der Name des Attributs */
    public String Name; 

    /** hier wird seine Domaene gespeichert  
      *  (selectedItem in der ComboBox ist die aktuelle Domaene */
   public DefaultComboBoxModel Domain; 
   
   
   private    CheckBoxModel pk,opt,mw,uni; // Checkboxen fuer PrimaryKey , Optional , ....



/** klont this , und ueberpruet dabei , ob neue Typen in desttypes eingefuegt werden muessen.
  * @param desttypes der Typenvektor des ERFrame , in dem die geklonte Reihe verwendet wird . */
public AttributRowModel klone(Vector desttypes)
{  int save=-1;
  DefaultComboBoxModel ndfm = new DefaultComboBoxModel(desttypes);
  Object o = Domain.getSelectedItem();
  StringWrapper old = (StringWrapper) o;
  
  int sz = desttypes.size();
  for(int i=0;i<sz;i++)
  {
    Object o2 = desttypes.elementAt(i);
    StringWrapper nstr = (StringWrapper) o2;
    if (nstr.equals(old)) {save=i; break;}
    
  }

  if (save>=0) 
  { 
  Object no = desttypes.elementAt(save);
  ndfm.setSelectedItem(no);
  }

  else
  {
    desttypes.addElement(old);
    ndfm.setSelectedItem(old);

  }

  AttributRowModel arm = new AttributRowModel(Name,ndfm,pk.isSelected(),uni.isSelected(),mw.isSelected(),opt.isSelected());
  return arm;
}


/** Konstruktor , legt eine schon vollkommen definierte Reihe an
  * (beim laden und klonen) */ 
public AttributRowModel(String name,DefaultComboBoxModel dfm,boolean p,boolean u,
                         boolean m,boolean o )
{  Name = name;
   Domain = dfm;
  if (p==true) 
 { pk = new CheckBoxModel(true,true);
   opt = new CheckBoxModel(false,true);
   mw = new CheckBoxModel(false,true);
   uni = new CheckBoxModel(false,true);
 }  

  else
  {  pk = new CheckBoxModel(false,true);
     opt = new CheckBoxModel(o,true);
     mw = new CheckBoxModel(m,true);
     if (m==true) u = false; 
     uni = new CheckBoxModel(u,true);
    
  }
}


/**  Konstruktor , ruft den oberen Konstruktor mit
  *  Standardwerten auf.
  *  (beim Einfuegen einer neuen Reihe in eine Tabelle  */
public AttributRowModel(String name,DefaultComboBoxModel dfm)
{
   this(name , dfm, true,false,false,false);
}


/** liefert den Namen des Attributs zurueck */
public String getName()
{
   return Name;
}

/** setzt das Attribut Name auf s */
public void setName(String s)
{
  Name = s;
}


/** gibt die Domain Variable zurueck */
public DefaultComboBoxModel getDomain()
{ 
   return Domain;
}


/** setzt Domain auf s */
public void setDomain(DefaultComboBoxModel s)
{
  Domain = s;
  
}

/** gibt an , ob Primary Key gesetzt ist */
public CheckBoxModel getPk()
{ return pk;}

/** gibt an , ob dieses Attribut mehrwertig ist*/
public CheckBoxModel getMw()
{ return mw;}

/** gibt an , ob dieses Attribut Unique ist */
public CheckBoxModel getUn()
{ return uni;}

/** gibt an , ob dieses Attribut Optional ist */
public CheckBoxModel getOp()
{ return opt;}


/** Setzt Primary Key auf true oder false .
  * Solange Prinary Key  true ist  , kann keine andere CheckBox 
  * ausgewaehlt werden */

public void setPk(boolean cbm)
{         pk.setSelected(cbm);
       if (cbm) 
       {  //opt.setEnabled(false) ;
          //mw.setEnabled(false) ;

          //uni.setEnabled(false) ;
          
          opt.setSelected(false) ;
          mw.setSelected(false) ;

          //uni.setSelected(false) ;

       }
     else
     {    //opt.setEnabled(true) ;
          //mw.setEnabled(true) ;

          //uni.setEnabled(true) ;
     }
}

/** Legt fest ob das Attribut mehrwertig ist */
public void setMw(boolean cbm)
{  mw.setSelected(cbm);
    if (cbm)
    {
       pk.setSelected(false);
       uni.setSelected(false);
       //uni.setSelected(false);
    
    }

}

/** Legt fest ob das Attribut unique ist */
public void setUn(boolean cbm)
{  uni.setSelected(cbm);
   if (cbm)
    {
      mw.setSelected(false);
      
    }
}

/** Legt fest ob das Attribut optional ist */
public void setOp(boolean cbm)
{  opt.setSelected(cbm);
   if (cbm)
   {
     pk.setSelected(false);
        
   
   }
}

/** gibt den datentype des Attributs als String zurueck */
public String getDomainName()
{
  return Domain.getSelectedItem().toString();
}

}
