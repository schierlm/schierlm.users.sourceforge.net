
/**Diese Klasse enth�lt die Infos, mit denen eine TableRow 
 * einen Foreign Key anlegen kann. Normalerweise reicht der integer
 * aus, der die Table identifiziert, auf die der Fkey zeigen soll.
 * Wenn refName!="" wird statt references Table   references Table(refName)
 * angelegt.
 */
public class RefClass
{
 public int refTo;
 public String refName;



  public RefClass(int num,String Name)
  {
    
      refTo = num;
      refName = Name;

  }


}