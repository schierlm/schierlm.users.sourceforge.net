import javax.swing.JComponent;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.Polygon;
import javax.swing.UIManager;

/** Verbindungslinie bzw. Pfeil bei einer Vererbung */
public class IsaLine extends JComponent {
    /** Polygon wird nach setLine einmal berechnet (die Pfeilspitze) */
    protected Polygon Poly = new Polygon();   

    public ISA parent;
    public Entity ent=null; 
    public boolean waagrecht;
  
    public double dockPer=0.5;      
     
    /** legen Aussehen der Linie fest */

    public boolean pfeil, nachOben, nachRechts;
    
    /** Die gezeichnete Dimension der Linie , kleiner als die Dimension der Komponente , um bei kleinen
     *  Komponenten die Pfeilspitze zu zeichnen */
    protected Dimension dim = new Dimension(); 


/** Konstruktor ruft nur updateUI */
    public IsaLine(ISA r) {          
	parent = r;
	updateUI() ;       
    }


    /** legt die Eigenschaften der Linie fest 
     * @param locx Die X-Koordinate der Linie 
     * @param locy -"-
     * @param sx Die Gr��e
     * @param sy 
     * @param rechts Die horizontale Richtung
     * @param hoch
     * @param arrow Ob Pfeilspitze gezeichnet wird
     */
    public void setLine(int locx,int locy,int sx  ,int sy , boolean rechts , boolean hoch,boolean arrow) {
	// um die Fallunterscheidung in alterLine zu k�rzen, werden
	// hier verdrehte Parameter behoben    -- mihi, 2003-12-08
	if (sx <0) {
	    sx=-sx;
	    locx -=sx;
	    rechts=!rechts;
	}
	if (sy <0) {
	    sy=-sy;
	    locy-=sy;
	    hoch=!hoch;
	}
        dim.width = sx ; dim.height = sy;
        setSize(sx+2*Variables.SpecialD + 5 ,sy + 2*Variables.SpecialD+5 );
        setLocation(locx,locy);
        pfeil = arrow; nachOben = hoch; nachRechts = rechts;
        Poly = setUpPoly();
        repaint();
    }

/** Gibt im Gegensatz zu getSize() die zu zeichnende Gr��e der Linie zur�ck*/
    public Dimension getDim() {
	return dim;
    }

    public void setUI(IsaLineUI ui) {super.setUI(ui);}


    public void updateUI() {
	setUI( (IsaLineUI) UIManager.getUI(this));
	invalidate();
    }


    public String getUIClassID() { return "IsaLineUI";}

  

/** legt eine neue Pfeilspitze an */
    public Polygon setUpPoly() {
	IsaLine isl = this;
	// FIXME: Variablen zusammenfassbar?
	Dimension d = isl.getDim();
	boolean r = isl.nachRechts;
	boolean h = isl.nachOben;
	double len = Math.sqrt(d.width*d.width + d.height*d.height);
	double nnew = ( (double) Variables.SpecialD) / len;
        double scaleY = ( (double) d.width )  / len  * Variables.SpecialD; 
        double scaleX = ( (double) d.height ) / len * Variables.SpecialD; 
	int scaleXi = (int) Math.round(scaleX);
	int scaleYi = (int) Math.round(scaleY);
	int dw = r ? d.width : 0;
	int dh = h ? 0 : d.height;
	int sx = r ? scaleXi : -scaleXi;
	int sy = h ? scaleYi : -scaleYi;
	double nnew1 = r ? 1-nnew : nnew;
	double nnew2 = h ? nnew : 1-nnew;
	int rx = (int) java.lang.Math.round(nnew1 * d.width) + Variables.SpecialD;
	int ry = (int) java.lang.Math.round(nnew2 * d.height) + Variables.SpecialD;
	Polygon pl = new Polygon();

	pl.addPoint(rx,ry);
	pl.addPoint(rx + sx, ry + sy);
	pl.addPoint(dw + Variables.SpecialD, dh + Variables.SpecialD);
	pl.addPoint(rx - sx, ry - sy);
	return pl;
    }

/** Gibt die aktuelle Pfeilspitze zur�ck */
    public Polygon getPoly() {
	return Poly;
    }


    /** liefert neue IsaLine die mit this identisch ist */
    public IsaLine klone() {
	IsaLine isl = new IsaLine(parent);
	Point p = getLocation();
	isl.setLine(p.x,p.y,dim.width,dim.height,nachRechts,nachOben,pfeil);
	return isl;

    }

    protected void alterLine(Entity e ) {
	if (e==null) return;
	alterLine(e,pfeil); }

    protected void alterLine(Entity e, boolean b) {
	if (dockPer<0) dockPer = 0; if (dockPer>1) dockPer=1;
	int adk=0;
	//FIXME: Andockkante hier bei Bedarf �ndern
	IsaCenter isc = parent.isc; 
	Point p = e.getLocation();
	Dimension d = e.getSize();
	Point cp = isc.getLocation();
	cp.x += Variables.IsaCenterX/2;
	cp.y += Variables.IsaCenterY/2;

        int dheight = (int) (d.height * dockPer);
        int dwidth = (int) (d.width * dockPer);

	int dx = cp.x - p.x ; int dy = cp.y - p.y;
	if (adk == 0) {
	    if (dy >= 0 && dy <d.height) {
		if (dx < 0) adk = 1; // links
		if (dx >= 0) adk = 3; // rechts
	    } else if (dx >=0 && dx< d.width) {
		if (dy < 0) adk = 4; // oben
		if (dy >= 0) adk = 2; // unten
	    } else { // diagonal:
		if (dx < 0 && dy < 0) {
		    if (-dx < -dy) adk=4; else adk=1;
		} else if (dx < 0 && dy >= d.height) {
		    if (-dx < (dy-d.height)) adk=2; else adk=1;
		} else if (dx >= d.width && dy < 0) {
		    if ((dx-d.width) < -dy) adk = 4; else adk=3;
		} else { // rechts unten
		    if ((dx-d.width) < (dy-d.height)) adk= 2; else adk=3;
		}
	    }
	}

	waagrecht = (adk==1 || adk==3);
	switch(adk) {
	case 1: 
	    setLine(cp.x - Variables.SpecialD,p.y+ dheight - Variables.SpecialD , -dx,cp.y - p.y - dheight, true, true, b);
	    break;
	case 2:
 	    setLine(cp.x- Variables.SpecialD,p.y+d.height - Variables.SpecialD,p.x + dwidth - cp.x , dy-d.height,true,true,b);
	    break;
	case 3:	    
	    setLine(p.x +d.width -Variables.SpecialD,p.y+dheight- Variables.SpecialD,dx-d.width,cp.y - p.y - dheight,false,true,b);
	    break;
	case 4:
	    setLine(cp.x- Variables.SpecialD,cp.y- Variables.SpecialD,p.x + dwidth - cp.x , -dy,true,false,b);
	}
    }

/** Setzt ent auf e */
    public void setEntity(Entity e) {
	ent = e;
    }


/** gibt ent zurueck */
    public Entity getEntity() {
	return ent;
    }
}

