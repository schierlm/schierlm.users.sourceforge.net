import javax.swing.plaf.ComponentUI;

public abstract class EntityUI extends ComponentUI
{


}
