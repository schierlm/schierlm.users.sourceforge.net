import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


/** Fuegt einen neuen ERFrame in die JDesktopPane an
  * wenn die entsprechende Aktion (diese!) ausgeloest wird. */
public class AddERFrameAction implements ActionListener
{ 
 
   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */
private Start parent;

   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
public AddERFrameAction(Start p)
   {  parent = p;
   }

  /** Wird ausgefuehrt , wenn jemand auf den Knopf bzw.
    * Menueeintrag zum Anlegen eines neuen ERFrame drueckt.
    * Ruft die Methode addERFrame von Start auf.
    * @see Start */
public void actionPerformed(ActionEvent ae)
   {   
           parent.addERFrame();
   }

}
