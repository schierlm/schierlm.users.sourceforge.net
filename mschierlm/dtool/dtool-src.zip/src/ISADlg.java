import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import java.util.Vector;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableCellEditor;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.DefaultComboBoxModel;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;


/** Dieser Dialog wird verwendet , um eine Vererbung zu bearbeiten.
  */
public class ISADlg extends JDialog
{ 
  /** der ERFrame zu dem die berarbeitete ISA gehoert */
  ERFrame parent;
  /** die Vererbung*/
  ISA IsaParent;
  /** Eine 1x1 Tabelle , zum auswaehlen der Super Entity */
  JTable jtfake;
  /** Eine 1xn Tabelle fuer die Sub Entities */ 
  JTable jt1;
  
  /** Das zu jt1 gehoerende Model */
  ISATableModel itm;
  
  /** Der Entity Vector von parent */
  Vector Ent;


   /** Konstruktor , der die gesamte Oberflaeche des Dialogs anlegt */
   public ISADlg(JFrame st,ERFrame erf,ISATableModel tm,ISA is,
                      Vector v,FakeComboBoxModel dcm , JCheckBox X )

   { super(st,"Vererbung bearbeiten",true);
     parent = erf;        itm = tm; Ent = v; 
     setSize(475,280); IsaParent = is;
     
     JPanel p = new JPanel();
     p.setLayout(null); 
     getContentPane().add(p,BorderLayout.CENTER);


      jtfake = new JTable(dcm); JScrollPane jf1 = new JScrollPane(jtfake);
     jtfake.setDefaultRenderer(DefaultComboBoxModel.class,new ComboBoxRenderer());
     jtfake.setDefaultEditor(DefaultComboBoxModel.class,new ComboBoxEditor2(Ent,false,IsaParent.subs,dcm));
     jtfake.setVisible(true); jf1.setVisible(true);

     jt1 = new JTable(itm); 
     jt1.addMouseListener(new IsaMouseListener(jtfake));  // s.u.
     JScrollPane jsp1 = new JScrollPane(jt1);
     jt1.setVisible(true); jsp1.setVisible(true); 
     jt1.setDefaultRenderer(DefaultComboBoxModel.class,new ComboBoxRenderer());
     jt1.setDefaultEditor(DefaultComboBoxModel.class,new ComboBoxEditor2(Ent,false,IsaParent.subs,dcm));
    
     jt1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
     jt1.setRowSelectionAllowed(true);


     /*JComboBox jcb = new JComboBox(dcm);
          jcb.setVisible(true);*/
     jtfake.addMouseListener(new IsaMouseListener(jt1));  // die beiden Listener werden verwendet , um den Editing Modus
         							          // der Tabellen zu beenden , wenn man den Mauszeiger aus
							                // ihrem Bildschirmbereich rausbewegt.

    
     X.setVisible(true); 
     JButton OKButton = new JButton("OK");
     OKButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
                 if (jt1.isEditing()) 
                {
                  TableCellEditor cellEditor =jt1.getCellEditor();           
                  if (cellEditor != null) 
                  {
                     cellEditor.stopCellEditing();    // schiesst ebenfalls den Editing Mode ab (wenn man auf OK drueckt)
                  }
                }             

                  if (jtfake.isEditing()) 
                {
                  TableCellEditor cellEditor =jtfake.getCellEditor();           
                  if (cellEditor != null) 
                  {
                     cellEditor.stopCellEditing();
                  }
                }        

                setVisible(false);
                dispose();
           


              } } );
     JButton AddButton = new JButton("Add");
     AddButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               DefaultComboBoxModel R = new DefaultComboBoxModel(Ent);
               itm.addRow(R);
           } } );

     JButton RemButton = new JButton("Remove");
     RemButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               int i = jt1.getSelectedRow();
              
               if (i<0 || i>=itm.getRowCount()) return;
              
                if (jt1.isEditing()) 
                {
                  TableCellEditor cellEditor =jt1.getCellEditor();           
                  if (cellEditor != null) 
                  {
                     cellEditor.stopCellEditing();      // dito 
                  }
                }             

                  if (jtfake.isEditing()) 
                {
                  TableCellEditor cellEditor =jtfake.getCellEditor();           
                  if (cellEditor != null) 
                  {
                     cellEditor.stopCellEditing();
                  }
                }        

               itm.removeRow(i);
              
           } } );

     JLabel vorSup=new JLabel("Super/Ober Entit�t :  ");
     vorSup.setVisible(true);
     JLabel vorSubs=new JLabel("Unterentit�ten : ");
     vorSubs.setVisible(true);
     JLabel vorX = new JLabel("Vererbung disjunkt? :  ");
     vorX.setVisible(true);



     

     jsp1.setSize(400,110);                  // hier werden die restlichen Komponenten angeordnet 
 							   // genialerweise alles mit fest eingebauten Zahlen 
     jsp1.setLocation(20,100);               // BoxLayout soll auch ganz nett sein 
     p.add(jsp1);
     
     vorSubs.setSize(200,25);
     vorSubs.setLocation(20,80); 
     p.add(vorSubs);


     /*jcb.setSize(200,20);
     p.add(jcb); jcb.setLocation(200,20);*/
     jf1.setSize(200,20); p.add(jf1); jf1.setLocation(200,20);

     vorSup.setSize(200,25);
     vorSup.setLocation(20,20); 
     p.add(vorSup);


     JPanel pp = new JPanel(); 
     pp.add(X); pp.setSize(30,30); 
     pp.setLocation(200,47); p.add(pp);
    
     vorX.setSize(200,25);
     vorX.setLocation(20,50); 
     p.add(vorX);





   JPanel butP = new JPanel();
   butP.add(OKButton);OKButton.setToolTipText("Fertig");
   butP.add(AddButton);AddButton.setToolTipText("Neue Subentit�t hinzuf�gen");
   butP.add(RemButton);RemButton.setToolTipText("Markierte Subentit�t l�schen");

   getContentPane().add(butP,BorderLayout.SOUTH);

    setLocationRelativeTo(st);
    setVisible(true);



   }



}



