
import javax.swing.plaf.ComponentUI;


public abstract class IsaLineUI extends ComponentUI
{


}
