/** Interface , dass zum Verschieben von Entitys , Lines 
 *  und Diamonds verwendet wird .
 */  

public interface DrawAble
{
  public void reDraw(boolean c,int nx , int ny);

 public void hasChanged(int nx , int ny);

 public void setNum(int n);



}
