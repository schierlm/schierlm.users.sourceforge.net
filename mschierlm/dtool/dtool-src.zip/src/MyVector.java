import java.util.Vector;

/** Ein Vector , der einen speziellen
  * Konstruktor zur Verfuegung stellt */
public class MyVector extends Vector 
{

/** Zuerst wollte ich die Strings 
  * , die in Variables.types stehen 
  * direkt in einen Vektor schreiben.
  * Das gab aber Probleme beim Darstellen
  * der Strings in den Tabellen.
  * Deshalb habe ich die Klasse StrringWrapper eingefuehrt.
  * Dieser Konstruktor wandelt die Strings in dem Array
  * in Stringwrapper um, bevor sie eingefuegt werden */
public MyVector(Object[] o)
{ super();
  int n = o.length;
  for (int i=0;i<n;i++) {
   StringWrapper s = new StringWrapper((String) o[i]);
   addElement(s);
   
  }
}





}