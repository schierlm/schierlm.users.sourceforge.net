import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;

import javax.swing.plaf.ComponentUI;
import javax.swing.JComponent;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Polygon;
import java.awt.Point;


/** Der UI-Delegate der Line Klasse 
 * @see Line */ 
public class BasicLineUI extends LineUI implements MouseListener,MouseMotionListener
{   private boolean pressed=false;
    private int x,y;


    /** legt eine neue Instanz von dieser Klasse an */
    public static ComponentUI createUI(JComponent c)
    { return new BasicLineUI();}

    /** legt fest , das die Mausereignisse von dieser Klasse (this)
      * bearbeitet werden */
    public void installUI(JComponent c)
    { Line l = (Line) c;
      l.addMouseListener(this);
      l.addMouseMotionListener(this);
    }

    /** raeumt auf ,wenn die Klasse aufgegeben wird */
    public void uninstallUI(JComponent c)
    { Line l = (Line) c;
      l.removeMouseListener(this);
      l.removeMouseMotionListener(this);


    }


    /** zum Zeichnen */
    public void paint(Graphics g,JComponent c)
    { 
         Line l = (Line) c;
         if (l.isMarked()) g.setColor(Color.red);
         else g.setColor(Variables.drawColor);             // markiert ??

         int le = l.length;
         Point p = l.getLocation();
         boolean w = l.waagrecht;
         boolean dir = l.direction;               // auslesen von Informationen
         
         if (w==true) g.drawLine(0,Variables.SpecialD,le,Variables.SpecialD); // waagrecht zeichnen
         else g.drawLine(Variables.SpecialD,0,Variables.SpecialD,le);         // vertikal zeichnen

         int sp = l.getSpecial();                // eine Zahl , die angibt ob noch weiter gezeichnet werden muss
         int num = l.getNum();

         if (sp == 0) return;                    // nein 


         /** ja : ein DreiEck fuer starke/schwache Entity */
         if (num == 1) {  if (((sp == 1) && ( dir ==true)) || ((sp==2) && (dir==false)))
                          {drawTriangle(true,l,g);return;}

                          else { drawTriangle(false,l,g);}
                        
                        }
         /** ja : ein Kreis fuer optional */  
         if (num == 2) {     if (sp>0)
                            
                           { drawCircle(l,g);}

                        }

         /** ja : zwei weitere kleine Linien fuer many */
         if (num == 3) {   if ((sp>0)&&(dir ==true) )
                                    drawDelta(true,l,g);

                                else drawDelta(false,l,g);



                        }


    }


 /** speichert den Punkt auf den gedrueckt wurde */
    public void mousePressed(MouseEvent e)
    {   x = e.getX();
        y = e.getY();   // merkt sich halt , dass gedrueckt wurde und wo
        Line l = (Line) e.getComponent();
        l.pressed = true;
    }

 /** Beendet das Verschieben */
    public void mouseReleased(MouseEvent e)
    {  Line l = (Line) e.getComponent();
       l.pressed = false;
    }


  /** leer */
    public void mouseEntered(MouseEvent e)
    {
    }

 /** leer */
    public void mouseExited(MouseEvent e)
    {
    }

  /** leer */
    public void mouseClicked(MouseEvent e)
    { 
    }



/** zum Verschieben */
    public void mouseDragged(MouseEvent e)
    {  
       int c1 = -1000;
       int c2 = +30000;
       
       int nx = e.getX();
       int ny = e.getY();
       Line li =(Line) e.getComponent();
        
        if  (li.num==3) // dann wird gerechnet , und zwar ne Zahl zwischen 0 und 1 , 
                        // die angibt , wo die Linie gerade an der Entity anliegt
        {               // ansonsten wird zwar auch gerechnet , der Wert aber nicht beachtet
          Rectangle cons = li.getEntityRec();
          if (li.waagrecht==true) { c1 = cons.y-Variables.SpecialD; c2 = cons.height-Variables.SpecialD;}
          else                    { c1 = cons.x-Variables.SpecialD; c2 = cons.width-Variables.SpecialD;}

        }

       nx = nx - x;
       ny = ny - y;    // berechnung , um wieviel wohin verschoben werden muss

       Point p = li.getLocation();

       if (li.waagrecht == true) 
       { 
         int ry = p.y+ny;

         if (ry > c2) ry = c2; 

         if (ry < c1) ry = c1;  // kann nur passieren , wenn li.num == 3 
         li.setLocation(p.x,ry);
         li.hasChanged(0,ry-p.y);  // jetzt wurde neu gezeichnet
         double rd = ((double) ry)/( ((double)c2)-((double)c1)) + ((double)c1)/(((double)c1)-((double)c2));                  
         li.setRelative(rd);     // jetzt wird der neue relative Wert zur Entity gespeichert
       }
     
       else 
       { 
         int rx = p.x+nx;

         if (rx > c2) rx = c2; 

         if (rx < c1) rx = c1;
         li.setLocation(rx,p.y);
         li.hasChanged(rx-p.x,0);
         double rd = ((double) rx)/( ((double)c2)-((double)c1)) + ((double)c1)/(((double)c1)-((double)c2));
                li.setRelative(rd);
        }
 

       if (li.num==2) { // kann durch einen Diamond oder eine Entity durchgehen
	   Diamond d = (Diamond) li.DrS.getDrawable(0);
	   for (int i=0;i<3;i++) {
	       if (d.drs[i] == li.DrS) {
		   d.correctLineOver(i);
	       }
	   }
	   Entity ent = (Entity) li.DrS.getDrawable(4);
	   ent.correctLineOver(li.DrS);
       }	   
    }

  /** leer*/
    public void mouseMoved(MouseEvent e)
    {
    }


 /** zeichnet ein Dreick , dass auf die schwache Entity zeigt */
    private void drawTriangle(boolean dir,Line l , Graphics g)
    {   boolean w = l.waagrecht;


        Point p = new Point(0,0);
        int le = l.length; if (le < Variables.SpecialD + 5) return; 
        int px1=0,py1=0,px2=0,px3=0,py2=0,py3=0;
        int xx = le / 2;

        if ( (w==false) && (dir == false) )
        {  
           px1 = p.x;                         py1 = p.y+xx + Variables.SpecialD;
           px2 = p.x + 2* Variables.SpecialD; py2 = p.y+xx + Variables.SpecialD;
           px3 = p.x + Variables.SpecialD;    py3 = p.y+xx - Variables.SpecialD;
          
        }

        if ( (w==false) && (dir == true) )
        {  
           px1 = p.x;                         py1 = p.y+xx - Variables.SpecialD;
           px2 = p.x + 2* Variables.SpecialD; py2 = p.y+xx - Variables.SpecialD;
           px3 = p.x + Variables.SpecialD;    py3 = p.y+xx + Variables.SpecialD;
 
            
        }

        if ( (w==true) && (dir == false) )
        {  
           px1 =  p.x+xx - Variables.SpecialD;      py1 = p.y;
           px2 =  p.x+xx - Variables.SpecialD;      py2 = p.y + 2* Variables.SpecialD;
           px3 =  p.x+xx + Variables.SpecialD;    py3 = p.y + Variables.SpecialD;

         
        }

        if ( (w==true) && (dir == true) )
        {  
           px1 =  p.x+xx + Variables.SpecialD;      py1 = p.y;
           px2 =  p.x+xx + Variables.SpecialD;      py2 = p.y + 2* Variables.SpecialD;
           px3 =  p.x+xx - Variables.SpecialD;      py3 = p.y + Variables.SpecialD;



                        
          
        }
        int xxx[] = {px1,px2,px3};
        int yy[] = {py1,py2,py3}; 
       g.setColor(Variables.ERbgColor); 

       Polygon poly = new Polygon(xxx,yy,3);
       g.fillPolygon(poly);
       g.setColor(Variables.drawColor);
       g.drawPolygon(xxx,yy,3);


    }

  /** zeichnet den Kreis fuer Optional */
    private void drawCircle(Line l , Graphics g)
    {  boolean w = l.waagrecht;
               int le = l.length ; if (le < Variables.SpecialD + 5) return; 
             le = le /2;
      if (w == false)
      {

       g.setColor(Variables.ERbgColor);
       g.fillOval(0,le-Variables.SpecialD,2*Variables.SpecialD,2* Variables.SpecialD);


       g.setColor(Variables.drawColor);
       g.drawOval(0,le-Variables.SpecialD,2*Variables.SpecialD,2* Variables.SpecialD);

              return;
      }

      else
      {
       g.setColor(Variables.ERbgColor);
       g.fillOval(le-Variables.SpecialD,0,2* Variables.SpecialD  , 2* Variables.SpecialD);


       g.setColor(Variables.drawColor);
       g.drawOval(le-Variables.SpecialD,0,2* Variables.SpecialD,2* Variables.SpecialD);

             return;
      }
                                                          
    }

/** fuer mehrwertig */
private void drawDelta(boolean dir,Line l,Graphics g)
{
     int le = l.length; boolean w = l.waagrecht;
     int x,y,x1,y1,x2,y2;

     x=y=x1=y1=x2=y2=0;

     if ((w==true)&&(dir == true))
     {
        x  = le - Variables.SpecialD; y = Variables.SpecialD;
        x1 = le; x2 = le;
        y1 = 0; y2 = 2*Variables.SpecialD;

     }

     if ((w==false)&&(dir == true))
     {
        x  = Variables.SpecialD; y = Variables.SpecialD;
        x1 = 0; x2 = 2*Variables.SpecialD;
        y1 = 0; y2 = 0;
     
     }

     if ((w==true)&&(dir == false))
     {
        x  = Variables.SpecialD; y = Variables.SpecialD;
        x1 = 0; x2 = 0;
        y1 = 0; y2 = 2*Variables.SpecialD;

     }

     if ((w==false)&&(dir == false))
     {
        x  =  Variables.SpecialD; y =le - Variables.SpecialD;
        x1 = 0; x2 = 2*Variables.SpecialD;
        y1 = le; y2 = le;

     }


     g.setColor(Variables.drawColor);
     g.drawLine(x,y,x1,y1);
     g.drawLine(x,y,x2,y2);


}

 
}
