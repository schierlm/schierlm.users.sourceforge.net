import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JInternalFrame;

/** Diese Klasse ist 100 prozent analog zu
  * CopyAction aufgebaut. Nur das(s) statt 
  * Copy() Del() aufgerufen wird. 
  * @see CopyAction */
public class DelAction implements ActionListener
{  

private Start parent;

public DelAction(Start p)
   {  
      parent = p;

   }

public void actionPerformed(ActionEvent ae) {
    JInternalFrame inf = parent.getActiveFrame();
    if (inf instanceof ChangableInternalFrame) {
	((ChangableInternalFrame)inf).Del();
    }
}

}
