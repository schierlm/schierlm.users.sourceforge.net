import javax.swing.plaf.ComponentUI;

public abstract class IsaCenterUI extends ComponentUI
{


}
