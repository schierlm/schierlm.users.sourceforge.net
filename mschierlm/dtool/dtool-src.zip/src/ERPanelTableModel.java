import javax.swing.DefaultComboBoxModel;
import javax.swing.table.AbstractTableModel;
import java.util.Vector;


/** Diese Klasse gehoert zu der Tabelle in RelShipDlg , mit der die
  * RelShip selbst bearbeitet wird . Sie hat 3 Reihen und 5 Spalten.
  * Die Reihen stellen je eine Verbindung zu einer Entity dar.
  * Spalte 1 : Auswahl der Entity mittels ComboBox
  *        2 - 5 : Optional / many / weak / strong 
  * Wenn eine Entity weak ist , muss eine andere Strong sein , und umgekehrt(nicht mehr) */

public class ERPanelTableModel extends AbstractTableModel
{    Vector data = new Vector();
     String [] headers = {"Entity","O","M","W","S"};
     Class [] columnClasses = {DefaultComboBoxModel.class,
                               Boolean.class,Boolean.class,
                               Boolean.class,
                               Boolean.class};

      /** Die anzahl der reihen in dieser Tabelle (3)*/
      public int getRowCount() { return 3;}

      /** DIE ANZAHL DER Spalten (5) */
      public int getColumnCount() { return 5;} 

      /** Welche Art von Objekt in Spalte c gespeichert wird */
      public Class getColumnClass(int c)
      { return columnClasses[c];}

      /** Die Ueberschrift von Spalte c */
      public String getColumnName(int c) { return headers[c];}

      /** Ob Zelle (r,c) geaendert werden darf */
      public boolean isCellEditable(int r , int c )
      { if (c<1) return true;
        else
        { ERPanelRow erm = (ERPanelRow)  data.elementAt(r);
          if (c==1) return erm.getOp().isEditable();
          if (c==2) return erm.getMa().isEditable();
          if (c==3) return erm.getWe().isEditable();
          if (c==4) return erm.getSt().isEditable();

         return false;
        }

      }

     /** Das in (r,c) gespeicherte Objekt */
      public Object getValueAt(int r  , int c)
      {  if (r>2 )  return null;

         ERPanelRow erm = (ERPanelRow) data.elementAt(r);



          if (c==0)  return erm.getEntity();
                                                             
          if (c==1) return new Boolean(erm.getOp().isSelected());
          if (c==2) return new Boolean(erm.getMa().isSelected());
          if (c==3) return new Boolean(erm.getWe().isSelected());
          if (c==4) return new Boolean(erm.getSt().isSelected());


        return null;
      }


/** gibt die Infos zu Reihe n des Modells zurueck*/
 public ERPanelRow getRow(int n)
 {
   return (ERPanelRow) data.elementAt(n);


 }


      /** setzt in Zelle (r,c) das Object value */
      public void setValueAt(Object value,int r , int c)
      {  ERPanelRow erm  = (ERPanelRow) data.elementAt(r);


        
         if (c==0){ 
                    
                    DefaultComboBoxModel dcm = (DefaultComboBoxModel) value;
                    erm.setEntity(dcm);return;
                  }  


         


         CheckBoxModel valu = new CheckBoxModel(((Boolean)value).booleanValue(),true);

         if (c==1) erm.setOp( (CheckBoxModel) valu );
         if (c==2) erm.setMa( (CheckBoxModel) valu );
         if (c==3) erm.setWe( (CheckBoxModel) valu );
         if (c==4) erm.setSt( (CheckBoxModel) valu );

        fireTableDataChanged();
      }

     public void addRow(ERPanelRow epr)
     {    
       data.addElement(epr);
     }
    

  /** beim speichern wird nur die Nummer der Entity abgelegt , da die Entities vor den RelShips wieder geladen werden */
    public int getEntityNum(int n)
    {
       ERPanelRow e = (ERPanelRow) data.elementAt(n-1);
       DefaultComboBoxModel d  = (DefaultComboBoxModel) e.getEntity();
       
       Object o =  d.getSelectedItem();

       return d.getIndexOf(o);
       

    }


     /** Die Entity , auf die in Reihe n "gezeigt" wird */
    public Entity getEntity(int n)
    {
       ERPanelRow e = (ERPanelRow) data.elementAt(n-1);
       DefaultComboBoxModel d  = (DefaultComboBoxModel) e.getEntity();
       
       Object o =  d.getSelectedItem();
       if (o instanceof String) return null;
       
       Entity en = (Entity) o;

       return en;
    }

    /** setzt eine entity auf null (auf keine) */
    public void clearEntity(int n) {
	ERPanelRow e = (ERPanelRow) data.elementAt(n-1);
	DefaultComboBoxModel d  = (DefaultComboBoxModel) e.getEntity();
	d.setSelectedItem(d.getElementAt(0));
    }



    /** Ob Reihe n auf eine starke Entity zeigt */
    public boolean isStrong(int n)
    {  ERPanelRow e = (ERPanelRow) data.elementAt(n-1);
        CheckBoxModel c  = (CheckBoxModel) e.getSt();
        return c.isSelected();

    }

    /** Ob Reihe n auf eine schwache Entity zeigt */
    public boolean isWeak(int n)
    {   ERPanelRow e = (ERPanelRow) data.elementAt(n-1);
        CheckBoxModel c  = (CheckBoxModel) e.getWe();
        return c.isSelected();

    }

       /** Ob Reihe n eine optionale Verbindung ist */
    public boolean isOptional(int n)
    {   ERPanelRow e = (ERPanelRow) data.elementAt(n-1);
        CheckBoxModel c  = (CheckBoxModel) e.getOp();
        return c.isSelected();
       
    }

        /** Ob Reihe n mehrwertig ist */
    public boolean isMany(int n)
    {   ERPanelRow e = (ERPanelRow) data.elementAt(n-1);
        CheckBoxModel c  = (CheckBoxModel) e.getMa();
        return c.isSelected();

    }


    
    /** informiert das anfragende Objekt , ob das Modell korrekt ist .
      * d.h. ob nicht z.B. eine schwache Entity ohne starke vorkommt.
      * wird von RelShipDlg gerufen
      * nach Kritik abgestellt : immer return true; 
      * @see RelShipDlg
     */ 
    public boolean canClose()
    { boolean weak = false , strong = false;
       return true; /*
       for (int i=0;i<3;i++)
       {   
          ERPanelRow e = (ERPanelRow) data.elementAt(i);
          Object o = e.getEntity().getSelectedItem();
          boolean b = o instanceof Entity;
          if (weak==false && b) weak = ( (CheckBoxModel) e.getWe()).isSelected();
          if (strong==false && b) strong = ( (CheckBoxModel) e.getSt()).isSelected();
       }
       
      if (strong == true && weak == false) return false;
      if (strong == false && weak == true) return false;

       return true;       
   */
    }



/** wird beim Klonen (cut und paste) verwendet */
public ERPanelRow kloneRow(Entity e,int num,Vector Entities)
{   
     DefaultComboBoxModel dfm1 = new DefaultComboBoxModel(Entities);
     dfm1.setSelectedItem(e);
     ERPanelRow erow1 = new ERPanelRow(dfm1,isOptional(num),isMany(num),isWeak(num),isStrong(num));
     return erow1;
}


   

}

