import javax.swing.JComponent;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.UIManager;


/** Diese Komponente zeichnet sich als Viereck(Quadrat)
 * auf die Zeichenflaeche. Sie ist das Mittelstueck einer
 * RelShip */
public class Diamond extends JComponent implements DrawAble {
    /** der uebliche link nach oben */
    public RelShip parent;

    /** verweis auf die Klassen , die die Linienzuege zu den Entities verwalten */
    //public DrawSample DrS1,DrS2,DrS3;
    public DrawSample[] drs = new DrawSample[3];

    /** zeigt an , ob auf die Komponente geklickt wurde , ie. ob sie gerade bewegt wird */
    public boolean pressed;

    /** ob die Komponente markiert ist */
    public boolean marked;
    

    /** legt die Groesse der Komponente fest und ruft updateUI() */ 
    public Diamond(RelShip r,int x , int y) {
	parent = r;
        setSize(Variables.DiamondX,Variables.DiamondY);
        centerDiamond(x,y);
        setMinimumSize(new Dimension(Variables.DiamondX,Variables.DiamondY));
        setPreferredSize(new Dimension(Variables.DiamondX,Variables.DiamondY));

        updateUI() ;       


    }

    /** ruft setUI der super Klasse */
    public void setUI(DiamondUI ui) {super.setUI(ui);}

    /** ruft setUI */
    public void updateUI() {
	setUI( (DiamondUI) UIManager.getUI(this));
	invalidate();
    }

    /** gibt den Namen des zugehoerigen UI Delegate zurueck 
     * @see BasicDiamondUI 
     */
    public String getUIClassID() { return "DiamondUI";}

 
    /** Accessor fuer marked */    
    public boolean isMarked() {
	return marked;
    }

    /** Accessor fuer marked */    
    public void setMarked(boolean m) {
	marked = m;
    }

    /** wird von BasicDiamodUI gerufen , wenn die Komponente bewegt wurde , informiert alle DrawSamples */
    public void hasChanged(int nx,int ny) {
	hasChanged(nx, ny, false);
    }

    public void hasChanged(int nx, int ny, boolean newWay) {
	pressed = true;

	for (int i=0;i<3;i++) {
	    drs[i].hasChanged(nx,ny,0);
	    if (newWay) {
		drs[i].drawAgain();
	    } else {
		correctLineOver(i);
	    }
	}
	pressed = false;  // 
    }

    /** Berechnet, ob die Linie des DrawSamples �ber den Diamanten
     * geht und korrigiert es, wenn m�glich. */
    public void correctLineOver(int samplenr) {
	DrawSample ds = drs[samplenr];
	if (!ds.hasEntity()) return;
	Line l = (Line) ds.getDrawable(1);
	Point lp = l.getLocation(),
	    dp = getLocation();
	Dimension lw = l.getSize();
	for (int i=0;i<3;i++) {
	    if (parent.ds[i] == ds) {
		// das ist das richtige DrawSample - wo ist es angedockt?
		if (parent.oco == i+1) {
		    if (lp.y +lw.height > dp.y + Variables.DiamondY) {
			if (parent.ocu == 0) {
			    parent.ocu=i+1;
			    parent.oco=0;
			    ds.hasChanged(0,Variables.DiamondY,0);
			}
			return;  
			}
		    }
		if (parent.ocr==i+1) {
		    if (lp.x < dp.x) {
			if (parent.ocl == 0) {
			    parent.ocl = i+1;
			    parent.ocr = 0;
			    ds.hasChanged(-Variables.DiamondX, 0, 0);
			}
			return;
		    }
		}
		    
	    
		if (parent.ocu== i+1) {
		    if (lp.y < dp.y ) {
			System.out.print(3);
			if (parent.oco == 0) {
			    parent.oco=i+1;
			    parent.ocu=0;
			    ds.hasChanged(0,-Variables.DiamondY,0);
			}
			return;
		    }
		}
		if (parent.ocl == i+1) {
		    if (lp.x +lw.width> dp.x + Variables.DiamondX) {
			if (parent.ocr == 0) {
			    parent.ocr = i+1;
			    parent.ocl = 0;
			    ds.hasChanged(Variables.DiamondX, 0, 0);
			}
			return;
		    }
		}
	    }
	}
    }
	

    /** wird gerufen , wenn eine anliegende Line bewegt wurde , positioniert die Komponente neu */
    public void reDraw(boolean dummy , int nx , int ny) { 
	if (pressed == false) {// wichtig , um endlos schleife (Diamond informiert Line , Line informiert Diamond ... ) 
	    // zu vermeiden
	    Point p = getLocation();
	    setLocation(p.x+nx,p.y+ny);
	    hasChanged(nx,ny);
	}
    }

    /** blubb , leer  */
    public void   canChange(boolean dummy , int nx,int ny) {}


    /** zentriert die Komponente in (x,y) */
    public void centerDiamond(int x , int y) {
	setLocation(x-20,y-20);
    }

    /** leer */
    public void setNum(int dummy) {}

    /** setzt den n-ten DrawSample der zu diesem Diamond gehoert auf d */
    public void setSample(int n,DrawSample d) {
	drs[3-n] = d; // grins 
    }
    
}
