import javax.swing.JComponent;
import java.util.Vector;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Point;
import java.awt.Dimension;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.table.TableColumn;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableCellEditor;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;

/** Diese Komponente stellt eine Entity auf der JLayeredPane des ERFrame dar , 
  * sie kann markiert (rot)  , verschoben und in ihrer Gr��e ge�ndert werden.
  * Beim Verschieben werden die registrierten DrawSamples informiert .
  * @author Christoph Unbehend
  
  */


public class Entity extends JComponent implements DrawAble
{   /** in diesem Panel werden die Knoepfe der Entity 
      * angeordnet  */
    private JPanel ButtonPanel;

    /** Diese Variable zaehlt , wieviele Reihen sich 
      * in der Tabelle  befinden. Damit kann ich vermeiden
      * dass nicht existierende Reihen entfernt werden.
      * 
      * War noetig , sie global zu machen , damit zwei 
      * interne Klassen drauf zugreifen koennen */ 
    private int cnt=0;

   
    /** Verwaltet die Scrollbars von AttributTable
      * Ist ganz praktisch , man muss der jsp nur die
      * Tabelle uebergeben , und alles andere laeuft automatisch
       */
    public JScrollPane jsp;

    /**Zeigt die Attribute der Entity an
      *Die Daten werden in AttributTableModel gespeichert  
      */

    private JTable AttributTable;
    /**Die Verwendung dieser Variable ist 
      *in AttributTableModel.java beschrieben
      * @see AttributTableModel
      */
    public AttributTableModel Attm;

    /** JLabel , das vor das JTextField Name gesetzt wird. 
      * (enthaelt also keinen Vornamen ) sondern irgendeinen
      * Text , der anzeigt dass dahinter der Name der Entity
      * eingetragen werden soll.(Bei nichtgefallen aendern)  */
    private JLabel VorName ;

    /** hier kann der Name der Entity eingegeben werden
      * wird rechts oben in den Entity Container eingefuegt */
    private JTextField Name;

    /** Verweis auf den ERFrame , der die Entity enth�lt 
     *  Solche Verweise kann man bei mir in fast jeder Klasse
     * finden. parent.parent ist hier z.B. die Start - Klasse 
     * Der Name ist evtl. ungluecklich , hat nichts mit Vererbung zu tun */
    public ERFrame parent;
    
    /** Wird gesetzt , bevor die Entity ihre DrawSamples informiert , 
      * um Deadlock zu vermeiden. Vorher konnte es passieren , dass
      * zwei Linien sich gegenseitig ununterbrochen Nachrichten schicken 
      * das sie neu gezeichnet werden sollen 
      */
    public boolean pressed;


    /** true zeigt an , das die Entity markiert wurde. 
      * Die Entity wird dann rot umrandet 
      * Wenn jetzt copy ausgeloest wird befindet sich danach ein Verweis auf this
      * im ClipBoard von Start */
    public boolean marked;

    /** Vector , der die Namen der w�hlbaren Attributtypen enth�lt , 
        der gleiche wie bei  ERFrame. d.h. wenn hier was geaendert wird , 
        ist das gleich global wirksam (d.h. fuer den ganzen ERFrame) 
     * @see ERFrame
     */
    private Vector types;

    /** hier werden die DrawSamples , die an die Entity gekoppelt sind registriert 
      * Ein DrawSample ist fuer einen Linienzug von Diamond zu Entity zustaendig
      * d.h. ein Array von 3 wuerde es auch tun 
      * naehere Infos in der Klasse selber 
      * @see DrawSample
      */
    private Vector DrawSamples = new Vector();
    

    /** Wenn diese Entity zu einer Vererbung gehoert wird eine IsaLine von
      * IsaCenter zur Entity gezeichnet. Alle IsaLines stehen in diesem Vector
      * Wenn die Entity verschoben wird werden alle IsaLines informiert */
    public Vector isalines=new Vector();  

/** Links auf alle RelShips die zu dieser Entity gehoeren */
    public Vector RelShips = new Vector();
   
/** Links auf alle Vererbungen die zu dieser Entity gehoeren */
    public Vector Vererb = new Vector();

/** Liefert einen Punkt innerhalb der Entity zurueck.
  * Dieser Punkt kann nicht nach links oder nach oben aus
  * der Zeichenflaeche geschoben werden. 
  * Dann waere die Entity naemlich fuer immer unsichtbar.
  * Nach rechts und unten geht schon , aber da kann man einfach
  * die Zeichenflaeche vergroessern. */
public Point getMiddle()
{
  Point p = getLocation(); Dimension d = getSize();
  p.x = p.x + d.width/2; p.y = p.y + d.height/2;
  return p;

}


/** gibt eine neue Entity zur�ck , die mit this identisch ist .
  * Stuetz sich auf klone Methode von AttributTableModel
  * Der ERFrame p ist der Rahmen , in den die geklonte Entity eingefuegt
  * werden soll. desttypes der types Vektor des ZielRahmens .
  * Damit kann man vergleichen , welche Datentypen im Zielfenster
  * neu angelegt werden muessen.
  */
public Entity klone(ERFrame p,Vector  desttypes)
{ Point pt = getLocation();
  

  AttributTableModel a = Attm.klone(desttypes);
  Entity e = new Entity(p,types,getName(),a,Variables.EntityY,Variables.EntityX);
  e.setLocation(pt.x,pt.y);
  return e;


}  


/** Dieser Konstruktor wird benutzt , wenn ein ERFrame geladen wird
  * d.h. nicht eine leere Entity wird angelegt , sondern eine in der schon
  * Daten drin stehen. Zusaetzlich uebergeben werden das schon aufgebaute
  * AttributTableModel , die y-Size der Entity (kann man ja aendern) und
  * der name der Entity uebergeben.
 */
    public Entity(ERFrame p,Vector ttypes,String name,AttributTableModel attm,int esizey,int esizex)
    {
        parent = p;      types = ttypes;
        
        // setzt die Groesse der Entity
        setSize(esizex,esizey);
        setMinimumSize(new Dimension(Variables.EntityX,Variables.EntityY));
        setPreferredSize(new Dimension(Variables.EntityX,Variables.EntityY));

        // wenn das false ist wird die Entity durchsichtig 
        if (Variables.EntityOpaque==true) setBackground(Variables.EntityBackGround);
        setOpaque(Variables.EntityOpaque);

       /* Die naechsten Zeilen bauen die beiden Textfelder der Entity auf */       
       Name = new JTextField(name);
       Name.setSize(100,20);
       Name.setVisible(true);
       add(Name);
       Name.setLocation(110,10);
        VorName = new JLabel();
        VorName.setSize(80,20);
        VorName.setBackground(Color.green); //??Gray passt eh net
        VorName.setVisible(true);
        VorName.setLocation(10,10);
        VorName.setText("Name: ");
        add(VorName);
        JCheckBox chb = new JCheckBox("");

        /* jetzt ist die Tabelle dran*/
        Attm = attm;
        AttributTable = new JTable(Attm);
 
        // comboEdit = new ComboBoxEditor(v,true);
         // nach den naechsten Befehlen weiss die Tabelle , wie ihre Zellen gezeichnet werden
       AttributTable.setDefaultRenderer(DefaultComboBoxModel.class,new ComboBoxRenderer());
        AttributTable.setDefaultEditor(DefaultComboBoxModel.class,new ComboBoxEditor(ttypes,true)) ;
       // AttributTable.setDefaultRenderer(CheckBoxModel.class,new CheckBoxRenderer());
        //AttributTable.setDefaultEditor(Boolean.class,new DefEd(chb));
        AttributTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        AttributTable.setRowHeight(20);

// die Schleife setzt die Spaltenbreite der Tabelle
        TableColumn column = null;
        for (int i = 0; i <= 5; i++) 
         {
   		 column = AttributTable.getColumnModel().getColumn(i);
  		   if (i==0) {   column.setPreferredWidth(75);}
 		   if (i==1) {   column.setPreferredWidth(75);}
   		   if (i>1)  {   column.setPreferredWidth(25);}
  	   }

      // jetzt wird die ScrollPane fuer die Tabelle angelegt 
        jsp = new JScrollPane(AttributTable);
        jsp.setSize(250,100);
        jsp.setLocation(20,60);
        jsp.setVisible(true); AttributTable.setVisible(true);
        add(jsp);

        // die JButtons werden angelegt , in das Panel eingefuegt
        // und am unteren Rand der Entity eingefuegt
        ButtonPanel = new JPanel();

        JButton AddButton = new JButton("Add");
        AddButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               Integer qqd = new Integer(cnt);cnt++;
               AttributRowModel R = new AttributRowModel("",new DefaultComboBoxModel(types));
               Attm.addRow(R);
           
           } } );

        JButton RemButton = new JButton("Remove");
        RemButton.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               int i = AttributTable.getSelectedRow();
               
               if (i<0 || i>=AttributTable.getRowCount()) return;
               cnt -- ;
                
               // diese Zeile sind wichtig , Sie beenden den EditingMode der
               // Tabelle bevor eine Zeile geloescht wird.
               // Sonst kann es zu haesslichen Effekten kommen 
              if (AttributTable.isEditing()) 
              {
                  TableCellEditor cellEditor = AttributTable.getCellEditor();           
                  if (cellEditor != null) 
                  {
                          cellEditor.stopCellEditing();
                  }
              }             

               Attm.removeRow(i);

               } } ); // P.S. eigentliche mag ich solche internen Klassen nicht


        ButtonPanel.setBackground(Color.lightGray);
        ButtonPanel.add(AddButton);
        ButtonPanel.add(RemButton);
        ButtonPanel.setSize(250,38);
        ButtonPanel.setLocation(5,160);
        ButtonPanel.setVisible(true);
        add(ButtonPanel);
        hasResized(); // s.u. 
        updateUI() ;  // s. auch unten ...


    }



/** wird aufgerufen , wenn eine neue Entity in ein Modell eingef�gt wird 
  * legt seit neuestem nur noch die leere Tabelle und einen leeren String an
  * und ruft dann den oberen Konstruktor mit diesen Werten .
*/
public Entity(ERFrame p,Vector v)
    {    
   
        this(p,v,new String(""), new AttributTableModel(),Variables.EntityY,Variables.EntityX  );

     }



public void setUI(EntityUI ui) {super.setUI(ui);}

public void updateUI()
     { setUI( (EntityUI) UIManager.getUI(this));
       invalidate();

      }

public String getUIClassID() { return "EntityUI";}

/** Accsessor fuer Attm  */
public AttributTableModel getTableModel()
   { return Attm;}


/** Accsessor fuer Name  */
public String getName()
    { return Name.getText();}

/** Accsessor fuer marked  */
public boolean isMarked()
     { return marked;}

/** Accsessor fuer marked  */
public void setMarked(boolean m)
     {  marked = m; }

/** Wenn die Entity in eine Tabelle  
 *  eingefuegt wird (z.B. im RelShipDlg ) 
 *  erscheint dieser String */
public String toString()
     {
        return getName();
     }


/** wird von @see BasicEntityUI gerufen , wenn die Entity verschoben wird 
 *  informiert alle registrierten DrawSamples , da� die Entity verschoben wurde 
 * @see DrawSample
*/
public void hasChanged(/*int nx,int ny*/)
    {
       pressed = true;
       int n = DrawSamples.size();

       DrawSample drs;
       for (int i = 0; i<n ; i++)
       {
        drs = (DrawSample) DrawSamples.elementAt(i);
        drs.drawAgain();
       }
       pressed = false;
     
        n = isalines.size();
        for (int i = 0; i<n;i++)
       {
         IsaLine isl =(IsaLine) isalines.elementAt(i);
          isl.alterLine(this);

       }
    

      }

/** leer , wird von anderen Klassen , die DrawAble erfuellen gebraucht */
public void setNum(int n)
 {              } 
     

/**  steht im Interface DrawAble wird nicht gebraucht */
public void hasChanged(int x ,  int y)
{}

   /** wird von einem DrawSample gerufen , um die Entity zu informieren , da� sie sich 
     * verschieben soll . Die Methode ist ueberfluessig , seit
     * die Lines nicht mehr immer in der Mitte der Entity angedockt werden.
     * ich lasse sie trotzdem mal drinstehen ( wer weiss zu was sie noch gut ist )
     * @see DrawSample
      */
     public void reDraw(boolean c,int nx,int ny)
     {  if (pressed == true) return;
        Point p = getLocation();
        p.x = p.x + nx; p.y = p.y + ny;
        setLocation(p.x,p.y);
        hasChanged();
     }

     /* Damit wollte ich anfangs ein Veto gegen das 
       * verschieben der Entity moeglich machen.
       * Lines haetten zuerst anfragen muessen ob die Entity mit
       * dem Verschieben einverstanden ist. Ich hab allerdings
       * nie irgendwelche Befehle in diese Methode geschrieben */
    //public void canChange(boolean c,int nx,int ny)
     //{

    // }


     /** diese Methode fuegt einen DrawSample in den DrawSamples Vektor
       * von Entity ein */
     
     public void addDrawSample(DrawSample drs)
     {  DrawSamples.addElement(drs);
        
     }

     /** diese Methode loescht einen DrawSample aus dem DrawSamples Vektor
       * von Entity  */

     public void removeDrawSample(DrawSample drs)
     {  DrawSamples.removeElement(drs);
        
     }



    /** �berpr�ft , ob der linke obere Eckpunkt ( getLocation() )
     *  sich im �bergebenen Rechteck befindet 
     *  Wird zum Markieren verwendet ( von der Methode 
     */
    public boolean isIn(int x1,int y1,int x2,int y2)
    {
        Point p = getLocation() ;
	Dimension d =  getSize();
	
	//swap
        if (x1 > x2 ) { int s = x1; x1 = x2; x2 = s;}
        if (y1 > y2 ) { int t = y1; y1 = y2; y2 = t;}

        

        if (p.x<x1) return false;
        if (p.x+d.width>x2) return false;
        if (p.y<y1) return false;
        if (p.y+d.height>y2) return false;

        return true;

    }




   /** wird vom BasicEntityUI nach resizen aufgerufen , um Komponenten neu anzuordnen
     * Wenn die Entity vergroessert wird , wird hier die Tabelle vergroessert
     */

   public void hasResized()
   {
     Dimension d = getSize();
      jsp.setSize(d.width - 40,d.height - 100); // die Zahlen hier lasse ich fest eingecodet      
                                       // macht keinen Sinn zu viel in Variables 
                                       // zu schreiben <hardcode> Markierung fuer grep         

     ButtonPanel.setLocation(5,d.height - 40);
     AttributTable.invalidate();
     jsp.validate();

   }

  /** wird vom BasicEntityUI nach resizen aufgerufen , um Komponenten neu anzuordnen
     * Wenn die Entity vergroessert wird , wird hier die Tabelle vergroessert
     * Diese ist in X Richtung
     */

   public void hasResizedX()
   {
     Dimension d = getSize();
      jsp.setSize(d.width-40,d.height - 100); // die Zahlen hier lasse ich fest eingecodet      
                                       // macht keinen Sinn zu viel in Variables 
                                       // zu schreiben <hardcode> Markierung fuer grep         

     //ButtonPanel.setLocation(5,d.height - 40);
     AttributTable.invalidate();
     jsp.validate();

   }
   /** Informiert die Entity , dass sie zu einer 
     * weiteren Vererbung gehoert. */
   public void addIsaLine(IsaLine isl)
   {
        isalines.addElement(isl);

   }

    /** Wenn eine Vererbung geloescht wurde muss
     * eine IsaLine weniger informiert werden */
   public void remIsaLine(IsaLine isl)
   { isalines.removeElement(isl);}



/** das hier gehoert zu einem ersten Versuch ,
  * die Entity nach SQL umzuwandeln */
  public String createSQL()
  {    int numofpk = 0;
       int numofRows = 0;
       String name = getName();
       String ret = "create table " + name + " (\n";
       String pk = "primary key (";

       int n = Attm.getRowCount();
    
       for(int i = 0; i<n ; i++)
       { 
         AttributRowModel arm = Attm.getRowAt(i);
         String snew = ""; 
         String nam = arm.getName();
         boolean ispk = arm.getPk().isSelected();
         boolean isuni = arm.getUn().isSelected();
         boolean isopt = arm.getOp().isSelected();
         String domain = (String) arm.getDomain().getSelectedItem();         

         String row = "";
         if (numofRows>0)  row = row + ",\n" + nam + " " + domain + " " ;
 
         else  row = row + nam + " " + domain + " " ;
         numofRows++;

         if (isuni) row = row + "unique ";
         if (!isopt) row = row + "not null " ;
         if (ispk) { if (numofpk == 0) pk = pk + nam;
                     else pk = pk + "," + nam ; 
                     numofpk++;
                   } 
           ret = ret + row;
        }

       ret = ret + "\n" ;
       pk = pk + ")";       
       ret = ret + pk;
  
       ret = ret + " \n);\n\n";     
          
       return ret;

  }

 /**sorgt daf�r, da� die AttributTable aus dem editing mode genommen wird, 
 * damit werden geaenderte Namen der Attribute gespeichert
 */
 public void shootAbTable()
 {
 
   if ( AttributTable.isEditing()) 
                {
                  TableCellEditor cellEditor = AttributTable.getCellEditor();           
                  if (cellEditor != null) 
                  {
                     cellEditor.stopCellEditing();    // schiesst ebenfalls den Editing Mode ab (wenn man auf OK drueckt)
                  }
                }             
 }

 public void setName(String s)
 {
   Name.setText(s);
 
 }

public void focusName() {
    Name.selectAll();
    Name.requestFocus();
}

public boolean knowsDrawSample (DrawSample ds) {
    return DrawSamples.contains(ds);
}

public void correctLineOver(DrawSample ds) {
    Line l = (Line) ds.getDrawable(3); // letzte Linie
    Point p = getLocation();
    Dimension d = getSize();
    //FIXME: Wie komme ich an die Positionen ran..?
    if (l.waagrecht) {
    } else {
    }
}

}
