import javax.swing.JComponent;
import javax.swing.UIManager;

/** Die halbkreisfoermige komponente im Zentrum einer Vererbung */
public class IsaCenter extends JComponent 
{   

    /** link auf die ISA , der this zugeordnet ist */
    ISA parent;
  
    /** true , wenn die Komponente gerade (d.h. jetzt) verschoben wird */
    boolean pressed; 

    /** wenn die ISA markiert ist , dann auch ISACenter */
    public boolean marked;  
   

    /** Konstruktor , setzt lediglich die Groesse der Komponente */    
    public IsaCenter(ISA r,int x , int y)
    {            parent = r;
        setSize(Variables.IsaCenterX+1,Variables.IsaCenterY/2+4);
        setLocation(x,y);
      
        setVisible(true); 

        updateUI() ;       


     }


     /** ruft setUI der Oberklasse */
     public void setUI(IsaCenterUI ui) {super.setUI(ui);}

     /** ruft setUI */
     public void updateUI()
     { setUI( (IsaCenterUI) UIManager.getUI(this));
       invalidate();

      }

    
    /** gibt den String "IsaCenterUI" zurueck */
    public String getUIClassID() { return "IsaCenterUI";}

     /** Accessor fuer marked */
     public boolean isMarked()
     { return marked;}

     /** Accessor fuer marked */
     public void setMarked(boolean m)
     {  marked = m; }

  
}
