import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.*;

/** Wird vom DeskTopManager aufgerufen , wenn
  * das jeweilige Ereignis fuer einen Internal Frame
  * eingetreten ist 
  *  
  * @see Start*/

public class IntFrameListener extends InternalFrameAdapter
{  /** Damit interalFrameActivated die Start-Klasse findet */
   private Start parent;

  /** setzt nur die parent Variable auf s */
  public IntFrameListener(Start s)
    { parent = s;}


  /** Beim Aktivieren eines Fensters 
   * ruft setActiveFrame() von Start */ 
  public void internalFrameActivated(InternalFrameEvent e)
  {   JInternalFrame jif = (JInternalFrame) e.getSource();

      if (jif instanceof TextFrame) parent.activ4Text();
      
      else if(jif instanceof ERFrame) parent.activ4ER();
      
      else parent.activ4Help();

      parent.setActiveFrame(jif);

  }

  /** raeumt hinter einem geschlossenen internen Rahmen auf */
  public void internalFrameClosed(InternalFrameEvent e)
  { 
    //JInternalFrame jif = (JInternalFrame) e.getSource();
   // System.out.println("internal frame closed " + jif);
   
  }

  /** setzt den aktiven Rahmen auf null */  
  public void internalFrameDeactivated(InternalFrameEvent e)
  {// System.out.println("deactivated");
      parent.activ4Null();
      parent.setActiveFrame(null);

  }

  

/** beim schliessen eines fensters */
public void internalFrameClosing(InternalFrameEvent e)
  {   
      //System.out.println("internal frame closing " );
      if (Variables.jdkRevision >= 3) 
       { //internalFrameClosed(e);
         JInternalFrame jif = (JInternalFrame) e.getSource();
	 try {jif.setClosed(true);} catch (Exception  eee) {}
       }
      //parent.activ4Null();
   
  }


}
