import javax.swing.JInternalFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



/** Action zum Anlegen einer neuen RelationShip */
public class AddRelAction implements ActionListener
{ 
   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */
private Start parent;


   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
public AddRelAction(Start p)
   { 
      parent = p;
   } 

  
  /** Wird ausgefuehrt , wenn jemand auf den Knopf bzw.
    * Menueeintrag zum Einfuegen einer RelShip drueckt.
    * Ruft die Methode addRel von ERFrame(dem aktiven!) auf.
    * 
    * @see ERFrame */
public void actionPerformed(ActionEvent ae)
   {  
      JInternalFrame inf = parent.getActiveFrame();
      
      if (inf instanceof ERFrame)
        {      ((ERFrame) inf).addRel();

        }

   }


}
