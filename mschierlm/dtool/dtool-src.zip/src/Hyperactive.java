import javax.swing.event.*;
import javax.swing.*;
import javax.swing.text.html.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class Hyperactive implements HyperlinkListener 
{



  public void hyperlinkUpdate(HyperlinkEvent e) 
  {
     
  
   try {
  
    if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) 
     {
       JEditorPane pane = (JEditorPane) e.getSource();
//       System.out.println(e.getURL());
       pane.setPage(e.getURL());
      
 
     }  } catch (IOException ex) {ex.printStackTrace(System.err);}

}

} //end class
 
