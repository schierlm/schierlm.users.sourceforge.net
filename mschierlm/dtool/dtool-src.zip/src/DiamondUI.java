import javax.swing.plaf.ComponentUI;

public abstract class DiamondUI extends ComponentUI
{


}
