import java.util.*;

/**Enth�lt die Informationen zu einer Reihe einer Relationalen Tabelle
  * wird beim Umwandeln von ER -> Sql verwendet
*/
public class TableRow
{
  /**link auf die Tabelle, zu der diese Reihe geh�rt*/
  public Table parent;

  /** Attributname*/
  public String Name;

  /** bei Attributen, die von anderen Tabellen �bernommen wurde steht 
      hier aus welcher Tabelle sie stammen
   */ 
  public int fromTable;
  
  
  /**Wenn mehrere Attribute in einer Tabelle den gleichen Namen haben wird einer
     ge�ndert. Hier steht der urspr�ngliche Name
  */
  public String realName;


  /** realName ist evtl. nicht korrekt, da der Name des anderen Attributs 
      sp�ter nochmal ge�ndert werden k�nnte , aus Sicherheitsgr�nden wird
      deshalb hier schonmal die Nummer des Attrinuts in der referernzierten 
      Tabelle gespeichert ( aber noch nicht verwendet)
   */
  public int realInt;  
  
  /**Datentyp*/
  public String Type;
  
  /**Not Null*/
  public boolean nn; 
  
  /**Primary Key*/
  public boolean pk;
  
  /**Unique*/
  public boolean un;

  /** return pk*/
  public boolean isPk()
  {
  
   return pk;
  }
  
  /**check this.getName() in allem was hier drinnen steht*/
  private String checkIn = "";
  /**Hier stehen alle Foreign Keys drinnen*/
  public Vector fkey = new Vector();
  
//  publicHashTable Fkeys = new HashTable
  
  /**Konstruktor , ganz normal */
  public TableRow(String name,String type,boolean notnull,boolean primkey,boolean uniq)
  {
    Name = name; Type = type; nn = notnull; pk = primkey; un = uniq;
  }
  
  
  /**foreignkey auf rn wird nur angelegt, wenn this.pk true ist*/
  public void addFkeyIfPk(int rn) ///ge�ndert auf int!!
  { if (pk==false) return;
     addFk(rn);
    
  }
  
  /**geht das bei mehreren Checks ???????????
     �berpr�fen 
  */
  public void addCheck(String s)
  {
    checkIn=s;

  }
  
  
 
  
  private int uniq= 0;
  

  /** Legt einen ForeignKey auf die Table Nummer s an*/  
  public void addFk(int s) 
  {   //Integer ss = new Integer(s);
    RefClass rcl = new RefClass(s,"");
      //int ji = fkey.size();////////////////////////korrekt????????????????????/////////////////////////
      //if (fkey.contains(ss)) { return;}//s1 = s + uniq;uniq++;addFk(s);}
    fkey.add(rcl);
  }
  
  /**Wie addFk(int), speichert aber zus�tzlich den Namen des referenzierten Attributs (nx)  */
  public void addFk(int s,String nx) 
  { 
    RefClass rcl = new RefClass(s,nx);
   
    fkey.add(rcl);
  }

 
  
  /** gibt den String in Name zur�ck */
  public String getName()
  {
    return Name;
  }
  
 /** gibt den String in Name zur�ck */
  public void setName(String s)
  {
    Name = s;
  }


  /**wie toString(unten),  aber zyklische Referenzen werden nicht vermieden#
     funktioniert evt. nicht mehr , nicht �berpr�ft, nicht mehr verwenden
   */
  public String toString()
  {
    Hashtable ht = null;Vector a = null;
    return toString(ht,"",a,false);
  
  }


  /** Gibt den String mit dem Teil des  SQL Befehls der zu diesem Attribut geh�rt zur�ck
    * In der hashtab stehen alle Tabellen, die schon angelegt wurden(zum �berpr�fen, ob ein foreign key delayed werden mu�)
    * Aufgeschobene ForeignKeys werden im Vector alters gespeichert. doPk gibt an ob ein evt. Primary Key sofort oder erst
    * sp�ter gekennzeichnet wird. Goal ist der Name der Tabelle, zu der dieses Attribut geh�rt. 
    */
  public String toString(Hashtable alht,String goal,Vector alters,boolean doPk)
  { String sref = "";
   
    String s = "";
    String scheck = "";

    s = s + Name + " " + Type + " "  ;
    if (nn) s = s + "NOT NULL";
    if (un) s = s + " UNIQUE";
    if (pk && doPk) s = s + " PRIMARY KEY";
    int i = fkey.size();
    if (i!=0)
    {  String salt =  " REFERENCES "; 
       int jj=0;
       String addToRef = "";
       if (!realName.equals(Name)) addToRef = "(" + realName + ")";

       for (int j=0;j<i;j++) 
         { 
	   
	   RefClass refCl = (RefClass) fkey.elementAt(j);
	   int refto = refCl.refTo;
	   if (refto==0) System.out.println("0 Reference in Table " + parent.Name + " , Attribut  " + Name);
         String refStr = "";
	   if (refCl.refName.equals("")) refStr = parent.getTableName(refto) + addToRef;
	   else refStr = parent.getTableName(refto) + "(" + refCl.refName + ")";
	 
	   boolean b = true;
	   
	   if (alht != null) b = alht.containsKey("" + refto);
	   
	     
	   if (b) {
	            sref = sref + refStr + ",";
		    jj++;
		  }
	 
	   else { 
	           //System.out.println("Creating AlterTable " + goal + " " + refStr + " // adding REF "+ Name);    
	           if (refto!=0)  {
		    AlterTable at = new AlterTable(goal,refStr);
	            at.addRef(Name);
	            alters.addElement(at); }
	        }
	 }
     
      if (jj>0) 
      {   sref =  sref.substring(0,sref.length()-1) ;  
       s = s + salt;
       if (jj>1) s = s + "(";  
        s = s + sref;
       if (jj>1) s = s + ")";	
      }
       
       
       
      
    }
    
    String sc = "";
    
    boolean b = checkIn.equals("");
    //System.out.println("CHECKIN22222 ::::::::::" + checkIn + "   boolean b ::" + b);
    
    if (!b)
    { 
      sc = sc +  " CHECK (" + Name + " in (" + checkIn + "))";
      //System.out.println("Hallooooooooo :: " + checkIn + " /// " + sc); 
    }
   
   
    return  s  + sc + " ,\n";
         
  }

/**Hier stehen alle Befehle, um die Konsistenz dieser TableRow zu �berpr�fen*/
 public void getErrors()
 {
   if (Name.equals("") || Name.equals(" ")) parent.addError("Attribut ohne Namen");
   String s = parent.CheckString(Name); 
   if (!s.equals("")) parent.addError("Attribut " + Name + " enth�lt die illegalen Zeichen " + s);
 }
 
 public void NotNotNullIfPk()
 {
  if (pk==false) return;
  nn = false;
 }

}
