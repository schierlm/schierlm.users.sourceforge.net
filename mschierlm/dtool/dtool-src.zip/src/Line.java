import javax.swing.JComponent;
import javax.swing.UIManager;
import java.awt.Point;
import java.awt.Rectangle;


/** Diese Komponente wird zum Darstellen einer RelationShip verwendet .
    Es gibt pro RelShip 3 , 6 , oder 9 Lines . 
 * @see RelShip */
public class Line extends JComponent implements DrawAble
{   
    /** Wenn true ist this eine waagrechte Linie */
    public boolean waagrecht; 

    /** die Richtung der Line , z.B. um Pfeile bei schwachen Entities zu zeichnen */
    boolean direction;

    /** die Laenge in Pixel */
    int length;

    /** Der DrawSample , der die Linie verwaltet 
     * @see DrawSample */
    DrawSample DrS;

    /** Wenn true wird die Linie rot(?) gezeichnet */
    boolean marked;

    /** 1-3 zur Identifikazierung der Linie */
    public int num;

    /** wenn die Linie verschoben wird (per Maus) wird pressed=true gesetzt , um 
      * zu verhindern , dass sie von den benachbarten Linien versetzt werden kann */
    boolean pressed=false;

    /** wird beim Verschieben einer benachbarten Linie gebraucht .
      * 
      * Wenn false , wird nur die Groesse der Linie geaendert ( da die geaenderte Linie darunter oder rechts von this war ) 
      * bei true muss auch die Position geaendert werden  
     */
    boolean connection;  // true heisst setLocation wenn  von left , d.h. kleinerer

     /** gibt an , ob Zusatzinfos (weak,optional,many) gezeichnet werden */
      
    int special=0;
    boolean left;

    public Line(DrawSample d) {
	DrS = d;                                   
        updateUI() ;
    }

  /* public void dump()
   {
     DrS.dump();

   }*/


     /** Setzt die uebergebenen Attribute der Line : 
       * bp? : die Koordinaten
       * len : die Laenge 
       * w : waagrecht ? */
     public void setLine(int bpx,int bpy,int len,boolean w,boolean c,boolean dir)
     {  length = len; direction = dir;
        waagrecht =  w;connection = c;
        setLocation (bpx,bpy);
        if (waagrecht == true) setSize(length+1,2*Variables.SpecialD+1);
        else setSize(2*Variables.SpecialD+1,length+1);
       
        setVisible(true);

     }

      
      void rotate()
     {   if ( (length >= 0) || (pressed ==  true )) return;
         else
         
           {  Point p = getLocation();
            if (waagrecht ==true) setLocation(p.x+length,p.y);
            else setLocation(p.x,p.y+length);

            length = -1 * length; connection = !connection;direction = !direction;
          
         }

     }

     public void setUI(LineUI ui) {super.setUI(ui);}

     public void updateUI()
     { setUI( (LineUI) UIManager.getUI(this));
       invalidate();

      }

    public String getUIClassID() { return "LineUI";}




    /** Accessor fuer marked */
     public boolean isMarked()
     { return marked;}

    /** Accessor fuer marked */
     public void setMarked(boolean m)
     {  marked = m; }

     /** ruft hasChanged in DrawSample 
       * @see DrawSample */
     public void hasChanged(int nx , int ny)
     {
         DrS.hasChanged(nx,ny,num);

  
     }

     /** Hilfsfunktion , zeichnet eine waagrechte Line */
     void SetX( boolean left , int dw)
     {        Point p = getLocation();

              if (left==connection){ length = length -  dw;

                              setLocation(p.x+dw,p.y);
                              if (length<0) rotate();
                              if (waagrecht == true) setSize(length+1,2*Variables.SpecialD+1);

                            }
                   else     { length = length +  dw;
                               
                              if (length<0) rotate();
                              if (waagrecht == true) setSize(length+1,2*Variables.SpecialD+1);
                             
                            }


     }

     /** Hilfsfunktion , zeichnet eine vertikale Line */
    void SetY(boolean left , int dw)
     {    Point p = getLocation();
       
            if (left == connection)
             {
                length = length -  dw;
                setLocation(p.x,p.y+dw);
                if (length<0) rotate();
                if (waagrecht == false)    setSize(2*Variables.SpecialD+1,length+1);
               
             }
             else
             {  length = length +  dw;
                
                if (length<0) rotate();
                if (waagrecht == false)    setSize(2*Variables.SpecialD+1,length+1);

             }



     }


/** wird vom DrawSample gerufen , wenn die Line neu gezeichnet werden muss */
public void   reDraw(boolean le , int nx , int ny)
   {  if (pressed == true) return;
      left = le;
     
     Point p = getLocation();
       

        if (waagrecht == true)
         { 
           SetX(left,nx);
           p = getLocation(); 
    

            setLocation(p.x,p.y+ny);

           if (ny!=0) DrS.hasChanged(0,ny,num);
         }
         else
         { 
        

           SetY(left,ny);
           p = getLocation(); 
           setLocation(p.x+nx,p.y);
       
           
           if (nx!=0) DrS.hasChanged(nx,0,num);
         }
         }

/*     public void   canChange(boolean c , int nx,int ny)
     {

     } */

 
/** Legt fest an welcher Position im DrawSample sich die Line befindet */ 
public void setNum(int n)
     { num = n;}

/** Gibt an ,  an welcher Position im DrawSample sich die Line befindet */
 public int getNum()
     { return num; }


 /** Legt fest , ob etwas zusaetzlich gezeichnet werden muss
     (fuer strong , many .... ) */
 public void setSpecial(int b)
 {  special = b;


    repaint();

 }

  /** Accessor fuer special */
 public int getSpecial()
 {  return special ;
 }

/** Gibt Position und Umfang der Entity zurueck */
 public Rectangle getEntityRec()
 {
   return   DrS.getEntityRec();
 }

 /** Setzt die Position der Line Relativ zur Entity . 
    * 0 =links / oben , 1 = rechts / unten */
public void setRelative(double d)
{
  DrS.dockPer=d; //System.out.println(d);

}

}
