import javax.swing.*;
import java.util.*;
import java.awt.Color;
import javax.swing.event.*;
import java.awt.BorderLayout;
import javax.swing.border.EtchedBorder;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;

/** Das Hauptfenster der Anwendung 
 * enthalt viele Methoden , die von anderen Klassen verwendet werden.
 * (z.B. das ClipBoard und die Open/Save Dialoge )
 * Wird in den von DTool.java erzeugten JFrame eingefuegt.
 * @author Christoph Unbehend
 * @version 20.6.99 (lang her)  Mai 19100
 */
public class Start extends JPanel { 

    /**URL f�r Startseite der online-Hilfe*/

    /** Wird Im AboutDialog angezeigt*/
    ImageIcon about = new ImageIcon(Start.class.getResource("html/about.gif"));

    /** Dynamisches Menu , enth�lt alle internen Fenster*/
    public JMenu jmFenster = new JMenu("Fenster");


    /** Alle Buttons und Menueintrage der Anwendung, die
	je nach Art des aktiven Fensters (de)aktiviert werden
	m�ssen.
    */

    private JMenu jmExp;

    private JMenuItem jmInsEnt, jmInsRel, jmSave, jmSaveAs, jmCopy,
	jmPaste, jmGener, jmSizeMinus, jmSizePlus, jmTypes, jmDel,
	jmCut;

    private JButton jbInsEnt,jbInsRel,	jbSave,	jbCopy,	jbPaste,
	jbGener, jbSizeMinus, jbSizePlus, jbTypes, jbDel,
	jbCut;
    
    public JButton jbSwitch;


    /** Das Hilfefenster der Anwandung */
    public HelpFrame helpFrame=null;

    /** 0 wenn dass ClipBoard fuer Text leer ist */
    public int clipTxt=0;

    /** 0 wenn dass ClipBoard fuer ERFrames leer ist */
    public int clipER=0;

    /** 0 wenn nichts markiert ist */
    public int selectER=0;


    /** der JFrame der Anwendung(wird an Dialoge als Hauptfenster uebergeben) */
    public JFrame jfr;

    /** Die Menuleiste , wird von DTool.java eingefuegt*/
    public JMenuBar jmbar = new JMenuBar();

    /** Der Toolbar der Anwendung , teilt sich viele Actions mit JMenuBar */
    public JToolBar jtb = new JToolBar();

    /** Um noch nicht benannte Frames eindeutig zu machen */
    public int noNameCount=0;

    /** zur Auswahl der Konvertier-Klasse
     * In diesem ComboBoxModel  
     * werden alle verfuegbaren Klassen , die das Interface Convert erfuellen
     * abgelegt. Die selektierte Klasse wird zum Konvertieren verwendet.
     * @see Convert   
     * @see DefaultComboBoxModel 
     */
//    public DefaultComboBoxModel convertDfm = new DefaultComboBoxModel(Variables.convertArray);

    /** ein Vector , der als ClipBoard f�r die ERFrames verwendet wird 
     * In diesen Vector werden , wenn jemand auf Copy oder Cut drueckt 
     * Verweise auf die markierten  Entities , RelShips und Vererbungen 
     * gespeichert. Bei einer Paste-Action werden die Objekte in diesem Vector
     * geklont und in den aktiven InternalFrame eingefuegt.
     * Bitte beachten : bei TextFrames wird das Standard ClipBoard des BetriebsSystems
     * verwendet 
     */
    public Vector ClipBoard = new Vector();

    /** Ein Verweis auf den momentan aktiven JInternalFrame.
     * Jedesmal , wenn der aktive Rahmen wechselt , setzt
     * IntFrameListener diese Variable um
     * @see IntFrameListener  */
    public JInternalFrame ActiveFrame;

    /** Wenn ein neuer Text - oder ERFrame angelegt wird ,
     * wird ein Verweis auf ihn am Ende dieses Vectors abgelegt. */
    public Vector Frames = new Vector();

    /** Dies ist ein Verweis auf den IntFrameListener , der schon bei 
     * ActiveFrame erwaehnt wurde. */
    public IntFrameListener ifl;


    /** JDesktopPane ist eine Swing-Klasse , in die JInternalframes 
     * eingefuegt werden koennen. Diese nimmt den groessten Teil
     * des JPanels Start (aka this) ein */
    public JDesktopPane jdp = new JDesktopPane();

    /** Der JFileChooser stellt Routinen zum Oeffnen von Open bzw. Save
     * Dialogen zur Verfuegung.
     * @see JFileChooser */
    public JFileChooser chooser = new JFileChooser();

    /** Der Konstruktor erledigt im wesentlichen folgendes :
     *  - ein paar Initialisierungen fuer die Open und Save Dialoge
     *  - das Aufbauen des Panels
     *  - ruft 2 Methoden , die die Toolbars aufbauen und das Lokk & Feel setzen */
 
    public Start(JFrame jf)
    { 
	super(); 
	String s="";

	//   try 
	//   {
        s = java.lang.System.getProperty("java.version");
	//   } catch (Exception e) {}
	String osver = java.lang.System.getProperty("os.version");
	String usdir = java.lang.System.getProperty("user.dir");
	String osnam = java.lang.System.getProperty("os.name");
	String osarc = java.lang.System.getProperty("os.arch");
	String sep = java.lang.System.getProperty("file.separator");
   
   
	jfr = jf;                         // damit ich spaeter Dialogen dasHauptfensteruebergeben kann
	ifl = new IntFrameListener(this); // diese Variable wird oben erklaert 
           
  
	// ein bisschen Optik
	setLayout(new BorderLayout());
	jmbar.setBorder(new BevelBorder(BevelBorder.RAISED));    
	jtb.setBorder(new EtchedBorder());
      
	// Diese Befehle legen FileFilter fuer die Dialoge an 
	// als Standard ist ff1 aktiviert
	chooser.setMultiSelectionEnabled(false);
	String [] dbf = new String[] { "dbf"};
	SimpleFileFilter ff1 = new SimpleFileFilter(dbf,"ER-Model (*.dbf)");
	chooser.addChoosableFileFilter(ff1);
       
	String [] sql = new String[] { "sql"};
	chooser.addChoosableFileFilter(new SimpleFileFilter(sql,"SQL TextFile (*.sql)"));
	chooser.setFileFilter(ff1);
      
	setLnF(); // setzt das Look and Feel 

	System.out.println("JDK " + s );
	if (s.startsWith("1.") && s.charAt(2) >= '0' && s.charAt(2) <= '9') {
	    Variables.jdkRevision = s.charAt(2) - '0';
	} else {
	    Variables.jdkRevision = 99;
	    System.out.println("+++ WARNING: could not detect jdk version.\n"+
			       "Assuming JDK 1.4+.");
	}
	
	if (osnam.startsWith("Win")) osnam = osnam  + " :-(";
	if (osnam.startsWith("Lin")) osnam = osnam  + " :-)";
	System.out.println("ON "   + osarc + " " + osnam + " " + osver);
	System.out.println("IN " + usdir);
      
	initActions(); // legt Tool und Menubar an und verknuepft die Items mit Actions
	add(jdp,BorderLayout.CENTER);
	jbSwitch.setEnabled(false);
    }
   
/** Oeffnet ein HilfeFenster oder aktiviert das schon vorhandene */
    public void Help()
    {
	if (helpFrame==null) 
	    { 
		try {helpFrame = new HelpFrame(this);} catch (Exception exx) {}
		Frames.addElement( helpFrame);
		if (Frames.size() > 1 ) jbSwitch.setEnabled(true);
		jdp.add( helpFrame);
		helpFrame.setVisible(true);
		helpFrame.setSize(Variables.ERFrameX,Variables.ERFrameY);
		helpFrame.setLocation(Variables.ERFrameLocX,Variables.ERFrameLocY); 
	    }     

	helpFrame.toFront(); helpFrame.moveToFront();
	jdp.getDesktopManager().activateFrame(helpFrame);
	try {   helpFrame.setSelected(true);} catch (Exception e) {}
    }



/** Wird entweder von addERFrame(void) oder von ERFileLoader gerufen
 * Fuegt den Rahmen in den Frames Vector ein und legt das Aussehen fest.
 * Am Schluss wird der Rahmen aktiviert. */
  
    public void addERFrame(ERFrame erf)
    {   Frames.addElement(erf); 
    if (Frames.size() > 1 ) jbSwitch.setEnabled(true);
    jdp.add(erf); 
    erf.setVisible(true);
    erf.setSize(Variables.ERFrameX,Variables.ERFrameY);
    erf.setLocation(Variables.ERFrameLocX,Variables.ERFrameLocY); 

    jdp.getDesktopManager().activateFrame(erf);
    erf.toFront();erf.moveToFront();
    try {   erf.setSelected(true);} catch (Exception e) {}

  
    }

/** legt einen neuen ERFrame an und ruft die gleichnamige 
 * Methode mit einem Parameter.
 * Ich habe das getrennt , weil beim Laden kein Frame namens "noname"
 * erzeugt wird */ 
    public void addERFrame()
    {   
	ERFrame erf = new ERFrame("noname"+noNameCount,this);
	noNameCount++;
	addERFrame (erf); 
     
    }

/** ein Accessor fuer die ActiveFrame Variable (und das obwohl die public ist) */
    public void setActiveFrame(JInternalFrame j)
    {
	ActiveFrame=j;
    }

/** Der zweite Accessor */
    public JInternalFrame getActiveFrame()
    {
	return ActiveFrame;
    }


/** NO COMMENT */
    public void removeFrame(JInternalFrame jif)
    { if (jif == ActiveFrame) ActiveFrame = null; 
  
  
    }
/** Zeigt die Lizenz in einem nicht editierbaren TExtFrame an*/
    public void License() {
	TextFrame tt = new TextFrame("",this);
	tt.ta.setEditable(false);
	addTextFrame(tt);
	tt.loadStream(Start.class.getResourceAsStream("/html/license.txt"));
    }



/** genau wie addERFrame(ERFrame erf) */
    public void addTextFrame(TextFrame tf)
    {  
       
	Frames.addElement(tf); if (Frames.size() > 1 ) jbSwitch.setEnabled(true);
	jdp.add(tf);
	tf.setVisible(true);
	tf.setSize(Variables.TextFrameX,Variables.TextFrameY);
	tf.setLocation(Variables.TextFrameLocX,Variables.TextFrameLocY);  jdp.getDesktopManager().activateFrame(tf);

	tf.toFront(); tf.moveToFront();   
	try {
	    tf.setSelected(true);
        } catch (Exception e) {}
    }


/** Legt einen neuen TextFrame namens "noname" an 
 * ansonsten analog zur anderen addTextFrame Methode */
    public void addTextFrame()
    {  TextFrame tf = new TextFrame("noname"+noNameCount,this);
    noNameCount++;
    Frames.addElement(tf);if (Frames.size() > 1 ) jbSwitch.setEnabled(true);
    jdp.add(tf);
    tf.setVisible(true);
    tf.setSize(Variables.TextFrameX,Variables.TextFrameY);
    tf.setLocation(Variables.TextFrameLocX,Variables.TextFrameLocY); 
    jdp.getDesktopManager().activateFrame(tf);
    tf.toFront(); tf.moveToFront(); try {   tf.setSelected(true);} catch (Exception e) {}
    }



    /** vom Konstruktor gerufen , baut menu und toolbar auf */
    private void initActions() {
	ActionListener al;

	/** als erstes werden die Menus in den Menubar eingefuegt */
	JMenu jmDatei = new JMenu("Datei");
	jmExp= new JMenu("Exportieren");
	JMenu jmBearb = new JMenu("Bearbeiten");
	JMenu jmDok   = new JMenu("Dokument");
	JMenu jmHilfe = new JMenu("Hilfe");

	jmbar.add(jmDatei);
	jmbar.add(jmBearb);
	jmbar.add(jmDok);
	jmbar.add(jmFenster);
	jmbar.add(new JSeparator());
	jmbar.add(jmHilfe);

	/** In den naechsten Zeilen werden immer zuerst die Actions angelegt.
	 * Dann werden Buttons und Knoepfe angelegt und mit der Action
	 * verknuepft.
	 * Bitte beachten : Nicht jede Action ist sowohl im MenuBar als auch
	 *                  im ToolBar vertreten 
	 */

	// -- Men� Datei -- 

	al = new AddERFrameAction(this);
	makeButton("erframe.gif",al,"Neues ER-Modell ");
	makeMenu("Neues ER-Modell",al,jmDatei);

	al = new AddTextFrameAction(this);
	makeButton("textfr.gif",al,"Neue Textdatei ");
	makeMenu("Neue Textdatei",al,jmDatei);

	jmDatei.add(new JSeparator());

	al = new LoadAction(this);
	makeButton("open2.gif",al,"�ffnen...");
	makeMenu("Laden...",al,jmDatei);

	al = new SaveAction(this);
	jbSave = makeButton("save.gif",al,"Speichern ");
	jmSave = makeMenu("Speichern", al,jmDatei, "control S");

	al = new SaveAction(this, true); // save as
	jmSaveAs = makeMenu("Speichern unter...", al,jmDatei);
	// Speichern Als geht nur vom MenuBAr aus 

	// Untermen� Exportieren
	jmDatei.add(jmExp);
	
	al = new ExportSqlNewAction(this);
	makeMenu("SQL",al,jmExp);

	al = new ExportFigAction(this);
	makeMenu("Fig 3.2",al,jmExp);
	// Ende Untermen� Exportieren
	
	jmDatei.add(new JSeparator());
	jtb.add(new JToolBar.Separator());

	al = new ExitAction(this);	
	makeMenu("Programm Verlassen",al, jmDatei, "control Q");


	// -- Men� Bearbeiten --
	al = new CutAction(this);
	jbCut=makeButton("cut.gif",al,"Ausschneiden ");
	jmCut=makeMenu("Ausschneiden",al, jmBearb, "control X");

	al= new CopyAction(this);
	jbCopy= makeButton("copy.gif",al,"Kopieren ");
	jmCopy= makeMenu("Kopieren",al, jmBearb, "control C");
	
	al = new PasteAction(this);
	jbPaste = makeButton("paste.gif",al,"Einf�gen ");
	jmPaste = makeMenu("Einf�gen",al, jmBearb, "control V");

	al = new DelAction(this);
	jbDel=makeButton("del.gif",al,"L�schen ");
	jmDel=makeMenu("L�schen",al, jmBearb, "DELETE");

	// -- Men� Dokument --

	jtb.add(new JToolBar.Separator());
	al=new AddEntAction(this);
	jbInsEnt=makeButton("entity.gif",al,"Neue Entity ");
	jmInsEnt=makeMenu("Entity einf�gen", al,jmDok);
    
	al = new AddRelAction(this);
	jbInsRel=makeButton("relship.gif",al,"RelationShip einf�gen ");
	jmInsRel=makeMenu("Relationship einf�gen",al,jmDok);

	al = new AddIsaAction(this);
	jbGener = makeButton("isa.gif",al,"Vererbung einf�gen ");
	jmGener = makeMenu("Vererbung einf�gen",al, jmDok);

	jmDok.add(new JSeparator());

	al = new AlterTypesAction(this);
	jbTypes= makeButton("types.gif",al,"Datentypen bearbeiten...");
	jmTypes= makeMenu("Datentypen...",al, null); // weiter unten in jmDok
    
	jtb.add(new JToolBar.Separator());

    	al = new DecPanelAction(this);
	jbSizeMinus = makeButton("minus.gif",al,"Zeichenfl�che verkleinern ");
        jmSizeMinus = makeMenu("Panel verkleinern",al, jmDok);

	al = new IncPanelAction(this);
	jbSizePlus = makeButton("plus.gif",al,"Zeichenfl�che vergr��ern ");
	jmSizePlus = makeMenu("Panel vergr��ern",al, jmDok);

	jtb.add(new JToolBar.Separator());
	jmDok.add(new JSeparator());
	jmDok.add(jmTypes); // Datentypen

	// -- Men� Fenster --
	
	al = new SwitchAction(this);
	jbSwitch = makeButton("switch.gif",al,"N�chstes Fenster ");

	// -- Men� Hilfe --
	
	al = new HelpAction(this);
	makeButton("help.gif",al,"Hilfe "); 
	makeMenu("Hilfe",al,jmHilfe);

	al = new AboutAction(this);
	makeMenu("�ber dieses Programm...",al,jmHilfe);

	al = new LicenseAction(this);
	makeMenu("Lizenz",al, jmHilfe);

	// -- alles deaktivieren --
	activ4Null();
    }


 /**Zeigt einen About Dialog an*/
    public void About() {
	JOptionPane.showMessageDialog(null,
				      Variables.AppName + "\nby Christoph Unbehend\nUniversit�t Augsburg\nInstitut f�r Informatik",
				      "About",
				      JOptionPane.INFORMATION_MESSAGE,
				      about);
    }

    public JButton makeButton(String image, ActionListener al,
			      String tooltip) {
	JButton b = new JButton(new ImageIcon(Start.class.getResource
					      ("html/"+image)));
	b.addActionListener(al);
	jtb.add(b);
	b.setToolTipText(tooltip);
	return b;
    }

    public JMenuItem makeMenu(String title, ActionListener al, JMenu in) {
	return makeMenu(title, al, in, null);
    }

    public JMenuItem makeMenu(String title, ActionListener al, JMenu in,
			      String keystroke) {
	JMenuItem m = new JMenuItem(title);
	m.addActionListener(al);
	if (in != null) in.add(m);
	if (keystroke != null) {
	    KeyStroke ks = KeyStroke.getKeyStroke(keystroke);
	    m.setAccelerator(ks);
	}
	return m;
    }
	
 
/** �ffnet einen Standard- Dialog und gibt nach dem Schlie�en desselben den Dateinamen zur�ck */
    public String OpenDialog()
    {
	int option =  chooser.showOpenDialog(this); // chooser wurde am Anfang definiert 
	if (option == JFileChooser.APPROVE_OPTION)  // wenn nicht gecancelt wurde : 
	    return chooser.getSelectedFile().getAbsolutePath(); // Absolute heisst mit Verzeichnissen
	else return null;        
    }


/** Analog zu OpenDialog , nur der Dialog sieht etwas anders aus ( wird von Swing vorgefertigt) */
    public String SaveDialog() {   
	int option =  chooser.showSaveDialog(this);
	if (option == JFileChooser.APPROVE_OPTION)
	    return chooser.getSelectedFile().getAbsolutePath(); 
	else return null; 
    }

    /** setzt das LookAndFeel der Applikation auf den in  Variables gesetzten Wert */
    public void setLnF() {
	try {
	    UIManager.setLookAndFeel(Variables.lnfName);
	    SwingUtilities.updateComponentTreeUI(this);
	    SwingUtilities.updateComponentTreeUI(chooser);
	    SwingUtilities.updateComponentTreeUI(jmbar);
	    SwingUtilities.updateComponentTreeUI(jtb);
	    //  das updaten aller Komponenten ist noetig, sonst sehen
	    // die Tabellen dort anders aus, wenn ich eine Komponente
	    // vergessen habe , hier nachtragen 
	} catch (Exception e) { }
    }



    /** leert das ClipBoard , das zu den ERFrames gehoert , nicht 
     *  das von den TextFrames ( das zum OS gehoert ) */
    public void resetClipBoard() {
	ClipBoard.removeAllElements();
    }

    /** Fuegt ein Object in den Vector ClipBoard ein */
    public void addToClipBoard(Object o) {
	ClipBoard.addElement(o);
    }

    /** liefert die Anzahl der Objecte im ClipBoard */
    public int getClipBoardSize() {
	return ClipBoard.size();
    }

    /** Liefert ein bestimmtes Object im ClipBoard */ 
    public Object getClipBoardObjectAt(int n) {
	if (n<ClipBoard.size()) {
	    return ClipBoard.elementAt(n);
	} else {
	    return null;
	}
    }

   
/** verlaesst die Anwendung ;-< */
    public void leave()
    {

	int i =0;

	for (Iterator it = Frames.iterator(); it.hasNext();) {
	    Object f = it.next();
	    if (f instanceof ChangableInternalFrame &&
		!((ChangableInternalFrame)f).shouldClose()) {
		i=1;
		break;
	    }
	}
	// if 0 : ich will raus , else ich will noch bleiben
   
	if (i!=0) {
	    return;
	}

	jfr.setVisible(false);
	try {
	    jfr.dispose();
	} catch (Exception ex) {
	    ex.printStackTrace();
	} finally {
	    System.exit(0); // <-- damit dass Programm auch wirklich beendet wird
	}
    }

/* unused
    /** Wenn es irgendwelche Optionen geben wuerde , koennte man sie hier eintragen */
/*    public void options()
    {
	//OptionsDlg odlg = new OptionsDlg(jfr,convertDfm);
    }*/

    /** schnelles wechseln zum naechsten InternalFrame 
     * Waehlt denjenigen InternalFrame aus , der im 
     * Frames Vector auf ActiveFrame folgt.
     * Und aktiviert in und bringt ihn in den Vordergrund  
     */ 
    public void Switch() {
	int nn = Frames.size();
	int Goto;
	if (nn<=0)  return; 
	if (ActiveFrame==null) Goto=0;
	else {
	    Goto = Frames.indexOf(ActiveFrame)+1; 
	    if (Goto>= nn) Goto =  0;
	} 
	JInternalFrame erf = (JInternalFrame) Frames.elementAt(Goto);
	jdp.getDesktopManager().activateFrame(erf);
	erf.toFront();erf.moveToFront();
	try {erf.setIcon(false);} catch (Exception e) {}
	try {erf.setSelected(true);} catch (Exception e) {}
    } 
   
/** De(aktiviert) Menueintraege und Buttons
 * passend zu einem TextFenster 
 */

    public void activ4Text() {
	activ4All(false, true, false, false);
    }

    public void activ4All(boolean er, boolean text, boolean help, boolean dummy) {
	jmExp.setEnabled(er);
	jmInsEnt.setEnabled(er);
	jbInsEnt.setEnabled(er);
	jmInsRel.setEnabled(er);
	jbInsRel.setEnabled(er);
	jmSave.setEnabled(text || er);
	jbSave.setEnabled(text || er); 
	jmSaveAs.setEnabled(text || er);
	activPaste(text || (er && clipER==1));
	jmGener.setEnabled(er); 
	jbGener.setEnabled(er);
	jmSizeMinus.setEnabled(er);
	jbSizeMinus.setEnabled(er);
	jmSizePlus.setEnabled(er); 
	jbSizePlus.setEnabled(er); 
	jmTypes.setEnabled(er);
	jbTypes.setEnabled(er);
	activSelect(text);
    }


/** De(aktiviert) Menueintraege und Buttons
 * wenn kein Fenster aktiv ist 
 */
    public void activ4Null()
    {
	activ4All(false, false, false, false);
    }

   
/** De(aktiviert) Menueintraege und Buttons
 * passend zum Hilfefenster
 */

    public void activ4Help()
    {
	activ4All(false, false, true, false);
    }

/** De(aktiviert) Menueintraege und Buttons
 * passend zu einem ER-Fenster
 */
    public void activ4ER() {
	activ4All(true, false, false, false);
    }
/**  entfernt  f aus dem Frames vektor. */
    public void removeInternalFrame(JInternalFrame f)
    {
  
	Frames.removeElement(f);
	// if (Frames.size() < 2 ) jbSwitch.setEnabled(false);
	f.setVisible(false);
	jdp.remove(f);
 
	if (f.isSelected()) activ4Null();
    
    
	if (f instanceof ERFrame) 
	    {
		ERFrame erf = (ERFrame) f;
		jmFenster.remove(erf.MenuMarker);
    
	    }
	if (f instanceof TextFrame) 
	    {
		TextFrame tf = (TextFrame) f;
		jmFenster.remove(tf.MenuMarker);
    
	    }
   
	if (f instanceof HelpFrame) 
	    {
		HelpFrame hf = (HelpFrame) f;
		jmFenster.remove(hf.MenuMarker); helpFrame = null;
	    }
	if (Frames.size() <= 1 ) jbSwitch.setEnabled(false);
    }

/** (De)Aktiviert die Buttons und Menuitems , die zu cut del und copy gehoeren*/
    public void activSelect(boolean b) {
	jbDel.setEnabled(b);  
	jmDel.setEnabled(b);  
	jbCopy.setEnabled(b);  
	jmCopy.setEnabled(b);  
	jbCut.setEnabled(b);  
	jmCut.setEnabled(b);  
    }

/** (De)Aktiviert die Buttons und Menuitems , die zu paste gehoeren*/
    public void activPaste(boolean b) {
	jbPaste.setEnabled(b);  
	jmPaste.setEnabled(b);  
    }
}
