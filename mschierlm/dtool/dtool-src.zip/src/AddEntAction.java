import javax.swing.JInternalFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/** Die Action bewirkt , dass eine Entity in den aktiven 
  * ERFrame eingefuegt wird
  * @see ERFrame */
public class AddEntAction implements ActionListener 

{ 
   
 
   /** Verweis auf das Hauptfenster der Applikation.
     * Start enthaelt die Funktion getActiveFrame , 
     * die verwendet wird , um den aktiven JInternalFrame
     * festzustellen. 
     * @see Start 
     */
private Start parent;

   
   /** Konstruktor , der dafuer sorgt , dass die Klasse 
     * einen Verweis auf die Klasse Start enthaelt. */
public AddEntAction(Start p)
   {  
      parent = p;

   }


   /** Wird ausgefuehrt , wenn jemand auf den Knopf bzw.
    *  Menueeintrag zum Einfuegen einer Entity drueckt. */
public void actionPerformed(ActionEvent ae)
   {  

      JInternalFrame inf = parent.getActiveFrame();  // ermittelt den aktiven JInternalFrame
      
      if (inf instanceof ERFrame)                    // wenn TextFrame oder null passiert nichts
        { 
          ((ERFrame) inf).addEntity();               // ruft die Funktion zum Einfuegen auf.

        }

      
   }

}
