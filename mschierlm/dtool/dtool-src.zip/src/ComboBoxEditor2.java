import java.awt.Component;
import javax.swing.table.TableCellEditor;
import javax.swing.JComboBox;
import java.util.Vector;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import java.util.EventObject;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;


/** Diese Klasse ist fast voellig identisch zu ComboBoxEditor
  * allerdings wird statt DefaultComboBoxModel FakeComboBoxModel verwendet
  * FakeComboBoxModel ist in eine TableModel (eine Klasse , die die Daten
  * einer Tabelle verwaltet) dem einige (nicht alle) Methoden einer
  * ComboBox beigefuegt wurden.
  * Diese Klasse wird nur in ISADlg verwendet
  * @see ISADlg
  * @see ComboBoxEditor
 */
public class ComboBoxEditor2 extends JComboBox implements TableCellEditor
{   
    private Vector selected;
    private Vector ent;
    protected transient Vector listeners;
    protected boolean editAble;
    private DefaultComboBoxModel cbm;
    private Object oldSelection;
    private Object sup;
    /** Dies ist der Unterschied zu ComboBoxEditor  */
    private FakeComboBoxModel dcbm;    // <------------

    /** Konstruktor , ruft den 2ten Konstruktor mit null,null am Ende auf  */ 
    public ComboBoxEditor2(Vector vv,boolean eable)
    {
     this( vv, eable,null,null);
     
    }

    
    /** legt lediglich die uebergebenen Werte an */
    public ComboBoxEditor2(Vector vv,boolean eable,Vector dd,FakeComboBoxModel dfcm)
    {       super();  ent = vv; //alle vorhandenen entities 
             dcbm = dfcm;
            selected =  dd; // hier stehen alle markierten Vektoren drin , vom itm , nicht aendern
   

      editAble = eable;
      listeners = new Vector(); 
    }


     /** liefert die Komponente zurueck , die in der Tabelle jt in 
      *  Zelle (row,column) gezeichnet wird */
    public Component getTableCellEditorComponent(JTable jt,Object value,
                                                        boolean isSelected,int row,int column)
    { 
        
      if (value instanceof DefaultComboBoxModel)
      {  cbm = (DefaultComboBoxModel) value;
         oldSelection = cbm.getSelectedItem(); 
         Vector model = new Vector();        
         
         int i23 = selected.size();
       
          sup = dcbm.getSelectedItem();
         model.addElement(ent.elementAt(0));
         if (oldSelection instanceof Entity) model.addElement(oldSelection);
         for(int i=1;i<ent.size();i++)
         { Object o2 = ent.elementAt(i);
           if (! (selected.contains(o2) || o2.equals(sup)  ) ) {model.addElement(o2);}   //SuperEntity fehlt!!
      

         }
         
          
      
  

    
         setModel(new DefaultComboBoxModel(model));
         setSelectedItem(oldSelection);
          
      }

       jt.setRowSelectionInterval(row,row);
      
      //setBackground(Color.yellow);
      return this;

    }

    /** informiert alle registrtierten Listener ueber einen cancelEditing event */
    public void cancelCellEditing()
    { fireEditingCanceled();}

    public Object getCellEditorValue()
    { 
         DefaultComboBoxModel dcm = new DefaultComboBoxModel(ent);
         Object o =  getSelectedItem();
         if (o!=oldSelection) {selected.removeElement(oldSelection);if (o instanceof Entity) selected.addElement(o);}
         dcm.setSelectedItem(o);
       return dcm ;
      
    }

    /** gibt immer true zurueck */
    public boolean isCellEditable(EventObject eo) { return true;}

    /** gibt immer true zurueck */
    public boolean shouldSelectCell(EventObject eo)
    { return true;}

    
    /** informiert alle Listener ueber einen stopEditing Event*/
    public boolean stopCellEditing()
    { fireEditingStopped(); return true;}

   /** registriert cel als Listener */
   public void addCellEditorListener(CellEditorListener cel)
   {
      listeners.addElement(cel);
      
   }

   /** entfernt cel wieder */
   public void removeCellEditorListener(CellEditorListener cel)
   {  listeners.removeElement(cel);

   }

   protected void fireEditingCanceled()
   {
      ChangeEvent ce = new ChangeEvent(this);
      for (int i = listeners.size();i>=0;i--)
        ( (CellEditorListener) listeners.elementAt(i)).editingCanceled(ce);
   }

   protected void fireEditingStopped()
   {
      ChangeEvent ce = new ChangeEvent(this);
      for (int i = listeners.size()-1 ;i>=0;i--)
        { CellEditorListener cel = (CellEditorListener) listeners.elementAt(i);
          cel.editingStopped(ce);

        }
       
   }


}
