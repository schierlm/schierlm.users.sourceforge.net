import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


/** Kann zum schnellen Wechseln der
  * JINternalFrames verwendet werden.
  * @see Start */
public class SwitchAction implements ActionListener
{  
   /** Verweis auf die Klasse , die die Switch-Methode enthaelt */
   private Start parent;


  /** Legt den Verweis auf die Start-Klasse des Programms an */
   public SwitchAction(Start p)
   {  
      parent = p;

   }


 /** Ruft nur Switch() in der Klasse Start */
   public void actionPerformed(ActionEvent ae)
   {  parent.Switch();
      
      
   }


}
