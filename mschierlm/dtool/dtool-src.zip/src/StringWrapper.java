
/** Damit ich einen String als Objekt verwenden kann */
public class StringWrapper 
{
 /** hier wird der String gespeichert */
  public String s;


/** Legt eine neue Instanz mit dem String ss an */
public StringWrapper(String ss)
{
   s = ss;


}


/* s == str ?? */
public boolean equals(StringWrapper str)
{
  String comp = str.toString();
  if (comp.equals(s)) return true;
 

  return false;


}


/* s := ss */
public void setString(String ss)
{ s = ss;}






/* return s */
public String toString()
{ return s;}


}