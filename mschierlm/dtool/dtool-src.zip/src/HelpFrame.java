import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
import java.net.*;

/** ein Frame , der vorgefertigte java Funktionen verwendet , um 
  * einen simplen TextEditor zur Verfuegung zu stellen ) */
public class HelpFrame extends JInternalFrame
{

 /** link auf die Klasse Start */
 public  Start parent;
 
 /** Der Name der TExtdatei */
 public String filename ;
 
  /** Eintrag ins Fenster-Menu f�r dieses Fenster */
 public JMenuItem MenuMarker;
 
 /** Zum Anzeigen von html */
 public JEditorPane ta;
 
 /** fuer interne klassen : link auf this */
 public JInternalFrame tf = this;

/** Kontruktor , fuegt die Textarea in den internen Rahmen ein*/
 public HelpFrame(Start s) throws java.io.IOException
 {  
/*
         try {
			URLClassLoader cl = (URLClassLoader)this.getClass().getClassLoader();
			jedtHelpText = new JEditorPane(cl.findResource(nhelpurl));
			helpurl = jedtHelpText.getPage();
		} catch (MalformedURLException e) {
 */
  super("Hilfe",true,true,true,true);
     parent = s;
     addInternalFrameListener(parent.ifl);
     setBounds(Variables.HelpFrameLocX,Variables.HelpFrameLocY,
                        Variables.HelpFrameSizX,Variables.HelpFrameSizY);

     Container cP = getContentPane();
     try
     {
      //ta = new JEditorPane(parent.uRL);
      ClassLoader cl = this.getClass().getClassLoader();
      ta = new JEditorPane(cl.getResource(Variables.HelpFile));
     } catch (Exception ex) {
      System.out.println("Exception");
      ex.printStackTrace();
      return;
     }
     
     ta.setEditable(false);
     ta.setContentType("text/html");
     ta.addHyperlinkListener(new Hyperactive());
     
     
     JScrollPane jsp = new JScrollPane(ta);
     cP.add(jsp,BorderLayout.CENTER);
     setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);     
    
 
    
    
     MenuMarker = new JMenuItem("Hilfe");
     MenuMarker.addActionListener( new ActionListener() {
               public void actionPerformed(ActionEvent ev) {
               
	        parent.jdp.getDesktopManager().activateFrame(tf);
                tf.toFront();  tf.moveToFront();
                try {tf.setIcon(false);} catch (Exception e) {}
                try {tf.setSelected(true);} catch (Exception e) {}       
           } } );
    
     parent.jmFenster.add(MenuMarker);

 }


/** laedt eine Textdatei in die Textarea*/
 public void Load(String name)
 {
 
 try
   {
    FileReader fr = new FileReader(filename);
    ta.read(fr,null);
    fr.close();

   }
   catch (Exception e) { }
 }

public void setClosed(boolean b)
{
  parent.removeInternalFrame(this);
}

}
