import javax.swing.plaf.ComponentUI;

public abstract class MarkRectangleUI extends ComponentUI
{


}
