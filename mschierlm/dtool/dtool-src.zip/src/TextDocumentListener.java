import javax.swing.*;
import javax.swing.event.*;

public class TextDocumentListener implements DocumentListener {
    private TextFrame frame;
    
    public TextDocumentListener(TextFrame tf) {
	frame=tf;
    }

    public void changedUpdate(DocumentEvent evt) {
	frame.setChanged();
    }
    public void insertUpdate(DocumentEvent evt) {
	frame.setChanged();
    }
    public void removeUpdate(DocumentEvent evt) {
	frame.setChanged();
    }
}
