import java.awt.event.WindowEvent;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import javax.swing.JOptionPane;

/** sorg dafuer , dass beim Schliessen des 
 * JFrames das Programm auch wirklich beendet wird. 
 * Vorher wird nochmal per Dialog nachgefragt ob 
 * der Benutzer das Programm wirklich verlassen will. */ 
public class BWM extends WindowAdapter
{

    Start start;
    
    public BWM(Start s) {
	start=s;
    }
    /** wird ausgefuehrt , wenn das Programm beendet werden soll */
    public void windowClosing(WindowEvent e) { 
	Window w = e.getWindow();
	start.leave();
	//w.setVisible(true);

    }
}
