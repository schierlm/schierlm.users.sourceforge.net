import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



/** Oeffnet einen FileChooserDialog , 
  * und laedt die ausgewaehlte Datei */
public class LoadAction implements ActionListener
{ 

  /** Verweis auf die Klasse Start */
private Start parent;


 /** Der Standardkonstruktor aller Action-Klassen*/
public LoadAction(Start p)
   {  
      parent = p;
    }


/** 1. Oeffnet einen Dialog zur Ermittlung des Dateinamens.
  * 2. Oeffnet die Datei kurz , um den Header zu ueberpruefen 
  * Je Nach Ergebnis wird die Datei :
  * 3. Als ER-Datei 
  * 4. Als TextDatei 
  * geladen. 
  * @see TestReader 
  */
public void actionPerformed(ActionEvent ae)
   {  String name = parent.OpenDialog();
      if (name==null) return;

      TestReader tr = new TestReader(name);
      boolean b = tr.isDBFile();
      tr.closeStream();

      if (b==true)
      {   ERFrame erf = new ERFrame(name,parent);
          parent.addERFrame(erf);
          erf.Load(name);
          return;
      }

      if (b==false)
      {  TextFrame tf = new TextFrame(name,parent);
         parent.addTextFrame(tf);
         tf.Load(name);

         return;
      }

  }


}
