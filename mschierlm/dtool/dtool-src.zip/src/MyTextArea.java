import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;

public class MyTextArea  extends JTextArea
{
  private int Start=0;
  private int End=0;

public  void setSelectionEnd(int selectionEnd)  
{
  super.setSelectionEnd(selectionEnd)  ;
  System.out.println("Seletion End: " + selectionEnd);



}


public  void setSelectionStart(int selectionStart)  
{
  super.setSelectionStart(selectionStart)  ;
  System.out.println("Seletion Start: " + selectionStart);
}

public void select(int st,int en)
{
 super.select(st,en);
 System.out.println("Select : " + st + " - " + en);

}



}