import java.io.*;



/** testet den Header der Datei
 * @see ERFrame , ERFileSaver , ERFileReader */
public class TestReader
{
    private DataInputStream in;
    private BufferedInputStream bis;
    private FileInputStream fis;

 /** oeffnet die Inputstreams zum Lesen der Datei name*/
 public TestReader(String name)
 {

  try {  
         fis =  new FileInputStream(name);
         bis =  new BufferedInputStream(fis);
         in  =  new DataInputStream(bis);
      }
 
  catch(Exception e) {System.out.println("File Read Exception");}
 }

/** ueberprueft ob es sich um ein gespeichertes Datenbankmodell handelt .
 * alle anderen Dateien werden als Text behandelt
*/
public boolean isDBFile()
{
    try
     {   int d1 = in.readInt(); 
         int d2 = in.readInt();
         int d3 = in.readInt();

         if ( (d1!=13) || (d2 !=8) || (d3 != 76) )   // ueberprueft , ob in den ersten 3 Stellen der Datei 13 8 76 steht
         {                                            
            return false;
         }
      return true;
     }
  catch(Exception e) {System.out.println("File Test Exception");return false;}
}


/** schliesst die Datei wieder */
  public void closeStream()
  {

    try
     {in.close();}  
    catch (Exception e) {System.err.println("Error closing InputStream");}

  }

 
}
