import java.util.Vector;
import java.awt.*;



/** Konvertiert einen ERFrame  in das Fig 3.2. Format
  (xfig unter Un*x , oder auch javafig.
  
  Aufl�sung in xfig : 1200 dpi 
  
  Umrechnung : 1 Pixel entspricht 10 dots
  
  d.h. eine Standard Entity (300 Pixel) ist 
  3000 * 2.54 / 1200 = 6.35 cm auf dem Papier breit
  

*/ 
public class ConvertFig implements Convert
{
 
 /** Der  String enth�lt den  Anfang  einer  Fig Datei*/
 public String createHeader()
 {
   String s = "#FIG 3.2\n";
   
   s += "Landscape\n";
 
   s += "Center\n";
   s += "Inches\n";
   s += "A4\n100.0\nSingle\n-2\n1200 2\n";   // Single  ist nicht  gut******************************
   
   return s;
   //+ Diamond(1000,1000) + Rectangle(1200,1200,3600,2400) 
    //+ Text(1220,1350,"Hallo");
  
  
 }




/** Diamond mit linker oberer  Ecke x , y */
public String Diamond(int x , int y)
{
  //coord : 1 : 200 0 / 400 200 / 200 400 / 0 200 
  int dx = Variables.DiamondX * 10 ;int dy = Variables.DiamondY *10;
      
  String s = "2 2 0 1 0 7 100 0 -1 0.000 0 0 -1  0 0 5\n             ";
  
  s = s + " " + (x+dx/2) + " " +  y + " " ;
  
  s = s + " " + (x+dx) + " " + (y+dy/2) + " " ;
 
  s = s + " " + (x+dx/2) + " " + (y+dy) + " " ;
  
  s = s + " " + x + " " + (y+dy/2) + " " ;
  
  s = s + " " + (x+dx/2) + " " +  y  ;
  
  return s + "\n";
}


/** Halbkreis am Punkt x,y, X gibt an , ob die  ISA disjunkt ist */
public  String isacenter(int x , int y , boolean X)
{ int dx = Variables.IsaCenterX *10; int  dy = Variables.IsaCenterY *10;
  String s= "5 1 0 1 0 7 99 0 20 0.000 0 0 0 0 ";
 
 
  s = s + (x+dx/2)   +".00 "+ (y+dy/2)   +".00 ";
 
  s = s + x + " " + (y+dy/2) + " ";
  
  s = s + (x+dx/2) + " " + y + " " ;

  s = s + (x+dx) + " " + (y + dy/2) + "\n"  ;
  
  s = s + "2 1 0 1 0 7 98 0 -1 0.000 0 0 -1 0 0 2\n            " + x + " " + (y + dy/2) + " " + (x+dx) 
           + " " + (y+dy/2) + "\n" ; 

  if (X)
  {
    s = s + "2 1 0 1 0 7 98 0 -1 0.000 0 0 -1 0 0 2\n            " + (x+(7*dx/16)) + " " 
      + (y + dy/4) + " " + (x+9*dx/16) + " " + (y+3*dy/8) + "\n" ; 

    s = s + "2 1 0 1 0 7 98 0 -1 0.000 0 0 -1 0 0 2\n            " + (x+7*dx/16)+ " " 
      + (y + 3*dy/8) + " " + (x+9*dx/16) + " " + (y+dy/4) + "\n" ; 
       
   
 
  }
  
 

  return s ;
}


/** Gibt  txt an der  Koordinate x,y (in Dots) aus
  type    name                    (brief description)
----    ----                    -------------------
int     object                  (always 4)
int     sub_type                (0: Left justified
                                 1: Center justified
                                 2: Right justified)
int     color                   (enumeration type)
int     depth                   (enumeration type)
int     pen_style               (enumeration , not used)
int     font                    (enumeration type)
float   font_size               (font size in points)
float   angle                   (radians, the angle of the text)
int     font_flags              (bit vector)
float   height                  (Fig units)
float   length                  (Fig units)
int     x, y                    (Fig units, coordinate of the origin
      of the string.  If sub_type = 0, it is the lower left corner of the string.
      If sub_type = 1, it is the lower center.  Otherwise it is the lower
      right corner of the string.)

char    string[]                (ASCII characters; starts after a blank
  character following the last number and ends before the sequence '\001'.  This
  sequence is not part of the string. Characters above octal 177 are
  represented by \xxx where xxx is the octal value.  This permits fig files to
  be edited with 7-bit editors and sent by e-mail without data loss.
  Note that the string may contain '\n'.
 */
public String Text(int x , int y , String txt)
{ if (txt.length()==0) return ""; //leere Strings f�hren zu Fehler in XFIG
   String s = 
  "4 0 0 999 0 0 12 0.0000 4 135 " + " 2630 " + x + " "+ y + " "+ txt+ "\\" + "001" + "\n" ;

  return s;
}


/** Ein  Viereck x,y obere */
public String Rectangle(int x , int y  , int dx , int dy)
{
  String s = "2 2 0 1 0 7 100 0 -1 0.000 0 0 -1  0 0 5\n             ";

  s = s + " " + x + " " +  y + " " ;
  
  s = s + " " + (x+dx) + " " + y + " " ;
 
  s = s + " " + (x+dx) + " " + (y+dy) + " " ;
  
  s = s + " " + x + " " + (y+dy) + " " ;
  
  s = s + " " + x + " " +  y  ;
  
  return s + "\n";


}


/**Linie bzw. Pfeil von x,y nach xx,yy im Fig Format*/
public String Line(int x , int y , int xx , int yy,boolean arrow,boolean dir)
{  int p = 0; int pb = 0;
   String s = "";

   if (arrow){ if (dir==false) p=1;  else pb=1;}
    
 s = s +  "2 1 0 1 0 7 100 0 -1 0.000 0 0 -1 " + p + " " + pb + " 2\n            ";
 
   if (arrow)  s = s + "1 1 1.00 60.00 120.00\n           ";
 
 s = s +             + x+ " " 
      + y + " " + xx + " " + yy + "\n" ; 

 return s;
}


/**Ein Dreieck*/
public String Triangle(int x , int y , int xx , int yy,int xxx , int yyy)
{  int p = 0;
   String s = "";

  
    
 s = s +  "2 1 0 1 0 7 99 0 20 0.000 0 0 -1 " + "0" + " 0 4\n         ";
 
  
 s = s +             + x+ " " 
      + y + " " + xx + " " + yy + " " + xxx + " " + yyy + " " + x + " " + y + "\n" ; 

 return s;
}

/** Wandelt e nach Fig um  */
public String createFig(Entity e)
{  
  String s = "";

  Point p = e.getLocation();
  Dimension d = e.getSize();

  s = s + Rectangle(p.x*10,p.y*10,d.width*10,d.height*10);
  
  s = s + Text(p.x*10+30,p.y*10+180,e.getName());
  
  s = s + Line(p.x*10 , p.y*10 + 200 , d.width * 10 + p.x *10, p.y * 10 + 200,false,false);
  s = s + attribs(e.Attm,p.x*10+20,p.y*10+380);  

  return s;       
}


public String  attribs(AttributTableModel atm,int x,int y)
{
   String s = "";
   
   
   
   int n = atm.getRowCount();
   
   for(int i=0;i<n;i++)
   {
     AttributRowModel arm = atm.getRowAt(i);
     String g = "";
     g = g + arm.getName() + " " +arm.getDomainName();
     
     if (arm.getPk().isSelected()) g = g + " P "; else g = g+ "   ";
     if (arm.getUn().isSelected()) g = g + " U "; else g = g+ "   ";
     if (arm.getMw().isSelected()) g = g + " M "; else g = g+ "   ";
     if (arm.getOp().isSelected()) g = g + " O "; else g = g+ "   ";
     s = s + Text(x,y,g);
     y = y + 180;
   }
   
   return s;

}


/** Sub Routine f�r IsaLines*/
public String isaline(IsaLine isl)
{
       Point po = isl.getLocation();
       int x = po.x; int y = po.y;
       Dimension d = isl.getDim();
       Dimension dd = isl.getSize();
      
       boolean r = isl.nachRechts; boolean h = isl.nachOben; boolean p = isl.pfeil;
             
    
        String s = "";

       // long longlen = java.lang.Math.round(java.lang.Math.sqrt((double) d.width*d.width + d.height*d.height));
        //int len = (int) longlen; 
       // double nnew = ( (double) Variables.SpecialD) / ((double)len);
       
        
       
       if (r==true)  // nachRechts
       {
          if (h==true)  //nachOben
          {  
             s = s + Line( (x+Variables.SpecialD) * 10 , (y+ d.height + Variables.SpecialD) * 10
	                , (x+d.width + Variables.SpecialD ) * 10, (y+ Variables.SpecialD) * 10,p,false);
           
          }

          if (h==false) // nachUnten
          {    
              s = s + Line ((x+Variables.SpecialD ) * 10, (y+ Variables.SpecialD )* 10,
	                 ( x+d.width+ Variables.SpecialD) * 10 , (y+ d.height+ Variables.SpecialD) * 10,p,false);
             
          } 
       } 

       if (r==false)
       {
          if (h==false)
          {
             s = s + Line( (x+Variables.SpecialD) * 10 , (y+ d.height+Variables.SpecialD) * 10,
	               ( x+ d.width+Variables.SpecialD) * 10 , ( y+Variables.SpecialD) * 10,p,true);
           
              
          }

          if (h==true)
          {
              s = s + Line ((x+Variables.SpecialD) * 10 , (y+ Variables.SpecialD) * 10,
	                 (  x+ d.width+Variables.SpecialD) * 10 ,(y+ d.height+Variables.SpecialD) * 10,p,true);
         
         
          } 
       } 

    
    return s;
}
      

/**Konvertiert eine Vererbung*/
public String createFig(ISA a)
{
  Point p = a.isc.getLocation();
 
  String s = isacenter(p.x*10,p.y*10,a.isX.isSelected());

  if (a.supr.isVisible())
  {
    s = s + isaline(a.supr);
  }
  
  

  int nl = a.lines.size();
  
  for(int ii = 0; ii<nl; ii++)
   {
     IsaLine isl = (IsaLine) a.lines.elementAt(ii);
      if (isl.isVisible())
       {
           s = s + isaline(isl);
       }
   
   }

  return s ; 
}


public  String RelLine(Line l)
{
          String s = "";

  
         int le = l.length;
         Point p = l.getLocation();
         boolean w = l.waagrecht;
         boolean dir = l.direction;               // auslesen von Informationen
         
         if (w==true) s = s+Line( (p.x)*10,(p.y+Variables.SpecialD)*10,(p.x+le)*10,(p.y+Variables.SpecialD)*10,false,false); // waagrecht zeichnen
         else s = s+Line((p.x+Variables.SpecialD)*10,(p.y)*10,(p.x+Variables.SpecialD)*10,(p.y+le)*10,false,false);         // vertikal zeichnen

         int sp = l.getSpecial();                // eine Zahl , die angibt ob noch weiter gezeichnet werden muss
         int num = l.getNum();

         if (sp == 0) return s;                    // nein 


// ja : ein DreiEck fuer starke/schwache Entity 
         if (num == 1) {  if (((sp == 1) && ( dir ==true)) || ((sp==2) && (dir==false)))
                          {s = s + Triangle(true,l);return s;}

                          else { s = s+ Triangle(false,l);}
                        
                        }
         // ja : ein Kreis fuer optional 
         if (num == 2) {     if (sp>0)
                            
                           { s = s + Circle(l);}

                        }

//          ja : zwei weitere kleine Linien fuer many 
         if (num == 3) {   if ((sp>0)&&(dir ==true) )
                                    s = s + Delta(true,l);

                                else s = s + Delta(false,l);

           }
  return s; 
}  
 

/**Wandelt r in einen String im Fig Format*/
public String createFig(RelShip r)
{
  Point  p = r.d.getLocation();

  String s = Diamond(p.x*10,p.y*10);
  
  Point np = r.NameLabel.getLocation();
  String nn = r.NameLabel.getText();
  
  s = s + Text(np.x*10-80,np.y*10+100,nn);

  for (int i=0;i<3;i++) {
      for (int j=0;j<3;j++) {    
	  s = s+ RelLine(r.lin[i][j]);
      }
  }
 
 return s; 
}


/** Die Startfunktion , ruft alle anderen Methoden auf 
  * und gibt am Schlu� den String zur�ck*/
public String convert(ERFrame erf)
{

 
   int ne = erf.Entities.size() ;   // Die Anzahlen von Entities , RelShips und ISAs
   int ni = erf.Isa.size(); 
   int nr = erf.Rels.size();

   String s = createHeader();
  

     /** jetzt werden nacheinder untige Methoden fuer jede Entity / RelShip & ISA gerufen : */

    for (int i = 1; i<ne; i++)  //kein Fehler , an 0 steht der String "keine"
       {  
          Entity e =(Entity) erf.Entities.elementAt(i);
          s = s +  createFig(e);
       }
 
  

    for (int i = 0; i<nr; i++)
       {  RelShip r =(RelShip) erf.Rels.elementAt(i);
          s = s  +  createFig(r);
       }

  


    for (int i = 0; i<ni ; i++)
       {  s = s + createFig( (ISA) erf.Isa.elementAt(i));
       }

// das wars , der String wird jetzt von ERFrame.translate() in einem neuen TextFrame angezeigt
 return s; 


}


private String Triangle(boolean dir,Line l )
    {   boolean w = l.waagrecht;

          
        Point p = new Point(0,0); Point ww = l.getLocation();
        int le = l.length; if (le < Variables.SpecialD + 5) return ""; 
        int px1=0,py1=0,px2=0,px3=0,py2=0,py3=0;
        int xx = le / 2;

        if ( (w==false) && (dir == true) )
        {  
           px1 = p.x;                         py1 = p.y+xx + Variables.SpecialD;
           px2 = p.x + 2* Variables.SpecialD; py2 = p.y+xx + Variables.SpecialD;
           px3 = p.x + Variables.SpecialD;    py3 = p.y+xx - Variables.SpecialD;
          
        }

        if ( (w==false) && (dir == false) )
        {  
           px1 = p.x;                         py1 = p.y+xx - Variables.SpecialD;
           px2 = p.x + 2* Variables.SpecialD; py2 = p.y+xx - Variables.SpecialD;
           px3 = p.x + Variables.SpecialD;    py3 = p.y+xx + Variables.SpecialD;
 
            
        }

        if ( (w==true) && (dir == true) )
        {  
           px1 =  p.x+xx - Variables.SpecialD;      py1 = p.y;
           px2 =  p.x+xx - Variables.SpecialD;      py2 = p.y + 2* Variables.SpecialD;
           px3 =  p.x+xx + Variables.SpecialD;    py3 = p.y + Variables.SpecialD;

         
        }

        if ( (w==true) && (dir == false) )
        {  
           px1 =  p.x+xx + Variables.SpecialD;      py1 = p.y;
           px2 =  p.x+xx + Variables.SpecialD;      py2 = p.y + 2* Variables.SpecialD;
           px3 =  p.x+xx - Variables.SpecialD;      py3 = p.y + Variables.SpecialD;



                        
          
        }
	String  s = Triangle((ww.x+px1)*10,(ww.y+py1)*10,(ww.x+px2)*10,(ww.y+py2)*10,(ww.x+px3)*10,(ww.y+py3)*10);
   
        return s ;

    }

  /** zeichnet den Kreis fuer Optional */
    private String Circle(Line l )
    {  boolean w = l.waagrecht;  Point p = l.getLocation(); String s = "";
               int le = l.length ; if (le < Variables.SpecialD + 5) return s ; 
             le = le /2;
      if (w == false)
      {

      

       
       s = s + Circle((p.x+Variables.SpecialD)*10,(p.y + le)*10,(Variables.SpecialD)*10);

              return s ;
       }

      else
      {
      
      // g.fillOval(le-Variables.SpecialD,0,2* Variables.SpecialD  , 2* Variables.SpecialD);


       s = s + Circle((p.x+le)*10,(p.y+Variables.SpecialD)*10,(Variables.SpecialD)*10);

             return s;
      }
                                                          
    }


private String Circle(int cx,int cy , int rad)
{
 String s = 
         "1 3 0 1 0 7 99 0 20 0.000 1 0.0000 " + cx + " "  + cy + " " + rad + " " + rad + " " + 
	 cx +" " + cy + " " + cx + " " + (cy + rad)  ;
	 
	 return s + "\n";
}


/**Istf�r die Verzweigung bei mehrwertigen
  * RelShips zust�ndig*/

private String Delta(boolean dir,Line l)
{
     int le = l.length; boolean w = l.waagrecht;
     int x,y,x1,y1,x2,y2; Point pp = l.getLocation();

     x=y=x1=y1=x2=y2=0;

     if ((w==true)&&(dir == true))
     {
        x  = le - Variables.SpecialD; y = Variables.SpecialD;
        x1 = le; x2 = le;
        y1 = 0; y2 = 2*Variables.SpecialD;

     }

     if ((w==false)&&(dir == true))
     {
        x  = Variables.SpecialD; y = Variables.SpecialD;
        x1 = 0; x2 = 2*Variables.SpecialD;
        y1 = 0; y2 = 0;
     
     }

     if ((w==true)&&(dir == false))
     {
        x  = Variables.SpecialD; y = Variables.SpecialD;
        x1 = 0; x2 = 0;
        y1 = 0; y2 = 2*Variables.SpecialD;

     }

     if ((w==false)&&(dir == false))
     {
        x  =  Variables.SpecialD; y =le - Variables.SpecialD;
        x1 = 0; x2 = 2*Variables.SpecialD;
        y1 = le; y2 = le;

     }

   String s = "";

     s = s  + Line((pp.x+x)*10,(pp.y+y)*10,(pp.x+x1)*10,(pp.y+y1)*10,false,false);
     s = s +  Line((pp.x+x)*10,(pp.y+y)*10,(pp.x+x2)*10,(pp.y+y2)*10,false,false);

 return s;
}


}
