
import java.util.Vector;

/** Hiermit werden beim konvertieren nach SQL nach
  * hinten verschobene FOREIGN KEYS gespeichert, 
  * die sp�ter mit ALTERTABLE nachgereicht werden*/

public class AlterTable
{
  /** Die Tabelle die ge�ndert werden soll*/
  public String goal;
  
  /**Die Attribute in goal die ge�ndert werden*/
  public Vector attribs = new Vector();
  
  /**Die Tabelle die refernziert wird (per FOREIGN KEY)*/
  public String ref;
  
  private int numOfE = 0;  
  
  public AlterTable(String g,String r)
  {
    goal = g; 
  
    ref = r;
  }

  private int uniq=0;


  public String namme = "";


  public void addRef(String s)
  {
    namme = namme + s;
    attribs.addElement(s);
    numOfE++;
  }

  public String toString()
  { if (numOfE<=0) return "";
    String s ="";
    String ref12 = ref.replace('(','_');
    ref12 = ref12.replace(')','_');
    ref12 = ref12.replace(' ','_');

    s = s + "ALTER TABLE " + goal + " ADD CONSTRAINT " + namme+ "ref" + ref12 + "\n";
    
    s = s + "  FOREIGN KEY (";
    
    for(int i=0;i<numOfE;i++) s = s + ((String) attribs.elementAt(i)) + ","; 
    
    s = s.substring(0,s.length()-1);
    s = s + ") REFERENCES " + ref + ";\n";
  
  
    return s;
  }









}
