import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.Point;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;


/** zeichnet und verwaltet die Mausereignisse der Diamond Komponente ( die zentrale 
 * Komponente der Klasse RelShip ) 
 * @see Diamond 
 * @see RelShip  */

public class BasicDiamondUI extends DiamondUI implements MouseListener,MouseMotionListener
{   private boolean pressed=false; // zeigt an , ob eine Verschiebung der Komponente im Gange ist 
    private int x,y;               //  speichert die Anfangsposition , wo auf die Komponente geklickt wurde   


    /** leerer Konstruktor */
    public BasicDiamondUI()
    {
    }

    /** legt eine neue Instanz dieser Klasse an */
    public static ComponentUI createUI(JComponent c)
    { return new BasicDiamondUI();}

    /** installiert die MausListener */
    public void installUI(JComponent c)
    { Diamond d = (Diamond) c;
      d.addMouseListener(this);
      d.addMouseMotionListener(this);
    }

    /** deinstalliert die MausListener */
    public void uninstallUI(JComponent c)
    { Diamond d = (Diamond) c;
      d.removeMouseListener(this);
      d.removeMouseMotionListener(this);


    }


    /** zeichnet halt die vier Linien in der richtigen Farbe, je nachdem ob die
        RelShip markiert ist oder nicht  */
    public void paint(Graphics g,JComponent c)
    { 
         Diamond d = (Diamond) c;
         if (d.isMarked()) g.setColor(Variables.markColor);
         else g.setColor(Variables.drawColor);
         g.drawLine(Variables.DiamondX/2,0,  Variables.DiamondX,Variables.DiamondY/2);
         g.drawLine(Variables.DiamondX,Variables.DiamondY/2,   Variables.DiamondX/2,Variables.DiamondY);
         g.drawLine(Variables.DiamondX/2,Variables.DiamondY,  0,Variables.DiamondY/2);
         g.drawLine(0,Variables.DiamondY/2,       Variables.DiamondX/2,0);

    }


      /** Nimmt an , dass die Komponente verschoben
        * werden soll , und speichert den Punkt , auf
        * den gedrueckt wurde als Startpunkt */
    public void mousePressed(MouseEvent e)
    {   x = e.getX();
        y = e.getY();
        Diamond d = (Diamond) e.getComponent();
        d.pressed = true;
        d.parent.isId();
    }


    /** fertig , hier muss nichts getan werden , da bei jedem Drag neu gezeichnet wird */
    public void mouseReleased(MouseEvent e)
    {
      Diamond d = (Diamond) e.getComponent();
      d.pressed = false;
    }
 
    /** leer */
    public void mouseEntered(MouseEvent e)
    {
    }

    /** leer */
    public void mouseExited(MouseEvent e)
    {
    }

    /** wird ausgefuehrt , wenn auf die Komponente geklickt wurde , 
      * oeffnet einen Dialog zum Bearbeiten */
    public void mouseClicked(MouseEvent e)
    { Diamond d = (Diamond) e.getComponent();
      d.parent.openDialog();
         
    }

    /** Wenn die Komponente verschoben werden soll , 
      * wird diese Methode verwendet */
    public void mouseDragged(MouseEvent e)
    {  int nx = e.getX();
       int ny = e.getY();  // der aktuelle Punkt 
       Diamond d =(Diamond) e.getComponent();
       nx = nx - x;
       ny = ny - y;    // die Differenz zum Start Punkt (wurde in *pressed gespeichert)

       Point p = d.getLocation();  // die aktuelle Position von parent
       
       if (p.x+nx > -20 && p.y + ny > -20 ) { // wir wollen doch nichts aus der Zeichenflaeche rausschieben oder ?
       d.setLocation(p.x+nx,p.y+ny);
       d.parent.NameLabel.setLocation(p.x+nx+Variables.NameLabelDX,p.y+ny+Variables.NameLabelDY);

       // wenn man die rechte Maustaste benutzt: Linien neu berechnen
       
       d.hasChanged(nx,ny, Methods.isRightClick(e));
       
       }

    }

    /** leer */
    public void mouseMoved(MouseEvent e)
    {
    }


}
