import java.util.Vector;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Dimension;

/** regelt das Verhalten von RelationShips auf der Zeichenflaeche ,
 *  nimmt Nachrichten von Komponenten der RelShip entgegen und leitet sie an die
 *  benachbarten Komponenten weiter.
 *  Enthaelt 5 Komponenten : 0: Diamond , 1-3:Lines , 4:Entity
 *  
 */

public class DrawSample
{
/** Die Nummer des DrawSamples(1-3) */
private int drsnum=0;

/** Die Anzahl der Elemente im Vektor */
private int num=0;

/** Enthaelt die Komponenten */
private  Vector DrawAbles;

/** Bei einer binaeren Relationship wird ein DrawSample deaktiviert , d.h. er leitet keine Nachrichten weiter */
private boolean activated;

/** Die RelShip-Instanz zu der dieser DrawSample gehoert */
private RelShip parent;

/** Die Position , an der die dritte Linie an der Entity andockt , 0: links,oben 1:rechts,unten */
public double dockPer=0.4;

/** zum "debuggen" */
  public void dump()
  {
    //System.out.print("dump : " + parent.oco + " " + parent.ocr + " " + parent.ocu + " " + parent.ocl);

   }

  public DrawSample(RelShip ppp)
  {  DrawAbles = new Vector();
     parent = ppp;
  }


/** wird bei 'init' der RelShip verwendet , um nacheinander die Komponenten einzufuegen */
  public void addDrawAble(DrawAble d)
  {       d.setNum(num);
          num++;
          DrawAbles.addElement(d);
  
   }


/** wird von Komponenten , die sich geaendert haben gerufen */
  public  void hasChanged(int nx , int ny , int num)
  {  if (activated==false) return;
     

     /*if (num==3) 
     {

       
       return;
     } */ 

     if (num>0)
        { DrawAble d = (DrawAble) DrawAbles.elementAt(num-1);
          d.reDraw(false,nx,ny);

        }
     if (num<3)  // Line 3 schickt keine Nachricht an Entity , Constraints werden von LineUI eingehalten 
                 // d.h. line 3 bewegt sich innerhalb Hoehe oder Breite der Entity
        { DrawAble d1 = (DrawAble) DrawAbles.elementAt(num+1);
 
          d1.reDraw(true,nx,ny);
        }


  }

  
/** steht noch im Interface , wird nicht verwendet */
public boolean canChange(int nx,int ny , int num)
  {

     return true;
  }


  public void setActivated(boolean b)
  {
    activated = b;
  }

  public void setEntity(Entity e)
  {
     DrawAbles.setElementAt(e,4);
  }


/** bei Bewegungen der Entity wird der gesamte DrawSample neu gezeichnet */
  public void drawAgain() {
      Diamond dia = (Diamond) DrawAbles.elementAt(0);
      Line[] ls = new Line[3];
      for (int i=0;i<3;i++) {
	  ls[i] = (Line) DrawAbles.elementAt(i+1);
      }
      // beim Neu malen koennte auch keine Entity dranhaengen, dann aber
      // nicht neu malen              -- mihi, 2003-12-06
      if (!hasEntity()) return;
      Entity e = (Entity) DrawAbles.elementAt(4);
      int ll2 = ls[1].length;
      int dy=0,dx=0,lx=0,ly=0;
      boolean b = ls[0].waagrecht;
      Point p2 = ls[1].getLocation();
      boolean s = ls[1].direction;
      Rectangle r = e.getBounds();

      for(int i=0;i<3;i++) {
	  ls[i].setVisible(false);
	  parent.parent.p.remove(ls[i]);
      }     
     if (parent.ocl==drsnum) parent.ocl=0;
     if (parent.ocr==drsnum) parent.ocr=0;
     if (parent.oco==drsnum) parent.oco=0;
     if (parent.ocu==drsnum) parent.ocu=0;
     parent.dockEntity(drsnum,dia,ls,e,this);
  }

/** Die Nummer gibt an , wo der DrawSample am Diamond anliegt .
  * 1 = oben , dann im Uhrzeigersinn */
public void setNum(int n)
{
 drsnum = n;
}

/** gibt die Position und Groesse der Entity zurueck */
public Rectangle getEntityRec()
{
  Entity e = (Entity) DrawAbles.elementAt(4);
  Dimension d = e.getSize();
  Point p =  e.getLocation(); 
  Rectangle r = new Rectangle(p.x,p.y,p.x+d.width,p.y+d.height);
  return r;
}


/** entfernt alle Komponenten bis auf Diamond und Entity*/
public void remove()
{
  Line l;
  l = (Line) DrawAbles.elementAt(1); l.setVisible(false);parent.parent.p.remove(l); 
  l = (Line) DrawAbles.elementAt(2); l.setVisible(false);parent.parent.p.remove(l); 
  l = (Line) DrawAbles.elementAt(3); l.setVisible(false);parent.parent.p.remove(l); 

}

public DrawAble getDrawable(int nr) {
    return (DrawAble) DrawAbles.elementAt(nr);
}

public boolean hasEntity() {
    if (!(DrawAbles.elementAt(4) instanceof Entity)) return false;
    // dasselbe, wenn die Entity nichts mehr von dem RelShip wei�
    // im alten Code wurde das neuzeichnen nur von der Entity angesto�en
    Entity e = (Entity) DrawAbles.elementAt(4);
    if (!e.knowsDrawSample(this)) return false;
    return true;
}
    
}
