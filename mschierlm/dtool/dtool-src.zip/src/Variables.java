import java.awt.Color;



/** Diese Klasse enthaelt Konstanten , die im Programm verwendet werden */

public class Variables {

    /** der Look & Feel , der das Aussehen des Programms festlegt (z.B. windows, metal oder motif ) */
    public static String lnfName = "javax.swing.plaf.windows.MetalLookAndFeel";  
    // alternativ z.B. "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";  

    /** der Name , der im Titel des Hauptrahmens angezeigt wird */
    public static String AppName = "DesignTool 1.02";

    /**  die Startgroesse des Hauptrahmens */
    public static int StartX = 800;
    public static int StartY = 600;

    /** Die nexten 6 Variablen legen Position , Groesse und Aussehen eines ERFrame fest */
    public static int ERFrameLocX = 100;
    public static int ERFrameLocY = 100;
    public static int ERFrameX = 400;
    public static int ERFrameY = 300;
    public static Color ERbgColor = new Color(1,21,121); // Hier kann man den
    // Hintergrund aendern
    public static Color drawColor = Color.pink;
    public static Color markRecColor = Color.yellow;
    public static Color markColor = Color.red;   // Mit rot wird die Selektion angezeigt
    public static int panelSizeX = 1800;
    public static int panelSizeY = 1800; // Die Anfangsgroesse der Zeichenflaeche
    public static int sizeChange = 100; // um wieviele Pixel die Groesse der Zeichenflaeche geaendert wird
    public static int minSizeX = 900;
    public static int minSizeY = 900; // die minimale Groesse der Zeichenflaeche

/** Position und Groesse eines neuen Textframes */
    public static int TextFrameLocX = 100;
    public static int TextFrameLocY = 100;
    public static int TextFrameX = 200;
    public static int TextFrameY = 200;


    /** Entities sind grau , haben die Anfangsgroesse 300x200 und sind nicht durchsichtig */
    public static Color EntityBackGround = Color.lightGray;
    public static int EntityX = 300;
    public static int EntityY = 200;
    public static boolean EntityOpaque = true;


    /** Zuerst die Groesse der DiamondKomponente */
    public static int DiamondX = 40;
    public static int DiamondY = 40;
    public static int SpecialD = 5;  // Dies bezieht sich auf die Groesse der Kreise , Dreiecke und
    // 'Flussdelta' bei RelShips 
    public static int NameLabelDX = -20; // Wo der Name der RelShip relativ zu Diamond gezeichnet
    public static int NameLabelDY = -20; // wird

    /** Ein IsaCenter (der Halbmond) ist 40 x 40/2 gross , der Y-Wert wird im Programm halbiert */
    public static int IsaCenterX = 40;
    public static int IsaCenterY = 40;
    public static Color IsaLineColor = Color.pink; // Isa Lines sind im gegensatz zu normalen
    // Linien blau

    /** Hier werden die Namen der Klassen eingetragen , die zum Konvertieren
     * nach SQL verwendet werden */
    // die Variable wird nicht verwendet -- mihi, 2003-12-06
//    public static Class[] convertArray = { ConvertExample.class ,Convert3.class };

    /** Die Strings in diesem Vector stehen nach Anlegen eines neuen ERFrame
     * als Datentypen zur Verfuegung */
    public static String[] types = {"numeric","blob","string","integer","float"};

    public static int RelShipDlgSizeX  = 485;
    public static int RelShipDlgSizeY  = 400;

    /**Zum Helpframe : */
    public static int HelpFrameLocX = 1; 
    public static int HelpFrameLocY = 1;
    public static int HelpFrameSizX = 300; 
    public static int HelpFrameSizY = 200;
    public static String HelpFile = "html/toc.html";
    public static String HtmlFile = ""; // hier wird dynamisch die URL zur Doku gesetzt :
    // "file:/" + usr.dir +  Separator + HelpFile 

    /**Infos  zu SQL*/
    public static String StringType = "String";
    public static String Comment = "//";

    /**Die in SQL-9x illegalen Zeichen sollten hier stehen*/
    public static String illegals = "?�#~��!)({}[]";

    /**ob jdk 1.3 benutzt wird, wird  im Konstruktor von Start gesetzt*/
    //   public static boolean is13 = false;

    public static int jdkRevision = 3;
}
