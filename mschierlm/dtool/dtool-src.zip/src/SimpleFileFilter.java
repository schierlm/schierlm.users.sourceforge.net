import javax.swing.filechooser.FileFilter;
import java.io.File;


/** Diese Klasse habe ich aus einem Buch (Eckstein)
  * abgeschrieben . Sie stellt Eingabemasken fuer die 
  * open und Save Dialoge zur Verfuegung */
public class SimpleFileFilter extends FileFilter
{

  String[] extensions;
  String description;

  public SimpleFileFilter(String ext)
  {
    this (new String[] {ext}, null);
  }

  public SimpleFileFilter(String[] exts, String descr)
  {
    extensions = new String[exts.length];
    for (int i = exts.length - 1; i >= 0; i--)
    { extensions[i] = exts[i].toLowerCase();}  // anscheinend hat der Auto die Windoof Krankheit

    
    description = (descr == null ? exts[0] + " files" : descr);
  }

  public boolean accept(File f)
  {
  
    if (f.isDirectory()) { return true; }

  
    String name = f.getName().toLowerCase();
    for (int i = extensions.length - 1; i >= 0; i--)
    {
      if (name.endsWith(extensions[i])) { return true; }

    }
    return false;
  }



public String getDescription()
{ return description; }


}
