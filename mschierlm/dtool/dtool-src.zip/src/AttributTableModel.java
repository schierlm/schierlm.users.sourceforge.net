import javax.swing.table.AbstractTableModel;
import javax.swing.DefaultComboBoxModel;
import java.util.Vector;


/** Dieses Modell speichert die Attribute einer Entity bzw. RelShip
 *  Diese Daten werden von den Tabellen in der Entity Komponente bzw.
 *  im RelShipDlg angezeigt   */
public class AttributTableModel extends AbstractTableModel
{    

     /** In diesen Vector werden die Reihen der Tabelle eingefuegt 
      * in diesem Fall (AttributTabelle) sind das AttributRowModels 
      * @see AttributRowModel 
      */ 
     private Vector data = new Vector(); // hier werden AttributRowModels eingefuegt

     
      /** Diese Tabelle enthaelt sechs Spalten , dies sind die Ueberschriften */
     private String [] headers = {"Name","Domain","P","U","M","O"};


     /** In jeder Spalte muessen Objekte vom gleichen Typ stehen , hier werden
       * die Klassen festgelegt */
     Class [] columnClasses = {String.class,DefaultComboBoxModel.class,
                               Boolean.class,
                               Boolean.class,Boolean.class,
                               Boolean.class};

/** Die Klone Methoden von Entities und RelShips stuetzen sich auf diese Methode ab.
  * Diese Methode wiederum stuetzt sich auf klone von AttributRowModel ab 
  * @param desttypes Dieser Vector wird verwendet, damit AttributRowModel.klone() weis ob die Domaene schon vorhanden ist*/ 
public AttributTableModel klone(Vector desttypes)
      {
          int r = getRowCount();
          AttributTableModel a = new AttributTableModel();

          for (int i = 0; i<r;i++)
          { 
            AttributRowModel arm = (AttributRowModel) data.elementAt(i);
            AttributRowModel ar = arm.klone(desttypes);
            a.addRow(ar);
                

          }     

             return a;
      }



  /** Informiert den Renderer der Tabelle (macht Swing intern) , wieviele Reihen er darstellen muss
    * gibt logischerweise die Laenge des data Vektors zurueck */
  public int getRowCount() { return data.size();}

 /** Hier habe ich die Anzahl der Spalten der Tabelle fest eingecodet .
   * Bei AttributTableModel sind das sechs (s.o) */
  public int getColumnCount() { return 6;}

  /** Hier kann Swing nachfragen , welche Art von Objekt in der Spalte c steht */
  public Class getColumnClass(int c)
      { return columnClasses[c];}

  /** Hier erfaehrt Swing , welche Ueberschrift eine Spalte haben soll */
  public String getColumnName(int c) { return headers[c];}


  /** Wenn diese Methode false liefert kann der Inhalt von Zelle (r,c) einer Tabelle nicht 
    * geaendert werden (z.B. wenn PrimaryKey aktiviert ist ) */
  public boolean isCellEditable(int r , int c )
      { if (c<2) { return true;}
       
           AttributRowModel atrm = (AttributRowModel) data.elementAt(r);
          if (c==2) return atrm.getPk().isEditable();

          if (c==3) {return atrm.getUn().isEditable();}
          if (c==4) return atrm.getMw().isEditable();
          if (c==5) return atrm.getOp().isEditable();
                  
return false;
        

      }


 /** Liefert den Inhalt von Zelle (r,c) zurueck ,
   * Zuerst wird die von r angegebene Reihe aus dem data - Vektor geladen (vom Typ AttributRowModel
   * Dann wird aus AttributRowModel entsprechende (je nach c) Objekt zurueckgegeben*/
 public Object getValueAt(int r  , int c)
      { AttributRowModel atrm = (AttributRowModel) data.elementAt(r);


          if (c==0) return atrm.getName();
          if (c==1)  return atrm.getDomain();
                                                             
          if (c==2) return new Boolean(atrm.getPk().isSelected());

          if (c==3) return new Boolean(atrm.getUn().isSelected());
          if (c==4) return new Boolean(atrm.getMw().isSelected());
          if (c==5) return new Boolean(atrm.getOp().isSelected());

        return null;
      }


/** Invers zu getValueAt , nur dass das Objekt geaendert statt zurueckgegeben wird.
  * Zusaetzlich wird fireTableDataChanged ausgeloest, damit alle Bescheid wissen , 
  *  dass sich etwas geaendert hat. */ 
 public void setValueAt(Object value,int r , int c)
      {  AttributRowModel arm  = (AttributRowModel) data.elementAt(r);
         if (c==0) arm.setName( (String) value );
         if (c==1){ DefaultComboBoxModel dcm = (DefaultComboBoxModel) value;
                    arm.setDomain(dcm);
                  }  
         if (c==2) arm.setPk(((Boolean) value).booleanValue());

         if (c==3) arm.setUn(((Boolean) value).booleanValue() );
         if (c==4) arm.setMw(((Boolean) value).booleanValue() );
         if (c==5) arm.setOp(((Boolean) value).booleanValue() );

        fireTableDataChanged();
      }


 /** fuegt eine neue Reihe unten an und zeichnet die Tabelle neu */
 public void addRow(AttributRowModel atrm )
      {  
           data.addElement(atrm);
           fireTableDataChanged();
      }



/** Liefert die Reihe (AttributRowModel) an Position i in data zurueck */
 public AttributRowModel getRowAt(int i)
      {
          return (AttributRowModel) data.elementAt(i);

      }
   

/** Loescht Reihe Nr. i und zeichnet die Tabelle neu */ 
 public void removeRow(int i)
      {
           data.removeElementAt(i);
           fireTableDataChanged();
      }

}
