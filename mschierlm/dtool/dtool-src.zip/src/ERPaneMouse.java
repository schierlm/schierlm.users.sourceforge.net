import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.Rectangle;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;

/** Verarbeitet die Mausereignisse der JLayeredPane (d.h. in ERFrame werden der MouseListener von der 
  * Zeichenflaeche (jlp p)
  * auf eine Instanz dieser Klasse gesetzt )
 * @see ERFrame */

public class ERPaneMouse implements MouseListener,MouseMotionListener
{   MarkRectangle mr = new MarkRectangle();  // zeichnet Viereck auf Zeichenflaeche

   
    int x1 = 0 , y1 = 0; // globale Variablen zum speichern der Klick Position
 
    ERFrame parent;    // der uebliche link ( hier auf den ERFrame )


/** Konstruktor , fuegt ein MarkRectangle in die Zeichenflaeche ein (unsichtbar)*/
public ERPaneMouse(ERFrame ee)
      {
       parent = ee;
       parent.p.add(mr,new Integer(20));

      }


 /** macht das MarkRectangle sicht bar , und setzt es auf den Punkt , auf den geklickt wurde */
    public void mousePressed(MouseEvent e)
    {  int x = e.getX();
       int y = e.getY();
    
       x1  = x; y1  = y; // wird global gespeichert 
       mr.setLocation(x,y);
       mr.setVisible(true);
       mr.setSize(1,1);    // und das MarkRectangle wird sichtbar

       parent.p.invalidate();
       mr.invalidate();
       parent.p.validate();
       mr.repaint();   // die uebliche Sequenz , damit auch ja gleich richtig gezeichnet wird ...
     

        parent.marking = true;
                  
    }

   /** macht das MarkRectangle wieder unsichtbar und ruft setMarked in ErFrame auf */
    public void mouseReleased(MouseEvent e)
    {  int i=0;                                                          
        Point p = mr.getLocation(); Dimension d = mr.getSize();
        mr.setVisible(false);
        mr.setVisible(false); // das Viereck wird wieder unsichtbar
        if (e.isShiftDown()) { /*System.out.println("SH DOWN");*/i=1;}     
        parent.setMarked(p.x,p.y,p.x + d.width,p.y + d.height,i); // ueberprueft alle Komponenten ob sie innerhalb sind 
        parent.marking=false;
    }

    /** leer */
    public void mouseClicked(MouseEvent e)
    { 
       
    }
    /** leer */
    public void mouseMoved(MouseEvent e)
    { 
      
    }

   /** berechnet die neue Groesse des Vierecks und zeichnet es neu und am Schluss noch was zum AutoScrollen */
    public void mouseDragged(MouseEvent e)
    {  int sx=0,sy=0;
       int mvx=x1,mvy=y1;
       int szx = 0 , szy = 0;       

          

        int nx = e.getX();
        int ny = e.getY();
      
       szx = nx - x1;
       szy = ny - y1;


       if (nx<x1) {mvx = nx; szx = x1 - nx;}       
       if (ny<y1) {mvy = ny; szy = y1 - ny;}          


       mr.setLocation(mvx,mvy);
       mr.setSize(szx , szy);
       mr.repaint();


       Rectangle r = parent.getViewPort();

///////////////////////////////////////////////////////////////////
     if (nx < r.x + 8 ) sx = -40;
     if (nx > r.x + r.width - 8) sx = 40;
     if (ny < r.y + 8 ) sy = -40;
     if (ny > r.y + r.height - 8) sy = 40;
     if (sx != 0 || sy != 0) parent.scroll(sx,sy);  // das daemlichste AutoScrollen aller Zeiten
    

    }

    /** leer */
   public void mouseExited(MouseEvent e)
    { 
    }

    /** leer */
    public void mouseEntered(MouseEvent e)
    { 
    }

  

}
