import javax.swing.DefaultComboBoxModel;
import java.util.Vector;


/** Diese Klasse modelliert eine (von 3) Reihe(n) im ERPanelTableModel 
  * sie entspricht einer Verbindung von Diamond zu einer Entity (* bei Relationships )
  * Sie enthaelt ein ComboBoxModel , in dem man die Entity selektieren kann.
  * Und vier CheckBoxModels fuer optional , mehrwertig , schwach oder stark 
  * @see CheckBoxModel
  */

public class ERPanelRow
{
    /** Die Entity zu der diese "Verzweigung" der RelShip  fuehrt */
    private DefaultComboBoxModel Entity;
   
    /** Die vier Attribute Optional , Many , Weak , Strong */
    private    CheckBoxModel opt,man,wea,str;

/** Konstruktor mit vorgegebenen Attributen (Paste und Load) */
public ERPanelRow(DefaultComboBoxModel dfm,boolean o,boolean ma,boolean we,boolean st)
{
   Entity = dfm;
   opt = new CheckBoxModel(o,true);
   man = new CheckBoxModel(ma,true);
   wea = new CheckBoxModel(we,true);
   str = new CheckBoxModel(st,true);
                              // zum zweiten Argument : Diese CheckBoxen sind momentan immer Editierbar(true)
                              // koennte hier leicht geaendert werden , z.B weak nur wenn�Strong */

}

/** Konstruktor , der Standardwerte verwendet  */
public ERPanelRow(DefaultComboBoxModel dfm)
{  
   Entity = dfm;
   opt = new CheckBoxModel(false,true);
   man = new CheckBoxModel(false,true);
   wea = new CheckBoxModel(false,true);
   str = new CheckBoxModel(false,true);
  
}


/** gibt ein ComboBoxModel zurueck , in dem die aktuelle Entity selected ist */
public DefaultComboBoxModel getEntity()
{ 
   return Entity;
}

/** ersetzt das aktuelle ComboBoxModel durch s */
public void setEntity(DefaultComboBoxModel s)
{
  Entity = s;
  
}

/** ob diese Verbindung optional ist */
public CheckBoxModel getOp()
{ return opt;}

/** ob diese Verbindung mehrwertig ist */
public CheckBoxModel getMa()
{ return man;}

/** ob diese Verbindung  schwach ist*/
public CheckBoxModel getWe()
{ return wea;}

/** ob diese Verbindung stark ist */
public CheckBoxModel getSt()
{ return str;}

/** Accessor fuer opt(ional) */
public void setOp(CheckBoxModel cbm)
{         opt = cbm;
}

/** Accessor fuer man (wie mehrwertig) */
public void setMa(CheckBoxModel cbm)
{  man = cbm;}

/** Accessor fuer str(ong) */
public void setSt(CheckBoxModel cbm)
{  str = cbm;
   wea.setSelected(false);
}

/** Accessor fuer weak  */
public void setWe(CheckBoxModel cbm)
{  wea = cbm;
   str.setSelected(false);
}


/** klont sich selbst */
public ERPanelRow klone()
{
   return new ERPanelRow(Entity,opt.isSelected(),man.isSelected(),wea.isSelected(),str.isSelected());
}

}
