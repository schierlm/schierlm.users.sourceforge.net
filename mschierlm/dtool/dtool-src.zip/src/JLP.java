import javax.swing.JLayeredPane;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Rectangle;

/** eine giftgruene (igitt) JLayeredPane */

public class JLP extends JLayeredPane {

   /** fuellt die Zeichenflaeche gruen */
   public void paint(Graphics g)
   {
      Rectangle r = g.getClipBounds();
      g.setColor(Variables.ERbgColor);
      setBackground(Variables.ERbgColor);
      g.fillRect(r.x,r.y,r.width,r.height);

      super.paint(g);
   }
}
