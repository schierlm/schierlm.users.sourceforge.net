import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;



public class IsaMouseListener implements MouseListener
{   
 private JTable jt1,jtfake; 
   public IsaMouseListener(JTable jt)
      {
       jt1 = jt; 

      }


    public void mousePressed(MouseEvent e)
    {  
                  
    }

    public void mouseReleased(MouseEvent e)
    {                                                          
      
    }

    public void mouseClicked(MouseEvent e)
    { 
      

    }
 
    

    public void mouseExited(MouseEvent e)
    { 
       
    }

    public void mouseEntered(MouseEvent e)
    {
     if (jt1.isEditing()) 
                {
                  TableCellEditor cellEditor =jt1.getCellEditor();           
                  if (cellEditor != null) 
                  {
                     cellEditor.stopCellEditing();
                  }
                }            

     
    }

  

}
