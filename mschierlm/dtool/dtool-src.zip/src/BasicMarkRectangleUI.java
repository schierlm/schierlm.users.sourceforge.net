import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;

import javax.swing.plaf.ComponentUI;
import javax.swing.JComponent;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;


/** zum Zeichnen der MarkRectangle Komponente , 
  * ( das REchtEck zum markieren von Entities , etc . */
public class BasicMarkRectangleUI extends MarkRectangleUI 
{  
 
    /** legt eine neue Instanz von dieser Klasse an */
    public static ComponentUI createUI(JComponent c)
    { return new BasicMarkRectangleUI();}

    /** leer */ 
    public void installUI(JComponent c)
    { //MarkRectangle e = (MarkRectangle) c;
      
    }

    /** leer */
    public void uninstallUI(JComponent c)
    { //MarkRectangle e = (MarkRectangle) c;

    }


  /** zeichnet halt einen schwarzen Rahmen */
  public void paint(Graphics g , JComponent c)
  {

     g.setColor(Variables.markRecColor);

     Dimension d = c.getSize();

     g.drawRect(0 , 0 , d.width -1 , d.height -1 );


  }
  

   


  

}
