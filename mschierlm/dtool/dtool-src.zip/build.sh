#!/bin/bash
# Batchdatei f�r das Compilieren von DTool.
# Ich empfehle nat�rlich, ant zu verwenden. Ist schneller und besser.
# -- mihi, 2003-12-02
#
set -e
mkdir -p build/html
cp license.txt build/html
cd src
javac *.java -d ../build
cp html/* ../build/html
cd ../build
echo Main-Class: DTool>manifest
jar cfm ../dtool.jar manifest *.class html
cd ..
echo Fertig.