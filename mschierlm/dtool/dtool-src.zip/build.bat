:: Batchdatei f�r das Compilieren von DTool.
:: Ich empfehle nat�rlich, ant zu verwenden. Ist schneller und besser.
:: -- mihi, 2003-12-02
::
@echo off
if not exist build\nul mkdir build
if not exist build\html\nul mkdir build\html
copy license.txt build\html
cd src
javac *.java -d ..\build
if errorlevel 1 goto ende
copy html\*.* ..\build\html\*.*
cd ..\build
echo Main-Class: DTool>manifest
jar cfvm ..\dtool.jar manifest *.class html
cd ..
echo Fertig.
:ende