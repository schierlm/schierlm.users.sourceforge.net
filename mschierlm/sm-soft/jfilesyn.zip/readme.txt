jFileSync V0.5
==============

(c) 2003 Michael Schierl

This program is written in java and therefore needs an installed Java
Runtime Environment 1.4 or higher. You can get it at
http://java.sun.com/

If you have it installed, double click onto the jFileSync.jar file or
enter

java -jar jFileSync.jar

(case sensitive) at the command prompt.

For additional command line switches, see below.


Description
-----------

JFileSync synchronizes the contents of multiple directory pairs. The
contents after the last sync of that directory are stores in a text
file and changes on either side (create, modify, delete) are
synchronized to the other side. After the directory selection (which
can be saved) a table is displayed showing all actions necessary to
get the directories synchronous again. If the action is "clear" (as
the file has only changed in one of the directories) it is
preselected. Otherwise the user may decide how to handle this
file. After confirming that table all actions are processed. If
actions remain (e. g. the directories changed while synchronization),
they are displayed again.

Useful Hints
------------

- You can select multiple files and use the drop down menu to change
  the action of all of the simultaneously.
- in default.sync (or any other settings file), you can add a few
  useful options which did not make it into the GUI yet:
  * synctest.local, synctest.remote  
    two paths which must be accessible before the sync starts -
    reduces the number of messages you see when a network drive is not
    available.
  * settings.listpath
    the directory where the syncing lists should be kept (defaults to
    the current directory)

Known Bugs
----------

- File time differences of +-3 seconds or +-1 hour +-3 seconds are
  ignored. This is actually not a bug, but necessary on Windoze to
  successfully sync files from NTFS to FAT and vice versa (Daylight
  saving time).
- On a file system that does not distinguish case in file names (like
  FAT), you might get unexpected behaviour if you create a file called
  e. g. `foo' in one and a file called `Foo' in the other directory
  simultaneously. jFileSync will crash if one of them is a folder and
  the other isn't.

Command line switches
---------------------

after the jFileSync.jar filename you can add

[{-l|--lang} language] [{-p|--plaf} lookandfeel] [filename.sync [go]]

<language> specifies a locale identifier for the interface language
(e. g. `de' for German, `en_UK' for British English...). If you want
to translate jFileSync into another language, contact the
author. Default language is decided by the Java Runtime Environment
(depending on your locale settings).

<lookandfeel> specifies the "Look&Feel" (skin) that should be
used. Usual values for it are `native' (look as much as the platform
usually looks, or `metal' (look as platform independent as
possible). If you have installed additional Look&Feels in your java
runtime, you can specify the fully qualified name for one of them here
as well. Default plaf is `native'.

<filename.sync> specifies which config file you want to use. If you
specify the literal `go' behind it, no options dialog will be
displayed; synchronization starts immediately and jFileSync exits when
it's finished. However, you will still see tables of actions.

Example
~~~~~~~
java -jar jFileSync.jar -l de --plaf metal myfile.sync go

will start in German and metal look and feel and will start syncing
according to myfile.sync.

Changelog
---------

see changelog.txt

Contact me
----------

http://smsoft.ixy.de/
sm-soft@gmx.de