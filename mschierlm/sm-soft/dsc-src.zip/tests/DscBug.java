import java.io.*;
import java.net.*;

public class DscBug implements Runnable {

    public static void  main(String[] args) throws IOException,
						   InterruptedException {
	new Thread(new DscBug()).start();
	Thread.sleep(2);
	for(int i=0;i<10;i++) {
	    Socket s = new Socket("127.0.0.1",1238);
	    OutputStream out = s.getOutputStream();
	    out.write("X".getBytes());
	    out.flush();
	    InputStream in = s. getInputStream();
	    in.read();
	    s.close();
	}
	Thread.sleep(5);
	System.exit(0);
    }

    public void run() {
	try {
	    ServerSocket ss = new ServerSocket(1239);
	    while (true) {
		Socket s = ss.accept();
		InputStream in = s.getInputStream();
		in.read();
		OutputStream out = s.getOutputStream();
		out.write("Y".getBytes());
		out.flush();
	    }
	} catch (IOException ex) {
	    ex.printStackTrace();
	}
    }
}
