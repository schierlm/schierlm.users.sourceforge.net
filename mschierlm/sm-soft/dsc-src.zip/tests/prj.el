(jde-project-file-version "1.0")
(jde-set-variables
 '(jde-global-classpath nil)
 '(jde-run-working-directory "")
 '(jde-compiler (quote ("javac" "")))
 '(jde-compile-option-directory "")
 '(jde-compile-option-classpath nil)
 '(jde-compile-option-sourcepath nil)
 '(jde-run-application-class ""))
