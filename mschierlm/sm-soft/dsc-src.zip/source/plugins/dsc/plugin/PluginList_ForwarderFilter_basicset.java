package dsc.plugin;

public class PluginList_ForwarderFilter_basicset implements PluginList {
    public String[] getPluginNames() {
	return new String[] {"Delay", "Replace", "ROT13"};
    }
}
