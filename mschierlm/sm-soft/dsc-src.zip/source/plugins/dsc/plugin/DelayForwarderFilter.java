package dsc.plugin;

import java.io.*;

public class DelayForwarderFilter extends ForwarderFilter {

    private int toSend, toQuote;
    private boolean sending=false;
    private StringBuffer sb = new StringBuffer();

    public DelayForwarderFilter() {
	this("#_");
    }
    
    public DelayForwarderFilter(String par) {
	super(par);
	if (par==null)
	    par="#_";
	else
	    par+="#_";
	toSend=par.charAt(0);
	toQuote=par.charAt(1);
    }

    public ForwarderFilter newInstance() {
	return new DelayForwarderFilter(param);
    }

    public void sendDataToServer (OutputStream out, int data) 
	throws IOException {
	System.out.println("Hallo!");
	if (data==toSend) {
	    if (sending) {
		String s=sb.toString();
		for(int i=0;i<s.length();i++) {
		    out.write((int) s.charAt(i));
		}
		sb.setLength(0);
		sending=false;
	    } else {
		sending=true;
	    }
	} else if (sending && data==toQuote) {
	    sending=false;
	    sb.append((char)toSend);
	} else {
	    sb.append((char)data);
	    sending=false;
	}
    }
}
