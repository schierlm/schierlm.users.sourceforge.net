package dsc.plugin;

import dsc.core.*;

import java.io.*;
import java.util.*;

public class ReplaceForwarderFilter extends ForwarderFilter {

    private HashMap[] rules=new HashMap[]{new HashMap(), new HashMap()};
    private HashSet[] blockstrings=new HashSet[]{new HashSet(),new HashSet()};
    private ByteCollector[] bc=new ByteCollector[] {new ByteCollector(),
						    new ByteCollector()};
    
    public ReplaceForwarderFilter() throws IOException {
	this(null);
    }

    public ReplaceForwarderFilter(String par) throws IOException {
	super(par);
	if (par==null) return;
	int dir;
	BufferedReader br=new BufferedReader(new FileReader(par));
	String line;
	while((line=br.readLine())!=null) {
	    if (line.startsWith(">"))
		dir=1;
	    else if (line.startsWith("<"))
		dir =0;
	    else
		throw new IOException("Incorrect Line: "+line);
	    line=line.substring(1);
	    int i=line.indexOf("=");
	    if (i==-1 || (line.startsWith("#") || (line.startsWith(";"))))
		throw new IOException ("Incorrect line: "+line);
	    byte[] left=Options.unconvertB(line.substring(0,i),"\\");
	    byte[] right=Options.unconvertB(line.substring(i+1),"\\");
	    for(int j=1;j<=left.length;j++) {
		blockstrings[dir].add(new ByteCollector().append(left,j));
	    }
	    rules[dir].put(new ByteCollector(left),right);
	}
	br.close();
    }

    public ReplaceForwarderFilter(HashMap[] rules,HashSet[] blockstrings) {
	this.rules=rules;
	this.blockstrings=blockstrings;
    }
    
    public ForwarderFilter newInstance() {
	return new ReplaceForwarderFilter(rules, blockstrings);
    }

    public void sendDataToClient(OutputStream out, int data)
	throws IOException {
	sendConvertedData(0,out,data);
    }

    public void sendDataToServer(OutputStream out, int data)
	throws IOException {
	sendConvertedData(1,out,data);
    }

    public void sendConvertedData(int dir, OutputStream out, int data)
	throws IOException {
	byte b=(byte)data;
	bc[dir].append(b);
	while(!bc[dir].isEmpty() && !blockstrings[dir].contains(bc[dir])) {
	    out.write(bc[dir].removeFirst());
	}
	if (bc[dir].isEmpty()) return;
	byte[] b2=(byte[]) rules[dir].get(bc[dir]);
	if (b2!=null) {
	    bc[dir].clear();
	    out.write(b2);
	}
    }
}
