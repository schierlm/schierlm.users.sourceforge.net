package dsc.plugin;

import java.io.*;

public class ROT13ForwarderFilter extends ForwarderFilter {

    private boolean rotServ=true, rotClient=true;

    public ROT13ForwarderFilter() {
	this("");
    }
    
    public ROT13ForwarderFilter(String par) {
	super(par);
	if (par.length()>1) {
	    rotServ=(par.charAt(0)=='1');
	    rotClient=(par.charAt(1)=='1');
	}
    }

    public ForwarderFilter newInstance() {
	return new ROT13ForwarderFilter(param);
    }

    private int doROT(int data)
	throws IOException {
	if ((data >='A' && data <='M') || (data >='a' && data <='m'))
	    data+=13;
	else if ((data >='N' && data <='Z') || (data >='n' && data <='z'))
	    data-=13;
	return data;
    }

    public void sendDataToServer(OutputStream out, int data) 
	throws IOException {
	out.write(rotServ?doROT(data):data);
    }
    
    public void sendDataToClient(OutputStream out, int data)
	throws IOException {
	out.write(rotClient?doROT(data):data);
    }
}
