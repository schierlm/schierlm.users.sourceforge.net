import java.io.*;
import java.util.zip.*;

/**
 * Packages the ianaports.txt.gz
 */
public class MakeIanaports {
    public static void main(String[] args) throws IOException {
	String src = args[0], dest = args[1];
	BufferedReader in = new BufferedReader(new InputStreamReader
					       (new FileInputStream(src),
						"ISO-8859-1"));
	Writer out = new BufferedWriter
	    (new OutputStreamWriter
	     (new GZIPOutputStream (new FileOutputStream(dest)),
	      "ISO-8859-1"));
	out.write("Visit http://www.iana.org/assignments/port-numbers "+
		  "for an update.\n\n");
	String line;
	while((line = in.readLine()) != null) {
	    out.write(line);
	    out.write("\n"); // LF required here
	}
	out.flush();
	out.close();
	in.close();
    }
}