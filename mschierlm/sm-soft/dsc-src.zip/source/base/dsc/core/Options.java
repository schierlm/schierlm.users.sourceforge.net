package dsc.core;

import java.io.*;
import java.util.*;
import java.awt.Font;

public class Options {

    public static Font displayFont=new Font("Courier", Font.PLAIN,12);
    public static int maxThreads=-1;
    public static boolean wrapReturn=true;
    public static String returnText="\\r\\n";
    public static String encoding=null;
    public static char escapeChar='\\';
    public static int connectSleep=0;
    public static int socketTimeout = 0;

    public static String convert(byte[] before, String esc) {
	String s;
	if(encoding==null) {
	    s=new String(before);
	} else if (encoding.equals("HEX")) {
	    return convertHex(before);
	} else {	    
	    try {
		s=new String(before,encoding);
	    } catch (UnsupportedEncodingException e) {
		s=new String(before);
	    }
	}
	StringBuffer buff=new StringBuffer();
	for (int i=0;i<s.length();i++) {
	    char c=s.charAt(i);
	    if (c<32) {
		if (c=='\n') {
		    buff.append(esc).append('n');
		} else if (c=='\r') {
		    buff.append(esc).append('r');
		} else if (c=='\t') {
		    buff.append(esc).append('t');
		} else if (c=='\b') {
		    buff.append(esc).append('b');
		} else {
		    buff.append(esc).append((c<10?"0":"")+(int)c);
		}
	    } else if (c==esc.charAt(0)) {
		buff.append(esc).append(esc);
	    } else if (c==0xfffd || (c=='?' && before[i]!= '?')) {
		buff.append(esc).append("r").append(hex(before[i]));
	    } else if (displayFont!=null && !displayFont.canDisplay(c)) {
		buff.append(esc).append("u").append(unicodeHex(c));
	    } else {			    
		buff.append(c);
	    }
	}
	return buff.toString();
    }

    public static byte[] unconvertB(String before, String esc) {
	return unconvertB(before, esc, encoding);
    }
    
    public static byte[] unconvertB(String before, String esc,
				    String enc) {
	if ("HEX".equals(encoding)) {
	    return unconvertHexB(before);
	}
	StringBuffer buff=new StringBuffer();
	byte[] ret;
	byte[] rawbytes=new byte[before.length()];
	for (int i=0;i<before.length();i++) {
	    rawbytes[i]=(byte)'?';
	}
	for (int i=0;i<before.length();i++) {
	    char c=before.charAt(i);
	    if (c==esc.charAt(0)) {
		if(before.length()>i+1 && before.charAt(i+1) == esc.charAt(0)) {
		    buff.append(c);
		    i++;
		} else if (before.length()>i+1 && before.charAt(i+1)=='n') {
		    buff.append('\n');i++;
		} else if (before.length()>i+1 && before.charAt(i+1)=='r') {
		    buff.append('\r');i++;
		} else if (before.length()>i+1 && before.charAt(i+1)=='t') {
		    buff.append('\t');i++;
		} else if (before.length()>i+1 && before.charAt(i+1)=='b') {
		    buff.append('\b');i++;
		} else if (before.length()<i+3) {
		    throw new NumberFormatException(before.substring(i+1));
		} else if (before.charAt(i+1)=='x') {
		    if (before.length()<i+4)
			throw new NumberFormatException(before.substring(i+2));
		    
		    rawbytes[buff.length()] = (byte)
			Integer.parseInt(before.substring(i+2,i+4),16);
		    buff.append('?');
		    i+=3;
		} else if (before.charAt(i+1)=='u') {
		    if (before.length()<i+6) {
			throw new NumberFormatException (before.substring(i+2));
		    } else {
			buff.append((char)Integer.parseInt(before.substring
							   (i+2,i+6), 16));
			i+=5;
		    }
		} else if (before.charAt(i+1)=='#') {
		    buff.append((char)Integer.parseInt(before.substring
						       (i+2,i+4)));
		    i+=3;
		} else {
		    buff.append((char)Integer.parseInt(before.substring
						       (i+1,i+3)));
		    i+=2;
		}
	    } else {
		buff.append(c);
	    }
	}
	if (enc==null) {
	    ret = buff.toString().getBytes();
	} else {
	    try {
		ret = buff.toString().getBytes(enc);
	    } catch (UnsupportedEncodingException e) {
		ret = buff.toString().getBytes();
	    }
	}
	for (int i=0;i<rawbytes.length && i < ret.length;i++) {
	    if (rawbytes[i]!=(byte)'?' ) {
		ret[i]=rawbytes[i];
	    }
	}
	return ret;
    }
	    

    public static String convertHex(byte[] before) {
	StringBuffer sb = new StringBuffer();
	for (int i=0;i<before.length;i++) {
	    sb.append(hex(before[i])).append(' ');
	}
	sb.setLength(sb.length()-1);
	return sb.toString();
    }

    public static byte[] unconvertHexB(String before) {
	StringTokenizer st = new StringTokenizer(before," ");
	byte[] result = new byte[st.countTokens()];
	for(int i=0;i<result.length;i++) {
	    try {
		result[i] = (byte) Integer.parseInt(st.nextToken(),16);
	    } catch (NumberFormatException ex) {
		result[i] = 0;
	    }
	}
	return result;
    }

    public static String unicodeHex(char c) {
	String s="0000"+Integer.toHexString(c);
	return s.substring(s.length()-4);
    }

    public static String hex(byte b) {
	int i = b & 0xff;
	return (i<16?"0":"")+Integer.toHexString(i).toUpperCase();
    }

    public static boolean isSupportedEncoding(String enc) {
	try {
	    "".getBytes(enc);
	    return true;
	} catch (java.io.UnsupportedEncodingException ex) {
	    return false;
	}
    }

    public static void saveFile(File f, String text) {
	        BufferedWriter bw;
        BufferedReader br;
        String line;
        try {
            bw = new BufferedWriter(new FileWriter(f));
            br = new BufferedReader(new StringReader(text));
            while((line = br.readLine()) != null) {
                bw.write(line);
                bw.newLine();
            }
            br.close();
            bw.flush();
            bw.close();
        } catch (IOException ex) {
	    ex.printStackTrace();
	    throw new IllegalArgumentException(ex.getMessage());
	}
    }

    private static String patternhelp = null;

    public static String loadPatternHelp() {
	if (patternhelp != null) return patternhelp;
	patternhelp="helptext not available...";
	try {
	    InputStream in1=
		Options.class.getResourceAsStream("/res/patterns.txt");
	    if (in1==null) return patternhelp;
	    BufferedReader in=new BufferedReader
		(new InputStreamReader(in1));
	    StringBuffer sb = new StringBuffer("");
	    String line;
	    while ((line=in.readLine())!= null) {
		sb.append(line).append("\n");
	    }
	    patternhelp=sb.toString();
	} catch (IOException e) {
	    patternhelp="Error while reading help file: "+e.getMessage();
	}
	return patternhelp;
    }


}
