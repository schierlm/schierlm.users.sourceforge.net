package dsc.core;

import java.util.*;
import java.net.*;

public class IPPortParser implements Iterator {
    private NumberParser[][] results = null;
    private String[] ipv6Results = null;
    private NumberParser[] ports = null;
    private int[] next= new int[7];
    private int[] mapping=new int[7];
    private NumberParser[] npFixed=new NumberParser[2];
    private String ipString;
    private static NumberParser[] oneIPBitSet= new NumberParser[4];

    static {
	for (int i=0;i<4;i++) {
	    oneIPBitSet[i]=new NumberParser("1",2);
	}
    }
    
    public IPPortParser (String parseText, String p, String order) {
	BitSet[] bs;
	StringTokenizer st=new StringTokenizer(p,";");
	ports = new NumberParser[st.countTokens()];
	int cnt=0;
	while(st.hasMoreTokens()) {
	    NumberParser np=new NumberParser(st.nextToken(),65536);
	    np.clearNumber(0);
	    ports[cnt++]=np;
	}
	// NumberParser for port is finished...
	
	parseOrder(order);
	    
	st=new StringTokenizer(parseText,";");
	results = new NumberParser[st.countTokens()][4];
	ipv6Results = new String[st.countTokens()];
	cnt = 0;
	while (st.hasMoreElements()) {
	    String elem = st.nextToken();

	    if ("0123456789*".indexOf(elem.charAt(0))==-1 ||
		elem.indexOf(":") !=-1) {
		if (elem.charAt(0)=='.') elem=elem.substring(1);
		try {
		    InetAddress ipadr = InetAddress.getByName(elem);
		    elem=ipadr.getHostAddress();
		} catch (UnknownHostException e) {
		    throw new NumberFormatException (e.getMessage());
		}
	    }
	    if (elem.indexOf(".")==-1 ) { // IPv6-Adresse als Text merken
		ipv6Results[cnt] = elem;
		results[cnt] = null;
	    } else {
		int i=0;
		StringTokenizer st2=new StringTokenizer(elem,".");
		while (st2.hasMoreElements() && i != 4) {
		    results[cnt][i]=new NumberParser(st2.nextToken(),256);
		    i++;
		}
		for (int ii=i+1;i<4; i++) {
		    results[cnt][ii] = new NumberParser("",256);
		}
		results[cnt][3].clearNumber(0);
		cnt++;
	    }
	}
	if (results.length==0 || ports.length==0)
	    throw new NumberFormatException("Parameter missing");
// 	Object oo = results.elementAt(0);
// 	if (oo instanceof BitSet[]) {
// 	    bs = (BitSet[]) results.elementAt(0);
// 	}
	npFixed[0] = new NumberParser("*",results.length);
	npFixed[1] = new NumberParser("*",ports.length);
	reset();
    }

    private void parseOrder(String order){
	boolean ipmapped=false, portmapped=false;
	if (order.equals(""))
	    order="I1234Pp";
	if (order.length() != 7)
	    throw new NumberFormatException
		("Order must be 7 chars long");
	for (int i=0;i<order.length();i++) {
	    switch(order.charAt(i)) {
	    case 'I':
		mapping[i]=5; ipmapped=true;
		break;
	    case 'P':
		mapping[i] = 6;portmapped=true;
		break;
	    case '1':
	    case '2':
	    case '3':
	    case '4':
		if(!ipmapped) throw new NumberFormatException
				  ("ip map was not initialized");
		mapping[i] = (order.charAt(i)-'1');
		break;
	    case 'p':
		if(!portmapped) throw new NumberFormatException
				    ("port map was not initialized");
		mapping[i]=4;
		break;
	    default:
		throw new NumberFormatException
		    ("Unknown character in order string: "+order.charAt(i));
	    }
	    for(int j=0;j<i;j++) {
		if(mapping[i]==mapping[j])
		    throw new NumberFormatException
			("Double order mapping");
	    }
	}
    }
	
    public Object next() {
	IPPort n = nextIPPort();
	if (n==null) throw new NoSuchElementException();
	return n;
    }
        
    public IPPort nextIPPort () {
	NumberParser[] np = makeNPCollection();
	if (next[0]==-1) return null;
	String retVal= next[0]+"."+next[1]+"."+next[2]+"."+next[3];
	if (ipString != null) retVal=ipString;
	int retPort=next[4];

	// und das n�chste berechnen...
	int done=-1;
	for (int no2=6;no2>=0;no2--) {
	    int no=mapping[no2];
	    if (np[no].hasNext()) {
		int bit = np[no].nextNumber();
		next[no] = bit;
		done = no2;
	    } else {
		next[no] = -1;
	    }
	    if (done !=-1) break;
	}
	if (done==-1)  {
	    next[0]=-1;
	} else {
	    if (mapping[done]>4) np=makeNPCollection();
	    for (int ii=done+1; ii<7;ii++) {
		int i=mapping[ii];
		np[i].reset();
		if (np[i].hasNext()) {
		    next[i] = np[i].nextNumber();
		} else {
		    next[i] = -1;
		}		
		if (next[i]==-1) {next[0]=-1; break;}
		if (i>4) np=makeNPCollection();
	    }
	}
	return new IPPort(retVal,retPort);
    }

    public boolean hasNext() {
	return (next[0] != -1);
    }

    public void remove() {
	throw new UnsupportedOperationException();
    }
    
    public void reset() {
	next[5]=0;
	NumberParser[] np = makeNPCollection();
	for(int ii=0;ii<7;ii++) {
	    int i=ii;//mapping[ii];
	    np[i].reset();
	    if (np[i].hasNext()) {
		next[i]=np[i].nextNumber();
	    } else {
		next[i] = -1;
	    }
	    if (next[i]==-1) { next[0]=-1; break;}
//	    if (i>4)  np = makeNPCollection();
	}
    }
    
    private NumberParser[] makeNPCollection() {
	int n5, n6;
	if (next[5] == -1) {
//	    throw new RuntimeException("oops");
	    n5=0;
	} else {
	    n5=next[5];
	}
	if (next[6] == -1) {
//	    throw new RuntimeException("oops");
	    n6=0;
	} else {
	    n6=next[6];
	}
	NumberParser[] bs1 = results[n5];
	if (bs1 == null) {
	    bs1=oneIPBitSet;
	    ipString=ipv6Results[n5];
	} else  {
	    ipString=null;
	}
	NumberParser[] bs=new NumberParser[7];
	System.arraycopy(bs1,0,bs,0,4);
	bs[4]=ports[n6];
	bs[5]=npFixed[0];
	bs[6]=npFixed[1];
	return bs;
    }
}
