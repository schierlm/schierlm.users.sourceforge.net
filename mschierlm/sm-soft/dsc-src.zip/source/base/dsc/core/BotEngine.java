package dsc.core;

import java.io.*;
import java.net.*;
import java.util.*;

public class BotEngine implements Runnable {
    private BotListener listener;
    private File script;
    private boolean ready=false, running=false;
    private List commands=new ArrayList();
    private List threads=new ArrayList();
    private List sockets=new ArrayList();
    private String[] vars=new String[9];
    private static final String MAGIC="SocketBotFile001,";
    private ServerSocket ss=null;
    private Random rnd=new Random();
    
    public BotEngine (BotListener listener, File script) {
	this.listener=listener;
	this.script=script;
	init();
    }

    private void init () {
	String[] params=new String[0];
	try {
	    BufferedReader br=new BufferedReader(new FileReader(script));
	    String line=br.readLine();
	    if (line==null || !line.startsWith(MAGIC)) {
		throw new BotFileException ("Magic missing");
	    }
	    line=line.substring(MAGIC.length());
	    int i=line.indexOf(',');
	    String port, flags;
	    if (i==-1) {
		port=line;
		flags="";
	    } else {
		port = line.substring(0,i);
		flags=line.substring(i+1);
	    }
	    boolean autoListen=false;
	    boolean portFixed=false;
		
	    if (flags.indexOf(",")!=-1) {
		StringTokenizer st=new StringTokenizer(flags,",");
		flags=st.nextToken();
		params=new String[st.countTokens()*2];
		int cc=0;
		while (st.hasMoreTokens()) {
		    String tok=st.nextToken();
		    if (tok.indexOf("=")!=-1) {
			i=tok.indexOf("=");
			params[cc++]=tok.substring(0,i);
			params[cc++]=tok.substring(i+1);
		    } else {
			params[cc++]=tok;
			params[cc++]="";
		    }
		}
	    }
	    if (flags.indexOf("A") !=-1) autoListen=true;
	    if (flags.indexOf("F") !=-1) portFixed=true;
	    while((line=br.readLine())!=null) {
		if (!line.startsWith("#")) {
		    commands.add(line);
		}
	    }
	    commands.add("END");
	    br.close();
	    listener.botValues(port, autoListen, portFixed, params);
	    ready=true;
	} catch (IOException e) {
	    listener.botError("Error loading File: "+e.toString());
	    listener.botCritical();
	    ready=false;
	    running=false;
	} catch (BotFileException e) {
	    listener.botError("Unsupported Bot File: "+e.getMessage());
	    listener.botCritical();
	    return;
	}
	ready=false;
	running=false;
    }
    
    public synchronized void startBot(int port, String[] params) {
	if (params.length<10) {
	    System.arraycopy(params,0,vars,0,params.length);
	}
	if (running || ss != null) return;
	try {
	    ss=new ServerSocket(port);
	    listener_botMessage("*** Listening started ***");
	    Thread t=new Thread(this);
	    t.start();
	    threads.add(t);
	    running=true;
	} catch (IOException e) {
	    listener.botError("Error Creating Socket: "+e.getMessage());
	    listener.botClosed();
	    ss=null;
	} catch (IllegalArgumentException e) {
	    listener.botError("Incorrect port number: "+e.getMessage());
	    listener.botClosed();
	    ss=null;
	}
    }

    public void run () {
	try {
	    while(running) {
		Socket s = ss.accept();
		synchronized(this) {
		    if (!running) {
			// race occurred...
			listener_botMessage
			    ("*** Race condition: Connection received ***");
			s.close();
			break;
		    }
		    listener_botMessage ("*** New connection received ***");
		    Thread t = new BotThread(s,vars);
		    sockets.add(s);
		    threads.add(t);
		}
	    }
	} catch (SocketException e) {
	    if (!"socket closed".equals(e.getMessage())) {
		System.out.println("*"+e.getMessage()+"*");
		e.printStackTrace();
	    }
	} catch (IOException e) {
	    e.printStackTrace();
	}
	listener_botMessage("*** Listening stopped ***");
	listener_botClosed();
	ss=null;
	running=false;
    }

    private synchronized void listener_botClosed() {
	listener.botClosed();
    }

    private synchronized void listener_botMessage(String msg) {
	listener.botMessage(msg);
    }
    
    private synchronized void listener_botScriptMessage(String msg) {
	listener.botScriptMessage(msg);
    }
    
    private synchronized void listener_botError(String msg) {
	listener.botError(msg);
    }
	      
    public synchronized void stopBot() {
	running=false;
	try {
	    if (ss != null) ss.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}
	for (int i=0;i<sockets.size();i++) {
	    try {
		((Socket)sockets.get(i)).close();
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}
	for (int i=0;i<threads.size();i++) {
	    try {
		((Thread)threads.get(i)).join();
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}
	threads.clear();
	sockets.clear();
    }
    
    private class BotFileException extends Exception {
	public BotFileException(String reason) {
	    super(reason);
	}
    }

    private class BotThread extends Thread {
	//TODO variablen und initvalues
	private Socket sock;
	private boolean lastcondition=false;
	private ByteCollector buffer=new ByteCollector();
	private int iptr=0;
	private String[] vars=new String[9];
	
	public BotThread(Socket s, String[] vars) {
	    System.arraycopy(vars,0,this.vars,0,9);
	    sock=s;
	    start();
	}
	
	public void run () {
	    try {
		BufferedInputStream bis=new BufferedInputStream
		    (sock.getInputStream());
		BufferedOutputStream bos=new BufferedOutputStream
		    (sock.getOutputStream());
		while(running) {
		    String cmd=(String) commands.get(iptr++);
		    int p=cmd.indexOf(' ');
		    String cmd1,cmd2;
		    if (p==-1) {
			cmd1=cmd.toUpperCase();
			cmd2="";
		    } else {
			cmd1=cmd.substring(0,p).toUpperCase();
			cmd2=cmd.substring(p+1);
		    }
		    if (cmd1.equals("CLOSE") ||
			cmd1.equals("END")) {
			break;
		    } else if (cmd1.equals("READ")) {
			if (cmd2.equalsIgnoreCase("BYTE")) {
			    int b=bis.read();
			    if (b==-1) break;
			    buffer.append((byte)b);
			} else if (cmd2.equalsIgnoreCase("BYTES")) {
			    byte[] b = new byte[1024];
			    int len=bis.read(b);
			    if (len==-1) break;
			    buffer.append(b,len);
/*			} else if (cmd2.equalsIgnoreCase("LINE")) {
			    byte[] b = new byte[1024];
			    readline:
			    while (true) {
				int len=bis.read(b);
				buffer.append(b,len)
				for (int i=0;i<len;i++) {
				    if (b[i]==10)
					break readline;
				}
			    }*/
			} else {
			    listener_botMessage ("Unknown command: "+cmd);
			}
		    } else if (cmd1.equals("CLEAR")) {
			buffer.clear();
		    } else if (cmd1.equals("CONSUME")) {
			byte[] b = buffer.toByteArray();
			byte[] c = convert(cmd2);
			int i = buffer.indexOf(c);
			if (i!=-1) {
			    int newstart=i+c.length;
			    byte[] n = new byte[b.length-newstart];
			    System.arraycopy(b,newstart,n,0,
					     b.length-newstart);
			    buffer.clear();
			    buffer.append(n);
			}
		    } else if (cmd1.equals("GETLINE")) {
			byte[] b= buffer.toByteArray();
			int i;
			for(i=0;i<b.length;i++) {
			    if ((b[i]==10) ||
				(i<b.length-1 && b[i]==13 && b[i+1]!=10)) {
				break;
			    }
			}
			if (i==b.length) {
			    vars[8]="";
			    lastcondition=false;
			} else {
			    byte[] b1=new byte[(i>0&&b[i-1]==13)?i-1:i];
			    System.arraycopy(b,0,b1,0,b1.length);
			    vars[8]=new String(b1);
			    byte[] b2=new byte[b.length-(i+1)];
			    System.arraycopy(b,i+1,b2,0, b2.length);
			    buffer.clear();
			    buffer.append(b2);
			    lastcondition=true;
			}
		    } else if (cmd1.equals("WRITE")) {
			bos.write(convert(cmd2));
		    } else if (cmd1.equals("WRITERAW")) {
			bos.write(cmd2.getBytes());
		    } else if (cmd1.equals("SEND")) {
			bos.write(convert(cmd2));
			bos.flush();
		    } else if (cmd1.equals("FLUSH")) {
			bos.flush();
		    } else if (cmd1.equals(":")) { // Label
		    } else if (cmd1.equals("GOTO")) {
			iptr=-1;
			for (int i=0;i<commands.size();i++) {
			    if ((": "+cmd2).equalsIgnoreCase
				((String)commands.get(i))) {
				iptr=i;
				break;
			    }
			}
			if (iptr==-1) {
			    listener_botMessage("Unknown label: "+cmd);
			    break;
			}
		    } else if (cmd1.equals("THENGOTO")) {
			if (lastcondition) {
			    iptr=-1;
			    for (int i=0;i<commands.size();i++) {
				if ((": "+cmd2).equalsIgnoreCase
				    ((String)commands.get(i))) {
				    iptr=i;
				    break;
				}
			    }
			    if (iptr==-1) {
				listener_botMessage("Unknown label: "+cmd);
				break;
			    }
			}
		    } else if (cmd1.equals("ELSEGOTO")) {
			if (!lastcondition) {
			    iptr=-1;
			    for (int i=0;i<commands.size();i++) {
				if ((": "+cmd2).equalsIgnoreCase
				    ((String)commands.get(i))) {
				    iptr=i;
				    break;
				}
			    }
			    if (iptr==-1) {
				listener_botMessage("Unknown label: "+cmd);
				break;
			    }
			}
		    } else if (cmd1.equals("MSG")) {
			try {
			    listener.botScriptMessage
				(Options.convert(convert(cmd2),"\\"));
			} catch (NumberFormatException e) {
			    listener_botMessage
				("Error while displaying script message: "+
				 e.getMessage());
			}
		    } else if (cmd1.equals("DELAY")) {
			try {
			    Thread.sleep(Integer.parseInt(convertX(cmd2)));
			} catch (NumberFormatException e) {
			    listener_botMessage
				("Error while sleeping: "+
				 e.getMessage());
			} catch (InterruptedException e) {
			    e.printStackTrace();
			}
		    } else if (cmd1.equals("RANDOM")) {
			try {
			vars[8]=""+
			    rnd.nextInt(Integer.parseInt(convertX(cmd2)));
			} catch (NumberFormatException e) {
			    listener_botMessage
				("Error at random number generation: "+
				 e.getMessage());
			}
		    } else if (cmd1.startsWith("SETVAR")) {
			char no=cmd1.charAt(6);
			if (no >='1' && no <='9') {
			    vars[no-'1'] = convertX(cmd2);
			}
		    } else if (cmd1.startsWith ("PARSEINTO")) {
			char no=cmd1.charAt(9);
			if (no >='1' && no <='9') {
			    vars[no-'1'] = new String(convert(cmd2),
						      "ISO-8859-1");
			}
		    } else if (cmd1.startsWith("ADDVAR")) {
			try {
			    char no=cmd1.charAt(6);
			    if (no >='1' && no <='9') {
				try {
				    int vv= Integer.parseInt(vars[no-'1']);
				    vv+=Integer.parseInt(convertX(cmd2));
				    vars[no-'1']=""+vv;
				} catch (NumberFormatException e) {
				    listener_botError
					("Cannot add non-numbers: "+
					 e.getMessage());
				}
			    }
			} catch (NumberFormatException e) {
			    listener_botMessage("Error: "+
						e.getMessage());
			}
		    } else if (cmd1.equals("APPEND")) {
			buffer.append(convert(cmd2));
		    } else if (cmd1.equals("MAKEUPPERCASE")) {
			byte[] b = buffer.toByteArray();
			buffer.clear();
			buffer.append(new String(b,"ISO-8859-1").toUpperCase()
				      .getBytes("ISO-8859-1"));
		    } else if (cmd1.equals("IFCONTAINS")) {
			lastcondition = (buffer.indexOf(convert(cmd2)) !=-1);
		    } else if (cmd1.equals("IFIS")) {
			byte[] bb = convert(cmd2);
			if (bb.length==0) {
			    lastcondition = (buffer.isEmpty());
			} else {
			    lastcondition = (buffer.indexOf(bb) ==0 &&
					     buffer.toByteArray().length==
					     bb.length);
			}
		    } else if (cmd1.equals("IFSTARTS")) {
			lastcondition = (buffer.indexOf(convert(cmd2)) == 0);
		    } else {
			listener_botMessage("Unknown command: "+cmd);
		    }
		}
		sock.close();
		listener_botMessage("*** Connection closed ***");
	    } catch (SocketException e) {
		try {
		    sock.close();
		    listener.botMessage("*** Connection lost ***");
		} catch (IOException ex) {
		    ex.printStackTrace();
		}
	    } catch (UnsupportedEncodingException e) {
		e.printStackTrace();
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}

	private byte[] convert (String s) {
	    try {
		return Options.unconvertB(convertX(s),"\\","ISO-8859-1");
	    } catch (NumberFormatException e) {
		listener_botError ("Syntax error while parsing: "+
				   e.getMessage());
		return new byte[0];
	    }
	}

	private String convertX(String s) {
	    try {
		StringBuffer sb = new StringBuffer();
		for (int i=0;i<s.length();i++) {
		    if (s.charAt(i)!= '\\') {
			sb.append(s.charAt(i));
		    } else {
			if (s.charAt(i+1)=='$') { // Variable
			    int num=s.charAt(i+2)-'0';
			    if (num < 1 || num > 9 ) {
				sb.append(new String(buffer.toByteArray(),
						     "ISO-8859-1"));
			    } else {
				sb.append(vars[num-1]);
			    }
			    i+=2;
			} else if (s.charAt(i+1)=='"')  {// Quoted Variable
			    String res1;
			    int num=s.charAt(i+2)-'0';
			    if (num < 1 || num > 9 ) {
				res1 = new String(buffer.toByteArray(),
						  "ISO-8859-1");
			    } else {
				res1 = vars[num-1];
			    }
			    for (int j=0;j<res1.length();j++) {
				if (res1.charAt(j)=='\\') {
				    sb.append ("\\\\");
				} else {
				    sb.append(res1.charAt(j));
				}
			    }
			    i+=2;
			} else {
			    sb.append(s.charAt(i)).append(s.charAt(i+1));
			    i++;
			}
		    }
		}
		return sb.toString();
	    } catch (UnsupportedEncodingException e) {
		e.printStackTrace();
		return "";
	    } catch (NumberFormatException e) {
		listener_botError ("Syntax error while parsing: "+
				   e.getMessage());
		return "";
	    }
	}
    }
}
