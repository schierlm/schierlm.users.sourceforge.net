package dsc.core;

public interface ForwarderListener {
    void forwarderAdded(int howmany);
    void forwarderClosed();
    void forwarderMessage(String msg);
}
