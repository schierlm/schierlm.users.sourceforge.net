package dsc.core;
import dsc.plugin.*;

import java.io.*;
import java.net.*;
import java.util.*;

public class ForwarderEngine implements Runnable {
    private int portno1,portno2,portno3;
    private InetAddress host;
    private Thread thread;
    private List socks=new ArrayList();
    private List threads=new ArrayList();
    private ServerSocket seso;
    private ForwarderListener master;
    private boolean retry=false;
    private byte[] stopwordB;
    private ForwarderFilter fofiAbstract;
    private boolean onlyone;
    private InetAddress allowFrom=null;

    // for unparsed data:
    public static ForwarderEngine parseEngine(int p1, String host, int p2,
					      int p3,
					      String stop, ForwarderListener m,
					      String ffi, boolean onlyone,
					      String allowFrom1) {
	try {
	    InetAddress h = InetAddress.getByName(host);
	    ForwarderFilter ff;
	    if (ffi==null) {
		ff = ForwarderFilter.getDummy();
	    } else {
		ff=ForwarderFilter.getPlugin(ffi);
		if (ff==null) 
		    throw new IllegalArgumentException("Plugin error");
	    }
	    InetAddress allowFrom = null;
	    if (allowFrom1 != null) {
		allowFrom=InetAddress.getByName(allowFrom1);
	    }
	    return new ForwarderEngine(p1, h, p2, p3, stop, m, ff,
				       onlyone, allowFrom);
	} catch (UnknownHostException ex) {
	    throw new IllegalArgumentException("Unknown host: "+
					       ex.getMessage());
	}
    }
    
    
    public ForwarderEngine (int p1, InetAddress h, int p2, int p3, String stop,
			    ForwarderListener m, ForwarderFilter ff,
			    boolean onlyone, InetAddress allowFrom) {
	this.onlyone=onlyone;
	this.allowFrom=allowFrom;
	portno1=p1;
	portno2=p2;
	portno3=p3;
	host=h;
	master=m;
	if (stop != null) {
	    retry = true;
	    try {
		stopwordB=Options.unconvertB(stop,"\\");
	    } catch (NumberFormatException e) {
		master.forwarderClosed();
		master.forwarderMessage("Incorrect stop word: "+e.getMessage());
		return;
	    }
	}
	fofiAbstract=ff;
	thread=new Thread(this);
	thread.start();
    }
    
    public void run() {
	Socket rein, raus;
	ConnectionForwarder cf;
	try {
	    try {
	    seso = new ServerSocket(portno1);
	    }catch (IllegalArgumentException e) {
		synchronized(master) {
		    master.forwarderClosed();
		    master.forwarderMessage("Port Number Error: "+
					    e.getMessage());
		    return;
		}
 	    } catch (BindException e) {
		synchronized(master) {
		    master.forwarderClosed();
		    master.forwarderMessage("Port Error: "+e.getMessage());
		    return;
		}
	    }
	    while(true) {
		try {
		    rein = seso.accept();
		} catch (SocketException e) {
		    if (!"socket closed".equals(e.getMessage())) {
			System.out.println("*"+e.getMessage()+"*");
			e.printStackTrace();
		    }
		    break;
		}
		if (rein !=null && allowFrom!=null &&
		    !rein.getLocalAddress().equals(allowFrom)) {
		    rein.close();
		    rein=null;
		}
		if (rein !=null) {
		    cf= new ConnectionForwarder (rein);
		    if(onlyone)  {
			seso.close();
			break;
		    }
		}
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    public synchronized void cleanup() {
	Iterator it = socks.iterator();
	while(it.hasNext()) {
	    Socket ss= (Socket)it.next();
	    if (ss!=null) {
		try {
		    ss.close();
		} catch (IOException ex) {
		    ex.printStackTrace();
		}
	    }
	}
	socks.clear();
	it = threads.iterator();
	while(it.hasNext()) {
	    Thread t = (Thread) it.next();
	    if (t!=null) {
		try {
		    t.join();
		} catch (InterruptedException ex) {
		    ex.printStackTrace();
		}
	    }
	}
	threads.clear();
	if (seso!=null) {
	    try{
		seso.close();
		seso=null;
	    }catch (IOException ex) {
		ex.printStackTrace();
	    }
	}
	if (thread!=null) {
	    try {
		thread.join();
		thread=null;
	    } catch (InterruptedException ex) {
		ex.printStackTrace();
	    }
	}
	synchronized(master) {
	    master.forwarderClosed();
	}
    }

    /* ********************************************************** */
    private class ConnectionForwarder extends Thread {
	private Socket rein, raus;
	private BufferedOutputStream reino, rauso;
	private ByteCollector buffer=new ByteCollector();
	private ForwarderFilter fofi;
	private volatile boolean reconnect=false, reconnecting=false;
	
	public ConnectionForwarder(Socket in) {
	    fofi=fofiAbstract.newInstance();
	    rein=in;
	    try {
		reino = new BufferedOutputStream
		    (rein.getOutputStream());
	    } catch (IOException e) {e.printStackTrace();}
	    reconnect=retry;
	    start();
	}
	public void run () {
	    ForwarderThread t1=new ForwarderThread(false);
	    synchronized(ForwarderEngine.this) {
		threads.add(t1);
	    }
	    try {
		raus = new Socket(host,portno2);
		rauso = new BufferedOutputStream
		    (raus.getOutputStream());
		clearBuffer();
	    }catch (IllegalArgumentException e) {
		try{
		seso.close();
		rein.close();
		} catch (IOException ex) {
		    ex.printStackTrace();
		}
		synchronized(master) {
		    master.forwarderClosed();
		    master.forwarderMessage("Error while connecting: "+
					    e.getMessage());
		    return;
		}
	    } catch (SocketException e) {
		if (!reconnect) {
		    try {
			rein.close();
		    } catch (IOException ex) {
			ex.printStackTrace();
		    }
		    return;
		}
		reconnecting=true;
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	    synchronized(ForwarderEngine.this) {
		socks.add(rein);
	    }
	    if (reconnecting) {
		doReconnecting();
		
		if (!reconnecting) {
		    try{
			if (rein !=null) rein.close();
			if (raus !=null) raus.close();
		    } catch(IOException e) {
			e.printStackTrace();
		    }
		    return;
		} else {
		    reconnecting=false;
		}
	    }
	    ForwarderThread t2=new ForwarderThread(true);
	    synchronized(ForwarderEngine.this) {
		threads.add(t2);
		socks.add(raus);
	    }
	    synchronized(master) {
		master.forwarderAdded(1);
	    }
	    try {
		t1.join();
	    } catch (InterruptedException e ) {
		e.printStackTrace();
	    }
	    try {
		t2.join();
	    } catch (InterruptedException e ) {
		e.printStackTrace();
	    }
	    synchronized(master) {
		master.forwarderAdded(-1);
	    }
	}

	private void clearBuffer() {
	    if (!buffer.isEmpty()) {
		byte[] b=buffer.toByteArray();
		try {
		    for(int i=0;i<b.length;i++) {
			fofi.sendData(false,rauso,b[i]);
		    }
		    rauso.flush();
		    buffer.clear();
		    reconnect=false;
		} catch (IOException e) {
		    e.printStackTrace();
		}
	    }
	}
	private void doReconnecting () {
	    while (reconnecting) {
		try{
		    thread.sleep(1000);
		} catch (InterruptedException e) {
		    e.printStackTrace();
		}
		try {
		    raus=new Socket(host,portno3);
		    rauso = new BufferedOutputStream
			    (raus.getOutputStream());
		    clearBuffer();
		}catch (IllegalArgumentException e) {
		    try {
			seso.close();
			rein.close();
			synchronized(master) {
			    rein.close();
			    master.forwarderMessage
				("Error while second connect: "+
				 e.getMessage());
			}
		    }catch (IOException ex) {
			ex.printStackTrace();
		    }
		    return;
		} catch (SocketException e) {
		    continue;
		}catch (IOException e) {
		    e.printStackTrace();
		}
		break;
	    }
	}
    
	/* ********************************************************** */
	private class ForwarderThread extends Thread {
	    private BufferedInputStream in;
	    private BufferedOutputStream out;
	    private Socket sockout, sockin;
	    private boolean flag;
	    public ForwarderThread(boolean f) {
		flag=f;
		try {
		    sockin=(flag?raus:rein);
		    in = new BufferedInputStream(sockin.getInputStream());
		    out=null;
		    sockout=null;
		    if (flag || ! reconnecting) {
			doInits();
		    }
		    start();
		} catch(IOException e) {
		    e.printStackTrace();
		}
	    }
	    
	    public void run() {
		int ch;
		ByteCollector buff=null;
		if (flag&&reconnect) {
		    buff=new ByteCollector();
		}
		try {
		    try {
			while((ch = in.read())!=-1) {
			    doInits();
			    if (flag&&reconnect) {
				buff.append((byte)ch);
				if (buff.indexOf(stopwordB)!= -1) {
				    byte[] ba=buff.toByteArray();
				    if (out !=null) {
					for (int i=0;i<ba.length;i++) {
					    fofi.sendData(flag,
							  out,
							  ba[i]);
					}
					if (in.available()==0) out.flush();
				    }
				    buff=null;
				    reconnect=false;
				} else {
//				    if(in.available()==0) buff.clear;
				}
			    } else if (out!=null) {
				fofi.sendData(flag,out,ch);
			    if (in.available()==0) out.flush();
			    } else if (!flag) {
				buffer.append((byte)ch);
			    }
			}
		    } catch (SocketException e) {/* nichts */}
		    in.close();
		    if (flag &&reconnect){
			reconnecting=true;
			doReconnecting();
			if (reconnecting) {
			    sockin=raus;
			    try {
				in = new BufferedInputStream
				    (sockin.getInputStream());
			    } catch(IOException e) {
				e.printStackTrace();
			    }
			    run();
			}
			return;
		    }
		    doInits();
		    if (!flag)
			reconnect=false;
		    if (out!=null) {
			out.flush();
			out.close();
		    }
		    if (sockout !=null) {
			try {
			sockout.shutdownInput();
			} catch (IOException e) {/*nichts*/}
		    }
		    sockin.close();
		    if (!flag && reconnecting) reconnecting=false;
		} catch (IOException e) {
		    e.printStackTrace();
		}
	    }
	    
	    private void doInits() {
		if (out==null) {
		    if (sockout==null) {
			sockout=(flag?rein:raus);
		    }
		    if (sockout!=null) {
			out=(flag?reino:rauso);
			if (!flag)
			    reconnect=false;
		    }
		}
	    }
	}
    }
}

