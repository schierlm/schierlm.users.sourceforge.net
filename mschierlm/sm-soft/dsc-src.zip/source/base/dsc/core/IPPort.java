package dsc.core;

class IPPort {
    public String ip;
    public int port;

    IPPort(String i,int p) {
	ip=i;port=p;
    }

    public String toString() {
	return ip+":"+port;
    }
}
