package dsc.core;

public interface UDPListener {

    void logoutPrintln(String s);
}
