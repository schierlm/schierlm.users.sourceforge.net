package dsc.core;

import java.io.*;
import java.util.*;
import java.util.zip.*;

public class PortInfoEngine {

    private static PortInfoEngine instance;
    
    private List data;

    private PortInfoEngine() {
	    loadPortList();
    }

    public static PortInfoEngine getInstance() {
	if (instance == null) {
	    instance = new PortInfoEngine();
	}
	return instance;
    }
	
    private void loadPortList() {
	data=new ArrayList();
	try {
	    String line, buff="";
	    InputStream in1=null;
	    try {
		in1=new FileInputStream("plugins/ianaports.txt");
	    } catch (FileNotFoundException e) {
		in1=null;
	    }
	    if (in1==null) {
		try {
		    in1=new GZIPInputStream( new FileInputStream
					     ("plugins/ianaports.txt.gz"));
		} catch (FileNotFoundException e) {
		    in1=null;
		}
	    }
	    if (in1==null) {
		data.clear();
		data.add("plugins/ianaports.txt(.gz) not found");
		return;
	    }
	    BufferedReader br = new BufferedReader(new InputStreamReader
		(in1));
	    int headcount=0;
	    while ((line=br.readLine())!= null) {
		if (line.length()!=0 &&
		    (line.indexOf("/tcp")!=-1 ||
		     line.indexOf("/udp")!=-1)) {
		    if (buff !="")
			data.add(buff);
		    buff=line;
		} else if ((line.startsWith("Keyword") ) ||
			   (line.startsWith("-------"))) {
		    if (headcount++ <2) {
			data.add(line);
		    }
		} else if (line.startsWith("#                          ")) {
			buff= buff+"\n"+line;
		}
	    }
	    if (buff != "") data.add(buff);
	    br.close();
	    if (data.size()<2) {
		data.clear();
		data.add("Empty or broken file plugins/ianaports.txt(.gz)");
	    }
	} catch (IOException e) {
	    data.clear();
	    data.add("Error while loading plugins/ianaports.txt(.gz): \n"+e.getMessage());
	}
    }

    public String doFind(String f, int type) {
	String find="";
	switch(type) {
	case 0:
	    if (f.length()!=0 && "0123456789".indexOf(f.charAt(0))==-1)
		find=f;
	    else
		find="  "+f+"/";
	    break;
	case 1:
	    find="  "+f+"/";
	    break;
	case 2:
	    find="  "+f+"/TCP ";
	    break;
	case 3:
	    find="  "+f+"/UDP  ";
	    break;
	case 4:
	    find=f;
	}
	find=find.toLowerCase();
	StringBuffer res=new StringBuffer((String)data.get(0));
	res.append("\n").append((String)data.get(1)).append("\n");
	Iterator it=data.iterator();
	while (it.hasNext()) {
	    String elem=(String)it.next();
	    if (elem.toLowerCase().indexOf(find)!= -1) {
		res.append(elem).append("\n");
	    }
	}
	return res.toString();
    }

    public int getPortNumber(String protocol) {
	Iterator it=data.iterator();
	while(it.hasNext()) {
	    String elem=(String)it.next();
	    if (elem.startsWith(protocol+" ")
		 || elem.startsWith(protocol+"\t")) {
		int i1=elem.indexOf("/tcp");
		if (i1!=-1) {
		    int i2=elem.lastIndexOf(' ',i1);
		    String num=elem.substring(i2+1,i1);
		    try {
			return Integer.parseInt(num);
		    } catch (NumberFormatException ex) {
			System.out.println(num);
		    }
		}
	    }
	}
	return 0;
    }

    public String getLoadError() {
	if (data.size() == 1) {
	    return data.get(0).toString();
	} else {
	    return null;
	}
    }
}
