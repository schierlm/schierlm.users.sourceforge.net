package dsc.core;

import java.util.*;
import java.net.*;

public class LookupEngine extends Thread {
    private IPPortParser source;
    private ScanListener listener;
    private int cnt;
    private boolean running=true, sync = false;
    
    public LookupEngine(IPPortParser ipp, ScanListener sl) {
	this(ipp, false, sl);
    }

    public LookupEngine(IPPortParser ipp, boolean sync, ScanListener sl) {
	source=ipp;
	listener=sl;
	cnt=0;
	this.sync=sync;
	start();
    }

    public synchronized void hasResult (String entry) {
	listener.scanFound(entry);
    }

    public synchronized void hasNoResult() {
	listener.scanDone();
    }

    public void closeNow() {
	running=false;
	try {
	    this.join();
	} catch (InterruptedException e) {}
    }
    
	
    public void run () {
	int where=0;
	source.reset();
	while (running && source.hasNext()) {
	    source.nextIPPort(); cnt++;}
	source.reset();
//	List runners= new ArrayList((int)cnt);
	LookupWaiter[] runners = new LookupWaiter[cnt];
	while (running && source.hasNext()) {
	    IPPort ip = source.nextIPPort();
	    synchronized(this) {
		if (where >= cnt) {
		    listener.scanFound("Internal Error 004");
		} else {
		    listener.scanState(where,cnt,ip.ip);
		    runners[where]=new LookupWaiter(ip.ip);
		    where++;
		}
	    }
	}
	synchronized(this) {
	    if (running)
		listener.scanState(where,cnt,"All requests sent");
	    else
		listener.scanState(cnt,cnt,"stopping...");
	}
	for (int i=0;i<runners.length;i++) {
	    try {
		runners[i].join();
	    } catch (InterruptedException ex) {}
	}
	if (running && cnt != where) listener.scanFound("Internal Error 001");
	synchronized(this) {
	    listener.scanFinished();
	}
    }
    
    private class LookupWaiter extends Thread {
	private String ip;
	public LookupWaiter(String ip) {
	    this.ip=ip;
	    if(sync) run(); else start();
	}
	public void run () {
	    InetAddress ia=null;
	    try {
		ia=InetAddress.getByName(ip);
	    } catch (UnknownHostException e) {
		hasResult(ip+"->?");
		return;
	    } catch (Exception e) {
		System.err.println("---"+ip);
		e.printStackTrace();
		hasNoResult();
		return;
	    }
//	    String hn=ia.getCanonicalHostName();
	    String hn=ia.getHostName();
	    if (ip.equals(hn))
		hasResult("("+ip+")");
	    else
		hasResult(ip+"->"+hn);
	}
    }
}
	    
	
