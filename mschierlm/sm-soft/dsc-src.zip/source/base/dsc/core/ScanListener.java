package dsc.core;

public interface ScanListener {
    void scanFinished();
    void scanFound(String entry);
    void scanState(int now, int max, String entry);
    void scanDone();
}
