package dsc.core;

public interface BotListener {

    void botError(String description);
    void botMessage(String msg);
    void botScriptMessage(String msg);
    void botCritical();
    void botClosed();
    void botValues(String port, boolean autoListen, boolean portFixed,
		   String[] varDesc);
}
