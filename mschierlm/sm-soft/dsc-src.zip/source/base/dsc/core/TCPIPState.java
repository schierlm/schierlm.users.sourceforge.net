package dsc.core;

public class TCPIPState {
    private String description;
    private TCPIPState(String description) {
	this.description=description;
    }

    public String toString() {
	return description;
    }

    public String toExtString(String host, String port) {
	if (this==CONNECTED) {
	    return host+":"+port;
	} else if (this==LISTENING) {
	    return port;
	} else {
	    return "/";
	}
    }

    public static final TCPIPState
	CLOSED = new TCPIPState("CLOSED"),
	CONNECTED = new TCPIPState("CONNECTED"),
	LISTENING = new TCPIPState("LISTENING");
}
