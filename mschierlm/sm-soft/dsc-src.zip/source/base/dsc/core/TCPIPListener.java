package dsc.core;

public interface TCPIPListener {

    void logoutPrintln(String s);
    void showState(TCPIPState passive, TCPIPState active);
    void reportPassiveIP(String ip);
    String confirmText(String direction, String text);
    void connectionClosed(int num);
    String getDestIP();
    int getDestPort();
    TCPIPEngine newInstance();
}
