package dsc.core;

import java.io.*;
import java.net.*;


public class CouplerEngine implements Runnable {
    private CouplerListener listener;
    private int[] ports;
    private String[] hosts;
    private Thread[] threads;
    private Thread thread;
    private boolean running=true;
    private int size;
    private Socket[] socks;
    private BufferedOutputStream[] outs;
    private boolean[][] sendTo;
    private ServerSocket ss;
    private Object syncObj = new Object();
    
    public CouplerEngine(int[] ports, String[] hosts,
			 boolean[][] sendTo, CouplerListener cl) {
	listener=cl;
	this.hosts=hosts;
	this.ports=ports;
	this.sendTo=sendTo;
	size=hosts.length;
	if (size!=ports.length) throw new IllegalArgumentException
				      ("Number of hosts and ports must match");
	if (size!=sendTo.length) throw new IllegalArgumentException
				       ("Invalid bit field");
	for(int i=0;i<size;i++) 
	    if (size !=sendTo[i].length)
		throw new IllegalArgumentException
		    ("Invalid bit field");
	threads=new Thread[size];
	socks=new Socket[size];
	outs=new BufferedOutputStream[size];
	(thread=new Thread(this)).start();
    }

    public void run () {
	for(int i=0;i<size;i++) {
	    if (!running) return;
	    socks[i]=null;
	    try {
		if (hosts[i].length()==0) {
		    ss=new ServerSocket(ports[i]);
		    synchronized(this) {
			listener.couplerListening(i);
		    }
		    socks[i]=ss.accept();
		    ss.close();
		    ss=null;
		} else {
		    socks[i]=new Socket(hosts[i],ports[i]);
		}
		synchronized(this) {
		    listener.couplerConnected(i);
		}
		outs[i]=new BufferedOutputStream
		    (socks[i].getOutputStream());
	    } catch (SocketException e) {
		synchronized(this) {
		    if (!running)
			listener.couplerClosed(i);
		    else
			listener.couplerError(i,e.getMessage());
		}
	    } catch (UnknownHostException e) {
		synchronized(this) {
		    listener.couplerError(i,e.getMessage());
		}   
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}
	for (int i=0;i<size;i++) {
	    if (socks[i] != null)
		threads[i]=new CouplerThread(i);
	}
    }
    

    public void cleanup() {
	running=false;
	new Thread(new Runnable() {
		public void run() {
		    cleanup_();
		}
	    }).start();
    }

    private void cleanup_() {
	if(ss!=null) {
	    try {
		ss.close();
	    } catch (SocketException e) {
		// nothing
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}
	try {
	    thread.join();
	} catch (InterruptedException e) {
	    e.printStackTrace();
	}
	for (int i=0;i<size;i++) {
	    if (socks[i]!=null) {
		try {
		    socks[i].close();
		} catch (SocketException e) {
		    synchronized(this) {
			listener.couplerError(i,e.getMessage());
		    }
		} catch (IOException e) {
		    e.printStackTrace();
		}
	    }
	}
	for (int i=0;i<size;i++) {	
	    if(threads[i] !=null)
		try {
		    threads[i].join();
		} catch (InterruptedException e) {
		    e.printStackTrace();
		}
	}
	synchronized(this) {
	    listener.couplerFinished();
	}
    }

    private class CouplerThread extends Thread {
	private int no;
	public CouplerThread(int number) {
	    no=number;
	    start();
	}

	public void run () {
	    try {
		BufferedInputStream in=null;
		int ch;
		try {
		    in=new BufferedInputStream
			(socks[no].getInputStream());
		    while (running && (ch = in.read())!= -1) {
			synchronized(syncObj) {
			    while(running) {
				for(int i=0; i<size; i++) {
				    if (sendTo[no][i]&&outs[i]!=null) {
//					synchronized(outs) {
					    if (outs[i]!=null) {
						try {
						    outs[i].write(ch);
						    if (in.available() == 0)
							outs[i].flush();
						} catch (SocketException e) {
						    outs[i]=null;
						}
					    }
//					}
				    }
				}
				int inav;
				try {
				    inav=in.available();
				} catch (IOException e) {
				    System.err.println("Coupler IOE: "+e.toString());
				    inav=0;
				}
				if (inav!=0) {
				    if ((ch=in.read())==-1) break;
				} else {
				    break;
				}
			    }
			}
		    }
		} catch (SocketException e) {
		    // nothing
		}
		socks[no].close();
		if (in!=null) in.close();
		synchronized(syncObj) {
		    if (outs[no]!=null) {
			outs[no].close();
			outs[no]=null;
		    }
		}
		socks[no]=null;
		synchronized(this) {
		    listener.couplerClosed(no);
		}
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}
    }
}




