package dsc.core;

import java.net.*;
import java.io.*;
import java.util.*;

public class UDPEngine implements Runnable {

    private UDPListener udpl;
    private DatagramSocket ds = null;
    private boolean running = false;

    public UDPEngine(UDPListener l) {
	udpl=l;
    }


    public synchronized void destroySocket() {
	if (ds !=null) {ds.close(); ds=null;}
    }

    public synchronized void connect(int localPort, boolean mcast,
				     String mcastGroups, int destPort,
				     String addr) {
	//FIXME: clean up code
	destroySocket();
	if (mcast) { // Multicasting
	    openMulticastSocket(localPort, mcastGroups);
	} else {
	    openSocket(localPort);
	}
	if (ds == null) return;
	if (!running) {
	    running=true;
	    new Thread(this).start();
	}
	if (destPort != 0) {
	    try {
		ds.connect(InetAddress.getByName(addr),destPort);
		udpl.logoutPrintln("[^] Connected to "+
				   ds.getInetAddress().getHostAddress()+
				   ":"+ ds.getPort());
	    } catch (UnknownHostException ex) {
		udpl.logoutPrintln("[!] Unknown Host: "+ex.getMessage());
	    }
	}
    }
    
    private void openMulticastSocket(int localPort,
				     String multicastGroups) {
	MulticastSocket ms=null;
	try {
	    if (localPort !=0) 
		ms=new MulticastSocket(localPort);
	    else 
		ms=new MulticastSocket();
	} catch (SocketException ex) {
	    udpl.logoutPrintln("[!] Local Port error: "+ex.getMessage());
	} catch (IOException ex) {
	    ex.printStackTrace();
	}
	if (ms!=null) {
	    ds=ms;
	    udpl.logoutPrintln("[^] Bound to multicast port "+
			       ds.getLocalPort());
	    StringTokenizer mg=new StringTokenizer(multicastGroups," ");
	    while(mg.hasMoreTokens()) {
		String mgname=mg.nextToken();
		try {
		    ms.joinGroup(InetAddress.getByName(mgname));
		    udpl.logoutPrintln("[^] Joined multicast group "+mgname);
		}catch (IOException ex) {
		    udpl.logoutPrintln("[!] Error while joining "+
				       "multicast group "+mgname+": "+
				       ex.getMessage());
		}
	    }
	}
    }

    private void openSocket(int localPort) {
	try {
	    if (localPort !=0)
		ds=new DatagramSocket(localPort);
	    else
		ds=new DatagramSocket();
	} catch (SocketException ex) {
	    udpl.logoutPrintln("[!] Local Port error: "+ex.getMessage());
	}
	if (ds!=null)
	    udpl.logoutPrintln("[^] Bound to port "+ds.getLocalPort());
    }
        
    public synchronized boolean sendText(String text) {
	if (ds!=null && ds.getPort() != -1) {
	    byte[] ba=Options.unconvertB(text,"\\");
	    DatagramPacket dp=
		new DatagramPacket(ba,ba.length,
				   ds.getInetAddress(),
				   ds.getPort());
	    try {
		ds.send(dp);
		udpl.logoutPrintln("[<] "+text);
		return true;
	    } catch (IOException ex) {
		udpl.logoutPrintln("[!] Error while sending:"+ex.getMessage());
		return false;
	    }
	} else {
	    return false;
	}
    }

    public void run () {
	DatagramPacket dp;
	byte[] arr=new byte[4100];
	while(running) {
	    if (ds==null) {
		synchronized(this) {}
	    } else {
		dp=new DatagramPacket(arr,4096);
		try {
		    ds.receive(dp);
		    //StringBuffer sb=new StringBuffer();
		    byte[] bb=new byte[dp.getLength()];
		    System.arraycopy(arr,0,bb,0,dp.getLength());
		    synchronized(this) {
			udpl.logoutPrintln("[>] (Package from "+
					   dp.getAddress().getHostAddress()+
					   ":"+ dp.getPort()+ ")\n"+
					   "[>] "+ Options.convert(bb,"\\"));
		    }
		} catch (SocketException e) {
		    synchronized(this) {}
		} catch (IOException e) {
		    e.printStackTrace();
		    return;
		}
	    }
	}
    }

    public void shutDown() {
	running=false;
	if (ds!=null) ds.close();
    }
}

