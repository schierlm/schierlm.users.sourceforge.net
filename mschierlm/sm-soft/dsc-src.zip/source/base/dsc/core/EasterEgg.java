package dsc.core;

import java.io.*;
import java.net.*;
public class EasterEgg {

    private static final String screens[][] = {
	{"",
	 "              Congratulations! You found an ","",
	 " ******        *        ******    *******    ******  *****  ",
	 " *            * *      *             *       *       *    * ",
	 " *           *   *     *             *       *       *    * ",
	 " *****      *******     *****        *       *****   *****  ",
	 " *         *       *         *       *       *       * *    ",
	 " *        *         *        *       *       *       *  *   ",
	 " ******  *           * ******        *       ******  *   *  ","","",
	 " ######   ####    ####     &          ..            ",
	 " #       #    #  #    #    &         .  .            ",
	 " #       #       #         &        .    . ",
	 " #####   # ####  #  ###    &        .====.         ",
	 " #       #    #  #    #    &        .    . ",
	 " #       #    #  #    #              .  . ",
	 " ######   ####    ####     &          ..              "},
	{"Special thanks fly to: ",
	 "",
	 "   Mr. Moeller, my computer science teacher,",
	 "      for his great introduction in Java",
	 "",
	 "   SUN Microsystems,",
	 "      for Java itself and the Java Tutorial",
	 "      which is even a better introduction to Java",
	 "",
	 "   all betatesters,",
	 "",
	 "and to all others I forgot."},
	{"DirectSocketControl was programmed by Michael Schierl",
	 "a 21-year-old computer science student",
	 "living in Aichach, near Augsburg, Germany.",
	 "",
	 "If you wanna write me a postcard:",
	 "",
	 " Michael Schierl",
	 " Ignaz-Baldauf-Str. 5",
	 " D-86551 Aichach",
	 " GERMANY"},
	{"",
	 "If you want to contact my via internet:",
	 "    E-Mail: schierlm@gmx.de or sm-soft@gmx.de",
	 "    ICQ: 31020687        Jabber: schierlm@a-message.de",
	 "    homepage: http://smsoft.ixy.de/",
	 "",
	 "",
	 "",
	 "Thanks for viewing and enjoy DirectSockedControl!"}
	
    };
 
    
    private int currentPort;
    private ServerSocket ss;
    
    public EasterEgg () {
	try {
	    ss=new ServerSocket(5993);
	    currentPort=5993;
	} catch (IOException e) {
	    try {
		ss=new ServerSocket(15993);
		currentPort=15993;
	    } catch (IOException e2) {
		try {
		    ss=new ServerSocket(25993);
		    currentPort=25993;
		} catch (IOException e3) {
		    ss=null;
		}
	    }
	}
	if (ss==null) {
	    currentPort=0;
	    return;
	}
	new EasterThread().start();
    }
    
    public int getCurrentPort() {
	return currentPort;
    }

    private class EasterThread extends Thread {

	public void run() {
	    try {
		while(true) {
		Socket s=ss.accept();
		new ConnThread(s);
		}
	    } catch(SocketException e) {
		
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}
    }

    private class ConnThread extends Thread {
	private boolean fastmode=false;
	private Socket sock;
	public ConnThread(Socket s) {
	    sock=s;
	    start();
	}

	public void run () {
	    int mode=0;
	    int ch;
	    try {
		BufferedInputStream in=new BufferedInputStream(sock.getInputStream());
		BufferedWriter bw=new BufferedWriter
		    (new OutputStreamWriter(sock.getOutputStream()));
		Thread.sleep(500);
		if (in.available()!=0) {
		    ch=in.read();
		    if (ch==255)  {
			mode=1; //ANSI
			while(in.available()>0) {
			    in.read();
			}
		    }
		    if (ch=='G') mode=2; //HTML
		    if (ch=='u' || ch=='U') {
			sock.close();
			ss.close();
			return;
		    }
		}
		if (mode==0) {
		    bw.write("+OK Easter egg ready\r\n");
		    bw.flush();
		    Thread.sleep(500);
		    if (in.available()!=0) mode=3; //POP3
		}
		if (mode==0) {
		    bw.write("\033[2J\033[H\r\n Press DOWN now to enable ANSI mode,\r\n u to unload server...");
		    bw.flush();
		    Thread.sleep(2000);
		    if (in.available()!=0) {
			byte[] by=new byte[3];
			int leng= in.read(by);
			if (leng>=1 && (by[0]=='u'|| by[0]=='U')) {
			    sock.close();
			    ss.close();
			    return;
			}
			if (leng>=3 && by[0]=='\033' && by[1]=='[' && by[2]=='B') {
			    mode=1; //ANSI
			}
			while(in.available()>0) {
			    in.read();
			}
		    }
		}
		switch (mode) {
		case 0: // plain text, Socket Tool
		    bw.write("\r\n\r\n\r\nCongratulation, you found an EASTER EGG! \r\n\r\n");
		    bw.write("You can view this Easter egg in web browsers, \r\nin ANSI telnet clients and even in mail readers that understand POP3! \r\n"+
			     "Try it and  e n j o y !");
		    bw.flush();
		    Thread.sleep(5000);
		    for (int i=0;i<screens.length;i++) {
			textShowScreen(i,bw);
			if (in.available()>0) break;
			Thread.sleep(5000);
		    }
		    bw.write("Thanks for viewing!");
		    bw.flush();
		    Thread.sleep(2000);
		    break;
		case 1: // ANSI
		    	bw.write("\033[2J\033[2;30f\033[7m Press u now to unload server ");
		    ansiClearScreen(bw,in,false);
		    if (in.available()>0) {
			ch=in.read();
			if (ch=='u' || ch=='U') {
			    sock.close();
			    ss.close();
			    return;
			} else if (ch=='f') {
			    bw.write("\033[0m\033[2J\033[2;30f\033[7m"+
				     " fast mode enabled ");
			    fastmode=true;
			    while(in.available()>0) in.read();
			    ansiClearScreen(bw,in,false);
			} else {
			    sock.close();
			    return;
			}
		    }
		    ansiShowScreen(0,bw);
		    ansiFillBar(bw);
		    for(int i=1;i<screens.length;i++) {
			ansiClearScreen(bw,in,i%2==1);
			if (in.available()>0) break;
			ansiShowScreen(i,bw);
			if (in.available()>0) break;
			ansiFillBar(bw);
			if (in.available()>0) break;
		    }
		    if (in.available()==0)
			ansiClearScreen(bw,in,screens.length%2==1);
		    bw.write("\033[0m\033[2J\033[H Thanks for viewing!");
		    bw.flush();
		    Thread.sleep(3000);
		    break;
		case 2: // HTML
		    String line;
		    boolean toUninstall=false;
		    byte[] buff=new byte[in.available()];
		    in.read(buff);
		    String sss=new String(buff);
		    if (sss.indexOf("unload.htm")!=-1) {
			toUninstall=true;
		    }
		    if (toUninstall) {
			bw.write("HTTP/1.0 200 Document following\r\n"+
				 "Content-Type: text/html\r\n\r\n"+
				 "<HTML><HEAD><TITLE>Easter egg unloaded</TITLE>"+
				 "</HEAD><BODY><H1>Easter egg unloaded</H1>"+
				 "Have fun with DirectSocketControl!</BODY></HTML>");
			bw.flush();
			sock.close();
			ss.close();    
			return;
		    }
		    bw.write ("HTTP/1.0 200 Document following\r\n"+
			      "Content-Type: text/html\r\n\r\n"+
			      "<HTML><HEAD><TITLE>Easter Egg</TITLE></HEAD>\r\n"+
			      "<BODY><H1> Congratulation, you found an EASTER "+
			      "EGG!</H1>\r\n<HR><I>to unload it, "+
			      "<A HREF=\"unload.html\">click here</A>!</I><HR>"+
			      "\r\n");
		    bw.flush();
		    Thread.sleep(1000);
		    for (int i=0;i<screens.length;i++) {
			htmlShowScreen(i,bw);
			Thread.sleep(1000);
		    }
		    bw.write("<I>Thanks for viewing!</I>");
		    bw.write("</BODY></HTML>\r\n");
		    bw.flush();
		    break;
		case 3: // POP3
		    handlePOP3(in,bw);
		    break;
		default:
		}
		sock.close();
	    } catch (IOException e) {
		e.printStackTrace();
	    } catch (InterruptedException e) {
		e.printStackTrace();
	    }
	}

	private String makePOP3MailText() throws IOException {
	    StringBuffer mailtext=new StringBuffer();
	    mailtext.append("From: Michael Schierl <schierlm@gmx.de>\r\n"+
			    "Subject: You found an EASTER EGG!\r\n"+
			    "Date: Sun, 20 Apr 2003 00:00:00 +0000\r\n"+
			    "Message-ID: <easter-egg@smsoft.ixy.de>\r\n"+
			    "To: You <socket-tool-user@smsoft.invalid>\r\n"+
			    "\r\n");
	    StringWriter sw;
	    BufferedWriter bw2=new BufferedWriter(sw=new StringWriter());
	    for(int i=0;i<screens.length;i++) {
		textShowScreen(i,bw2);
	    }
	    mailtext.append(sw.toString()).append("\r\nThanks for viewing!")
		.append("\r\n\r\nMichael Schierl\r\n");
	    return mailtext.toString();
	}
	
	private void handlePOP3 (InputStream in, BufferedWriter bw)
	throws IOException {
	    String mail=makePOP3MailText();
	    BufferedReader br=new BufferedReader(new InputStreamReader(in));
	    String line;
	    while((line=br.readLine())!=null) {
		line=line.toUpperCase();
		if (line.startsWith("QUIT")) {
		    bw.write ("+OK\r\n");
		    bw.flush();
		    break;
		} else if (line.equals("STAT")) {
		    bw.write("+OK 1 "+mail.length()+"\r\n");
		} else if (line.equals("LIST")) {
		    bw.write("+OK 1 message\r\n1 "+mail.length()+"\r\n.\r\n");
		} else if (line.equals("LIST 1")) {
		    bw.write("+OK 1 "+mail.length()+"\r\n");
		} else if (line.equals("RETR 1")) {
		    bw.write("+OK message follows\r\n"+mail+".\r\n");
		} else if ((line.equals("DELE 1")) || (line.equals("NOOP")) ||
			   (line.equals("RSET"))|| (line.startsWith("USER ")) ||
			   (line.startsWith("PASS "))){
		    bw.write("+OK\r\n");
		} else {
		    bw.write("-ERR\r\n");
		}
		bw.flush();
	    }
	}
	
	private void ansiClearScreen(BufferedWriter bw, InputStream in,
				 boolean colorFlag)
	    throws IOException, InterruptedException{
	    bw.write("\033[m\033[3"+(colorFlag?"4":"3")+";4"+
		     (colorFlag?"3":"4")+"m\033[H");
	    for(int i=0;i<80;i++) {
		bw.write("*");
		bw.flush();
		Thread.sleep(10);
	    }
	    for(int i=2;i<=22;i++) {
		
		bw.write("\033["+i+";80f*");
		bw.flush();
		Thread.sleep(10);
	    }
	    for(int i=80;i>0;i--) {
		bw.write("\033[22;"+i+"f*");
		bw.flush();
		Thread.sleep(10);
	    }
	    for(int i=21;i>1;i--) {
		bw.write("\033["+i+";1f*");
		bw.flush();
		Thread.sleep(10);
	    }
	    bw.write("\033[23;1f*\033[24;1f");
	    bw.flush();
	    Thread.sleep(10);
	    for(int i=0;i<80;i++) {
		bw.write("*");
		bw.flush();
		Thread.sleep(10);
	    }
	    bw.write("\033[23;80f*");
	    bw.flush();
	    Thread.sleep(10);
	    for(int i=0;i<78;i++) {
		bw.write("\033[23;"+(79-i)+"f ");
		bw.flush();
		Thread.sleep(10);
	    }
	    if (in.available()!=0) return;
	    if (fastmode) {
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<78;i++) sb.append(" ");
		String line=sb.toString();
		for(int i=0;i<20;i++) {
		    bw.write("\033["+(i+2)+";2f"+line);
		}
	    } else {
		for(int i=0;i<10;i++) {
		    bw.write("\033["+(i+2)+";"+(i+2)+"f");
		    for(int j=0;j<78-2*i;j++) {
			bw.write(" ");
			bw.flush();
			Thread.sleep(10);
		    }
		    for(int j=0;j<18-2*i;j++) {
			bw.write("\033["+(j+i+3)+";"+(79-i)+"f ");
			bw.flush();		
			Thread.sleep(10);
		    }
		    for (int j=0;j<78-2*i;j++) {
			bw.write("\033["+(21-i)+";"+(79-i-j)+"f ");
			bw.flush();
			Thread.sleep(10);
		    }
		    for (int j=0;j<18-2*i;j++) {
			bw.write("\033["+(20-j-i)+";"+(2+i)+"f ");
			bw.flush();		
			Thread.sleep(10);
		    }
		}
	    }
	    bw.write("\033[H");
	    bw.flush();
	}
	
	private void ansiFillBar(BufferedWriter bw) throws IOException,
							   InterruptedException {
	    bw.write("\033[23;2f\033[7m");
	    for(int i=0;i<78;i++) {
		bw.write(" ");
		bw.flush();
		Thread.sleep(fastmode?10:100);
	    }
	    Thread.sleep(500);
	}
	
	private void ansiShowScreen(int screenNr, BufferedWriter bw)
	    throws IOException {
	    //bw.write("\033[2,1f");
	    for(int i=0;i<screens[screenNr].length;i++) {
		bw.write("\033["+(i+2)+";3f"+screens[screenNr][i]+"\r\n");
	    }
	    bw.write("\033[23;2f");
	    bw.flush();
	}
	
	private void textShowScreen (int screenNr, BufferedWriter bw)
	    throws IOException {
	    bw.write("================================================================================\r\n");
	    for(int i=0;i<screens[screenNr].length;i++) {
		bw.write("| "+padLine(screens[screenNr][i])+"|\r\n");
	    }
	    bw.write("================================================================================\r\n");
	    bw.flush();
	}

	private void htmlShowScreen(int screenNr,BufferedWriter bw)
	    throws IOException {
	    bw.write("<PRE>");
	    for(int i=0;i<screens[screenNr].length;i++) {
		bw.write(padLine(screens[screenNr][i])+"\r\n");
	    }
	    bw.write("</PRE>\r\n<HR>\r\n");
	    bw.flush();
	}
   
	private String padLine(String line) {
	    final String emptyspace="                                                                                ";
	    return (line+emptyspace).substring(0,77);
	}
    }
}
		
	
