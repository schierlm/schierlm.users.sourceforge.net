package dsc.core;

import java.net.*;
import java.io.*;

public class TCPIPEngine {

    private TCPIPListener tcpl;
    public TCPIPEngine(TCPIPListener l) {
	tcpl = l;
	returnText=Options.returnText;
	escapeChar=""+Options.escapeChar;
	connectsleep=Options.connectSleep;
    }

    public static final String[] PREFIX= new String[]
        {"[>  ] ", "[  <] ", "[<  ] ", "[  >] ",
	 "[>?>] ", "[<?<] ", "[>>>] ", "[<<<] ",
         "[^  ] ", "[  ^] ", "[!  ] ", "[  !] "};
    private boolean[] activeclose = new boolean[] {false, false};
    private Object sync = new Object();    
    private ServerSocket listensock;
    private Socket[] socks=new Socket[2];
    private PrintStream[] outs=new PrintStream[2];
    private ServerThread listener = new ServerThread();
    private ClientThread[] senders = new ClientThread[2];
    private ByteCollector[] fwdBuf=new ByteCollector[] {new ByteCollector(),
							new ByteCollector()};
    private String returnText, escapeChar;
    private int connectsleep;

    private boolean fwdState, fwdMessage, fwdConfirm,
	multiEngines, dologging=true;

    public void setOptions (boolean state, boolean message, boolean confirm,
			    boolean multi, boolean logging) {
	synchronized(sync) {
	    fwdState=state;
	    fwdMessage=message;
	    fwdConfirm=confirm;
	    multiEngines=multi;
	    dologging = logging;
	}
    }

    public void cleanup() {
        try {
            synchronized (sync) {
                if (listensock != null) listensock.close();
                for (int i =0;i<2;i++) {
                    if (outs[i]!=null) outs[i].close();
                    if (socks[i]!= null) socks[i].close();
                }
            }
        } catch (IOException e) {e.printStackTrace();}
    }

    public void showState() {
	TCPIPState st1,st2;
        synchronized (sync) {
            if (socks[0]!=null){
		st1=TCPIPState.CONNECTED;
            } else if (listensock!=null) {
		st1=TCPIPState.LISTENING;
            } else {
		st1=TCPIPState.CLOSED;
	    }
            if (socks[1]!=null) {
		st2=TCPIPState.CONNECTED;
	    } else {
		st2=TCPIPState.CLOSED;
	    }
        }
	tcpl.showState(st1, st2);
    }

    public boolean sendtextto(int no, String text) {
	synchronized(sync) {
	    if (outs[no]!=null) {
		try {
		    byte[] bs = Options.unconvertB(text,
						   escapeChar);
		    outs[no].write(bs,0,bs.length);
		    outs[no].flush();
		    if (dologging) {
			tcpl.logoutPrintln(PREFIX[no+2 ]+text);
		    }
		    return true;
		} catch (NumberFormatException e) {
		    if (dologging) {
			tcpl.logoutPrintln(PREFIX[10+no]+
					   "Incorrect escape: \\"+
					   e.getMessage());
		    }
		}
	    }
	}
	return false;
    }

    public boolean doClose(int no) {
	synchronized(sync) {
	    if (socks[no]!=null) {
		activeclose[no]=true;
		try {
		    socks[no].close();
		} catch (IOException x) {x.printStackTrace();}
		socks[no]=null;
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[8+no]+"Closed");
		}
		showState();
		return true;
	    } else {
		return false;
	    }
	}
    }
    
    public boolean doConnect(String actip, int actport) {
	try {
	    synchronized(sync) {
		if (socks[1]!=null) return true;
		socks[1] = new Socket(actip, actport);
		outs[1] = new PrintStream
		    (new BufferedOutputStream
		     (socks[1].getOutputStream()));
		if (dologging) {
		    tcpl.logoutPrintln("[  ^] Connected");
		}
	    }
	    if (!fwdBuf[1].isEmpty()) {
		outs[1].write(fwdBuf[1].toByteArray());
		outs[1].flush();
		fwdBuf[1].clear();   
	    }
	    senders[1]=new ClientThread(1);
	    showState();
	    return true;
	} catch (NumberFormatException e) {
	    if (dologging) {
		tcpl.logoutPrintln(PREFIX[11]+"Not a port number:" +
				   e.getMessage());
	    }
	} catch (IllegalArgumentException e) {
	    if (dologging) {
		tcpl.logoutPrintln(PREFIX[11]+"Illegal IP/Port ("+
				   e.getMessage()+")");
	    }
	} catch (SocketException e) {
	    if (dologging) {
		tcpl.logoutPrintln(PREFIX[11]+"IP/Port error: "+
				   e.getMessage());
	    }
	} catch (UnknownHostException e) {
	    if (dologging) {
		tcpl.logoutPrintln(PREFIX[11]+"Unknown host: "+e.getMessage());
	    }
        } catch (IOException ex) {ex.printStackTrace();}
        return false;
    }
    
    public void startListening (int port) {
	synchronized(sync) {
	    try {
		listensock = new ServerSocket(port);
		
		new Thread(listener).start();
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[8]+"Listening");
		}
		showState();
	    } catch (NumberFormatException x) {
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[10]+
				       "Not a port number: "+x.getMessage());
		}
	    } catch (IllegalArgumentException x) {
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[10]+ "Incorrect port: "+
				       x.getMessage());
		}
	    } catch (BindException x){
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[10]+"Port already in use ("+
				       x.getMessage()+")");
		}
	    }catch (IOException x) {
		x.printStackTrace();
	    }
	}
    }

    public boolean stopListening() {
	synchronized(sync) {
	    if (listensock != null) {
		try {
		    listensock.close();
		} catch (IOException x) {x.printStackTrace();}
		listensock=null;
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[8]+"Listening stopped");
		}
		showState();
		return true;
	    } else {
		return false;
	    }
	}
    }

    public void acceptConnection(Socket sock) throws IOException {
	synchronized(sync) {
	    if (socks[0]==null) {
		socks[0]=sock;
		tcpl.reportPassiveIP(sock.getInetAddress().getHostName());
		outs[0] = new PrintStream
		    (new BufferedOutputStream
		     (sock.getOutputStream()));
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[8]+"Connection received");
		}
		showState();
		if (fwdState) {
		    if (!doConnect(tcpl.getDestIP(), tcpl.getDestPort())) {
			doClose(0);
		    }
		}
		senders[0]=new ClientThread(0);
	    } else if (multiEngines) {
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[10]+" concurrent request "+
				       "granted (new window)");
		}
		TCPIPEngine ne = tcpl.newInstance();
		ne.acceptConnection(sock);
	    } else {
		if (dologging) {
		    tcpl.logoutPrintln(PREFIX[10]+" concurrent request "+
				       "blocked");
		}
		sock.close();
	    }
	}
    }
    
    private class ServerThread extends Thread {
        
        public ServerThread () {
        }

        public void run () {
            Socket sock;
            try {
                while(true) {
                    try{
                        sock=listensock.accept();
                    }catch (SocketException e) {
                        break;
                    }
		    acceptConnection(sock);
		}
            }catch (IOException e) {
                e.printStackTrace();
            }
	    showState();
	    
        }
            
    }

    private class ClientThread extends Thread {
        private int num;
        public ClientThread (int n) {
            num=n;
            start();
        }

        public void run() {
            ByteCollector collect=new ByteCollector();
            boolean doforward, doLog, canfwd;
	    Socket mysock;
            try {
                BufferedInputStream in;
                synchronized(sync) {
		    if (socks[num]==null)
			return;
		    mysock=socks[num];
                    in = new BufferedInputStream
                        (socks[num].getInputStream());
                }
                int chr;
                try{
		    while ((chr=in.read())!=-1) {
			collect.append((byte)chr);
			if (connectsleep!=0 && in.available()==0) {
			    try {
				Thread.sleep(connectsleep);
			    } catch (InterruptedException e) {
				e.printStackTrace();
			    }
			}
			if (in.available()==0 || collect.getLength() > 65536) {
			    boolean doconfirm;
			    synchronized(sync) {
				doforward = fwdMessage;
				doconfirm = fwdConfirm;
				doLog=dologging;
			    }
			    canfwd=doforward && outs[1-num] != null;
			    if (doLog) {
				tcpl.logoutPrintln
				    (PREFIX[num+(doforward?4:0)+(canfwd?2:0)]+
				     Options.convert
				     (collect.toByteArray(), escapeChar));
			    }
			    if (doforward) {
				if (doconfirm) {
				    synchronized(sync) {
					String cf = tcpl.confirmText
					    (PREFIX[num+4+(canfwd?2:0)],
					     Options.convert
					     (collect.toByteArray(),
					      escapeChar));
					collect.clear();
					collect.append
					    (Options.unconvertB
					     (cf,
					      escapeChar));
				    }
				}
			    
				if (canfwd) {
				    outs[1-num].write(collect.toByteArray());
				    outs[1-num].flush();
				} else {
				    synchronized(sync) {
					if (outs[1-num] != null) {
					    outs[1-num].write
						(collect.toByteArray());
					    outs[1-num].flush();
					} else {
					    fwdBuf[1-num].append(collect);
					}
				    }
				}
			    }    
			    collect.clear();
			}
		    }
                }catch(SocketException e) {
		    // discard
                }
                synchronized (sync) {
		    if (socks[num] == mysock || socks[num] == null) {
			// perhaps reduce that use of "global" vars
			// a bit?
			if (outs[num]!=null) outs[num].close();
			outs[num]=null;
			if (socks[num]!=null) socks[num].close();
			socks[num]=null;
			sync.notifyAll();
			if (!activeclose[num]) {
			    if (dologging) {
				tcpl.logoutPrintln(PREFIX[8+num]+
					       "Connection lost");
			    }
			    if (fwdState) {
				doClose(1-num);
			    }
			} else {
			    activeclose[num]=false;
			}
		    } else {
			tcpl.logoutPrintln
			    ("[***] Someone has stolen my socket!");
		    }
                }
		if (num == 0) {
		    tcpl.reportPassiveIP("");
		}
                showState();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
    }

}
