package dsc.core;

import java.util.*;
import java.net.*;

public class ScanEngine extends Thread {
    private IPPortParser source;
    private ScanListener listener;
    private int cnt;
    private boolean giveDone;
    private boolean running=true;
    private int threadLimit;
    private int runningThreads=0;
    private int soTimeout;
    
    public ScanEngine(IPPortParser ipp, ScanListener scanListener,
		      boolean giveDone, int threadLimit) {
	source=ipp;
	listener=scanListener;
	this.giveDone=giveDone || (threadLimit != -1);
	cnt=0;
	this.threadLimit=threadLimit;
	soTimeout = Options.socketTimeout;
	start();
    }

    public synchronized void hasResult (String entry) {
	listener.scanFound(entry);
	if (threadLimit != -1) {
	    runningThreads--;
	    notify();
	}
    }

    public synchronized void hasNoResult() {
	listener.scanDone();
	if (threadLimit != -1) {
	    runningThreads--;
	    notify();
	}
    }

    public void closeNow() {
	running=false;
	try {
	    this.join();
	} catch (InterruptedException e) {}
    }
    
    public void run () {
	int where=0;
	source.reset();
	while (running && source.hasNext()) {
	    source.nextIPPort(); cnt++;}
	source.reset();
	ScanWaiter[] runners = new ScanWaiter[cnt];
	while (running && source.hasNext()) {
	    IPPort ip = source.nextIPPort();
	    synchronized(this) {
		if (threadLimit != -1) {
		    while (runningThreads >= threadLimit)
			try {
			    wait();
			} catch (InterruptedException e){
			    e.printStackTrace();
			}
		    runningThreads++;
		}
		if (where >= cnt) {
		    listener.scanFound("Internal error 004");
		} else {
		    listener.scanState(where,cnt,ip.ip+":"+ip.port);
		    runners[where]=new ScanWaiter(ip.ip,ip.port);
		    where++;
		}
	    }
	}
	synchronized(this) {
	    if (running)
		listener.scanState(where,cnt,"All requests sent");
	    else
		listener.scanState(cnt,cnt,"stopping...");
	}
	try {
	    for (int i=0;i<runners.length;i++) {
		if(runners[i] == null) break;
		runners[i].join();
	    }
	} catch (InterruptedException ex) {
	    ex.printStackTrace();
	}
	if (running && cnt != where) listener.scanFound("Internal Error 001");
	synchronized(this) {
	    listener.scanFinished();
	}
    }
    

    private class ScanWaiter extends Thread {
	private String ip;
	private int port;
	
	public ScanWaiter(String ip, int port) {
	    this.ip=ip;
	    this.port=port;
	    start();
	}
	
	public void run () {
	    try {
//		System.out.println(ip+":"+port);
		Socket s = null;
		try {
		    if (soTimeout == 0) {
			s = new Socket(ip,port);
		    } else {
			s = new Socket();
			s.connect(new InetSocketAddress(ip, port),
				  soTimeout);
		    }
		} catch (ConnectException e) {
		    if (!"Connection refused: connect".equals
			(e.getMessage())
			&& !"Operation timed out: connect".equals
			(e.getMessage())) {
			System.err.println("---"+ip+":"+port);
			e.printStackTrace();
		    }
		    if (giveDone) hasNoResult();
		    return;
		} catch (NoRouteToHostException e) {
		    if (giveDone) hasNoResult();
		    return;
		} catch (SocketTimeoutException ex) {
		    if (giveDone) hasNoResult();
		    return;
		} catch (SocketException e) {
		    hasResult("! "+ip+":"+port+" ("+
			      e.getMessage()+")");
		    return;
		}
		s.close();
	    } catch (Exception e) {
		System.err.println("---"+ip+":"+port);
		e.printStackTrace();
		if (giveDone) hasNoResult();
		return;
	    }
	    hasResult(ip+":"+port);
	}
    }
}
	    
	
