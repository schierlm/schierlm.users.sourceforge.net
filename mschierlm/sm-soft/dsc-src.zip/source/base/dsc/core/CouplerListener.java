package dsc.core;

public interface CouplerListener {
    
    void couplerLog(String s);
    void couplerClosed(int no);
    void couplerConnected(int no);
    void couplerError(int no, String what);
    void couplerFinished();
    void couplerListening(int no);

}
