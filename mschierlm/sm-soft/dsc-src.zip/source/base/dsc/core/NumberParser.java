package dsc.core;

import java.util.*;

class NumberParser implements Iterator {
    
    private BitSet bs, workBS;
    private boolean isRandom = false;
    private NumberParser after;

    public NumberParser(String text, int max) {
	this(text, max, null);
    }
    
    public NumberParser(String text, int max, NumberParser after) {
	this.after=after;
	bs=new BitSet(max);
	if (text.length() != 0 && text.charAt(text.length()-1)=='r') {
	    text=text.substring(0,text.length()-1);
	    isRandom = true;
	}   
	if ("*".equals(text)) {
	    for (int i=0;i<max;i++) 
		bs.set(i);
	    reset();
	    return;
	}
	StringTokenizer st=new StringTokenizer(text,",");
	while(st.hasMoreTokens()) {
	    String tok=st.nextToken();
	    if (tok.indexOf("-")!=-1) {
		int von=Integer.parseInt(tok.substring(0,tok.indexOf("-")));
		int bis=Integer.parseInt(tok.substring(tok.indexOf("-")+1));
		if (von <0 ||von >=max )
		    throw new NumberFormatException(""+von);
		if (bis <0 || bis >=max)
		    throw new NumberFormatException(""+bis);
		for (int i=von;i<=bis;i++) {
		    bs.set(i);
		}
	    } else {
		int wert=Integer.parseInt(tok);
		if (wert<0 || wert >= max)
		    throw new NumberFormatException(""+wert);
		bs.set(wert);
	    }
	}
	reset();
    }

    public void reset() {
	workBS=(BitSet)bs.clone();
	if (after != null) after.reset();
    }

    public int nextNumber() {
	if (workBS.length() == 0) {
	    if (after == null) throw new NoSuchElementException();
	    return after.nextNumber();
	}
	if (isRandom) {
	    int i= getRandomBit();
	    if (i==-1)
		throw new RuntimeException("Oops");
	    workBS.clear(i);
	    return i;
	}
	int i= getMinimumBit();
	if (i != -1) {	    
	    workBS.clear(i);
	    return i;
	}
	throw new RuntimeException("Oops!");
    }

    public Object next() {
	return new Integer(nextNumber());
    }

    public void remove() {
	throw new UnsupportedOperationException();
    }

    public boolean hasNext() {
	if (workBS.length() != 0)
	    return true;
	if (after == null)
	    return false;
	return after.hasNext();
    }

    public boolean contains(int what) {
	if (bs.get(what))
	    return true;
	if (after == null) return false;
	return after.contains(what);
    }

    public void clearNumber(int num) {
	bs.clear(num);
	reset();
    }

    // this one is bad...
    private int getRandomBit() {
	BitSet b = workBS;
	int bl=b.length();
	if (bl==0) return -1;
	int num=((int)(Math.random()*bl));
	boolean rum=false;
	while (!b.get(num)) {
	    num++;
	    if (num==bl) 
		if(rum) {
		    return -1;
		} else {
		    rum=true;
		    num=0;
		}
	}
	return num;
    }

    public int getMinimumBit() {
	for (int i=0;i<workBS.length();i++) {
	    if (workBS.get(i))
		return i;
	}
	return -1;
    }

    public static void main(String[] args) {
	NumberParser np = new NumberParser("1-10,55-77",100, new NumberParser("80-90,1-3r", 100));
//	np=new NumberParser("*",5);
	while (np.hasNext()) {
	    System.out.println(np.next());
	}
	np.reset();
	while (np.hasNext()) {
	    System.out.println(np.next());
	}
    }
}
