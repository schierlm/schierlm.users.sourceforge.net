package dsc.plugin;
import dsc.core.*;

import java.io.*;
import java.net.*;
import java.util.*;

public abstract class ForwarderFilter {

    protected String param;

    protected ForwarderFilter() {
    }

    protected ForwarderFilter(String par) {
	param=par;
    }
    
    public abstract ForwarderFilter newInstance();
    
    public void sendData(boolean direction, OutputStream out,int data)
	throws IOException {
	if (direction)
	    sendDataToClient(out,data);
	else
	    sendDataToServer(out, data);
    }

    public void sendDataToClient(OutputStream out, int data)
	throws IOException {
	out.write(data);
    }

    public void sendDataToServer(OutputStream out, int data)
	throws IOException {
	out.write(data);
    }

    public static URL[] plugins=null;

    private static URL[] getPluginsParam() {
	if (plugins == null) {
	    try {
		File ff=new File("plugins/");
		ArrayList al=new ArrayList();
		al.add(ff.toURL());
		File[] files=ff.listFiles();
		for (int i=0;i<files.length;i++) {
		    if (files[i].getName().endsWith(".jar")) {
			al.add(files[i].toURL());
		    }
		}
		plugins=(URL[]) al.toArray(new URL[0]);
	    } catch (MalformedURLException e) {
		e.printStackTrace();
		plugins = new URL[0];
	    } catch (IOException e) {
		e.printStackTrace();
		plugins=new URL[0];
	    }
	}
	return plugins;
    }

    public static String[] pluginNames = null;

    public static String[] getPluginNames() {
	if (pluginNames== null) {
	    ArrayList names = new ArrayList();
	    names.add("builtin");
	    URL[] pars = getPluginsParam();
	    ClassLoader cl=new URLClassLoader(pars);    
	    for (int i=0;i<pars.length;i++) {
		if (pars[i].getFile().endsWith(".jar")) {
		    String n = new File(pars[i].getFile()).getName();
		    n = n.substring (0,n.length()-4);
		    names.add(n);
		}
	    }
	    ArrayList pnames = new ArrayList();
	    PluginList pl;
	    for (Iterator it = names.iterator(); it.hasNext();) {
		String name = (String) it.next();
		try {
		    pl = (PluginList)cl.loadClass
			("dsc.plugin.PluginList_ForwarderFilter_"+name)
			.newInstance();
		    pnames.addAll(Arrays.asList(pl.getPluginNames()));
		} catch (Throwable t) {
		    System.err.println("Could not load plugin spec for "+
				       name);
		    t.printStackTrace();
		}
	    }
	    pluginNames = (String[]) pnames.toArray(new String[pnames.size()]);
	}
	return pluginNames;
    }
    
    public static final ForwarderFilter getPlugin(String pluginSpec) {
	try {
	    ForwarderFilter ff;
	    int pos=pluginSpec.indexOf("/");
	    ClassLoader cl=new URLClassLoader(getPluginsParam());
	    if (pos==-1) {
		ff = (ForwarderFilter) cl.loadClass
		    ("dsc.plugin."+pluginSpec+"ForwarderFilter").newInstance();
	    } else {
		Class c=cl.loadClass("dsc.plugin."+pluginSpec.substring(0,pos)+
				      "ForwarderFilter");
		ff=(ForwarderFilter) c.getConstructor(new Class[]
		    {String.class}).newInstance
		    (new Object[]{pluginSpec.substring(pos+1)});
	    }
	    return ff;
	} catch (Throwable e) {
	    System.err.println("--- Plugin error: ---");
	    e.printStackTrace();
	    System.err.println("--- End Plugin error: ---");
	    return null;
	}
    }

    public static final ForwarderFilter getDummy() {
	return new DummyForwarderFilter();
    }
}
