package dsc.plugin;
import dsc.core.*;

public interface PluginList {
    public String[] getPluginNames();
}

    


