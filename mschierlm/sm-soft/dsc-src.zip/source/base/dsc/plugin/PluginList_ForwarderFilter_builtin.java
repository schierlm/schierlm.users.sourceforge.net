package dsc.plugin;

public class PluginList_ForwarderFilter_builtin implements PluginList {
    public String[] getPluginNames() {
	return new String[] {"Dummy"};
    }
}
