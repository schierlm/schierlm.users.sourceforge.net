package dsc.plugin;
import dsc.core.*;

import java.io.*;

public class DummyForwarderFilter extends ForwarderFilter {

    public DummyForwarderFilter() {
	this(null);
    }

    public DummyForwarderFilter(String par) {
	super(par);
	
    }
    public ForwarderFilter newInstance() {
	return new DummyForwarderFilter(param);
    }
}
