package dsc;
import dsc.core.*;
import dsc.cli.*;
import dsc.gui.*;

public class Main {
    public static final String VERSION="0.52";
    public static void main (String[] args) {
	if (args.length!=0) {
	    Cli.main(args);
	} else {
	    Splash s=new Splash();
	    new MainWindow();
	    s.disposeAll();
	}
    }
}
