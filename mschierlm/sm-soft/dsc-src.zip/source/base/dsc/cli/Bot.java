package dsc.cli;
import dsc.core.*;

import java.io.File;

public class Bot implements BotListener {

    private String r_port;
//    boolean r_autoListen;
    private boolean r_portFixed;
    private String[] r_varDesc;

    public void botError(String description) {
	System.out.println("[!] "+description);
    }
    public void botMessage(String msg) {
	System.out.println("[^] "+msg);
    }
    public void botScriptMessage(String msg) {
	System.out.println("[*] "+msg);
    }
    public void botCritical() {
	System.out.println("--- Critical error, closing ---");
	System.exit(-1);
    }
    public void botClosed() {
	System.out.println("--- Bot closed ---");
    }
    public void botValues(String port, boolean autoListen, boolean portFixed,
			  String[] varDesc) {
	r_port=port;
//	r_autoListen=autoListen;
	r_portFixed=portFixed;
	r_varDesc=varDesc;
    }

    static void showUsage() {
	System.out.println("Usage:\n"+
			   "java "+Cli.getCmdLine("Bot")+
			   " botfile [-p port] parameters\n\n"+ 
			   "botfile is a file name with extension (usually .sbf)");
	System.exit(0);
    }
    public static void main(String[] args) {
	if (args.length==0)
	    showUsage();
	File botfile=new File(args[0]);
	Bot thiz=new Bot();
	BotEngine be=new BotEngine(thiz,botfile);
	int astart=1;
	if (args.length>1) {
	    if (args[1].equals("-p") && args.length>2) {
		if (thiz.r_portFixed) {
		    System.out.println("Sorry, port number is fixed!");
		    return;
		}
		    thiz.r_port=args[2];
		    astart=3;
	    }
	    for (int i=astart;i<args.length;i++) {
		int ref=(i-astart)*2+1;
		if (thiz.r_varDesc.length<=ref) {
			System.out.println("too many parameters for this botscript.");
			return;
		}
		thiz.r_varDesc[ref]=args[i];
	    }
	}
	System.out.println("  Starting botscript: "+botfile.getName());
	System.out.println("  Port: "+thiz.r_port);
	String[] params=new String[thiz.r_varDesc.length/2];
	if (params.length>0)
	    System.out.println("  Parameters: ");
	for (int i=0;i<params.length;i++) {
	    System.out.println("    "+thiz.r_varDesc[i*2]+": \""+thiz.r_varDesc[i*2+1]+"\"");
	    params[i]=thiz.r_varDesc[i*2+1];
	}
	System.out.println("----------");
	try {
	    be.startBot(Integer.parseInt(thiz.r_port),params);
	} catch (NumberFormatException e) {
	    System.out.println("Not a port number: "+e.getMessage());
	    thiz.botCritical();
	}
    }
}
