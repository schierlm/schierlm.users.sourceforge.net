package dsc.cli;
import dsc.core.*;
import dsc.plugin.*;

import java.net.*;

public class Forwarder implements ForwarderListener {
    private Forwarder() {}

    private int count=0;
    
    public void forwarderAdded(int howmany) {
	count+=howmany;
	System.out.println("+++++ "+count+" connections open +++++");
    }
    
    public void forwarderClosed() {
    }
    
    public void forwarderMessage(String msg) {
	System.out.println(msg);
    }


    private static void showUsage() {
	System.out.println("\nUsage:\n======\n\n"+
			   "java "+Cli.getCmdLine("Forwarder")+" localPort destination remotePort [OPTIONS]\n\n"+
			   "Opens a forwarder thet forwards incoming connections " +
			   "from <localPort> to \n<destination>:<remotePort>. If more "+
			   "than one connection is accepted at \n<localPort>, all of them "+
			   "are forwarded to remotePort.\n\n"+
			   "Options:\n========\n\n"+
			   " -1             restricts the Forwarder to one connection, i.e. after the "+
			   "first \n                connection is established, the local port is released.\n"+
			   " -plugin name   uses <name> as a ForwarderPlugin. These "+
			   "plugins are Java \n                subclasses of ForwarderFilter - the "+
			   "plugin name is the part of \n                the class name before the "+
			   "String \"ForwarderFilter\".\n"+
			   " -from address  accecpts only connections from this address"
			   );
    }
    public static void main(String[] args) {
	int locPort;
	int remPort;
	InetAddress host;
	if (args.length<3) {
	    showUsage();
	    return;
	}
	try {
	    locPort=Integer.parseInt(args[0]);
	} catch (NumberFormatException e) {
	    System.out.println("Incorrect local port: "+e.getMessage()+"\n");
	    showUsage();
	    return;
	}
	try {
	    host=InetAddress.getByName(args[1]);
	} catch (UnknownHostException e) {
	    System.out.println("Incorrect destination host: "+
			       e.getMessage()+"\n");
	    showUsage();
	    return;
	}   
	try {
	    remPort=Integer.parseInt(args[2]);
	} catch (NumberFormatException e) {
	    System.out.println("Incorrect remote port: "+e.getMessage()+"\n\n");
	    showUsage();
	    return;
	}
	if (args.length==3) {
	    new ForwarderEngine (locPort,host,remPort,0, null,
				 new Forwarder(),
				 ForwarderFilter.getDummy(),false, null);
	} else {
	    int opos=3;
	    boolean onlyone=false;
	    String plugin=null;
	    InetAddress from=null;
	    while(opos<args.length) {
		if (args[opos].equals("-1")) {
		    opos++;
		    onlyone=true;
		} else if(args[opos].equals("-plugin") && args.length>opos+1) {
		    plugin=args[opos+1];
		    opos+=2;
		} else if(args[opos].equals("-from") && args.length>opos+1) {
		    try {
			from=InetAddress.getByName(args[opos+1]);
			opos+=2;
		    } catch (UnknownHostException e) {
			System.out.println("Incorrect allowed host: "+
					   e.getMessage()+"\n");
			showUsage();
			return;
		    }   
		} else {
		    break;
		}
	    }
	    if (args.length==opos) {
		ForwarderFilter ff;
		if (plugin==null) {
		    ff=ForwarderFilter.getDummy();
		} else {
		    ff=ForwarderFilter.getPlugin(plugin);
		}
		new ForwarderEngine (locPort, host, remPort, 0, null,
				     new Forwarder(), ff, onlyone, from);
	    } else {
		showUsage();
	    }
	}
    }
}
