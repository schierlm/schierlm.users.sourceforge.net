package dsc.cli;

public class Cli {
    private static boolean wasHere = false;
    
    public static String getCmdLine(String clazz) {
	String cl = System.getProperty("java.class.path");
	if (wasHere && !clazz.equals("Main")) {
	    return getCmdLine("Main") + " "+clazz;
	}
	if (cl.indexOf(":")==-1 && cl.indexOf(";") == -1) {
	    if (cl.endsWith(".jar") && clazz.equals("Main")) {
		return "-jar "+cl;
	    } else if (cl.equalsIgnoreCase("forwarder.jar") &&
		       clazz.equals("Forwarder")) {
		return "-jar "+cl;
	    }
	}
	if (clazz.equals("Main")) {
	    return "-cp "+cl+" dsc."+clazz;
	} else {
	    return "-cp "+cl+" dsc.cli."+clazz;
	}
	    
    }

    public static String[] shift (String[] a) {
	String[] res = new String[a.length-1];
	System.arraycopy(a, 1, res, 0, res.length);
	return res;
    }
    public static void main(String[] args) {
	wasHere=true;
	if (args[0].equalsIgnoreCase("forwarder")) {
	    Forwarder.main(shift(args));
	} else if (args[0].equalsIgnoreCase("bot")) {
	    Bot.main(shift(args));
	} else {
	    System.out.println("This is a GUI application. Nevertheless "+
			       "there are a few CLI utilities in\n"+
			       "this jar file. Try these: \n\n"+
			       "java "+getCmdLine("Main")+" Forwarder\n"+
			       "java "+getCmdLine("Main")+" Bot\n\n");
	}
    }
}
