package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

public class OptionsDialog extends Dialog implements ActionListener,
						     ItemListener {

    private TextField returnText, maxThreads, encoding,
	connectsleep, sockettimeout;
    private Checkbox limitThreads, wrapReturn;
    
    public OptionsDialog(Frame owner) {
	super(owner,"Options",true);
	Button b;
	setLayout(new GridBagLayout());
	setBackground(Color.lightGray);
	GridBagConstraints gc1 = new GridBagConstraints();
	GridBagConstraints gc2 = new GridBagConstraints();
	gc2.gridwidth=GridBagConstraints.REMAINDER;
	gc2.weightx=1.0;
	gc2.weighty=1.0;
	gc1.weighty=1.0;
	gc1.anchor=GridBagConstraints.EAST;
	gc2.fill=GridBagConstraints.HORIZONTAL;
	gc2.insets=new Insets(0,8,0,8);
	gc1.insets=gc2.insets;
	add(new Label("Return text"),gc1);
	add(returnText=new TextField(Options.returnText),gc2);
	add(new Label("\"Packet\" wait delay (ms):"),gc1);
	add(connectsleep=new TextField(""+Options.connectSleep),gc2);
	add(new Label("Socket timeout (ms):"),gc1);
	add(sockettimeout=new TextField(""+Options.socketTimeout),gc2);
	add(limitThreads=new Checkbox("Limit parallel threads to",
				      Options.maxThreads !=-1),gc1);
	limitThreads.addItemListener(this);
	add(maxThreads=new TextField(Options.maxThreads==-1?"":
				     ""+Options.maxThreads),gc2);
	if (!limitThreads.getState()) maxThreads.setEditable(false);
	add(new Label("Use Encoding (default if empty):"),gc1);
	add(encoding=new TextField(Options.encoding==null?"":
			      Options.encoding,10),gc2);
	add(wrapReturn=new Checkbox("Wrap logs after returns (\\n)",
				    Options.wrapReturn),gc2);
	add(new Label("These values are only valid for new windows"),gc2);
	add(b=new Button("OK"),gc2);
	b.addActionListener(this);
	add(b=new Button("Cancel"),gc2);
	b.addActionListener(this);
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
	    });
	pack();
	show();
    }

    public void actionPerformed(ActionEvent e) {
	if ("OK".equals(e.getActionCommand())) {
	    int mt, cs, st;
	    try {
		cs=Integer.parseInt(connectsleep.getText());
	    } catch (NumberFormatException ex) {
		return;
	    }
	    try {
		st=Integer.parseInt(sockettimeout.getText());
	    } catch (NumberFormatException ex) {
		return;
	    }
	    try {
		mt=limitThreads.getState()?
		    Integer.parseInt(maxThreads.getText()):-1;
	    } catch (NumberFormatException ex) {
		return;
	    }
	    String enc=encoding.getText();
	    if (enc.length()==0) {
		enc=null;
	    } else if (enc.equals("HEX")){
		// this one is okay
	    } else if (!Options.isSupportedEncoding(enc)) {
		encoding.setText(enc+" (unsupported)");
		return;
	    }
	    if (mt<1 && limitThreads.getState()) return;
	    Options.encoding=enc;
	    Options.maxThreads=mt;
	    Options.connectSleep=cs;
	    Options.socketTimeout=st;
	    Options.wrapReturn=wrapReturn.getState();
	    Options.returnText=returnText.getText();
	}
	dispose();    
    }

    public void itemStateChanged(ItemEvent e) {
	maxThreads.setEditable(limitThreads.getState());
	if (!limitThreads.getState())
	    maxThreads.setText("");
    }
}
