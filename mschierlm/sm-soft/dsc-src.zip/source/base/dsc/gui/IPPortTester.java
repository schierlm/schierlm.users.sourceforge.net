package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

class IPPortTester extends Frame implements ActionListener {
    private TextField ips, ports, order;
    private TextArea helptext;
    private Button test,help;
    private String patternHelp;

    public IPPortTester() {
	super("Help for IP/Port Patterns");
	if (patternHelp==null)
	    patternHelp = Options.loadPatternHelp();
	setLayout(new GridBagLayout());
	setBackground(Color.lightGray);
	setIconImage(MainWindow.getIcon(0));
	GridBagConstraints gc1=new GridBagConstraints();
	GridBagConstraints gc2=new GridBagConstraints();
	gc2.gridwidth=GridBagConstraints.REMAINDER;
	gc2.weightx=1.0;
	gc1.weightx=0.0;
	gc2.fill=GridBagConstraints.HORIZONTAL;
	add(new Label("IPs:"),gc1);
	add(ips=new TextField("127.0.0.1"),gc2);
	add(new Label("Ports:"),gc1);
	add(ports=new TextField("1-1024"),gc2);
	add(new Label("Order: "),gc1);
	add(order=new TextField("IP1234p"),gc2);
	add(test=new Button("Test"),gc2);
	test.addActionListener(this);
	gc2.gridwidth=GridBagConstraints.REMAINDER;
	gc2.gridheight=GridBagConstraints.RELATIVE;
	gc2.weighty=1.0;
	gc2.fill=GridBagConstraints.BOTH;
	add(helptext=new TextArea(patternHelp,20,80,
				  TextArea.SCROLLBARS_VERTICAL_ONLY),gc2);
	helptext.setEditable(false);
	helptext.setFont(new Font("Courier", Font.PLAIN,12));

	gc2.gridheight=GridBagConstraints.REMAINDER;
	gc2.weighty=0.0;
	add(help=new Button("Reshow HelpText"),gc2);
	help.addActionListener(this);
	addWindowListener(new WindowAdapter () {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
	    });
	pack();
	show();
    }

    public synchronized void actionPerformed(ActionEvent e) {
	Object src=e.getSource();
	IPPortParser ipp;
	if (src==test) {
	    helptext.setText("please wait...");
	    try {
		ipp=new IPPortParser
		    (ips.getText(),ports.getText(),order.getText());
	    } catch (NumberFormatException x) {
		helptext.setText("Error: Not a number:"+x.getMessage());
		return;
	    }
	    int i=0;
	    StringBuffer buff=new StringBuffer("first up to 2000 results:\n\n");
	    while (ipp.hasNext() && i<1000) {
		i++;
		buff.append (ipp.nextIPPort()+"\n");
	    }
	    helptext.setText(buff.toString());
	} else if (src==help) {
	    helptext.setText(patternHelp);    
	}
    }
}

