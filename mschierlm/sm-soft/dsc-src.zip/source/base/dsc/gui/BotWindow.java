package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class BotWindow extends Frame implements ActionListener,
						BotListener {

    private File botfile;
    private TextField ip, port;
    private Button start, stop;
    private TextArea log;
    private BotEngine be;
    private boolean autoListen=false, editPort=true;
    private String[] varDesc=new String[0];
    private TextField[] varText=null;

    public BotWindow () {
	super("Bot");
	botfile=getBotFile();
	if (botfile==null) {
	    dispose();
	    return;
	}
	setTitle(botfile.getName()+" - Bot");
	setBackground(Color.lightGray);
	setIconImage(MainWindow.getIcon(0));
	GridBagConstraints gc1 = new GridBagConstraints();
	GridBagConstraints gc2 = new GridBagConstraints();
	gc2.gridwidth=GridBagConstraints.REMAINDER;
	gc2.weightx=1.0;
	gc2.weighty=0.0;
	gc1.weighty=0.0;
	gc1.anchor=GridBagConstraints.EAST;
	gc2.fill=GridBagConstraints.HORIZONTAL;
	gc2.insets=new Insets(0,8,0,8);
	setLayout(new GridBagLayout());
	add(new Label("Port:"),gc1);
	add(port=new TextField(),gc2);
	add(start=new Button("Listen"),gc2);
	start.addActionListener(this);
	add(stop=new Button("Stop"),gc2);
	stop.addActionListener(this);
	stop.setEnabled(false);
	log=new TextArea("",5,40,TextArea.SCROLLBARS_VERTICAL_ONLY);
	be = new BotEngine(this, botfile);
	varText=new TextField[varDesc.length/2];
	for (int i=0;i<varDesc.length;i+=2) {
	    add(new Label(varDesc[i]),gc1);
	    add(varText[i/2]=new TextField(varDesc[i+1]),gc2);
	}
	gc2.weighty=1.0;
	gc2.fill=gc2.BOTH;
	add(log,gc2);
	log.setEditable(false);
	pack();
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    be.stopBot();
		    dispose();
		}
	    });
	show();
	if (autoListen) {
	    startBot();
	}

    }

    private File getBotFile() {
	FileDialog fd=new FileDialog(this,"Select Bot");
	fd.show();
	if (fd.getFile()==null) {
	    return null;
	} else {
	    return new File(fd.getDirectory(),fd.getFile());
	}
    }

    private void setControls (boolean on) {
	stop.setEnabled(!on);
	start.setEnabled(on);
	port.setEditable(on && editPort);
	if (varText != null) {
	    for (int i=0;i<varText.length;i++) {
		varText[i].setEditable(on);
	    }
	}
    }
	
    private void addlog(String s) {
	log.append(s+"\n");
    }
    
    public void actionPerformed(ActionEvent e) {
	if (e.getSource()==start) {
	    startBot();
	} else if (e.getSource() == stop){
	    be.stopBot();
	} else {
	    System.out.println(e.getActionCommand());
	}
    }

    public void botCritical() {
	setControls(false);
	stop.setEnabled(false);
    }
    public void botError(String description) {
	addlog("[!] "+description);
    }
    public void botMessage(String msg) {
	addlog("[^] "+msg);
    }
    public void botScriptMessage(String msg) {
	addlog("[*] "+msg);
    }
    
    public void botClosed() {
	setControls(true);
    }
    
    public void botValues(String portNo, boolean autoListen,
			  boolean portFixed, String[] varDesc) {
	port.setText(portNo);
	port.setEditable(!portFixed);
	editPort = !portFixed;
	this.autoListen=autoListen;
	this.varDesc=varDesc;
    }

    private void startBot() {
	setControls(false);
	try {
	    int po=TCPIPWindow.parsePort(port);
	    String[] v = new String[varText.length];
	    for (int i=0;i<v.length;i++) {
		v[i]=varText[i].getText();
	    }
	    be.startBot(po,v);
	} catch (NumberFormatException e) {
	    botError("Invalid port: "+e.getMessage());
	    setControls(true);
	}
    }
}
