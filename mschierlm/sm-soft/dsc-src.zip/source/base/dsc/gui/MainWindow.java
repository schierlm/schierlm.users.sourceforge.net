package dsc.gui;
import dsc.core.*;
import dsc.Main;

import java.awt.*;
import java.awt.event.*;

public class MainWindow extends Frame implements ActionListener {
    private static Image[] icon=new Image[1];
    
    public MainWindow () {
        super("DirectSocketControl "+Main.VERSION);
	Button b;
	setBackground(Color.lightGray);
	setIconImage(getIcon(0));
	Panel p2 = new Panel(new GridLayout(1,2));
        Panel p = new Panel(new GridLayout(0,1));
        p.add(b=new Button("TCP/IP-Window"));
        b.addActionListener(this);
        p.add(b=new Button("UDP-Window"));
        b.addActionListener(this);
	p.add(b=new Button("IP/Port-Scanner"));
	b.addActionListener(this);
	p.add(b=new Button("Port Information"));
	b.addActionListener(this);
	p.add(b=new Button("Forwarder"));
	b.addActionListener(this);
	p.add(b=new Button("Lookup Window"));
	b.addActionListener(this);
	p.add(b=new Button("Coupler"));
	b.addActionListener(this);
	p.add(b=new Button("Bot"));
	b.addActionListener(this);
	p.add(b=new Button("Options"));
	b.addActionListener(this);
	p2.add(p);
	p2.add(b=new Button("Exit"));
	b.addActionListener(this);
	add("Center",p2);
	add("South",new Label("(c) 2002-2004 Michael Schierl. This utility is freeware!"));
        pack();
        show();
        addWindowListener(new WindowAdapter () {
                public void windowClosing(WindowEvent e)
		{System.exit(0);} });
    }

    public void actionPerformed (ActionEvent e) {
        String cmd=e.getActionCommand();
        if ("Exit".equals(cmd)) System.exit(0);
        if ("TCP/IP-Window".equals(cmd)) new TCPIPWindow();
	if ("UDP-Window".equals(cmd)) new UDPWindow();
	if ("IP/Port-Scanner".equals(cmd)) new Scanner();
	if ("Port Information".equals(cmd)) new PortInfo();
	if ("Forwarder".equals(cmd)) new ForwarderWindow();
	if ("Lookup Window".equals(cmd)) new LookupWindow();
	if ("Coupler".equals(cmd)) new CouplerWindow();
	if ("Bot".equals(cmd)) new BotWindow();
	if ("Options".equals(cmd)) new OptionsDialog(this);
    }


    public static Image getIcon(int number) {
	if (icon[number]==null) {
	    icon[number]=Toolkit.getDefaultToolkit()
		.createImage(MainWindow.class.getResource
			     ("/res/icon"+number+".gif"));
	}
	return icon[number];
    }
}
