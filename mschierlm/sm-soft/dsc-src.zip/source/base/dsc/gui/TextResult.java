package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

class TextResult extends Frame implements ActionListener {

    private String txt; // TextArea sometimes does not return all its text...
    private TextArea ta;

    public TextResult (String text, String source) {
	super ("Text Viewer ("+source+")");
	txt=text;
	Button b;
	add("Center",ta=new TextArea(text,20,80,
				     TextArea.SCROLLBARS_VERTICAL_ONLY));
	ta.setFont(new Font("Courier", Font.PLAIN,12));
	add("South",b=new Button("Save as..."));
	b.addActionListener(this);
	pack();
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
	    });
	show();
    }
    
    public void actionPerformed (ActionEvent e) {

	FileDialog fd = new FileDialog (this, "Save as",
                                        FileDialog.SAVE);
        fd.show();
        String path = fd.getDirectory();
        String fname = fd.getFile();
        if (fname == null || path == null) return;
	File f = new File(path, fname);
	try {
	    Options.saveFile(f, txt);
	} catch (IllegalArgumentException ex) {
	    setTitle("Error while saving: "+ex.getMessage());
	}
    }
}

