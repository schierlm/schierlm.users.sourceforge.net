package dsc.gui;
import dsc.core.*;
import dsc.plugin.*;

import java.awt.*;
import java.awt.event.*;

class ForwarderWindow extends Frame implements ActionListener,
					       ForwarderListener,
					       ItemListener {
    private TextField port1, port2, ip, port3, waittext, pluginparams, fromip;
    private Choice plugin;
    private Checkbox retry, filter, onlyone, fromipC;
    private Button start,stop;
    private TextArea log;
    private ForwarderEngine engine;
    private int numconn=0;
    
    public ForwarderWindow () {
	super("Forwarder");
	setBackground(Color.lightGray);
	setIconImage(MainWindow.getIcon(0));
	GridBagConstraints gc1 = new GridBagConstraints();
	GridBagConstraints gc2 = new GridBagConstraints();
	gc2.gridwidth=GridBagConstraints.REMAINDER;
	gc2.weightx=1.0;
	gc2.weighty=0.0;
	gc1.weighty=0.0;
	gc1.anchor=GridBagConstraints.EAST;
	gc2.fill=GridBagConstraints.HORIZONTAL;
	gc2.insets=new Insets(0,8,0,8);
	setLayout(new GridBagLayout());
	add(fromipC=new Checkbox("Only from IP:"),gc1);
	fromipC.addItemListener(this);
	add(fromip=new TextField(""),gc2);
	fromip.setEditable(false);
	add(new Label("From Port:"),gc1);
	add(port1=new TextField(),gc2);
	add(new Label("To IP:"),gc1);
	add(ip=new TextField("127.0.0.1"),gc2);
	add(new Label("To Port:"),gc1);
	add(port2=new TextField(),gc2);
	add(retry=new Checkbox("Retry to Port:"),gc1);
	retry.addItemListener(this);
	add(port3=new TextField(""),gc2);
	port3.setEditable(false);
	add(new Label("Until received:"),gc1);
	add(waittext=new TextField(""),gc2);
	waittext.setEditable(false);
	add(filter=new Checkbox("Use Filter Plugin:"),gc1);
	filter.addItemListener(this);
	Panel p;
	add(p= new Panel(new BorderLayout()), gc2);
	p.add(plugin=new Choice(), BorderLayout.WEST);
	String[] plugins = ForwarderFilter.getPluginNames();
	for (int i=0;i<plugins.length;i++) {
	    plugin.add(plugins[i]);
	}
	plugin.select(0);
	plugin.setEnabled(false);
	p.add(pluginparams=new TextField(20), BorderLayout.CENTER);
	pluginparams.setEditable(false);
	add(onlyone=new Checkbox("Close after one connection"),gc2);
	add(start=new Button("Start"),gc2);
	start.addActionListener(this);
	add(stop=new Button("Stop"),gc2);
	stop.addActionListener(this);
	stop.setEnabled(false);
	gc2.weighty=1.0;
	gc2.fill=GridBagConstraints.BOTH;
	add(log=new TextArea("",5,10,TextArea.SCROLLBARS_VERTICAL_ONLY),gc2);
	log.setEditable(false);
	pack();

	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    if (engine!=null) engine.cleanup();
		    dispose();
		}
	    });
	show();
	port1.requestFocus();
    }

    public void actionPerformed(ActionEvent e) {
	Object src=e.getSource();
	if (src==start) {
	    int portno1,portno2,portno3 = 0;
	    String host;
	    String ffi;
	    setControls(false);
	    try {
		portno1=TCPIPWindow.parsePort(port1);
		portno2=TCPIPWindow.parsePort(port2);
		host=ip.getText();
		numconn=0;
		if (filter.getState()) {
		    String pluginname=plugin.getSelectedItem();
		    if (pluginparams.getText().length()>0) {
			pluginname+="/"+pluginparams.getText();
		    }
		    ffi = pluginname;
		} else {
		    ffi= null;
		}
		// todo Felder einbauen
		String fromIPString=null;
		if (fromipC.getState()) {
		    fromIPString=fromip.getText();
		}
		String wt = null;
		if (retry.getState()) {
		    portno3=TCPIPWindow.parsePort(port3);
		    wt = waittext.getText();
		}
		engine=ForwarderEngine.parseEngine
		    (portno1, host, portno2, portno3, wt, 
		     this, ffi, onlyone.getState(), fromIPString);
		forwarderAdded(0);
	    } catch (NumberFormatException ex) {
		addlog ("[!] Not a number: "+ex.getMessage());
		setControls(true);
	    } catch (IllegalArgumentException ex) {
		addlog ("[!] "+ex.getMessage());
		setControls(true);
	    }
	} else if (src==stop) {
	    if (engine != null) engine.cleanup();
	}
    }

    private void addlog(String s) {
	log.append(s+"\n");
    }
    
    private void setControls(boolean was) {
	start.setEnabled(was);
	stop.setEnabled(!was);
	port1.setEditable(was);
	port2.setEditable(was);
	ip.setEditable(was);
	retry.setEnabled(was);
	filter.setEnabled(was);
	boolean r = retry.getState();
	port3.setEditable(was && r);
	waittext.setEditable (was && r);
	plugin.setEnabled(was && filter.getState());
	pluginparams.setEditable(was && filter.getState());
	onlyone.setEnabled(was);
	fromip.setEditable(was&&fromipC.getState());
	fromipC.setEnabled(was);
	if (was) {
	    setTitle("Forwarder");
	} else {
	    String w = waittext.getText();
	    setTitle(port1.getText()+"->"+ip.getText()+":"+port2.getText()+
		     (r?"/"+port3.getText()+
		      ("".equals(w)?"":" ("+w+")"):"")+
		     (filter.getState()?"["+plugin.getSelectedItem()+
		      (pluginparams.getText().length()==0?"":"/"+
		       pluginparams.getText())+"]":"")+
		     " - Forwarder");
	}
    }

    public void forwarderAdded(int howmany) {
	numconn+=howmany;
	addlog ((howmany>0?"[+] ":(howmany==0?"[*] ":"[-] "))+
		numconn+" active connections");
    }

    public void forwarderClosed() {
	setControls(true);
	addlog("[*] closed");
	engine=null;
    }

    public void forwarderMessage(String s) {
	addlog("[?] "+s);
    }

    public void itemStateChanged(ItemEvent e) {
	Object source=e.getSource();
	if (source==retry) {
	    boolean was=retry.getState();
	    port3.setEditable(was);
	    waittext.setEditable(was);
	    if (was)
		port3.setText(port2.getText());
	} else if (source==filter) {
	    boolean was=filter.getState();
	    plugin.setEnabled(was);
	    pluginparams.setEditable(was);
	} else if (source==fromipC) {
	    fromip.setEditable(fromipC.getState());
	}
    }
}
	
	
