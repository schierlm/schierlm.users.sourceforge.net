package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

public class ChangeDialog extends Dialog implements ActionListener {

    public String returnText; // FIXME: private
    private TextArea ta;
    
    public ChangeDialog(Frame parent,String prompt, String text) {
	super(parent, "Change text", true);
	Button b;
	Panel p;
	add("North",new Label(prompt));
	add("Center",ta=new TextArea(text,5,40,TextArea.SCROLLBARS_NONE));
	add("South",p=new Panel(new GridLayout(2,1)));
	p.add(b=new Button("OK"));
	b.addActionListener(this);
	p.add(b=new Button("Cancel"));
	b.addActionListener(this);
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
	    });
	returnText="";
	pack();
	show();
    }

    public void actionPerformed(ActionEvent e) {
	String cmd=e.getActionCommand();
	if ("OK".equals(cmd)) {
	    returnText=ta.getText();
	    dispose();
	} else if ("Cancel".equals(cmd)) {
	    dispose();
	}
    }

    public String getReturnText() {
	return returnText;
    }
}
