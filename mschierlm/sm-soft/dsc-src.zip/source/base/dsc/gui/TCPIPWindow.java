package dsc.gui;
import dsc.core.*;
import java.awt.*;
import java.awt.event.*;

class TCPIPWindow extends Frame implements ActionListener,
					   KeyListener,
					   ItemListener,
					   TCPIPListener {

    private TextField actip,actport,passip,passport,msgtext;
    private TextArea log;
    private Button actb, passb, actsend,passsend, savelog, clearlog,
	actfrag, passfrag;
    private Label actstate, passstate;
    private Checkbox optstate,optmsg, nolog, optconfirm, optnewwin;
    private TCPIPEngine engine;
    private String returnText, escapeChar;
    private boolean wrapReturn;
    private Object logsync=new Object();

    public TCPIPWindow(String localport, boolean state, boolean msg,
		       boolean confirm, boolean nolog,
		       String ip, String port) {
	this(ip, port);
	passport.setText(localport);
	optstate.setState(state);
	optmsg.setState(msg);
	optconfirm.setState(confirm);
	this.nolog.setState(nolog);
	passport.setEditable(false);
	passb.setLabel("Close");
	itemStateChanged(null); // notify engine
    }
	
    public TCPIPWindow(String ip, String port) {
        this();
        actport.setText(port);
        actip.setText(ip);
    }
    
    public TCPIPWindow() {
        super("[/|/] TCP/IP");
	engine = new TCPIPEngine(this);
	returnText=Options.returnText;
	escapeChar=""+Options.escapeChar;
	wrapReturn=Options.wrapReturn;
	GridBagConstraints gc = new GridBagConstraints();
        Label l;
        setLayout(new GridBagLayout());
        setBackground(Color.lightGray);
	setIconImage(MainWindow.getIcon(0));
        gc.fill=GridBagConstraints.VERTICAL;
        gc.anchor=GridBagConstraints.NORTH;
        gc.weightx=0;gc.weighty=0;
        Panel p3, p2, p = new Panel();
	p.setLayout(new GridLayout(4,1));
        p.add(passstate=new Label("CLOSED"));
        passstate.setForeground(Color.red);
        p.add (passip = new TextField(""));
        passip.setEditable(false);
        p.add(p2=new Panel());
        p2.setLayout(new BorderLayout());
        p2.add("Center",p3=new Panel(new BorderLayout()));
        p3.add ("Center",passport=new TextField(3));
        p3.add("East", passfrag=new Button("?"));
        passfrag.addActionListener(this);
        p2.add("East",passb=new Button("Listen"));
        passb.addActionListener(this);
        add(new TitledBorder("Passive connection",p),gc);
        p = new Panel(new GridLayout(4,1));
        p.add(optstate=new Checkbox("Forward State"));
	optstate.addItemListener(this);
	p.add(optmsg=new Checkbox("Forward Messages"));
	optmsg.addItemListener(this);
	p.add(optconfirm=new Checkbox("Confirm Forwards"));
	optconfirm.addItemListener(this);
	p.add(optnewwin=new Checkbox("Open new windows"));
	optnewwin.addItemListener(this);
        add(new TitledBorder("Options",p),gc);
        p = new Panel(new GridLayout(4,1));
        p.add(actstate=new Label("CLOSED"));
        actstate.setForeground(Color.red);
        p.add (actip = new TextField("127.0.0.1"));
        p.add(p2=new Panel());
        p2.setLayout(new BorderLayout());
        p2.add("Center", p3=new Panel(new BorderLayout()));
        p3.add ("Center",actport=new TextField(3));
        p3.add("East",actfrag=new Button("?"));
        actfrag.addActionListener(this);
        p2.add("East",actb=new Button("Connect"));
        actb.addActionListener(this);
        add(new TitledBorder("Active Connection",p),gc);
        gc.weightx=1.0;gc.gridwidth=GridBagConstraints.REMAINDER;
        Canvas dummy = new Canvas(); // Dummy-Panel
        add(dummy, gc);
        gc.fill=GridBagConstraints.BOTH;
        gc.anchor=GridBagConstraints.CENTER;
        p2=new Panel(new BorderLayout());
        p2.add("Center", msgtext=new TextField());
	msgtext.addKeyListener(this);
        p2.add("West",passsend = new Button("^ Send"));
        passsend.addActionListener(this);
        p2.add("East",actsend = new Button("Send ^"));
        actsend.addActionListener(this);
        add(new TitledBorder("Messages",p2), gc);
        gc.weighty=1.0;
        gc.gridheight=GridBagConstraints.REMAINDER;
	gc.insets=new Insets(0,10,0,10);
        p = new Panel(new BorderLayout());
        p.setLayout(new BorderLayout());
        p.add("Center",log = new TextArea("",10,10,
					  TextArea.SCROLLBARS_VERTICAL_ONLY));
	log.setFont(new Font("Monospaced", Font.PLAIN,12));
	log.setEditable(false);
        p.add("South", p2=new Panel());
        p2.add(nolog=new Checkbox("No Logging"));
	nolog.addItemListener(this);
        p2.add(savelog=new Button("Viewer ^"));
	savelog.addActionListener(this);
        p2.add(clearlog=new Button("Clear ^"));
	clearlog.addActionListener(this);
        add(p, gc);
	actip.addActionListener(this);
	actport.addActionListener(this);
	passport.addActionListener(this);
        pack();
        show();
	passport.requestFocus();
        addWindowListener(new WindowAdapter () {
                public void windowClosing(WindowEvent e) {
                    engine.cleanup();
		    dispose();
                }});
    }

    public void itemStateChanged(ItemEvent e) {
	engine.setOptions(optstate.getState(),
			  optmsg.getState(),
			  optconfirm.getState(),
			  optnewwin.getState(),
			  !nolog.getState());
    }

    public void actionPerformed (ActionEvent e) {
	Object src=e.getSource();
	if (src==passb || src==passport) {
	    if ("Listen".equals(passb.getLabel())) {
		if (passport.getText().endsWith("?")) {
		    String s=passport.getText();
		    s=s.substring(0,s.length()-1);
		    new PortInfo(s,false);
		} else {
		    engine.startListening(parsePort(passport));			
		}
	    } else if ("Close".equals(passb.getLabel())) {
		if (engine.doClose(0)) {
		} else if (engine.stopListening()) {
		} else {
		    //should not happen
		    passb.setLabel("Listen");
		    passport.setEditable(true);
		}
	    }
	} else if (src==actb || src==actport || src==actip) {
	    if ("Connect".equals(actb.getLabel())) {
		if (actip.getText().equals("eASTER") &&
		    actport.getText().equals("eGG")) {
		    actip.setText("127.0.0.1");
		    log.setColumns(100);
		    log.setRows(23);
		    pack();
		    actport.setText(""+new EasterEgg().getCurrentPort());
		} else if(actport.getText().endsWith("?")) {
		    String s=actport.getText();
		    s=s.substring(0,s.length()-1);
		    new PortInfo(s,false);
		} else {
		    engine.doConnect(actip.getText(), parsePort(actport));
		}
	    }else if ("Close".equals(actb.getLabel())) {
		if (!engine.doClose(1)) {
		    actb.setLabel("Connect");
		    setactcontrols(true);                    }
	    }
	} else if (src==passsend) {
	    	if (engine.sendtextto(0, msgtext.getText())) {
		    msgtext.setText("");
		}
	} else if (src==actsend) {
	    if (engine.sendtextto(1, msgtext.getText())) {
		msgtext.setText("");
	    }
	} else if (src==actfrag) {
	    new PortInfo(actport.getText());
	} else if (src==passfrag) {
	    new PortInfo(passport.getText());
	} else if (src==clearlog) {
	    log.setText("");
	} else if (src==savelog) {
	    new TextResult(log.getText(),"TCP/IP");
	}
    }

    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
    
    public void keyTyped(KeyEvent e) {
	if (e.getKeyChar()=='\n') {
	    boolean sh=e.isShiftDown(),
		ct=e.isControlDown();
	    if (!sh && !ct) {
		StringBuffer msg=new StringBuffer(msgtext.getText());
		int posi=msgtext.getSelectionStart();
		msg.replace(posi,
			    msgtext.getSelectionEnd(),
			    returnText);
		msgtext.setText(msg.toString());
		msgtext.setCaretPosition(posi+returnText.length());
	    } else {
		if (sh) {
		    engine.sendtextto(0, msgtext.getText());
		}
		if (ct) {
		    engine.sendtextto(1, msgtext.getText());
		}
		msgtext.setText("");
	    }
	    e.consume();
	}
    }

    public synchronized void logoutPrintln(String s) {
	if (nolog.getState()) {
	    new Throwable("Redundant logging").printStackTrace();
	    return;
	}
	StringBuffer sb=new StringBuffer();
	String what=escapeChar+"n";
	int where;
	if (wrapReturn){
	    while ((where=s.indexOf(what)) !=-1) {
		sb.append(s.substring(0,where+2)).append("\n      ");
		s=s.substring(where+2);
	    }
	}
	sb.append(s).append("\n");
        synchronized(logsync) {
	    if (!nolog.getState()) 
		log.append(sb.toString());
        }
    }
    
    public synchronized void showState(TCPIPState passive, TCPIPState active) {
	passstate.setText(passive.toString());
	actstate.setText(active.toString());
	String s1, s2;
	s1 = passive.toExtString(passip.getText(),passport.getText());
	s2 = active.toExtString(actip.getText(), actport.getText());
	if (active == TCPIPState.CLOSED) {
	    actb.setLabel("Connect");
	    setactcontrols(true);
	} else {
	    actb.setLabel("Close");
	    setactcontrols(false);
	}
	if (passive == TCPIPState.CLOSED) {
	    passb.setLabel("Listen");
	    passport.setEditable(true);
	} else {
	    passb.setLabel("Close");
	    passport.setEditable(false);
	}
	setTitle("["+s1+"|"+s2+"] TCP/IP");
    }

    public void connectionClosed(int num) {
	if (num!=1) {
	    passip.setText("");
	}
    }

    private void setactcontrols(boolean was) { 
        actport.setEditable(was);
        actip.setEditable(was);
    }

    static int parsePort(TextField portIn) {
	return parsePort(portIn.getText(),portIn);
    }

    static int parsePort(String port, TextField portIn)
	throws NumberFormatException {
	if (port.indexOf(",")!=-1) {
	    int i=port.indexOf(",");
	    String left=port.substring(0,i),
		right=port.substring(i+1);
	    //TODO andersrum?
	    int po= Integer.parseInt(left)*256+Integer.parseInt(right);
	    portIn.setText(""+po);
	    return po;
	} else {
	    try {
		int po=Integer.parseInt(port);
		return po;
	    } catch (NumberFormatException e) {
		int pn=PortInfo.getPortNumber(port);
		if (pn !=0) {
		    portIn.setText(""+pn);
		    return pn;
		} else {
		    throw new NumberFormatException(e.getMessage());
		}
	    }
	}
    }

    public void reportPassiveIP(String ip) {
	passip.setText(ip);
    }
    
    public String confirmText(String direction, String text) {
	ChangeDialog cd = 
	    new ChangeDialog
	    (this,"Send text "+
	     direction+"?", text);
	return cd.returnText;
    }


    public String getDestIP() {
	return actip.getText();
    }

    public int getDestPort() {
	return parsePort(actport);
    }

    public TCPIPEngine newInstance() {
	TCPIPWindow inst = new TCPIPWindow
	    (passport.getText(), optstate.getState(), optmsg.getState(),
	     optconfirm.getState(), nolog.getState(), actip.getText(),
	     actport.getText());
	return inst.engine;
    }
}
