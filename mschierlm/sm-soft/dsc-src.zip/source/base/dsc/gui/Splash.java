package dsc.gui;
import dsc.core.*;

import java.awt.Frame;
import java.awt.Window;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Font;

public class Splash extends Window {

    private Frame loaderFrame;
    private static Frame f;
    
    public Splash (){
	super(f=new Frame("LOADER"));
	loaderFrame=f;
	Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
	setBounds(d.width/2-150,d.height/2-100,300,200);
	show();
    }

    public void paint(Graphics g) {
	int w=getWidth();
	int h=getHeight();
	g.setColor(Color.yellow);
	g.fillRect(0,0,w,h);
	g.setColor(Color.blue);
	g.setFont(new Font("Dialog",Font.BOLD, 22));
	g.drawString("Loading",50,90);
	g.drawString("DirectSocketControl...",50,120);
	g.setColor(Color.black);
	g.drawRect(0,0,w-1,h-1);
    }

    public void disposeAll() {
	dispose();
	loaderFrame.dispose();
    }
}
