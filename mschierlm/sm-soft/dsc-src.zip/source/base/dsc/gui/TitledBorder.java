package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

public class TitledBorder extends Panel {
    private int width, height;
    private String ttl;

    public TitledBorder(String title, Component inner) {
	this(title, inner, 20,20);
    }

    public TitledBorder(String title, Component inner, int width, int height) {
	ttl=title;
	this.width=width;
	this.height=height;
	setLayout(new GridBagLayout());
	GridBagConstraints gc=new GridBagConstraints();
	gc.insets=new Insets(height, width, height, width);
	gc.fill=gc.BOTH;
	gc.anchor=gc.CENTER;
	gc.gridwidth=gc.gridheight=gc.REMAINDER;
	gc.weightx=gc.weighty=1.0;
	add(inner,gc);
	setBackground(Color.lightGray);
    }

    public void paint(Graphics g) {
	super.paint(g);
	int wi=getWidth();
	int he=getHeight();
	g.setColor(Color.white);
	g.drawRect(width/2+1,height/2+1, wi-width, he-height);
	g.setColor(Color.gray);
	g.drawRect(width/2,height/2,wi - width, he - height);
	Font f=getFont();
	FontMetrics fm=getFontMetrics(f);
	int baseline=height/2+fm.getAscent()/2;
	int swidth=fm.stringWidth(ttl);
	g.setColor(Color.lightGray);
	g.fillRect(width, height/2,swidth+4,3);
	g.setColor(Color.black);
	g.drawString(ttl, width+2,baseline);
    }

    public Dimension getPreferredSize() {
	Dimension d=super.getPreferredSize();
	Font f=getFont();
	FontMetrics fm=getFontMetrics(f);
	int prefwidth=fm.stringWidth(ttl)+4+2*width;
	if (d.width<prefwidth) {
	    d.width=prefwidth;
	}
	return d;
    }
    
    public Dimension getMinimumSize() {
	Dimension d=super.getMinimumSize();
	Font f=getFont();
	FontMetrics fm=getFontMetrics(f);
	int prefwidth=fm.stringWidth(ttl)+4+2*width;
	if (d.width<prefwidth) {
	    d.width=prefwidth;
	}
	return d;
    }
}
