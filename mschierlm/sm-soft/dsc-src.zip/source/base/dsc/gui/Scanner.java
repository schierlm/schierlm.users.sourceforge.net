package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

class Scanner extends Frame implements ActionListener, ScanListener {
    private TextField ips, ports, order;
    private List list;
    private Button cmd, help, save, stop;
    private Label progress, result, numbers;
    private int resultcnt;
    private long starttime;
    private ScanEngine thread;
    private int waiting, working, done, workmax;
    private boolean doProgress;
    private int maxThreads;

    public Scanner() {
	this(true);
    }
    
    public Scanner (boolean detail) {
	super("IP/Port-Scanner");
	maxThreads=Options.maxThreads;
	doProgress=detail;
	setLayout(new GridBagLayout());
	setBackground(Color.lightGray);
	setIconImage(MainWindow.getIcon(0));
	GridBagConstraints gc1=new GridBagConstraints();
	GridBagConstraints gc2=new GridBagConstraints();
	GridBagConstraints gc3=new GridBagConstraints();
	gc2.gridwidth=GridBagConstraints.RELATIVE;
	gc2.weightx=1.0;
	gc1.weightx=0.0;
	gc2.fill=GridBagConstraints.HORIZONTAL;
	gc3.gridwidth=GridBagConstraints.REMAINDER;
	gc3.fill=GridBagConstraints.BOTH;
	//gc3.insets=new Insets(8,8,8,8);
	add(new Label("IPs:"),gc1);
	add(ips=new TextField("127.0.0.1"),gc2);
	add(cmd=new Button("Start"),gc3);
	cmd.addActionListener(this);
	add(new Label("Ports:"),gc1);
	add(ports=new TextField("1-1024"),gc2);
	add(stop=new Button("Stop"),gc3);
	stop.addActionListener(this);
	stop.setEnabled(false);
	add(new Label("Order: "),gc1);
	add(order=new TextField("IP1234p"),gc2);
	add(help=new Button("Help"),gc3);
	help.addActionListener(this);
	add(new Label("Progress:"),gc1);
	gc2.gridwidth=GridBagConstraints.REMAINDER;
	add(progress=new Label
	    ("-- not started. Press Start to start. --             "), gc2);
	if (doProgress) {
	    add(new Label(""),gc1);
	    add(numbers=new Label("0 / 0 / 0, max Threads: 0"),gc2);
	} else {
	}
	add(new Label("Result:"),gc1);
	add(result=new Label("No hits."),gc2);
	gc2.gridwidth=GridBagConstraints.REMAINDER;
	gc2.gridheight=GridBagConstraints.RELATIVE;
	gc2.weighty=1.0;
	gc2.fill=GridBagConstraints.BOTH;
	add(list=new List(),gc2);
	list.addActionListener(this);
	gc2.gridheight=GridBagConstraints.REMAINDER;
	gc2.weighty=0.0;
	add(save=new Button("Viewer ^"),gc2);
	save.addActionListener(this);

	addWindowListener(new WindowAdapter () {
		public void windowClosing(WindowEvent e) {
		    if (thread != null) {
			new Thread() {
			    public void run() {
				thread.closeNow();
				dispose();
			    }
			}.start();
		    } else {
		    dispose();
		    }
		}
	    });
	pack();
	show();
    }

    public synchronized void actionPerformed(ActionEvent e) {
	Object src=e.getSource();
	IPPortParser ipp;
	if (src==help) {
	    new IPPortTester();
	} else if (src==cmd) {
	    setControls(false);
	    resultcnt=done=working=workmax=waiting=0;
	    list.removeAll();
//	    log.setText("");
	    result.setText("No hits.");
	    progress.setText("Initalizing...");
	    starttime=System.currentTimeMillis();
	    try {
		thread = new ScanEngine
		    (new IPPortParser (ips.getText(),
				       ports.getText(), order.getText()),
		     this, doProgress,maxThreads);
	    } catch (NumberFormatException x) {
		list.add("Error: "+x.getMessage());
//		log.append("Error: "+x.getMessage());
		setControls(true);
		return;
	    }
	} else if (src==stop) {
	    if (thread != null){
		new Thread() {
		    public void run () {
			thread.closeNow();
			progress.setText("-- Stopped --");
			setControls(true);
		    }}.start();
	    }
	    
	} else if (src==list) {
	    String item = list.getSelectedItem();
	    int pos=item.indexOf(":");
	    new TCPIPWindow(item.substring(0,pos), item.substring(pos+1));
	} else if (src==save) {
	    StringBuffer sb=new StringBuffer();
	    for (int i=0;i<list.getItemCount();i++) {
		sb.append(list.getItem(i)).append("\n");
	    }
	    new TextResult(sb.toString(),"IP/Port Scan");
	}
    }

    private void setControls(boolean what) {
	cmd.setEnabled(what);
	stop.setEnabled(!what);
	ips.setEditable(what);
	ports.setEditable(what);
	order.setEditable(what);    
    }
    public void scanFinished() {
	setControls(true);
	progress.setText("-- Finished. Time taken: "+
			 ((System.currentTimeMillis()-starttime)/1000)
			 +" seconds --");
	thread=null;
    }
    
    public void scanFound(String entry) {
	list.add(entry);
//	log.append(entry+"\n");
	result.setText((++resultcnt)+" hits.");
	if (doProgress)
	    scanDone();
    }

    public void scanState(int now, int max, String entry) {
	progress.setText(entry+" ("+now+" of "+max+")");
	if (doProgress) {
	waiting=max-now;
	if (now>0) working++;
	numberrefresh();
	}
    }

    public void scanDone() {
	working--;
	done++;
	numberrefresh();
    }

    private void numberrefresh() {
	if(doProgress) {
	    if (working>workmax) workmax=working;
	    numbers.setText(waiting+" /" + working + " / " + done+
			    ", max Threads: "+workmax);
	}
    }
}

