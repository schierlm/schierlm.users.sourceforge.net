package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

public class CouplerWindow extends Frame implements ActionListener,
						    CouplerListener,
						    KeyListener {
    private static final int MAXCONN=10;
    private TextField[] hosts, ports;
    private Checkbox[][] sendto;
    private Button[] togglefrom, toggleto;
    private Label[] status;
    private Button showmore, showless, connect, close, viewer;
    private Panel changePanel;
    private TextArea log;
    private int numConn=3;
    private CouplerEngine engine;

    public CouplerWindow() {
	super("Coupler window");
	setBackground(Color.lightGray);
	hosts=new TextField[MAXCONN];
	ports=new TextField[MAXCONN];
	togglefrom=new Button[MAXCONN];
	toggleto=new Button[MAXCONN];
	sendto=new Checkbox[MAXCONN][MAXCONN];
	status=new Label[MAXCONN];
	Panel p,p2;
	setIconImage(MainWindow.getIcon(0));
	add("North", changePanel=new Panel(new GridBagLayout()));
	changePanel.setBackground(Color.lightGray);
	add("Center",p=new Panel(new BorderLayout()));
	p.add("North", p2=new Panel(new GridLayout(2,2)));
	p2.add(showless=new Button("Less <<"));
	showless.addActionListener(this);
	p2.add(showmore=new Button("More >>"));
	showmore.addActionListener(this);
	p2.add(connect=new Button("Connect"));
	connect.addActionListener(this);
	p2.add(close=new Button("Close"));
	close.addActionListener(this);
	close.setEnabled(false);       
	p.add("Center", log=new TextArea(30,80));
	log.setEditable(false);
	add("South", viewer=new Button("Viewer ^"));
	viewer.addActionListener(this);
	pack();
	setupPanel();
	show();
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    if (engine !=null) engine.cleanup();
		    dispose();
		}
	    });
    }

    private void setupPanel() {
	GridBagConstraints gc1=new GridBagConstraints();
	GridBagConstraints gc2=new GridBagConstraints();
	GridBagConstraints gc3=new GridBagConstraints();
	Label l;
	setCursor(new Cursor(Cursor.WAIT_CURSOR));
	gc2.fill=gc2.BOTH;
	gc2.weightx=1.0;
	gc3.gridwidth=gc3.REMAINDER;
	changePanel.setVisible(false);
	changePanel.removeAll();
	changePanel.add(new Label("No"),gc1); //Nr
	changePanel.add(new Label("Host"),gc2); //IP
	changePanel.add(new Label("Port"),gc1); //Port 
	changePanel.add(new Label("State"),gc1); //Status
	changePanel.add(new Label("From \\ To"), gc1);
	for (int j=0;j<numConn;j++) {
	    if (toggleto[j]==null) {
		toggleto[j]=new Button(""+(j+1));
		toggleto[j].addActionListener(this);
		toggleto[j].addKeyListener(this);
	    }
	    changePanel.add(toggleto[j],gc1);
	}
	changePanel.add(new Label("No"),gc3);
	for (int i=0;i<numConn;i++) {
	    if (hosts[i]==null) {
		hosts[i]=new TextField("127.0.0.1");
		ports[i]=new TextField(5);
		togglefrom[i]=new Button(""+(i+1));
		togglefrom[i].addActionListener(this);
		togglefrom[i].addKeyListener(this);
		status[i]=new Label("NOT USED YET");
		status[i].setForeground(Color.red);
		status[i].addKeyListener(this);
	    }
	    changePanel.add(new Label(""+(i+1))); //Nr
	    changePanel.add(hosts[i],gc2);  //IP
	    changePanel.add(ports[i],gc1); // Port
	    changePanel.add(status[i],gc1); //Status
	    changePanel.add(togglefrom[i],gc1);
	    for(int j=0;j<numConn; j++) {
		if (sendto[i][j]==null) {
		    sendto[i][j]=new Checkbox("");
		    sendto[i][j].addKeyListener(this);
		    if (i==j) {
			sendto[i][j].setEnabled(false);
			sendto[i][j].setBackground(Color.lightGray);
		    } else {
			sendto[i][j].setState(true);
		    }
		}
		changePanel.add(sendto[i][j],gc1);
	    }
	    changePanel.add(new Label(""+(i+1)), gc3);
	}
	changePanel.setVisible(true);
	validate();
	setCursor(null);
    }

    public void actionPerformed(ActionEvent e) {
	Object src=e.getSource();
	if (src == showmore) {
	    if (e.getModifiers() != 0) {
		numConn = MAXCONN;
		setupPanel();
	    } else if (numConn < MAXCONN) {
		numConn++;
		setupPanel();
	    }
	} else if (src == showless) {
	    if (e.getModifiers() != 0) {
		numConn = 2;
		setupPanel();
	    } else if (numConn > 2) {
		numConn--;
		setupPanel();
	    }
	} else if (src == connect) {
	    int[] ePorts=new int[numConn];
	    String[] eHosts=new String[numConn];
	    boolean[][] eSendTo = new boolean[numConn][numConn];
	    for(int i=0;i<numConn;i++) {
		status[i].setText("CLOSED");
	    }
	    for(int i=0;i<numConn;i++) {
		eHosts[i]=hosts[i].getText();
		try {
		    ePorts[i]=TCPIPWindow.parsePort(ports[i]);
		} catch (NumberFormatException ex) {
		    log.append("["+(i+1)+"] Not a number: "+ex.getMessage()+
			       "\n");
		    return;
		}
		for (int j=0;j<numConn;j++) {
		    eSendTo[i][j]=sendto[i][j].getState();
		}
	    }
	    setControls(false);
	    engine = new CouplerEngine(ePorts, eHosts, eSendTo, this);
	} else if (src == close) {
	    if (engine!=null)
		engine.cleanup();
	} else if (src == viewer) {
 		new TextResult(log.getText(),"Coupler");

	} else {
	    for (int i=0;i<numConn;i++) {
		if (src==togglefrom[i]) {
		    for (int j=0;j<numConn;j++) 
			if (i!=j)
			    sendto[i][j].setState(!sendto[i][j].getState());
		} else if (src==toggleto[i]) 
		    for(int j=0;j<numConn;j++) {
			if (i!=j)
			    sendto[j][i].setState(!sendto[j][i].getState());
		}
	    }
	}
    }
    public void couplerLog(String s) {
	log.append(s+"\n");
    }

    public void couplerClosed(int no) {
	status[no].setText("CLOSED");
	log.append("["+(no+1)+"] Closed\n");
    }

    public void couplerConnected(int no) {
	status[no].setText("CONNECTED");
	log.append("["+(no+1)+"] Connected\n");
    }

    public void couplerError(int no, String what) {
	status[no].setText("ERROR");
	log.append("["+(no+1)+"] "+what+"\n");
    }

    public void couplerListening(int no) {
	status[no].setText("LISTENING");
	log.append("["+(no+1)+"] Listening\n");
		
    }
    public void couplerFinished() {
	setControls(true);
    }

    public void keyPressed(KeyEvent evt) {
//	System.out.println("Pressed: "+evt);
	//FIXME
    }

    public void keyReleased(KeyEvent evt) {
    }

    public void keyTyped(KeyEvent evt) {
    }
    
    private void setControls(boolean was) {
	connect.setEnabled(was);
	close.setEnabled(!was);
	showmore.setEnabled(was);
	showless.setEnabled(was);
	for (int i=0;i<numConn;i++) {
	    hosts[i].setEditable(was);
	    ports[i].setEditable(was);
	    for (int j=0;j<numConn;j++) {
		if (i!=j)
		    sendto[i][j].setEnabled(was);
	    }
	}
    }
}
