package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

class PortInfo extends Frame implements ActionListener {

    private Choice typwahl;
    private TextField search;
    private TextArea log;
    private PortInfoEngine engine;

    public PortInfo() {
	this("");
    }

    public PortInfo(String s) {
	this(s,true);
    }
    
    public PortInfo(String s, boolean isPort) {
	super("Port Information");
	engine=PortInfoEngine.getInstance();
	setIconImage(MainWindow.getIcon(0));
	Panel p = new Panel(new BorderLayout());
	p.add("West", typwahl=new Choice());
	typwahl.add("Find: ");
	typwahl.add("Port number:");
	typwahl.add("TCP Port Number: ");
	typwahl.add("UDP Port Number: ");
	typwahl.add("Description: ");
	if ("".equals(s) || !isPort)
	    typwahl.select(0);
	else
	    typwahl.select(1);
	p.add("Center", search=new TextField(s));
	add("North", p);
	add("Center", log=new TextArea(25,80));
	log.setFont(new Font("Courier", Font.PLAIN,12));
	log.setEditable(false);
	String error = engine.getLoadError();
	if (error != null) {
	    log.setText(error);
	} else {
	    search.addActionListener(this);
	}
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    dispose();
		}
	    });
	pack();
	show();
	search.requestFocus();
	if (!"".equals(s)) {
	    int type = typwahl.getSelectedIndex();
	    log.setText(engine.doFind(s, type));
	}
    }

    public void actionPerformed(ActionEvent e) {
	int type = typwahl.getSelectedIndex();
	log.setText(engine.doFind(e.getActionCommand(), type));
    }

    public static int getPortNumber(String protocol) {
	return PortInfoEngine.getInstance().getPortNumber(protocol);
    }
}
	
	
