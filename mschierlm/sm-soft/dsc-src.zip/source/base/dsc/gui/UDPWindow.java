package dsc.gui;
import dsc.core.*;

import java.awt.*;
import java.awt.event.*;

public class UDPWindow extends Frame implements ActionListener,
						UDPListener {

    private TextField addr, destport, locport, msg, mgroup;
    private TextArea log;
    private Checkbox mcast;
    private UDPEngine engine;
    
    public UDPWindow () {
	super("UDP Window");
	engine=new UDPEngine(this);
	Button b;
	setBackground(Color.lightGray);
	setIconImage(MainWindow.getIcon(0));
	setLayout(new GridBagLayout());
	GridBagConstraints gc1=new GridBagConstraints();
	GridBagConstraints gc2=new GridBagConstraints();
	GridBagConstraints gc3=new GridBagConstraints();
	gc2.weightx=1.0;
	gc2.fill=GridBagConstraints.HORIZONTAL;
	gc3.gridwidth=GridBagConstraints.REMAINDER;
	gc3.fill=GridBagConstraints.BOTH;
	add(new Label("Dest. Address:"),gc1);
	add(addr=new TextField("127.0.0.1"),gc2);
	add(new Panel(),gc3);
	add(new Label("Dest. Port:"),gc1);
	add(destport=new TextField(""),gc2);
	add(new Panel(),gc3);
	add(new Label("Local Port:"),gc1);
	add(locport=new TextField(""),gc2);
	add(b=new Button("Set"),gc3);
	add(mcast=new Checkbox("Multicast group:"),gc1);
	add(mgroup=new TextField(""),gc2);
	add(new Panel(),gc3);
	b.addActionListener(this);
	add(new Label("Message:"),gc1);
	add(msg=new TextField(""),gc2);
	add(b=new Button("Send"),gc3);
	b.addActionListener(this);
	gc3.weighty=1.0;
	add(log=new TextArea(""),gc3);
	log.setFont(new Font("Courier",Font.PLAIN,12));
	log.setEditable(false);
	gc3.weighty=0.0;
	add(b=new Button("Viewer ^"),gc3);
	b.addActionListener(this);
	add(b=new Button("Clear ^"),gc3);
	b.addActionListener(this);
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    engine.shutDown();
		    dispose();
		}
	    });
	pack();
	show();
    }

    public synchronized void logoutPrintln(String s) {
	log.append(s+"\n");
    }
    
    public void actionPerformed(ActionEvent e) {
	String cmd=e.getActionCommand();
	if ("Set".equals(cmd)) {
	    int localPort=0, dport=0;
	    if (!"".equals(locport.getText())) {
		try {
		    localPort=TCPIPWindow.parsePort(locport);
		} catch (NumberFormatException ex) {
		    log.append("[^] Incorrect Number: "+ex.getMessage()+"\n");
		}
	    }
	    if (!"".equals(destport.getText())) {
		try {
		    dport=TCPIPWindow.parsePort(destport);
		} catch (NumberFormatException ex) {
		    log.append("[!] Incorrect Number: "+
			       ex.getMessage()+"\n");
		}
	    }
	    engine.connect(localPort, mcast.getState(), mgroup.getText(),
			   dport, addr.getText());
	} else if ("Send".equals(cmd)) {
	    if (engine.sendText(msg.getText())) {
		msg.setText("");
	    }
	} else if ("Clear ^".equals(cmd)) {
	    log.setText("");
	} else if ("Viewer ^".equals(cmd)) {
	    new TextResult(log.getText(),"UDP");
	}
    }
}
