Direct Socket Control v0.60
===========================

This tool allows you to open active and passive socket connections
(TCP and UDP) to other hosts and to send and receive data from them.
Additional modules - e. g. a forwarder tool and a "programmable" bot
make it even more useful.

This program is actually a reimplementation of a rather old and buggy
Visual Basic tool ("Winsock Tools") in Java.

You need a Java Runtime 1.4 or higher. To start DSC, double click
DSC.jar or run

java -jar DSC.jar

MODULES DOCUMENTATION
=====================

TCP/IP-Window
-------------

That is the "general" module of DSC. On the left, you see an area to
specify a port to listen on; on the right you can specify a
destination IP and port for an active connection. The options in the
middle allow you to send data you receive on the left to the right and
vice versa ("Forward messages") as well as opening a connection on the
right as soon as a connection is accepted on the left and closing a
connection if the other one is closed ("Forward State"). An additional
feature is to confirm every message that is forwarded - you can send
it "as is", change it or drop it.

The middle of the window is a text box where you can enter a message
and send it to one of the sides. You can use "escapes" to specify
control characters - see below. The bottom part logs all your
communication and allows to save it into a file or clear it.


UDP window
----------

Here you can send and receive UDP datagrams. Dest Address and Dest
port specify the destination of your packages, local port specifies
the port to watch. If local port is empty, a random free port is
used. If you do not specify IP or port, you cannot send any messages,
but only receive them.

When enabling "Multicast group", you can listen to or send to a
multicast address. If you want to use more than one multicast group,
separate them by spaces.  Only selecting Multicast group without
entering anything simply opens a UDP socket that is able to send
multicast packets.

When you have set your settings, you can enter a message and send it.


IP/Port scanner
---------------

This module can be used to scan IPs or ports. It is not very powerful
(if you need a "real" port scanner, use nmap), but at least it works.

There is an internal help function for how to specify IP or port ranges.


Port Information
----------------

This module can show you information about port numbers. These
information is taken from plugins/ianaports.txt.gz, which is a gzipped
version of <http://www.iana.org/assignments/port-numbers>. To update
the information, download this file as ianaports.txt and gzip it.
(You can also leave it ungzipped, but that file is quite big, so
gzipping seems to be a good idea. It is transparently decompressed
into memory when it's first used.

If you enter a "keyword" into one of the Port textboxes DSC, it will
be expanded as well.


Forwarder
---------

This module can forward connections that come to one port to another
port on another machine. It has quite lots of options, including
"plugins" that change the data in some way.

Only from IP: Specifies a local IP that is the only one for accepting
connections from. All other connections are closed diretly after a
connect attempt.

From Port: Specifies the local port this forwarder is listening at.

To IP, To Port: Specify the destination.

Retry to port: If the connection to the default port fails, it is
retried to this port. You may specify the same port if you want to
retry connections until they succeed.

Until received: When this textbox is not empty, a connection attempt
is regarded as "failed" if the reveiver does not send a text that
contains the text specified here before disconnecting. All sent text
is held back until this text is received. Might be useful for overfull
servers that send a greeting if they can be used. If the greeting does
not appear until the connection is closed, the connection is seen as
unsuccesful. (If the originator of the connection sends something, the
connection is seen as successful anyway, regardless if the receiver
sends this text.

Use Filter plugin: Here you can specify the name of a filter
plugin. See below for a list of basic filter plugins. A slash (/) is
used to separate plugin name and its parameters.

Close after one connection: When the first connection came in, the
listening socket is closed. Useful if you only want to forward one
process. 


Lookup window
-------------

The lookup window can be used to look up domain names for IP
ranges. The syntax for the IP ranges is the same as in IP/Port
scanner. 


Coupler
-------

This module is in my opinion only useful for testing. You can use it
to connect multiple different (e. g. active or passive) connections
and send data from one to another. It might be useful if you want to
use a normal telnet program for incoming connections, but most
probably you'll never need it...

Clicking the "more" and "less" buttons with the CTRL or SHIFT key
pressed will give you the maximum or minimum of slots.

To add a passive connection, leave the "Host" field blank.

Options
-------

Return text: the text that is added to the "Send" box of TCP/IP-Window
when you press the return key.

Packet wait delay: if nonzero, all TCP packets that arrive within that
delay are seen as one packet (useful for apps that send every char as
an extra packet to make the log more readable)

Limit parallel threads to: Limits the number of threads in Port
Scanner and Lookup Window.

Use encoding: Specifies the character enchoding that is used to show
packets in TCP/IP Window.

Wrap logs after returns (\n): In TCP/IP window, a newline character
causes a new line in the log. ("\n" is printed as well).


Bot
---

This module allows you ... (sorry, will be documented in next
version. You might look at the examples (*.sbf).)

GENERAL INFORMATION
===================

Using Escapes
-------------

To specify special characters, you can use escape sequences:

\r         carriage return
\n         line feed
\t         tab
\b         backspace
\00 - \31  control character 0-31
\xnn       Hexadecimal character \x00-\xFF
\unnnn     Hexadecimal unicode character (if available in current
           character encoding)
\\         backslash


Available plugins
-----------------

In the basic package:

Dummy     (no parameters)
          Does not change anything - sends everything "as is"


Additional files:

  ianaports.txt.gz 
    contains the port list necessary for port information and for the
    use of port names instead of numbers

  basicset.jar

    Delay      (param: two characters, defaulting to #_) 
               when sending to the receiver, everything is queued into
               a buffer except all firstchars (referring to the first
               character of the parameter). if the next char is a
               firstchar as well, the buffer is flushed, if it is a
               secondchar, a firstchar is written into the buffer; all
               other chars are written to the buffer as usual.
              
    Replace   (param: name of a file with rules)
              the file looks like this:
               >before=after
               <foo=bar
              In this case all before are replaced by after while
              sending and all foo are replaced by bar when
              receiving. If a text matches the beginning of a replace
              pattern, it is held back until it matches or it does not
              any more

    ROT13    (param: two digits 0 or 1, speifying if ROT13 should be
             done in that direction)
             Does ROT13 encoding. Only an example...

    Weak-    Very weak scrambling (XOR and additions). Useful to bypass
    Crypto   protocol detection heurisitics. Without parameters it uses
             one constant XOR pattern. You can use parameters to
             generate varying patterns that use multiple xor and
             additions and get shifted (by addition) after each
             character. The parameter looks like
             <clientScrambling>|<serverScrambling> where each
             scrambling list consists of comma-separated <value>+<add>
             pairs, the first and every odd pair describes a XOR rule,
             every even pair is an add rule.
             2+3,6+100,9+0|9+0,250+156,2+3 will xor the first
             character by 2, then add 6, then xor by 9. The second
             byte will be xored by 5, then added 106, then xored by
             9. Bytes to the server will be treated inversely. (To
             invert a scrambling rule, you can add a "!" mark before
             it, i. e. "!2+3,6+100" is the same as "0+0,250+156,2+3",
             which is handy if you want to cascade two forwarders so
             that the second ones reverts the scrambling).  Another
             shortcut is a pseudorandom rule, which can be created by
             <length>r<seed>. For example, 5r42 creates a random
             scrambling of length 5 (3 xor operations and 2 additions)
             that can be reverted by !5r42. Since the scrambling is
             seeded, it will create exactly the same scrambling each
             time it is created for the same seed value.

Send bug reports, suggestions, etc. to sm-soft@gmx.de. Thank you.