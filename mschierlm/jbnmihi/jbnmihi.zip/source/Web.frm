VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{767DF3A0-7801-11CF-A8A0-444553540000}#1.0#0"; "CSWEB32.OCX"
Begin VB.Form frmWeb 
   Caption         =   "Stats Browser"
   ClientHeight    =   7020
   ClientLeft      =   135
   ClientTop       =   390
   ClientWidth     =   8190
   Icon            =   "Web.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Stats Browser"
   ScaleHeight     =   7020
   ScaleWidth      =   8190
   Begin VB.CommandButton cmdCancel 
      Height          =   312
      Left            =   7740
      Picture         =   "Web.frx":0442
      Style           =   1  'Grafisch
      TabIndex        =   5
      TabStop         =   0   'False
      Top             =   6420
      Width           =   372
   End
   Begin VB.ComboBox cboURL 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   288
      Left            =   480
      TabIndex        =   0
      Top             =   6420
      Width           =   6072
   End
   Begin VB.CommandButton cmdNext 
      Height          =   312
      Index           =   1
      Left            =   7380
      Picture         =   "Web.frx":0884
      Style           =   1  'Grafisch
      TabIndex        =   4
      TabStop         =   0   'False
      Top             =   6420
      Width           =   372
   End
   Begin VB.CommandButton cmdNext 
      Height          =   312
      Index           =   2
      Left            =   7020
      Picture         =   "Web.frx":0CC6
      Style           =   1  'Grafisch
      TabIndex        =   3
      TabStop         =   0   'False
      Top             =   6420
      Width           =   372
   End
   Begin VB.CommandButton cmdNext 
      Height          =   312
      Index           =   0
      Left            =   6660
      Picture         =   "Web.frx":1108
      Style           =   1  'Grafisch
      TabIndex        =   2
      TabStop         =   0   'False
      Top             =   6420
      Width           =   372
   End
   Begin ComctlLib.ProgressBar barProgress 
      Height          =   192
      Left            =   6660
      TabIndex        =   7
      Top             =   6800
      Visible         =   0   'False
      Width           =   1332
      _ExtentX        =   2355
      _ExtentY        =   344
      _Version        =   327682
      Appearance      =   1
   End
   Begin ComctlLib.StatusBar barStat 
      Align           =   2  'Unten ausrichten
      Height          =   276
      Left            =   0
      TabIndex        =   6
      Top             =   6744
      Width           =   8196
      _ExtentX        =   14446
      _ExtentY        =   476
      Style           =   1
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   1
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.TextBox txtFinger 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   10.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   6252
      Left            =   60
      MaxLength       =   31035
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Beides
      TabIndex        =   9
      Top             =   60
      Visible         =   0   'False
      Width           =   8052
   End
   Begin WebClientCtrl.WebClient WebClient1 
      Height          =   6252
      Left            =   60
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   60
      Width           =   8052
      _Version        =   65536
      _ExtentX        =   14203
      _ExtentY        =   11028
      _StockProps     =   105
      BorderStyle     =   1
      AuthenticName   =   ""
      AutoLoad        =   -1  'True
      AutoRedirect    =   -1  'True
      AutoRefresh     =   0   'False
      AutoResolve     =   -1  'True
      Base            =   ""
      Blocking        =   -1  'True
      CacheDir        =   "C:\TEMP"
      CacheSize       =   32
      CacheTimeout    =   0
      FontFixed       =   "Courier New"
      FontHeading     =   "Times New Roman"
      FontNormal      =   "Times New Roman"
      HistorySize     =   0
      HostAddress     =   ""
      HostName        =   ""
      IndexFile       =   "index.htm"
      IsLocal         =   -1  'True
      IsProxy         =   0   'False
      LocalFile       =   ""
      Pragma          =   ""
      Private         =   0   'False
      ProxyHost       =   ""
      ProxyPort       =   0
      RemoteAccess    =   0   'False
      RemoteFile      =   ""
      RemotePort      =   0
      RemoteService   =   ""
      Timeout         =   60
      UserAgent       =   ""
      UserName        =   ""
      Begin VB.Timer tmrLoad 
         Enabled         =   0   'False
         Interval        =   50
         Left            =   6480
         Top             =   120
      End
   End
   Begin VB.Label lblURL 
      Caption         =   "URL:"
      Height          =   192
      Left            =   60
      TabIndex        =   8
      Top             =   6480
      Width           =   432
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuAddBookmark 
         Caption         =   "Add &Bookmark"
      End
      Begin VB.Menu mnuPrint 
         Caption         =   "&Print"
         Shortcut        =   ^P
      End
      Begin VB.Menu sepFile1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuStop 
         Caption         =   "&Stop Loading  [Esc]"
      End
      Begin VB.Menu mnuReload 
         Caption         =   "&Reload"
         Shortcut        =   ^R
      End
      Begin VB.Menu mnuRefreshDisplay 
         Caption         =   "Re&fresh"
      End
      Begin VB.Menu mnuReset 
         Caption         =   "R&eset"
      End
      Begin VB.Menu sepFile2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
      Begin VB.Menu sepFile3 
         Caption         =   "-"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   0
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   1
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   2
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   3
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   7
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   8
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   9
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   10
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   11
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   12
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   13
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   14
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   15
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   16
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   17
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   18
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHist 
         Caption         =   ""
         Index           =   19
         Visible         =   0   'False
      End
   End
   Begin VB.Menu mnuSoftware 
      Caption         =   "&Software"
      Begin VB.Menu mnuSoftURL 
         Caption         =   "Potato Software [SkuzNet]"
         Index           =   0
      End
      Begin VB.Menu mnuSoftURL 
         Caption         =   "Potato Software [Tripod]"
         Index           =   1
      End
      Begin VB.Menu mnuSoftURL 
         Caption         =   "Potato Software [Forward]"
         Index           =   2
      End
      Begin VB.Menu mnuSoftURL 
         Caption         =   "-"
         Index           =   3
      End
      Begin VB.Menu mnuSoftURL 
         Caption         =   "Helpful Links"
         Index           =   4
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "&Tools"
      Begin VB.Menu mnuShowStats 
         Caption         =   "&Show Stats"
         Shortcut        =   ^T
      End
      Begin VB.Menu mnuRefresh 
         Caption         =   "&Refresh Stats"
         Shortcut        =   ^E
      End
      Begin VB.Menu sepTool2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuUpdateKeys 
         Caption         =   "Get &CPunk Keys"
         Index           =   0
      End
      Begin VB.Menu mnuUpdateKeys 
         Caption         =   "Get &Mix Keys"
         Index           =   1
      End
      Begin VB.Menu sepTools7 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "&View PGP Keyring"
         Index           =   0
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "View Mi&x Keyring"
         Index           =   1
      End
      Begin VB.Menu sepTool1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFinger 
         Caption         =   "&Finger"
         Shortcut        =   ^F
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuAuto 
         Caption         =   "&Auto-Load Images"
         Index           =   0
         Shortcut        =   ^I
      End
      Begin VB.Menu mnuAuto 
         Caption         =   "Auto Re&direction"
         Index           =   1
      End
      Begin VB.Menu sepOpt1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuProxy 
         Caption         =   "Proxy Visits Via &A"
         Index           =   0
      End
      Begin VB.Menu mnuProxy 
         Caption         =   "Proxy Visits Via &B"
         Index           =   1
      End
      Begin VB.Menu mnuProxy 
         Caption         =   "Proxy Stats Retrieval"
         Index           =   2
      End
      Begin VB.Menu sepOptions2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfigWeb 
         Caption         =   "&Configuration..."
         Shortcut        =   {F7}
      End
   End
   Begin VB.Menu mnuWind 
      Caption         =   "&Window"
      Begin VB.Menu mnuWindow 
         Caption         =   "E&xplore"
         Index           =   0
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Queue"
         Index           =   1
         Shortcut        =   {F3}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Log"
         Index           =   2
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&View Mail"
         Index           =   3
         Shortcut        =   {F5}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Stats Browser"
         Index           =   4
         Shortcut        =   {F6}
      End
      Begin VB.Menu sepWindow1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Global Config"
         Index           =   0
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "R&etrieval Config"
         Index           =   1
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Books Config"
         Index           =   2
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Remailers Config"
         Index           =   3
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "S&tats Config"
         Index           =   4
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   5
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Sen&d Profiles"
         Index           =   6
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Retrieval &Profiles"
         Index           =   7
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Ne&ws Profiles"
         Index           =   8
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Nym Accounts Registry"
         Index           =   9
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Addresses"
         Index           =   10
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   11
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Check Configuration"
         Index           =   12
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&User's Manual              F1"
         Index           =   0
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Beginner's Guide"
         Index           =   1
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Troubleshooting Guide"
         Index           =   2
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Remailer Reference"
         Index           =   3
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "-"
         Index           =   7
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "Open Default &Browser"
         Index           =   8
      End
   End
End
Attribute VB_Name = "frmWeb"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Const Red = &HFF&
Const NotRed = &H80000012
Dim WebFile As String, WebCancel As Integer, WebLocalURL As String
Dim WebLoading As Boolean
Dim WebErrorCode As Integer, WebErrorString As String
Dim WebConnected As Boolean, WebResource As String, WebTempResource As String
Const MaxHist = 40
Dim URLHist(MaxHist) As String, URLHistX As Integer
Dim AutoMode As Boolean

Private Sub mnuAddBookmark_Click()
    URL = Trim(cboURL.Text)
    If URL = "" Then
        URL = InputBox(LMsg(437) + ":", LMsg(436), "http://")
        If Trim(URL) = "" Then Exit Sub
    End If
    a = InputBox(LMsg(438) + ":", LMsg(436))
    If Trim(a) = "" Then Exit Sub
    For i = 0 To MaxBookmarks
        If Bookmarks(i, 0) = "" Then
            Bookmarks(i, 0) = Trim(a)
            Bookmarks(i, 1) = Trim(URL)
            CheckConfig ("Stats")
            Exit For
        End If
    Next i
End Sub

Private Sub mnuViewRing_Click(Index As Integer)
    If Index = 0 Then
        SelectKey (LMsg(415))
    Else
        ShowConfig ConfigRemailers, 3
    End If
End Sub

Private Sub mnuConfigWeb_Click()
    ShowConfig (ConfigStats)
End Sub


Private Sub mnuFinger_Click()
    cboURL.Text = "finger: "
    cboURL.SetFocus
    cboURL.SelStart = Len(cboURL.Text)
End Sub

Private Sub mnuSoftURL_Click(Index As Integer)
    Select Case Index
    Case 0: URL = "http://www.skuz.net/potatoware/"
    Case 1: URL = "http://members.tripod.com/~l4795/"
    Case 2: URL = "http://www.bigfoot.com/~potatoware/"
    Case 4: URL = "http://www.bigfoot.com/~potatoware/links.html"
    End Select
    tmrLoad.Tag = URL
    tmrLoad.Enabled = True
End Sub

Private Sub mnuUpdateKeys_Click(Index As Integer)
    Dim Tmp(MaxRemailers) As String, URL1 As String, URL2 As String
    Dim URLList As String, ListH As Long, ListW As Long
    Dim KeyCount As Integer, AllMix As String
    Dim CheckValue As Byte
    
    On Error GoTo KeysError
    If Not CreateDir(ProgDir + "\Stats") Then Exit Sub
    
    If Not RASConnected And PData(54) = True2 Then KeepDate(16) = 0: DialRAS (True)
    If Not RASConnected Then If MsgTime(LMsg(397), 0, LMsg(294), vbOKCancel, 2, 90) = 2 Then Exit Sub
    If Index = 0 Then x = 546 Else x = 389
    URLList = MultiBox(LMsg(535), LMsg(x), Cnf(3, 22 + (2 * Index)), True, ListH, ListW)
    If URLList = "" Then Exit Sub
    
    UpdatingKeys = True
    StatsBusy = True
    EnableForm (False)
    On Error Resume Next
    WebClient1.Reset
    WebClient1.AutoLoad = False
    WebClient1.AutoRedirect = mnuAuto(1).Checked
    On Error GoTo KeysError
    
    urlx = ParseString(URLList, Tmp(), 30, False)
    If urlx = -1 Then MsgBox LMsg(385), vbInformation: EnableForm (True): Exit Sub
    For ux = 0 To urlx
        URL1 = Trim(Extract(Tmp(ux), ";"))
        URL2 = Trim(Mid(Tmp(ux), InStr(Tmp(ux), ";") + 1))
        If URL1 <> "" And (Index = 0 Or (InStr(Tmp(ux), ";") <> 0 And URL2 <> "")) Then
                Stat LMsg(372) + " " + URL1, StatDec
                fn1 = GetURL(URL1, False, True, ErrMsg)
                If fn1 <> "" And Index = 1 Then Stat LMsg(372) + " " + URL2, StatDec: fn2 = GetURL(URL2, False, True, ErrMsg)
                Stat "", StatDec
                If fn1 <> "" And (Index = 0 Or fn2 <> "") Then
                    If Index = 0 Then
                        'Cpunk keys
                        ImportKeyFile (fn1)
                        KeyCount = KeyCount + 1
                    Else
                        'Mix keys
                        mixpath = Cnf(1, 19)
                        If mixpath = "" Then mixpath = Cnf(1, 15)
                        t2 = Cnf(1, 20)
                        If InStr(t2, "\") = 0 Then t2 = mixpath + "\" + t2
                        pm = Cnf(1, 21)
                        If InStr(pm, "\") = 0 Then pm = mixpath + "\" + pm
                        x = AddMixKeys(fn1, fn2, t2, pm, PData(10), False, URL1)
                        If x <> 0 Then
                            n = FreeFile
                            Open fn1 For Input As n
                            AllMix = AllMix + vbCrLf + Input(LOF(n), n) + vbCrLf
                            Close n: n = 0
                            KeyCount = KeyCount + x
                        End If
                    End If
                Else
                    If fn1 = "" Then a = URL1 Else a = URL2
                    CheckValue = 0
                    MsgTime LMsg(355) + " " + a + vbCrLf + "      " + ErrMsg, 0, LMsg(4), vbOKOnly, 1, 0, "", "", "", LMsg(536), CheckValue
                    If CheckValue = 1 Then
                        a = Cnf(3, 22 + (2 * Index))
                        x = InStr(a, Tmp(ux))
                        If x <> 0 Then
                            y = InStr(x, a, vbCrLf)
                            If y = 0 Then y = Len(a) + 1
                            a = Left(a, x - 1) + Mid(a, y + 2)
                            If Right(a, 2) <> vbCrLf Then a = a + vbCrLf
                            Cnf(3, 22 + (2 * Index)) = a + Tmp(ux) + vbCrLf
                            If Not CheckingConfig Then SaveConfig
                        End If
                    End If
                End If
                DelFile fn1
                DelFile fn2
            'End If
        End If
    Next ux
    'Flush Mix
    If AllMix <> "" Then
        r = ""
        Type2 r, "", "", "", ""
        x = ParseString(r, Tmp(), MaxRemailers)
        For i = 0 To x
            mname = Extract(Trim(Tmp(i)), " ")
            If InStr(1, AllMix, vbCrLf + mname + " ", vbTextCompare) = 0 Then
                y = MsgBox(LMsg(390) + " " + mname + " " + LMsg(391) + vbCr + vbCr + Tmp(i), vbQuestion + vbYesNoCancel + vbDefaultButton2, LMsg(181))
                If y = vbCancel Then Exit For
                If y = vbYes Then
                    AddSingleMixKey Trim(Tmp(i)), t2, pm, PData(10), 1
                End If
            End If
        Next i
    End If
    If Index = 0 Then
        If KeyCount <> 0 Then MsgBox LMsg(386), vbInformation, LMsg(382)
    Else
        MsgBox Str(KeyCount) + " " + LMsg(387), vbInformation
    End If
    barStat.SimpleText = ""
    WebClient1.Reset
    Erase URLHist: URLHistX = -1
    If Not CheckingConfig Then CheckConfig "Remailers", True, True
    EnableForm (True)
    UpdatingKeys = False
    StatsBusy = False
    Stat "", StatDec
    frmMain!filExplore(0).Refresh
    If frmMain!filExplore(1).Visible Then frmMain!filExplore(1).Refresh
Exit Sub
KeysError:
    MsgBox LMsg(0) + vbCrLf + "      " + Error, vbCritical, LMsg(4)
    WebClient1.Reset
    Erase URLHist: URLHistX = -1
    EnableForm (True)
    UpdatingKeys = False
    StatsBusy = False
    Stat "", StatDec
    barStat.SimpleText = ""
    CloseFile n
End Sub

Private Sub RefreshStats()
    Dim Tmp(30) As String
    Dim NewStats(MaxRemailers) As String, NSx As Integer
    Dim CheckValue As Byte, ActiveURL(1, 1) As String, Attended As Boolean
    
    On Error GoTo RefreshError
    If Not CreateDir(ProgDir + "\Stats") Then
        MsgLog LMsg(26) + " " + ProgDir + "\Stats", 1, True, True
        Exit Sub
    End If
    
    If Not RASConnected And PData(54) = True2 Then KeepDate(16) = 0: DialRAS (True)
    If Not RASConnected Then If MsgTime(LMsg(397), 0, LMsg(294), vbOKCancel, 2, 90) = 2 Then Exit Sub
    StatsBusy = True
    EnableForm (False)
    On Error Resume Next
    WebClient1.Reset
    WebClient1.AutoLoad = False
    WebClient1.AutoRedirect = mnuAuto(1).Checked
    On Error GoTo RefreshError
    WebAbort = False
    'Start Stats.htm
    p = FreeFile
    Open ProgDir + "\Stats\Stats.htm" For Output As p
    Print #p, "<HTML><BODY>"
    Print #p, "<CENTER><A NAME="; Chr(34); "Top"; Chr(34); "><BIG>Jack B. Nymble v2</BIG></A><BR>"; Format(SafeTime, "ddd, dd mmm yyyy  hh:mm"); " </CENTER>"
    Print #p, "<P><PRE></PRE>"
    For rtype = 0 To 1
        If rtype = 0 Then rtypename = "CPunk" Else rtypename = "Mix"
        urlx = ParseString(Cnf(3, 20 + (rtype * 3)), Tmp(), 30, False)
        If urlx <> -1 Then
            If rtype = 0 Then a = "Cypherpunk" Else a = "Mixmaster"
            Print #p, "<B><A HREF="; Chr(34); "#"; a; Chr(34); ">"; a; " Stats"; "</A></B><BR><UL>"
            For ux = 0 To urlx
                If LCase(Left(Tmp(ux), 5)) = "http:" Then
                    Print #p, "<LI><A HREF="; Chr(34); Tmp(ux); Chr(34); ">"; Tmp(ux); "</A><BR>"
                Else
                    Print #p, "<LI>"; Replace(Tmp(ux), "\", "\\"); "<BR>"
                End If
            Next ux
            Print #p, "</UL>"; vbCrLf; "<P>"
        End If
        For ux = 0 To urlx
            'Get Stats File
            Msg = ""
            URL = Tmp(ux)
            
            Stat LMsg(372) + " " + URL, StatDec
            fn = GetURL(URL, False, True, ErrMsg)
            Stat "", StatDec
            If fn <> "" Then
                'Parse Stats
                barStat.SimpleText = LMsg(378)
                BeginStats = False: StatsDone = False
                StringDone = False
                StatsVer = 0: NSx = 0
                FirstLine = True
                n = FreeFile
                Open fn For Input As n
                While Not EOF(n)
                    Line Input #n, a
                    'Remailer String
Parse:              If LCase(Left(Trim(a), 9)) = "$remailer" Then
                        If ux = 0 And (Not AllStringsDone Or rtype = 0) And Val(Cnf(3, 1)) = 1 Then
                            'Process remailer string
                            rname = "": raddress = ""
                            RemailerString a, rname, raddress, roptions
                            If rname <> "" And InStr(raddress, "@") <> 0 Then
                                r = "$remailer{" + Chr(34) + rname + Chr(34) + "} = <" + raddress + "> " + Chr(34) + Trim(roptions) + Chr(34) + ";"
                                For i = 0 To MaxRemailers
                                    If RString(i) = "" Then
                                        'New
                                        If PData(35) <> False2 And Not OKToAll Then
                                            CheckValue = 0
                                            OKToAll = MsgTime(LMsg(373) + " " + LMsg(376) + ":" + vbCr + vbCr + r, 0, LMsg(375), 999, 1, 30, "&OK", "OK To &All", "", LMsg(292), CheckValue) = 2
                                            If CheckValue = 1 Then frmMain!mnuPopUp(5).Checked = False: PData(35) = False2
                                        End If
                                        RString(i) = r
                                        If InStr(roptions, " pgp ") <> 0 Then NewCPunk = True
                                        If InStr(roptions, " mix ") <> 0 Then NewMix = True
                                        Exit For
                                    Else
                                        RemailerString RString(i), rname2, raddress2, roptions2
                                        If rname2 = rname Then
                                            If raddress2 <> raddress Or roptions2 <> roptions Then
                                                'Replace
                                                If PData(35) <> False2 And Not OKToAll Then
                                                    CheckValue = 0
                                                    OKToAll = MsgTime(LMsg(373) + ":" + vbCr + vbCr + RString(i) + vbCr + LMsg(374) + ":" + vbCr + r, 0, LMsg(375), 999, 1, 30, "&OK", "OK To &All", "", LMsg(292), CheckValue) = 2
                                                    If CheckValue = 1 Then frmMain!mnuPopUp(5).Checked = False: PData(35) = False2
                                                End If
                                                RString(i) = r
                                            End If
                                            Exit For
                                        End If
                                    End If
                                Next i
                                AllNames = AllNames + rname + vbCrLf
                                StringDone = True
                            End If
                        End If
                    End If
                    'Machine and Chain Info
                    If Not MCIDone And ux = 0 Then
                        If LCase(Trim(a)) = "groups of remailers sharing a machine or operator:" Or _
                           LCase(Trim(a)) Like "broken type-* remailer chains:" Then
                            mci = mci + a + vbCrLf
                            a = "("
                            While Not EOF(n) And Left(a, 1) = "("
                                Line Input #n, a
                                a = Trim(a)
                                If Left(a, 1) = "(" Then mci = mci + a + vbCrLf
                            Wend
                            mci = mci + vbCrLf
                            GoTo Parse
                        End If
                    End If
                    'Stats V1
                    If LCase(Left(a, 12)) = "last update:" And Not BeginStats Then
                        LastUp = a
                        If Not EOF(n) Then Line Input #n, colhead Else colhead = ""
                        Select Case LCase(Extract(colhead, " "))
                        Case "remailer": rt = 0
                        Case "mixmaster": rt = 1
                        Case Else: rt = -1
                        End Select
                        If Not EOF(n) Then Line Input #n, a
                        If Left(a, 5) <> "-----" Then rt = -1
                        If rt = -1 Then
                            Msg = LMsg(367)
                        Else
                            If rt = rtype Then StatsVer = 1: BeginStats = True
                        End If
                    End If
                    'Stats V2
                    If LCase(Left(a, 16)) = "stats-version: 2" And Not BeginStats Then
                        If Not EOF(n) Then Line Input #n, LastUp Else LastUp = ""
                        If Not EOF(n) Then Line Input #n, colhead Else colhead = ""
                        Select Case LCase(Extract(colhead, " "))
                        Case "cypherpunk": rt = 0
                        Case "mixmaster": rt = 1
                        Case Else: rt = -1
                        End Select
                        If Not EOF(n) Then Line Input #n, a
                        If Left(a, 5) <> "-----" Then rt = -1
                        If rt = -1 Then
                            Msg = LMsg(367)
                        Else
                            If rt = rtype Then StatsVer = 2: BeginStats = True
                        End If
                    End If
                    If BeginStats And Not EOF(n) And Not StatsDone Then
                        'Read Lines of Stats
                        If LastUp = "" Then LastUp = "Generated:"
                        Erase NewStats
                        NewStats(0) = LastUp
                        NSx = 0
                        If StatsVer = 1 Then
                            lt = InStr(1, colhead, "latency", vbTextCompare) - 1
                            lh = InStr(1, colhead, "history", vbTextCompare) - 5
                            uh = 300
                            ut = InStr(1, colhead, "uptime", vbTextCompare) - 1
                            If lt < 1 Or lh < 1 Or ut < 1 Then
                                'Bad stats
                                Msg = LMsg(367)
                                BeginStats = False
                            End If
                        Else
                            lt = InStr(1, colhead, "latent ", vbTextCompare)
                            lh = InStr(1, colhead, "latent-hist", vbTextCompare)
                            uh = InStr(1, colhead, "uptime-hist", vbTextCompare)
                            ut = InStr(1, colhead, "uptime ", vbTextCompare)
                        End If
                        If BeginStats Then
                            Do
                                Line Input #n, a
                                If Trim(a) = "" Or LCase(Trim(a)) = "</pre>" Then Exit Do
                                rname = Extract(a, " ")
                                lhist = Right(String(12, " ") + Mid(a, lh, 12), 12)
                                If StatsVer = 1 Then
                                    'Modify History
                                    h1 = " #*+-._"
                                    h2 = "?014CGH"
                                    For k = 1 To 12
                                        t = InStr(h1, Mid(lhist, k, 1))
                                        If t <> 0 Then Mid(lhist, k, 1) = Mid(h2, t, 1)
                                    Next k
                                End If
                                uhist = Right(String(12, " ") + Mid(a, uh, 12), 12)
                                lat = Right(String(5, " ") + Mid(a, lt, 5), 5)
                                If InStr(lat, ":") = 0 Then
                                    If SVal(lat) < 10 Then lat = Right("     :0" + Trim(Int(SVal(lat))), 5) Else lat = Right("     :" + Trim(Int(SVal(lat))), 5)
                                End If
                                uptime = Right(String(5, " ") + Mid(a, ut, 5), 5)
                                NSx = NSx + 1
                                NewStats(NSx) = Left(rname + String(13, " "), 13) + _
                                     lhist + "  " + lat + "   " + uhist + "  " + uptime + "%"
                            Loop Until NSx = MaxRemailers Or EOF(n)
                            StatsDone = True
                        End If
                    End If
                Wend
                Close n: n = 0
                'Flush Remailer Strings
                If StringDone Then
                    AllStringsDone = True
                    If SafeTime - KeepDate(17) > 21 Then
                        For i = 0 To MaxRemailers
                            If RString(i) = "" Then Exit For
                            RemailerString RString(i), rname, "", ""
                            If rname <> "" And InStr(AllNames, rname + vbCrLf) = 0 And Not NoToAll Then
                                x = MsgTime(LMsg(377) + vbCr + vbCr + RString(i), 0, LMsg(375), 999, 2, 30, "&Yes", "&No", "No To &All")
                                If x = 3 Then NoToAll = True
                                If x = 1 Then
                                    For j = i To MaxRemailers - 1
                                        RString(j) = RString(j + 1)
                                    Next j
                                    RString(MaxRemailers) = ""
                                End If
                            End If
                        Next i
                        KeepDate(17) = SafeTime
                    End If
                End If
                If mci <> "" And Not MCIDone Then MCIDone = True: PData(42) = mci
                If BeginStats And NSx > 0 Then
                    'Write Stats File
                    DelFile ProgDir + "\Stats\" + rtypename + ".txt"
                    DelFile ProgDir + "\Stats\" + rtypename + ".htm"
                    ActiveURL(rtype, 0) = Tmp(ux)
                    ActiveURL(rtype, 1) = rtypename + "." + PlainName(fn, 3)
                    FileCopy fn, ProgDir + "\Stats\" + rtypename + "." + PlainName(fn, 3)
                    If rtype = 1 And Cnf(1, 15) <> "" Then
                        'Update Mixmaste.htm"
                        mixpath = Cnf(1, 19)
                        If mixpath = "" Then mixpath = Cnf(1, 15)
                        mixrel = Cnf(1, 22)
                        If InStr(mixrel, "\") = 0 Then mixrel = mixpath + "\" + mixrel
                        If StatsVer = 2 Then
                            DelFile fn
                            fn = GetWork
                            n = FreeFile
                            Open fn For Output As n
                            Print #n,
                            Print #n, "Last update: "; LTrim(Mid(LastUp, InStr(LastUp, ":") + 1))
                            Print #n, "mixmaster           history  latency  uptime"
                            Print #n, "--------------------------------------------"
                            For i = 1 To NSx
                                rname = Extract(NewStats(i), " ")
                                raddress = "": r = rname
                                Remailer r, 1, rname, raddress, "", "", "", "", ""
                                'Check never list
                                NeverMix = InStr(1, Cnf(1, 13), rname + vbCrLf, vbTextCompare) <> 0 Or InStr(1, Cnf(1, 13), raddress + vbCrLf, vbTextCompare) <> 0
                                'Check limit list
                                If Not NeverMix And Val(Cnf(1, 0)) = 4 Then If InStr(1, Cnf(1, 14), rname + vbCrLf, vbTextCompare) = 0 And InStr(1, Cnf(1, 14), raddress + vbCrLf, vbTextCompare) = 0 Then NeverMix = True
                                If Not NeverMix Then
                                    lat = Mid(NewStats(i), 28, 5)
                                    uptime = Mid(NewStats(i), 50, 5)
                                    Print #n, Left(rname + String(15, " "), 15) + String(12, "+") + " " + lat + ":00 " + Left(uptime, 5) + "0%"
                                End If
                            Next i
                            Print #n,
                            Close n: n = 0
                        End If
                        On Error Resume Next
                        FileCopy fn, mixrel
                        On Error GoTo RefreshError
                    End If
                    'Update Current Stats
                    For i = 0 To MaxRemailers
                        RemStats(rtype, i) = NewStats(i)
                    Next i
                    If ux <> 0 Then b = "  [" + LMsg(380) + "]" Else b = ""
                    MsgLog rtypename + " " + LMsg(379) + b, 1, False
                    DelFile fn
                    Exit For
                Else
                    Msg = LMsg(417) + " " + rtypename + " " + LMsg(418)
                End If
                DelFile fn
            Else
                Msg = ErrMsg
            End If
            If Msg <> "" Then
                Msg = LMsg(355) + " " + rtypename + " " + LMsg(369) + vbCrLf + "      " + Tmp(ux) + vbCrLf + "      " + Msg
                CheckValue = 0
                MsgLog Msg, 1, False, False
                Attended = False
                If PData(31) <> False2 Then
                    MsgTime Msg, 0, LMsg(4), vbOKOnly, 1, 30, "", "", "", LMsg(536), CheckValue, Attended
                    If CheckValue = 1 Then
                        a = Cnf(3, 20 + (rtype * 3))
                        x = InStr(a, Tmp(ux))
                        If x <> 0 Then
                            y = InStr(x, a, vbCrLf)
                            If y = 0 Then y = Len(a) + 1
                            a = Left(a, x - 1) + Mid(a, y + 2)
                            If Right(a, 2) <> vbCrLf Then a = a + vbCrLf
                            Cnf(3, 20 + (rtype * 3)) = a + Tmp(ux) + vbCrLf
                            If Not CheckingConfig Then SaveConfig
                        End If
                    End If
                End If
                If Not Attended Then
                    ErrorSummary = Right(ErrorSummary + Msg, 30000)
                    frmMain!PictureError.Visible = True
                    frmMain!PictureError.ZOrder
                    Stat StatMain, StatDec
                End If
            End If
            If WebAbort Then Exit For
        Next ux
        If WebAbort Then Exit For
    Next rtype
    'Complete Stats.htm
    urlx = ParseString(Cnf(3, 21), Tmp(), 30, False)
    If urlx <> -1 Then
        Print #p, "<B><U>Cypherpunk Chain Stats"; "</U></B><BR><UL>"
        For ux = 0 To urlx
            If LCase(Left(Tmp(ux), 5)) = "http:" Then
                Print #p, "<LI><A HREF="; Chr(34); Tmp(ux); Chr(34); ">"; Tmp(ux); "</A><BR>"
            Else
                Print #p, "<LI>"; Replace(Tmp(ux), "\", "\\"); "<BR>"
            End If
        Next ux
        Print #p, "</UL>"; vbCrLf; "<P><P>"
    End If
    For rtype = 0 To 1
        Print #p, "<HR>"
        If rtype = 0 Then a = "Cypherpunk" Else a = "Mixmaster"
        Print #p, "<A NAME="; Chr(34); a; Chr(34); "></A><B><A HREF="; Chr(34); ActiveURL(rtype, 1); Chr(34); ">Active "; a; " Stats"; "</A></B><BR>"
        If LCase(Left(ActiveURL(rtype, 0), 5)) = "http:" Then
            Print #p, "<SMALL>[<A HREF="; Chr(34); ActiveURL(rtype, 0); Chr(34); ">"; ActiveURL(rtype, 0); "</A>]</SMALL><BR>"
        Else
            Print #p, "<SMALL>["; Replace(ActiveURL(rtype, 0), "\", "\\"); "]</SMALL><BR>"
        End If
        Print #p, "<PRE>"
        Print #p, RemStats(rtype, 0)
        Print #p, a; "   Latent-Hist   Latent  Uptime-Hist   Uptime  Options"
        Print #p, String(68, "-")
        For i = 1 To MaxRemailers
            If RemStats(rtype, i) = "" Then Exit For
            Print #p, RemStats(rtype, i);
            If Remailer(Extract(RemStats(rtype, i), " "), rtype, "", "", roptions, "", "", "", "") Then
                Print #p, "  "; GetRopts(roptions, rtype)
            Else
                Print #p,
            End If
        Next i
        Print #p, "</PRE><P>"
        Print #p, "<CENTER><A HREF="; Chr(34); "#Legend"; Chr(34); ">Legend</A> - <A HREF="; Chr(34); "#Top"; Chr(34); ">Back To Top</A></CENTER><P>"
    Next rtype
    Print #p, "<BR><P><A NAME="; Chr(34); "Legend"; Chr(34); "></A><B><U>Legend</U></B><BR><PRE>"
    Print #p, "The stats table shows the 12-day performance history of each remailer."
    Print #p, "Pings (test messages) are sent to each remailer and response time is"
    Print #p, "measured."
    Print #p, ""
    Print #p, "Latent-Hist shows the average default response time for each day:"
    Print #p, "    0   less than 20 minutes"
    Print #p, "    1   less than 1 hour"
    Print #p, "    ..."
    Print #p, "    9   less than 9 hours"
    Print #p, "    A   less than 12 hours"
    Print #p, "    B   less than 18 hours"
    Print #p, "    C   less than 24 hours"
    Print #p, "    ..."
    Print #p, "    G   less than 48 hours"
    Print #p, "    H   more than 48 hours"
    Print #p, "    ?   No responses received / No data"
    Print #p, ""
    Print #p, "Latent shows the average default response time in HH:MM format."
    Print #p, ""
    Print #p, "Uptime-Hist shows the Uptime percentage (responses received divided by"
    Print #p, "pings sent) for each day:"
    Print #p, "    +  100% (Responses were received for all pings sent)"
    Print #p, "    9  90-99.9% (About 9 responses were received for every 10 pings)"
    Print #p, "    ..."
    Print #p, "    1  10-19.9%"
    Print #p, "    0  0-9.9%"
    Print #p, "    ?  No pings sent / No data"
    Print #p, ""
    Print #p, "Uptime shows the average Uptime percentage for 12 days."
    Print #p, ""
    Print #p, "Options shows an abbreviated form of the remailer's capability string:"
    Print #p, "    D       middle (Remailer is middleman and chains to other remailers)"
    Print #p, "    P       post (Supports news posting (Anon-Post-To or Post)"
    Print #p, "    M/R/2   mix/remix/remix2 (Supported Mixmaster features)"
    Print #p, "    H       hybrid (Supports CPunk directives in Mix messages)"
    Print #p, "    G/2     repgp/repgp2"
    Print #p, "    O       pgponly (Requires Cypherpunk messages to be PGP encrypted)"
    Print #p, "    X       ext (Supports extended directive features)"
    Print #p, "    A       max (Supports Max-Size, Max-Count, and Max-Date directives)"
    Print #p, "    T       test (Supports the Test-To directive)"
    Print #p, "    L       latent (Supports the Latent-Time directive)"
    Print #p, "    e/E     ek/ekx (Supports Encrypt-Key/-3DES,-CAST directives)"
    Print #p, "    U       esub (Supports the Encrypt-Subject directive)"
    Print #p, "    I       inflt (Supports the Inflate directive)"
    Print #p, "    N       rhop (Supports the Rand-Hop directive)"
    Print #p, "    #       klen - The digit indicates the maximum message size:"
    Print #p, "                9   Max is greater than 900K "
    Print #p, "                8   Max is less than 900K"
    Print #p, "                ..."
    Print #p, "                1   Max is less than 200K"
    Print #p, "                0   Max is less than 100K"
    Print #p, "</PRE><P><CENTER><A HREF="; Chr(34); "#Top"; Chr(34); ">Back To Top</A></CENTER><P>"
    Print #p, "</BODY></HTML>"
    Close p: p = 0
    KeepDate(3) = SafeTime
    barStat.SimpleText = ""
    WriteData
    WebClient1.Reset
    Erase URLHist: URLHistX = -1
    EnableForm (True)
    UpdateBooks ("Remailers")
    If Me.Visible Then
        tmrLoad.Tag = ProgDir + "\Stats\Stats.htm"
        tmrLoad.Enabled = True
    End If
    If NewCPunk And Not CheckingConfig Then If MsgTime(LMsg(430), 0, LMsg(375), vbYesNo, 2, 60) = 1 Then mnuUpdateKeys_Click (0)
    If NewMix And Not CheckingConfig And Cnf(1, 15) <> "" Then If MsgTime(LMsg(572), 0, LMsg(375), vbYesNo, 2, 60) = 1 Then mnuUpdateKeys_Click (1)
    StatsBusy = False
    Stat "", StatDec
    frmMain!filExplore(0).Refresh
    If frmMain!filExplore(1).Visible Then frmMain!filExplore(1).Refresh
Exit Sub
RefreshError:
    MsgLog LMsg(371) + vbCrLf + "      " + Error, 1, True, True
    CloseFile n
    CloseFile p
    WriteData
    WebClient1.Reset
    Erase URLHist: URLHistX = -1
    EnableForm (True)
    StatsBusy = False
    barStat.SimpleText = ""
    Stat "", StatDec
End Sub

Private Sub EnableForm(state)
    Dim dt As Date
    
    WebClient1.Enabled = state
    For i = 0 To 2
        cmdNext(i).Enabled = state
    Next i
    cboURL.Enabled = state
    lblURL.Enabled = state
    mnuFile.Enabled = state
    mnuOptions.Enabled = state
    mnuTools.Enabled = state
    mnuHelp.Enabled = state
    mnuSoftware.Enabled = state
    If state Then
        Me.MousePointer = 0
    Else
        cboURL.Text = ""
        Me.MousePointer = 11
        If (WebLoading Or WebClient1.state <> 1) Then
            cmdCancel_Click
            dt = SafeTime
            While WebLoading Or (WebClient1.state <> 1 And SafeTime - dt < 5 / 24 / 60 / 60)
                DoEvents
            Wend
        End If
    End If
End Sub

Private Sub cboURL_Click()
    x = cboURL.ListIndex
    If x <> -1 Then
        URL = Bookmarks(x, 1)
        cboURL.ListIndex = -1
        tmrLoad.Tag = URL
        tmrLoad.Enabled = True
    End If
End Sub

Private Sub cboURL_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        tmrLoad.Tag = cboURL.Text
        tmrLoad.Enabled = True
    End If
End Sub

Private Sub cboURL_KeyDown(KeyCode As Integer, Shift As Integer)
    If (KeyCode = vbKeyDown Or KeyCode = vbKeyUp Or KeyCode = vbKeyPageUp Or KeyCode = vbKeyPageDown) And Shift = 0 Then KeyCode = 0
End Sub

Private Sub mnuExit_Click()
    Unload Me
End Sub

Private Sub mnuPrint_Click()
    On Error Resume Next
    If txtFinger.Visible Then
        Printer.Print ""
        Printer.Print txtFinger.Text
    Else
        WebClient1.PrintPage
    End If
End Sub

Private Sub mnuRefresh_Click()
    RefreshStats
End Sub

Private Sub mnuRefreshDisplay_Click()
    WebClient1.Refresh
End Sub

Private Sub mnuReload_Click()
    WebClient1.CacheSize = 0
    LoadList ("CacheSize")
    tmrLoad.Tag = cboURL.Text
    tmrLoad.Enabled = True
End Sub

Private Sub mnuShowStats_Click()
    cmdNext_Click (2)
End Sub

Private Sub mnuStop_Click()
    cmdCancel_Click
End Sub

Private Sub tmrLoad_Timer()
    If StatsBusy Then tmrLoad.Interval = 700: Exit Sub
    tmrLoad.Enabled = False
    tmrLoad.Interval = 50
    If tmrLoad.Tag = ":::Reload:::" Then
        LoadList ("")
        tmrLoad.Tag = ""
    Else
        LoadURL (tmrLoad.Tag)
    End If
End Sub

Private Sub LoadURL(URL)
    Dim dt As Date
    
    If Trim(URL) <> "" Then
        cboURL.Text = URL
        If (WebLoading Or WebClient1.state <> 1) Then
            cmdCancel_Click
            'dt = SafeTime
            'While WebLoading Or (WebClient1.state <> 1 And SafeTime - dt < 5 / 24 / 60 / 60)
            '    DoEvents
            'Wend
        End If
        WebClient1.AutoLoad = mnuAuto(0).Checked
        WebClient1.AutoRedirect = mnuAuto(1).Checked
        fn = GetURL(URL, True, False, ErrMsg)
        If fn = "" And Not WebAbort Then MsgBox LMsg(355) + " " + URL + vbCrLf + ErrMsg, vbCritical, LMsg(4)
        If fn <> "" Then
            cboURL.Text = URL: cboURL.SelStart = Len(cboURL.Text)
        End If
    End If
End Sub

Private Sub cmdCancel_Click()
    If WebClient1.Visible And WebClient1.Enabled Then WebClient1.SetFocus
    WebClient1.Cancel
    WebClient1.Action = 6
    WebAbort = True
    WebClient1.AutoLoad = False
    barStat.Tag = "": barStat.SimpleText = "": Me.MousePointer = 0
End Sub

Private Sub mnuReset_Click()
    WebClient1.Reset
End Sub

Private Sub mnuAuto_Click(Index As Integer)
    mnuAuto(Index).Checked = Not mnuAuto(Index).Checked
    PData(77 + Index) = mnuAuto(Index).Checked
End Sub

Private Sub mnuProxy_Click(Index As Integer)
    mnuProxy(Index).Checked = Not mnuProxy(Index).Checked
    If Index < 2 And mnuProxy(Index).Checked Then mnuProxy(Abs(Index - 1)).Checked = False: mnuReset_Click
    For i = 0 To 2
        PData(79 + i) = mnuProxy(i).Checked
    Next i
    If mnuProxy(0).Checked Or mnuProxy(1).Checked Then lblURL.ForeColor = Red Else lblURL.ForeColor = NotRed
End Sub

Private Sub cmdNext_Click(Index As Integer)
    If WebClient1.Visible Then WebClient1.SetFocus
    If WebLoading Or URLHistX = -1 Then Exit Sub
    
    Select Case Index
    Case 0  'Left
        If URLHistX = MaxHist Then Exit Sub
        URL = URLHist(URLHistX + 1)
        If URL = "" Then Exit Sub
        URLHistX = URLHistX + 1
    Case 1  'Right
        If URLHistX = 0 Then Exit Sub
        URL = URLHist(URLHistX - 1)
        If URL = "" Then Exit Sub
        URLHistX = URLHistX - 1
    Case 2  'Home
        URL = ProgDir + "\Stats\Stats.htm"
    End Select
    tmrLoad.Tag = URL
    tmrLoad.Enabled = True
End Sub

Private Sub mnuFile_Click()
    xt = URLHistX + 10
    xb = URLHistX - 9
End Sub

Private Function GetURL(URL, ByVal Display As Boolean, ByVal Convert As Boolean, ErrMsg)
    Dim a As String
    GetURL = ""
    URL = Trim(URL): If URL = "" Then ErrMsg = LMsg(353): Exit Function
    
    On Error GoTo ErrorGetURL
    'Determine URL Type
Determine:
    If LCase(Left(URL, 5)) = "http:" Then
        'Web
        txtFinger.Visible = False
        URL = Replace(URL, "\", "/")
        a = Mid(URL, 6)
        While Left(a, 1) = "/"
            a = Mid(a, 2)
        Wend
        URL = "http://" + a
        fn = GetWeb(URL, False, Display, ErrMsg)
        If fn = "" Then Exit Function
    Else
        If Mid(URL, 2, 1) = ":" Or SDir(Extract(URL, "#")) <> "" Or SDir(URL) <> "" Then
            'Local File
            txtFinger.Visible = False
            If SDir(Extract(URL, "#")) = "" And SDir(URL) = "" Then ErrMsg = LMsg(66): Exit Function
            If Display Then
                fn = GetWeb(URL, True, True, ErrMsg)
                If fn = "" Then Exit Function
            Else
                fn = URL
            End If
            If Convert Then
                fn2 = GetWork
                fn2 = PlainName(fn2, 0) + PlainName(fn2, 2) + "." + PlainName(fn, 3)
                FileCopy fn, fn2
                fn = fn2
                DelOK = True
            End If
        Else
            If (InStr(URL, "@") <> 0 And InStr(URL, " ") = 0) Or LCase(Left(URL, 7)) = "finger:" Then
                'Finger Address
                If LCase(Left(URL, 7)) = "finger:" Then
                    URL = Mid(URL, 8)
                    While Left(URL, 1) = "/" Or Left(URL, 1) = "\"
                        URL = Mid(URL, 2)
                    Wend
                    URL = Trim(URL)
                End If
                fnf = GetFinger(URL, ErrMsg)
                If fnf = "" Then Exit Function
                If Display Then
                    txtFinger.Text = ""
                    txtFinger.Visible = True
                    txtFinger.ZOrder
                    n = FreeFile
                    Open fnf For Binary As n
                    x = LOF(n): If x > 31000 Then x = 31000
                    a = Input(x, n)
                    Close n: n = 0
                    a = Left(Replace(a, vbLf, vbCrLf), 31000)
                    txtFinger.Text = a
                End If
                AddHist (URL)
                fn = fnf
                DelOK = True
            Else
                'Invalid URL
                If URL Like "*.*" Then URL = "http://" + URL: GoTo Determine
                ErrMsg = LMsg(353)
                Exit Function
            End If
        End If
    End If
    If Convert Then
        fn2 = ConvertEOL(fn, ErrMsg)
        If DelOK Then DelFile fn
        If fn2 = "" Then
            GetURL = ""
        Else
            fn3 = PlainName(fn2, 0) + PlainName(fn2, 2) + "." + PlainName(fn, 3)
            Name fn2 As fn3
            GetURL = fn3
        End If
    Else: GetURL = fn
    End If
Exit Function
ErrorGetURL:
    MsgLog LMsg(542) + vbCrLf + Error, 1, True, True
    CloseFile n
End Function

'
'___________________________________________________________
'WEBCLIENT
Private Function GetWeb(URL, IsLocalFile As Boolean, Display As Boolean, ErrMsg)
    Dim a As String, b As String, dt As Date, ModURL As Boolean
    Dim WorkURL As String
    
    Err.Clear
    On Error GoTo GetWebError

    WebFile = "": ErrMsg = "": WebAbort = False
    WebErrorString = "": WebErrorCode = 0
    WebTempResource = "": WebResource = ""

    If IsLocalFile Then
        If Display Then
            'WebClient1.Cancel
            WebClient1.RemoteFile = ""
            WebClient1.RemoteAccess = False
            WebClient1.IsLocal = True
            WebClient1.LocalFile = ""
            WebLocalURL = URL
            If WebClient1.Load(URL) <> 0 Then GoTo GetWebError2
        End If
        GetWeb = URL
        barStat.SimpleText = "": barStat.Tag = ""
        Exit Function
    Else
        If Not RASConnected Then ErrMsg = LMsg(294): GetWeb = "": Exit Function
        'Proxy
        If (cboURL.Enabled And (mnuProxy(0).Checked Or mnuProxy(1).Checked)) Or (Not cboURL.Enabled And mnuProxy(2).Checked) Then
            If mnuProxy(1).Checked Then a = Cnf(3, 14) Else a = Cnf(3, 13)
            u = ParseURL(a, hname, port)
            If u = "" Then
                'Invalid Proxy
                ErrMsg = LMsg(364): GetWeb = "": Exit Function
            Else
                WebClient1.ProxyHost = hname
                WebClient1.ProxyPort = port
                WebClient1.IsProxy = True
            End If
        Else
            WebClient1.IsProxy = False
        End If
        'Remote Access
        WebLocalURL = ""
        WebClient1.IsLocal = False
        WebClient1.RemoteAccess = True
        'Check Host Name
        u = ParseURL(URL, hname, port)
        WebClient1.RemotePort = port
        'WebClient1.Blocking = True  '[Unneeded]
        If Not WebClient1.IsProxy Then
            WebClient1.HostName = hname
            If WebClient1.HostAddress = "" Then ErrMsg = LMsg(356): GetWeb = "": Exit Function
        End If
        WebCancel = 0  'If Display Then WebCancel = 0 Else WebCancel = 1  '[Causes IsLoading Hang]
        
        WebLoading = True
        For Try = 1 To 2
            'Modify URL
            If Try = 1 Then
                If InStr(8, u, "/") = 0 Then WorkURL = u + "/" Else WorkURL = u
            Else
                If Right(u, 1) = "/" Or InStr(8, u, "/") = 0 Then Exit For
                w = WorkURL
                If Right(WorkURL, 1) <> "/" Then
                    x = 0
                    Do
                        y = x
                        x = InStr(y + 1, u, "/")
                    Loop Until x = 0
                    a = Mid(u, y + 1)
                    If Not a Like ("*.*") Then WorkURL = u + "/"
                Else
                    WorkURL = u
                End If
                If u = w Then Exit For
            End If
            
            WebClient1.Blocking = False
            WebErrorString = "": WebErrorCode = 0
            WebResource = "": WebFile = ""
            WebTempResource = ""
            WebConnected = False
            If WebClient1.Load(WorkURL) <> 0 Or WebErrorCode <> 0 Then GoTo GetWebError2
            'Wait for connect
            DoEvents 'Allows IsCached to be set properly
            dt = SafeTime
            While Not WebConnected And Not WebClient1.IsCached And Not WebAbort
                DoEvents
                If (SafeTime - dt) > 60 / 24 / 60 / 60 Then GoTo GetWebError2
            Wend
            
            If Not WebConnected Then
                'Cached Resource
                WebFile = WebClient1.CacheFile
                WebLoading = False
                barStat.SimpleText = ""
                Exit For
            Else
                'Connected
                dt = SafeTime
                While WebConnected And Not WebAbort
                    DoEvents
                    If (SafeTime - dt) > 60 / 24 / 60 / 60 Then GoTo GetWebError2
                Wend
                'Disconnected
                'Wait for Preview event to fire
                dt = SafeTime
                While (WebClient1.state <> 1 Or WebClient1.IsLoading) And (SafeTime - dt) < 5 / 24 / 60 / 60 And Not WebAbort
                    DoEvents
                Wend
                'Done Loading
            End If
            If WebFile <> "" Then Exit For
        Next Try
    End If
    If WebAbort Then WebFile = ""
    If WebFile <> "" And SDir(WebFile) <> "" Then
        GetWeb = WebFile
        If WebResource <> "" Then URL = WebResource Else URL = WorkURL
    Else
        GetWeb = ""
        ErrMsg = LMsg(354)
    End If
    WebClient1.Blocking = False
    WebLoading = False
Exit Function
GetWebError:
    Resume GetWebError2
GetWebError2:
    Webconnecting = False
    WebLoading = False
    barProgress.Visible = False
    If WebErrorString <> "" Then
        ErrMsg = WebErrorString
    Else
        If Err.Description <> "" Then ErrMsg = Err.Description Else ErrMsg = LMsg(354)
    End If
    On Error Resume Next
    WebClient1.Blocking = False
    WebClient1.Cancel
    WebClient1.Reset
    GetWeb = ""
End Function

Private Function ParseURL(URL, hname, port) As String
    port = 0: hname = ""
    a = Trim(Replace(URL, "\", "/"))
    If LCase(Left(a, 7)) = "http://" And Len(a) > 7 Then
        a = Mid(a, 8)
        x = InStr(a, "/"): If x = 0 Then x = Len(a) + 1
        hn = Left(a, x - 1)
        y = InStr(hn, ":")
        If y <> 0 Then
            pt = Mid(hn, y + 1)
            hn = Left(hn, y - 1)
            port = Val(pt)
        End If
        hname = hn
        ParseURL = "http://" + hn + Mid(a, x)
    Else
        ParseURL = ""
    End If
End Function

Private Sub WebClient1_Click()
    If WebClient1.ActiveLink <> 0 Then
        WebAbort = False
        cboURL.Text = CurrentLink
        AddHist (cboURL.Text)
    End If
End Sub

Private Sub WebClient1_Connect()
    'Connect event generated when connection is established with an HTTP server
    'This occurs for each URL in a web page, not just the initial resource
    WebConnected = True
    barProgress.Value = 0
    barProgress.Visible = True
End Sub

Private Sub WebClient1_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If cboURL.Enabled Then
        If WebClient1.state = 1 Or WebAbort Then
            WebClient1.MousePointer = 0
            barStat.Tag = ""
        Else
            WebClient1.MousePointer = 11
        End If
    End If
    On Error Resume Next
    If WebClient1.ActiveLink <> 0 And URLHistX <> -1 Then
        barStat.SimpleText = CurrentLink
    Else
        barStat.SimpleText = barStat.Tag
    End If
End Sub

Private Function CurrentLink() As String
    If WebClient1.ActiveLink = 0 Then CurrentLink = "": Exit Function
    l = WebClient1.Link(WebClient1.ActiveLink)
    If Left(l, 5) <> "http:" And Left(l, 4) <> "ftp:" And Left(l, 5) <> "news:" And Left(l, 7) <> "telnet:" And Left(l, 7) <> "gopher:" Then
        a = URLHist(URLHistX)
        If Left(l, 1) = "#" Then
            l = Extract(a, "#") + l
        Else
            If InStr(a, "\") <> 0 Then c = "\" Else c = "/"
            If c = "\" Then l = Replace(l, "/", "\")
            Do
                z = t
                t = InStr(z + 1, a, c)
            Loop Until t = 0
            If z <> 0 Then b = Left(a, z - 1)
            If b = "" Then b = ".."
            If Left(l, 3) = "../" Then l = b + c + Mid(l, 4) Else l = b + c + l
        End If
    End If
    CurrentLink = l
End Function

Private Sub WebClient1_Progress(ContentRead As Long, ContentLength As Long, Percent As Integer)
    'Progress event is generated periodically during the transfer of a web resource
    'This is generated for any type file (HTML, image or audio)

    If ContentLength > 0 Then
        If ContentLength <> barProgress.Max Then barProgress.Max = ContentLength
        If ContentRead <= barProgress.Max Then barProgress.Value = ContentRead
    End If
End Sub

Private Sub WebClient1_Disconnect()
    'Disconnect event generated when we are done with a specific host
    'This happens after we have retrieved the requested resource
    'Debug.Print "Disconnected from " & WebClient1.HostName
    WebConnected = False
    barStat.Tag = ""
    barStat.SimpleText = ""
    WebClient1_MouseMove 0, 0, 0, 0
    barProgress.Visible = False
End Sub

Private Sub WebClient1_QueryLoad(Resource As String, Cancel As Integer)
    'QueryLoad event is generated prior to retrieval from the server.
    'This is a good place to validate the URL and possibly Cancel the request.
    'Here we are handling URL's not normally handled by the web browser control
    'such as mailto: for e-mailing hyperlinks and ftp: for file transfers.
    'Debug.Print "QueryLoad: "; Resource
    
        
    If WebAbort Then
        Cancel = 1
    Else
        If Not WebClient1.IsLocal Then barStat.SimpleText = LMsg(372) + " " + Resource + "...": barStat.Tag = barStat.SimpleText
    End If
    If WebLocalURL <> "" Then Resource = WebLocalURL: WebLocalURL = ""
    WebTempResource = Resource
    If Left(WebTempResource, 8) = "file:///" Then
        WebTempResource = Replace(Mid(WebTempResource, 9), "/", "\")
        While Left(WebTempResource, 1) = "\"
            WebTempResource = Mid(WebTempResource, 2)
        Wend
    End If
End Sub

Private Sub WebClient1_Preview(Filename As String, ContentType As Integer, Cancel As Integer)
    Dim Tmp(MaxHist) As String
    'Preview event is generated after the web resource is retrieved from the
    'server, but before it is rendered. This is a good place to check the
    'contents of the HTML source for unwanted material or other massaging.

    If (ContentType = 1 Or ContentType = 2) And WebTempResource <> "" Then   'HTML or Text
        AddHist (WebTempResource)
    End If
    If WebFile = "" Then WebFile = Filename: WebResource = WebTempResource
    Cancel = WebCancel  '[Causes IsLoading hang?]
    If WebAbort Then Cancel = 1
End Sub

Private Sub AddHist(Resource)
    Dim Tmp(MaxHist) As String
    
    If URLHistX = -1 Then
        URLHist(0) = Resource
        URLHistX = 0
    Else
        If Resource <> URLHist(URLHistX) Then
            Tmp(0) = Resource
            For i = URLHistX To MaxHist
                x = x + 1
                If x > MaxHist Then Exit For
                Tmp(x) = URLHist(i)
            Next i
            Erase URLHist
            For i = 0 To MaxHist
                URLHist(i) = Tmp(i)
            Next i
            URLHistX = 0
        End If
    End If
End Sub

Private Sub WebClient1_Execute(Filename As String, Executable As String)
    'Execute event is generated when a web resource is unable to be viewed
    'by the web browser control. The event passes the name of an Executable
    'if the Filename's extension has been registered.
    '!!!This event never seems to fire
End Sub

Private Sub WebClient1_LastError(ErrorCode As Integer, ErrorString As String, Response As Integer)
    'Web control's error handler
    '!!!This event never seems to fire

    WebErrorCode = ErrorCode
    WebErrorString = ErrorString
    'Debug.Print WebErrorCode, WebErrorString
End Sub


'
'_________________________________________________________
'FINGER CLIENT
Private Function GetFinger(ByVal fuser As String, ErrMsg) As String
    Dim Buffer As String, rhost As String
        
    On Error GoTo ErrorFinger
        
    If Not RASConnected Then ErrMsg = LMsg(294): GetFinger = "": Exit Function
    Me.MousePointer = 13
    Do
        y% = InStr(y% + 1, fuser, "@")
        If y% <> 0 Then x% = y%
    Loop Until y% = 0
    If x% <> 0 Then
        FingerUser = Left(fuser, x% - 1) + vbCrLf
        rhost = Mid$(fuser, x% + 1)
    Else
        FingerUser = ""
        rhost = fuser
    End If
        
    FingerText = ""
        
    frmMain!Socket1.AddressFamily = 2 'AF_INET
    frmMain!Socket1.Binary = False
    frmMain!Socket1.Blocking = False
    frmMain!Socket1.BufferSize = 1024
    frmMain!Socket1.LocalPort = 0 'IPPORT_ANY
    frmMain!Socket1.Protocol = 0 'IPPROTO_IP
    frmMain!Socket1.SocketType = 1 'SOCK_STREAM
    frmMain!Socket1.RemotePort = 79 'IPPORT_FINGER
    
    frmMain!Socket1.HostName = rhost
    
    barStat.SimpleText = LMsg(372) + " " + fuser + "...": barStat.Tag = barStat.SimpleText
    If frmMain!Socket1.Connect <> 0 Then GoTo ErrorFinger2
    frmMain!Socket1.Interval = 20000 'Set connection timeout here
    FingerConnecting = True
    dt = SafeTime
    Do While FingerConnecting And Not WebAbort
        DoEvents
        If (SafeTime - dt) > 90 / 24 / 60 / 60 Then GoTo ErrorFinger2
    Loop
    frmMain!Socket1.Disconnect
    FingerConnecting = False
    If FingerText <> "" And Not WebAbort Then
        fn = GetWork(Cnf(3, 19))
        fn = PlainName(fn, 0) + PlainName(fn, 2) + ".txt"
        n = FreeFile
        Open fn For Output As n
        Print #n, FingerText
        Close n: n = 0
        GetFinger = fn
    Else
        GetFinger = ""
        ErrMsg = LMsg(357)
    End If
    barStat.SimpleText = "": barStat.Tag = ""
    Me.MousePointer = 0
Exit Function
ErrorFinger:
    ErrDesc = Err.Description
    Resume ErrorFinger2
ErrorFinger2:
    If ErrDesc <> "" Then ErrMsg = ErrDesc Else ErrMsg = LMsg(357)
    barStat.SimpleText = "": barStat.Tag = ""
    GetFinger = ""
    On Error Resume Next
    CloseFile n
    frmMain!Socket1.Disconnect
    Me.MousePointer = 0
End Function

Private Sub Form_KeyPress(KeyAscii As Integer)
    If KeyAscii = 27 Then cmdCancel_Click  'Esc
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    Select Case Shift
    Case 0
        Select Case KeyCode
        Case vbKeyF1: mnuHelpSub_Click (0): KeyCode = 0
        Case vbKeyF7: ShowConfig (ConfigStats): KeyCode = 0
        End Select
    Case 1  'Shift
    Case 2  'Ctrl
        Select Case KeyCode
        Case vbKeyE: RefreshStats: KeyCode = 0
        Case vbKeyF: mnuFinger_Click: KeyCode = 0
        Case vbKeyI: mnuAuto_Click (0): KeyCode = 0
        Case vbKeyP: mnuPrint_Click: KeyCode = 0
        Case vbKeyR: mnuReload_Click: KeyCode = 0
        Case vbKeyT: mnuShowStats_Click: KeyCode = 0
        End Select
    Case 3  'Ctrl-Shift
    Case 4  'Alt
        Select Case KeyCode
        Case vbKeyBack, vbKeyLeft: cmdNext_Click (0): KeyCode = 0
        Case vbKeyRight: cmdNext_Click (1): KeyCode = 0
        Case vbKeyDown: cmdNext_Click (2): KeyCode = 0
        End Select
    End Select
End Sub

Private Sub mnuHelpSub_Click(Index As Integer)
    ShowHelp Index, "#Stats", "2"
End Sub

Private Sub mnuConfig_Click(Index As Integer)
    ShowConfig (Index)
End Sub

Private Sub mnuWindow_Click(Index As Integer)
    ShowWindow (Index)
End Sub

Private Sub Form_Resize()
    Dim sh As Long, sw As Long
    
    If Me.WindowState <> 1 Then
        If Me.Width < 2712 Then Me.Width = 2712
        If Me.Height < 1908 Then Me.Height = 1908
        sw = Me.ScaleWidth
        sh = Me.ScaleHeight
        WebClient1.Width = sw - 144
        WebClient1.Height = sh - 768
        txtFinger.Width = WebClient1.Width
        txtFinger.Height = WebClient1.Height
        cboURL.Top = sh - 600
        For i = 0 To 2
            cmdNext(i).Top = sh - 600
        Next i
        cmdCancel.Top = sh - 600
        lblURL.Top = sh - 540
        cboURL.Width = sw - 2124
        cmdNext(0).Left = sw - 1536
        cmdNext(2).Left = sw - 1176
        cmdNext(1).Left = sw - 816
        cmdCancel.Left = sw - 456
        barProgress.Top = sh - 220
        barProgress.Left = sw - 1536
    End If
End Sub

Private Sub LoadList(Job)
    'Bookmarks
    temp = cboURL.Text
    cboURL.Clear
    For i = 0 To MaxBookmarks
        If Bookmarks(i, 0) = "" Then Exit For
        cboURL.AddItem Bookmarks(i, 0)
    Next i
    cboURL.Text = temp
    'Colors
    WebClient1.ForeColor = Val(Cnf(3, 7))
    WebClient1.BackColor = Val(Cnf(3, 8))
    WebClient1.LinkColor = Val(Cnf(3, 9))
    If Right(Cnf(3, 19), 1) = ":" Then WebClient1.CacheDir = Cnf(3, 19) + "\" Else WebClient1.CacheDir = Cnf(3, 19)
    If Job = "CacheSize" Or Job = "" Then
        Select Case Val(Cnf(3, 10))
        Case 0: x = 1
        Case 1: x = 8
        Case 2: x = 16
        Case 3: x = 32
        Case 4: x = 64
        Case Else: x = 1
        End Select
        WebClient1.CacheSize = x
    End If

    If Job = "Fonts" Or Job = "" Then
        On Error Resume Next
        cboURL.FontSize = SVal(Cnf(0, 5)) + 8
        txtFinger.FontSize = SVal(Cnf(0, 5)) + 8
        On Error GoTo 0
    End If
End Sub

Private Sub DoBrowserJob()
    If BrowserJob <> "" Then
        a = BrowserJob
        BrowserJob = ""
        Select Case a
        Case ":::RefreshStats:::"
            RefreshStats
        Case ":::UpdateCPunkKeys:::"
            mnuUpdateKeys_Click (0)
        Case ":::UpdateMixKeys:::"
            mnuUpdateKeys_Click (1)
        Case ":::UpdateBothKeys:::"
            mnuUpdateKeys_Click (0)
            mnuUpdateKeys_Click (1)
        End Select
    End If
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    barStat.SimpleText = barStat.Tag
End Sub

Private Sub Form_Activate()
    If BrowserJob <> "" Then
        DoBrowserJob
    End If
End Sub

Private Sub Form_Load()
    BrowserLoaded = True
    StatsBusy = True
    'Window Position and Size
    Me.Left = Val(PData(87))
    Me.Top = Val(PData(88))
    If Val(PData(89)) <> 0 And Val(PData(90)) <> 0 Then
        Me.Width = Val(PData(89))
        Me.Height = Val(PData(90))
    End If
    If Val(PData(91)) <> 1 Then Me.WindowState = Val(PData(91))
    
    WebClient1.Private = True
    mnuAuto(0).Checked = PData(77) <> False2
    mnuAuto(1).Checked = PData(78) <> False2
    For i = 0 To 2
         mnuProxy(i).Checked = PData(79 + i) = True2
    Next i
    If mnuProxy(0).Checked Or mnuProxy(1).Checked Then lblURL.ForeColor = Red Else lblURL.ForeColor = NotRed
    LoadList ("")
    If BrowserJob <> "" Then DoBrowserJob
    StatsBusy = False
End Sub

Private Sub Form_Unload(Cancel As Integer)
    WebLoading = False
    BrowserLoaded = False
    If SDir(Cnf(3, 19) + "\*.*") <> "" And Cnf(3, 19) <> "" Then DelFile Cnf(3, 19) + "\*.*"
    frmWeb.Tag = ""
    BrowserJob = ""
    If Me.WindowState = 0 Then
        PData(87) = Str(Me.Left)
        PData(88) = Str(Me.Top)
        PData(89) = Str(Me.Width)
        PData(90) = Str(Me.Height)
    End If
    PData(91) = Str(Me.WindowState)
End Sub


