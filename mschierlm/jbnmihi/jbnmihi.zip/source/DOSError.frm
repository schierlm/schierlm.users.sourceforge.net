VERSION 5.00
Begin VB.Form frmDOSError 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "DOS Error"
   ClientHeight    =   1650
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   7845
   Icon            =   "DOSError.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1650
   ScaleWidth      =   7845
   Visible         =   0   'False
   Begin VB.CheckBox chkDetails 
      Caption         =   "Show Details"
      Height          =   372
      Left            =   4260
      Style           =   1  'Grafisch
      TabIndex        =   3
      Top             =   1080
      Width           =   1812
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Left            =   1680
      TabIndex        =   1
      Top             =   1080
      Width           =   1812
   End
   Begin VB.TextBox txtDetails 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3972
      Left            =   120
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertikal
      TabIndex        =   2
      Top             =   840
      Visible         =   0   'False
      Width           =   7572
   End
   Begin VB.Label lblMsg 
      Caption         =   "Function could not complete due to an unsuccessful DOS command."
      Height          =   612
      Left            =   480
      TabIndex        =   0
      Top             =   180
      Width           =   6852
   End
End
Attribute VB_Name = "frmDOSError"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Sub chkDetails_Click()
    Dim a As String, ln As Long, n As Integer
    
    If chkDetails.Value = 0 Then
        txtDetails.Visible = False
        Me.Height = 1992
        cmdOK.Top = 1080
        chkDetails.Top = 1080
    Else
        Me.Height = 5736
        cmdOK.Top = 4920
        chkDetails.Top = 4920
        txtDetails.Visible = True
        If Me.Tag <> "" Then
            If SDir(Me.Tag) <> "" Then
                On Error GoTo DetailsError
                n = FreeFile
                Open Me.Tag For Input As n
                ln = LOF(n)
                If ln > 31000 Then ln = 31000
                a = Input(ln, n)
                Close n: n = 0
                txtDetails.Text = Replace(a, Chr(7), "")
            End If
        End If
    End If
Exit Sub
DetailsError:
    CloseFile n
End Sub

Private Sub cmdOK_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    Me.Top = (Screen.Height - 5736) / 2
    Me.Left = (Screen.Width - Me.Width) / 2
End Sub
