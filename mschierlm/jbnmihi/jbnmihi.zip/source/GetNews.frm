VERSION 5.00
Object = "{B7FC3564-8CE7-11CF-9754-00AA00C00908}#1.0#0"; "NNTPCT.OCX"
Begin VB.Form frmGetNews 
   BorderStyle     =   0  'Kein
   Caption         =   "GetNews"
   ClientHeight    =   2490
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3750
   LinkTopic       =   "Form1"
   ScaleHeight     =   2490
   ScaleWidth      =   3750
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows-Standard
   Visible         =   0   'False
   Begin NNTPCTLib.NNTP NNTP1 
      Left            =   120
      Top             =   180
      _ExtentX        =   582
      _ExtentY        =   582
      Blocking        =   0   'False
      SleepTime       =   10
      RemoteHost      =   "news"
      RemotePort      =   119
      ConnectTimeout  =   0
      RecvTimeout     =   0
      NotificationMode=   1
      LastUpdate      =   932853942
   End
End
Attribute VB_Name = "frmGetNews"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

'NNTP
'This form requires Project|References|Netmanage Internet Support Objects (distributed with Netmaster's FASTNET controls)
Dim NNTPEvent As Byte, NNTPErrorString As String, NNTPErrorCode As Long
    Const NNTPEventGroupSelected = 1
    Const NNTPEventGotDoc = 2
    Const NNTPEventError = 3
    Const NNTPEventTimeout = 4
    Const NNTPEventAuthenticationFailed = 5
Dim NNTPUser As String, NNTPPass As String
Dim NNTPFirstArticle As Long, NNTPLastArticle As Long

Private Sub GetNews()
    Dim Groups(200) As String, a As String
    Dim Art() As String, ArtX() As Long
    Dim SearchHeader(200) As String
    Dim XPostDate As Date, XPostFile As String, GoodXPost As Boolean
    Dim EncSubject As String * 256, TestSubject As String * 256
    Dim SubjectKey As String * 256, ESUBSupport As Boolean
    
    XPostFile = Cnf(4, 0) + "\JBN2NEWS"
    'Test for ESUB support
    On Error Resume Next
    EncSubject = Chr(0)
    psEsub32DLLVersion (EncSubject)
    ESUBSupport = Not (Left(EncSubject, 1) = Chr(0))
    
    On Error GoTo GetNewsError
    For Prof = 31 To 45
        AbortRetrieve = False: CancelRetrieve = False
        If Val(UserProf(Prof, 0)) = 1 And ((Val(UserProf(Prof, 1)) = 1 And SafeTime - KeepDate(Prof + 4) > SVal(UserProf(Prof, 9)) / 24 / 60) Or CheckNewsAll) Then
            minartlines = SVal(UserProf(Prof, 14))
            maxartlines = SVal(UserProf(Prof, 15))
            If Trim(UserProf(Prof, 15)) = "" Then maxartlines = 10000000
            rtcount = 0: svcount = 0
            'Check for valid folder, etc
            If UserProf(Prof, 3) <> False2 Then
                'Folder
                MailFolder = UserProf(Prof, 10)
            Else
                'File
                MailFolder = PlainName(UserProf(Prof, 10), 0)
            End If
            If MailFolder = "" Then MailFolder = Cnf(4, 0) + "\Inbox"
            If Not CreateDir(MailFolder) Then
                MsgLog LMsg(58) + " " + LMsg(306) + " " + UserProf(Prof, 5) + ": " + LMsg(450) + " " + MailFolder, 2, True, True
                KeepDate(Prof + 4) = SafeTime
                GoTo NextProf
            End If

            'Dial
            If Not RASConnected And PData(54) = True2 Then DialRAS (True)
            If Not RASConnected Then Exit For
            'Connect to NNTP Server
            frmMain.MousePointer = 13
            Stat LMsg(287) + " " + UserProf(Prof, 5) + " [" + UserProf(Prof, 6) + "]...", StatDec
            NNTPErrorString = ""
            NNTPEvent = 0
            AbortRetrieve = False
            On Error GoTo NNTPError
            NNTPUser = UserProf(Prof, 7)
            NNTPPass = UserProf(Prof, 8)
            If NNTP1.state <> 6 Then NNTP1.Quit: DoEvents
            'Port
            If InStr(UserProf(Prof, 6), ":") <> 0 Then
                rport = SVal(Mid(UserProf(Prof, 6), InStr(UserProf(Prof, 6), ":") + 1))
                If rport = 0 Then rport = 119
            Else
                rport = 119
            End If
            NNTP1.RemotePort = rport
            NNTP1.Connect Extract(UserProf(Prof, 6), ":")
            
            dt = SafeTime
            While (NNTP1.state <> prcConnected Or NNTP1.Busy) And NNTPEvent = 0 And SafeTime - dt < 3 / 24 / 60 And Not AbortRetrieve
                DoEvents
            Wend
            If NNTP1.state <> prcConnected Or NNTPEvent <> 0 Or AbortRetrieve Then
                'Connection failed
                On Error Resume Next
                NNTP1.Quit
                On Error GoTo GetNewsError
                If NNTPEvent = NNTPAuthenticationFailed Then NNTPErrorString = LMsg(457)
                Msg = LMsg(290) + " " + UserProf(Prof, 5) + " [" + UserProf(Prof, 6) + "]"
                If NNTPErrorString <> "" Then Msg = Msg + vbCrLf + "      " + NNTPErrorString
                If Not AbortRetrieve Then MsgLog Msg, 2, True, True
            Else
                'Connected
                'Get Newsgroup list
                maxgrp = ParseString(UserProf(Prof, 11), Groups(), 200, False)
                cleangrpart = "": cleangrpcount = 0
                'Debug.Print "Pre:  "; PData(123 + Prof - 31)
                For grp = 0 To maxgrp
                    'Select Group
                    On Error GoTo NNTPError
                    NNTPEvent = 0
                    AbortRetrieve = False
                    Call NNTP1.SelectGroup(Trim(Groups(grp)))
                    While NNTPEvent = 0 And Not AbortRetrieve
                        DoEvents
                    Wend
                    On Error GoTo GetNewsError
                    If NNTPEvent = NNTPEventGroupSelected And Not AbortRetrieve Then
                        'Good group
                        'Check for previous article number
                        grpart = ":" + Trim(UserProf(Prof, 6)) + "," + Trim(Groups(grp)) + ","
                        y = InStr(1, PData(123 + Prof - 31), grpart, vbTextCompare)
                        If y <> 0 Then
                            NextArticle = SVal(Mid(PData(123 + Prof - 31), y + Len(grpart))) + 1
                            If NextArticle < NNTPFirstArticle Then NextArticle = NNTPFirstArticle
                        Else
                            NextArticle = NNTPFirstArticle
                        End If
                        If NextArticle <= NNTPLastArticle Then
                            'Get Headers
                            ReDim Art(NNTPLastArticle - NextArticle, 2)
                            ReDim ArtX(NNTPLastArticle - NextArticle, 1)
                            Stat UserProf(Prof, 5) + ": " + LMsg(462) + " " + Groups(grp), StatDec
                            For hx = 0 To 3
                                Needed = True
                                Select Case hx
                                Case 0: h = "Subject"
                                Case 1
                                    h = "From"
                                    Needed = InStr(1, UserProf(Prof, 12), "From:", vbTextCompare) + InStr(1, UserProf(Prof, 13), "From:", vbTextCompare) <> 0
                                Case 2
                                    h = "Message-ID"
                                    Needed = Val(Cnf(4, 18)) = 1
                                Case 3: h = "Lines"
                                End Select
                                If Needed Then
                                    hfile = GetWork(PData(10))
                                    NNTPEvent = 0
                                    On Error GoTo NNTPError
                                    NNTP1.DocOutput.Filename = hfile
                                    NNTP1.DocOutput.AppendToFile = False
                                    AbortRetrieve = False
                                    Call NNTP1.GetArticleHeaders(h, Trim(Str(NextArticle)), Trim(Str(NNTPLastArticle)))
                                    While NNTPEvent = 0 And Not AbortRetrieve
                                        DoEvents
                                    Wend
                                    On Error GoTo GetNewsError
                                    If NNTPEvent <> NNTPEventGotDoc Or SDir(hfile) = "" Or AbortRetrieve Then
                                        'Failure
                                        DelFile hfile
                                        If Not AbortRetrieve Then MsgLog LMsg(459) + " " + UserProf(Prof, 5), 3, True, True
                                        GoTo DisconnectNews
                                    Else
                                        'Read Headers file
                                        n = FreeFile
                                        Open hfile For Input As n
                                        While Not EOF(n)
                                            Line Input #n, a
                                            artnum = Val(Left(a, InStr(a, " ")))
                                            If artnum >= NextArticle And artnum <= NNTPLastArticle Then
                                                x = InStr(a, " "): If x = 0 Then x = Len(a)
                                                If hx = 3 Then
                                                    ArtX(artnum - NextArticle, 1) = Val(Mid(a, x + 1))
                                                Else
                                                    Art(artnum - NextArticle, hx) = Mid(a, x + 1)
                                                End If
                                            End If
                                        Wend
                                        Close n: n = 0
                                        DelFile hfile
                                    End If
                                
                                End If
                            Next hx
                            'Determine articles to download
                            'Filter Subject; From; Lines
                            Stat UserProf(Prof, 5) + ": " + LMsg(463) + " " + Groups(grp), StatDec
                            For k = 0 To 1
                                maxheader = ParseString(UserProf(Prof, 12 + k), SearchHeader(), 200, False)
                                For i = 0 To maxheader
                                    sh = LCase(LTrim(SearchHeader(i)))
                                    If Left(sh, 5) = "from:" Then
                                        hx = 1
                                        sh = LTrim(Mid(sh, 6))
                                    ElseIf Left(sh, 5) = "esub:" Then
                                        hx = -1
                                        sh = LTrim(Mid(LTrim(SearchHeader(i)), 6))
                                    Else
                                        If Left(sh, 8) = "subject:" Then sh = LTrim(Mid(sh, 9))
                                        hx = 0
                                    End If
                                    For j = 0 To NNTPLastArticle - NextArticle
                                        If ArtX(j, 1) >= minartlines And ArtX(j, 1) <= maxartlines And Art(j, 0) <> "" And (k = 0 Or ArtX(j, 0) = 1) Then
                                            If hx = -1 Then
                                                'Test Encrypted Subject
                                                x = InStr(sh, "%")
                                                If x <> 0 And ESUBSupport And Len(Trim(Art(j, 0))) = 48 Then
                                                    EncSubject = Left(Trim(Art(j, 0)), 255) + Chr(0)
                                                    TestSubject = Left(Trim(Left(sh, x - 1)), 255) + Chr(0)
                                                    SubjectKey = Left(Trim(Mid(sh, x + 1)), 255) + Chr(0)
                                                    If psTestSubject(EncSubject, TestSubject, SubjectKey) = 0 Then ArtX(j, 0) = Abs(k - 1)
                                                End If
                                            Else
                                                'Test From/Subject
                                                If LCase(Art(j, hx)) Like sh Then ArtX(j, 0) = Abs(k - 1)
                                            End If
                                        End If
                                    Next j
                                Next i
                            Next k
                            'Filter Duplicates  - Message-ID
                            If Val(Cnf(4, 18)) = 1 And SDir(XPostFile + ".IDX") <> "" Then
                                n2 = 0
                                n = FreeFile
                                Open XPostFile + ".IDX" For Input As n
                                If SafeTime - KeepDate(18) > 1 Then
                                    'Clean XPost Daily
                                    n2 = FreeFile
                                    Open XPostFile + ".TMP" For Output As n2
                                    Print #n2, "---"
                                End If
                                If Not EOF(n) Then Line Input #n, a
                                While Not EOF(n)
                                    XPostDate = 0
                                    On Error Resume Next
                                    Input #n, XPostDate
                                    On Error GoTo GetNewsError
                                    GoodXPost = SafeTime - XPostDate < 7
                                    If GoodXPost And n2 <> 0 Then Write #n2, XPostDate
                                    a = "X"
                                    Do While Not EOF(n)
                                        Line Input #n, a
                                        If GoodXPost And n2 <> 0 Then Print #n2, a
                                        If a <> "---" Then
                                            If GoodXPost Then
                                                For i = 0 To NNTPLastArticle - NextArticle
                                                    If ArtX(i, 0) = 1 Then
                                                        If Art(i, 2) = a Then ArtX(i, 0) = 0
                                                    End If
                                                Next i
                                            End If
                                        Else
                                            Exit Do
                                        End If
                                    Loop
                                Wend
                                Close n: n = 0
                                If n2 <> 0 Then
                                    Close n2: n2 = 0
                                    If DelFile(XPostFile + ".IDX") Then Name XPostFile + ".TMP" As XPostFile + ".IDX": KeepDate(18) = SafeTime
                                End If
                                DoEvents
                            End If
                            'Count articles to save
                            artcount = 0: allrtcount = 0
                            For i = 0 To NNTPLastArticle - NextArticle
                                artcount = artcount + ArtX(i, 0)
                                If ArtX(i, 1) >= minartlines And ArtX(i, 1) <= maxartlines Then If Art(i, 0) <> "" Then allrtcount = allrtcount + 1
                            Next i
                            If Val(UserProf(Prof, 2)) = 1 Then dispcount = allrtcount Else dispcount = artcount
                            gtcount = 0
                            If dispcount <> 0 Then
                                frmMain!barProgress.Max = dispcount
                                frmMain!barProgress.Value = 0
                                frmMain!barProgress.Visible = True
                            End If
                            'Retrieve Articles
                            If Val(Cnf(4, 18)) = 1 And (Val(UserProf(Prof, 2)) = 1 Or artcount <> 0) Then
                                'Filter Duplicates
                                nxpost = FreeFile
                                Open XPostFile + ".IDX" For Append As nxpost
                                AllMsgID = ""
                            Else
                                nxpost = 0
                            End If
                            For i = 0 To NNTPLastArticle - NextArticle
                                If (Val(UserProf(Prof, 2)) = 1 And ArtX(i, 1) >= minartlines And ArtX(i, 1) <= maxartlines And Art(i, 0) <> "") Or ArtX(i, 0) = 1 Then
                                    'Retrieve
TryGetArticle:                      Stat UserProf(Prof, 5) + ": " + LMsg(463) + Str(gtcount + 1) + " " + LMsg(297) + Str(dispcount) + " [" + Trim(Str(artcount)) + "] " + LMsg(464) + " " + Groups(grp), StatDec
                                    If ArtX(i, 0) = 1 Then
                                        'Save
                                        NNTP1.DocOutput.AppendToFile = False
                                        TempMailFile = GetWork(PData(10))
                                        NNTP1.DocOutput.Filename = TempMailFile
                                    Else
                                        'No Save
                                        NNTP1.DocOutput.Filename = ""
                                    End If
                                    NNTPErrorString = ""
                                    NNTPEvent = 0
                                    On Error GoTo NNTPError
                                    Call NNTP1.GetArticleByArticleNumber(Trim(Str(i + NextArticle)))
                                    While NNTPEvent = 0 And Not AbortRetrieve
                                        DoEvents
                                    Wend
                                    On Error GoTo GetNewsError
                                    If NNTPEvent = NNTPEventGotDoc And NNTPErrorString = "" And Not AbortRetrieve Then
                                        rtcount = rtcount + 1
                                        If ArtX(i, 0) = 1 Then
                                            'Save
                                            If UserProf(Prof, 3) <> False2 Then
                                                'Folder
                                                Do
                                                    mailfile = NoSlash(MailFolder) + "\" + MakeTag(8)
                                                Loop Until SDir(mailfile + ".*") = ""
                                                mailfile = mailfile + ".ML0"
                                                NeedLF = False
                                            Else
                                                'File
                                                mailfile = UserProf(Prof, 10)
                                                NeedLF = SDir(mailfile) <> ""
                                            End If
                                            ReserveMailFile = mailfile
                                            msgid = ""
                                            n2 = FreeFile
                                            Open TempMailFile For Binary As n2
                                            n = FreeFile
                                            Open mailfile For Append As n
                                            If NeedLF Then Print #n, vbCrLf
                                            Print #n, "From NNTP-Server@" + UserProf(Prof, 6) + " " + DateLine(1)
                                            For j = 1 To NNTP1.DocOutput.Headers.Count
                                                Print #n, NNTP1.DocOutput.Headers.Item(j).Name; ": "; NNTP1.DocOutput.Headers.Item(j).Value
                                                If nxpost <> 0 Then If LCase(NNTP1.DocOutput.Headers.Item(j).Name) = "message-id" Then msgid = NNTP1.DocOutput.Headers.Item(j).Value
                                            Next j
                                            Print #n, ""
                                            a = Input(LOF(n2), n2)
                                            Print #n, a
                                            a = ""
                                            Close n2: n2 = 0
                                            DelFile TempMailFile: TempMailFile = ""
                                            Close n: n = 0
                                            If nxpost <> 0 And msgid <> "" Then AllMsgID = AllMsgID + msgid + vbCrLf
                                            'SPAM and PGP
                                            
                                            TestMail mailfile, PGPFlag, SPAMFlag, MultiFlag
                                            If SPAMFlag Then
                                                'Move to Trash\Spam
                                                xmailfile = Cnf(4, 0) + "\Trash\Spam\" + PlainName(mailfile, 2)
                                                While SDir(xmailfile + ".*") <> ""
                                                    xmailfile = Cnf(4, 0) + "\Trash\Spam\" + MakeTag(8)
                                                Wend
                                                FileCopy mailfile, xmailfile + ".ML0"
                                                DelFile mailfile
                                                mailfile = xmailfile + ".ML0"
                                                ReserveMailFile = mailfile
                                            ElseIf MultiFlag Then
                                                'Move to Multi
                                                xmailfile = Cnf(4, 0) + "\Multi\" + PlainName(mailfile, 2)
                                                While SDir(xmailfile + ".*") <> ""
                                                    xmailfile = Cnf(4, 0) + "\Multi\" + MakeTag(8)
                                                Wend
                                                FileCopy mailfile, xmailfile + ".ML0"
                                                DelFile mailfile
                                                mailfile = xmailfile + ".ML0"
                                                ReserveMailFile = mailfile
                                                MultParts = True
                                            Else
                                                'Queue Saved Message for Decryption
                                                If Val(Cnf(4, 12)) = 1 And (PGPFlag Or Val(Cnf(4, 13)) = 0) Then QueueDec mailfile
                                            End If
                                            'Update New IDX if saved to folder
                                            If UserProf(Prof, 3) <> False2 Then
                                                On Error Resume Next
                                                n = FreeFile
                                                Open PlainName(mailfile, 0) + "JBN2NEW.IDX" For Append As n
                                                Print #n, mailfile
                                                Close n: n = 0
                                                On Error GoTo GetNewsError
                                            End If
                                            'Alert View Mail Window
                                            'If LCase(NoSlash(PlainName(mailfile, 0))) = LCase(ViewerCurBox) And ViewerLoaded Then
                                            '    frmViewer!tmrUpdate.Tag = frmViewer!tmrUpdate.Tag + "F"
                                            '    frmViewer!tmrUpdate.Enabled = True
                                            'End If
                                            mailfile = ""
                                            svcount = svcount + 1
                                        End If
                                    Else
                                        'Failure
                                        DelFile TempMailFile
                                        a = LMsg(459) + " " + UserProf(Prof, 5) + " [" + LMsg(467) + " #" + Trim(Str(i + NextArticle)) + "]"
                                        If NNTPErrorString <> "" Then a = a + vbCrLf + "      " + NNTPErrorString
                                        If NNTP1.state <> prcConnected Or NNTPEvent = NNTPEventTimeout Or AbortRetrieve Then
                                            'Connection state lost
                                            If Not AbortRetrieve Then MsgLog a, 3, True, True
                                            GoTo DisconnectNews
                                        Else
                                            'Still connected
                                            MsgLog a, 3, False, True
                                            mx = MsgTime(a + vbCrLf + LMsg(466), 0, LMsg(461), vbAbortRetryIgnore, 1, 45)
                                            If mx = 1 Then
                                                GoTo DisconnectNews
                                            ElseIf mx = 2 Then
                                                GoTo TryGetArticle
                                            End If
                                        End If
                                    End If
                                    gtcount = gtcount + 1
                                    If gtcount <= dispcount Then frmMain!barProgress.Value = gtcount
                                End If
                                'Update Article Memory
                                y = InStr(1, PData(123 + Prof - 31), grpart, vbTextCompare)
                                If y <> 0 Then
                                    PData(123 + Prof - 31) = Left(PData(123 + Prof - 31), y - 1) + grpart + Trim(Str(i + NextArticle)) + Mid(PData(123 + Prof - 31), y + Len(Extract(Mid(PData(123 + Prof - 31), y + 1), ":")) + 1)
                                Else
                                    PData(123 + Prof - 31) = PData(123 + Prof - 31) + grpart + Trim(Str(i + NextArticle))
                                End If
                                'Debug.Print "Updt: "; PData(123 + Prof - 31)
                                If i = NNTPLastArticle - NextArticle Then
                                    'Last Article retrieved, generate clean grpart
                                    cleangrpart = cleangrpart + grpart + Trim(Str(i + NextArticle))
                                    cleangrpcount = cleangrpcount + 1
                                End If
                                If AbortRetrieve Then Exit For
                                ReserveMailFile = ""
                                DoEvents
                            Next i
                            If nxpost <> 0 Then
                                If AllMsgID <> "" Then
                                    Print #nxpost, "---"
                                    Write #nxpost, SafeTime
                                    Print #nxpost, AllMsgID;
                                End If
                                Close nxpost: nxpost = 0
                            End If
                            DoEvents
                        End If
                    Else
                        'Bad group
                        If Not AbortRetrieve Then MsgLog UserProf(Prof, 5) + ": " + LMsg(460) + ": " + Groups(grp), 3, True, True
                    End If
                    If AbortRetrieve Then Exit For
                Next grp
                If Not AbortRetrieve And cleangrpcount = maxgrp + 1 Then PData(123 + Prof - 31) = cleangrpart
                'Debug.Print "Post: "; PData(123 + Prof - 31)
                'Disconnect
DisconnectNews: On Error Resume Next
                frmMain!barProgress.Visible = False
                If nxpost <> 0 Then Close nxpost: nxpost = 0
                Stat LMsg(289) + " " + UserProf(Prof, 5) + "...", StatDec
                
                NNTP1.Quit
                dt = SafeTime
                While (NNTP1.state = prcConnected Or NNTP1.Busy) And SafeTime - dt < 20 / 24 / 60 / 60
                    DoEvents
                Wend
                
                'Summary
                MsgLog UserProf(Prof, 5) + ":" + Str(rtcount) + " " + LMsg(465) + " " + Str(svcount) + " " + LMsg(452), 3, False
            End If
            KeepDate(Prof + 4) = SafeTime
            NewMessages = NewMessages + svcount
            If AbortRetrieve Then Exit For
        End If
NextProf:
    Next Prof
Done:
    On Error Resume Next
    NNTP1.Quit
    CheckNewsAll = False
    If NewMessages <> 0 Then
        a = Str(NewMessages) + " " + LMsg(456) + "."
        If ViewerLoaded Then
            frmViewer!tmrUpdate.Tag = frmViewer!tmrUpdate.Tag + "D"
            frmViewer!tmrUpdate.Enabled = True
        End If
    Else: a = ""
    End If
    ReserveMailFile = ""
    If AbortRetrieve Then a = LMsg(300) + "  " + a
    Stat a, StatDec
    frmMain!barProgress.Visible = False
    WriteData
    If Not Decrypting And (DecQCount <> 0 Or MultParts) Then StartSession 6
    frmMain.MousePointer = 0
Exit Sub
NNTPError:
    NNTPEvent = NNTPEventError
    If NNTPErrorString = "" Then NNTPErrorString = Error
    Resume Next
GetNewsError:
    ErrDesc = Error
    Resume GetNewsError2
GetNewsError2:
    If Not AbortRetrieve Then
        MsgLog LMsg(459) + " " + UserProf(Prof, 5) + vbCrLf + "      " + ErrDesc, 2, True, True
        KeepDate(Prof + 4) = SafeTime
    End If
    CloseFile n: n = 0
    CloseFile n2: n2 = 0
    CloseFile nxpost: nxpost = 0
    DelFile TempMailFile
    DelFile XPostFile + ".TMP"
    
    GoTo DisconnectNews
End Sub

Private Sub Form_Unload(Cancel As Integer)
    GetNewsLoaded = False
End Sub

'===================================================
'NNTP1  FASTNET
Private Sub NNTP1_SelectGroup(ByVal groupName As String, ByVal firstMessage As Long, ByVal lastMessage As Long, ByVal msgCount As Long)
    On Error GoTo ErrorSelect
    NNTPFirstArticle = firstMessage
    NNTPLastArticle = lastMessage
    NNTPEvent = NNTPEventGroupSelected
Exit Sub
ErrorSelect:
    NNTPEvent = NNTPEventError
End Sub

Private Sub NNTP1_DocOutput(ByVal DocOutput As DocOutput)
    On Error GoTo ErrorDocOutput
    Select Case DocOutput.state
    Case icDocEnd: If NNTPEvent = 0 Then NNTPEvent = NNTPEventGotDoc
    Case icDocError: NNTPEvent = NNTPEventError
    End Select
Exit Sub
ErrorDocOutput:
    NNTPEvent = NNTPEventError
End Sub

Private Sub NNTP1_Error(Number As Integer, Description As String, Scode As Long, Source As String, HelpFile As String, HelpContext As Long, CancelDisplay As Boolean)
    NNTPEvent = NNTPEventError
    NNTPErrorString = Description
    NNTPErrorCode = Number
End Sub

'Private Sub NNTP1_StateChanged(ByVal State As Integer)
'    Debug.Print "State", NNTP1.StateString, NNTP1.State
'End Sub

'Private Sub NNTP1_ProtocolStateChanged(ByVal ProtocolState As Integer)
'    Debug.Print "ProtocolState: " & CStr(ProtocolState) + "   " + NNTP1.ProtocolStateString ' Update status panel with current protocol state of connection
'End Sub

Private Sub NNTP1_Timeout(ByVal Xevent As Integer, XContinue As Boolean)
    NNTPEvent = NNTPEventTimeout
End Sub

Private Sub NNTP1_AuthenticateRequest(UserID As String, Password As String)
    UserID = NNTPUser
    Password = NNTPPass
End Sub

Private Sub NNTP1_AuthenticateResponse(ByVal Authenticated As Boolean)
    If Not Authenticated Then NNTPEvent = NNTPEventAuthenticationFailed
End Sub
'===========================================================

Private Sub Form_Load()
    On Error GoTo ErrorLoad
    GetNewsLoaded = True
    GetNews
Exit Sub
ErrorLoad:
    MsgBox "ErrorLoad" + vbCr + Error + vbCr + Str(Err.Number) + vbCr + "Debug =" + Str(-1), vbCritical, "Debug Info"
End Sub
