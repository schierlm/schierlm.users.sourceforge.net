Attribute VB_Name = "Ref_Cnf"
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

'PDATA
'
'0  Language preference
'1  frmMain.left
'2  frmMain.top
'3  frmMain.width
'4  frmMain.height
'5  frmMain.windowstate
'6  frmMain!chkRLatent.value
'7  frmMain!chkROrder.value
'8  frmMain!txtRLatent(1).value
'9  frmMain!chkSend.value
'10 Last Global Work Folder
'11 Last Wipe Files With
'12 Last PGP Version
'13 Last DOS Mode
'14 PubKeyCount
'15 PubKeyDate
'16 PubKeyFile
'17 frmKeys.Left
'18 frmKeys.Top
'19 frmKeys.Width
'20 frmKeys.Height
'21 frmKeyRing.Left
'22 frmKeyRing.Top
'23 frmKeyRing.Width
'24 frmKeyRing.Height
'25 frmPreview.Left
'26 frmPreview.Top
'27 frmPreview.Width
'28 frmPreview.Height
'29 frmPreview.WindowState
'30 Pop-Up Error Send (0) BOOL
'31 Pop-up Stats Refrsh BOOL
'32 RESERVED Pop-up Pop3 Error BOOL
'33 RESERVED Pop-Up NNTP Error BOOL
'34 Pop-Up General (4) BOOL
'35 Pop-up Capability Update (5) BOOL
'36 RESERVED
'37 RESERVED
'38 RESERVED
'39 RESERVED
'40 Book Last Pathname
'41 Hide typing frmPass chk
'42 Machine and Chain Info
'43 No Key Warnings  crlf delin string
'44-51 lstQ.columnheader(1-8).width %
'52 Queue SortKey
'53 Verify Connection BOOL
'54 Dial On Demand BOOL
'55 Auto Hang Up BOOL
'56 BLANK
'57 VBoard Custom Keys
'58 VBoard optStyle(0)
'59 VBoard optStyle(1)
'60 VBoard optStyle(2)
'61 VBoard Stagger (0)
'62 VBoard Scramble (1)
'63 VBoard No-Click (2)
'64 chkVBoard.value
'65 VBoard Slider
'66 VBoard Generate Chaff
'67 VBoard Filter Chaff
'68 Secure Mode  BOOL
'69 Explore Pattern List
'70 Explore Pattern 0 text
'71 Explore Pattern 1 text
'72 Explore Last Folder
'73 Recent List
'74 Explore Move-To Folder Last
'75 Explore Select Folder List
'76  VBoard Sound
'77  Stats Auto Images BOOL
'78  Stats Auto Redirect BOOL
'79  Stats Proxy A BOOL
'80  Stats Proxy B BOOL
'81  Stats Ret Proxy BOOL
'82  frmAdds.left
'83  frmAdds.top
'84  frmAdds.width
'85  frmAdds.height
'86  frmAdds.windowstate
'87  frmWeb.left
'88  frmWeb.top
'89  frmWeb.width
'90  frmWeb.height
'91  frmWeb.windowstate
'92  frmCfBook.left
'93  frmCfBook.top
'94  frmCfGlobal.left
'95  frmCfGlobal.top
'96  frmCfNym.left
'97  frmCfNym.top
'98  frmCfProf.left
'99  frmCfProf.top
'100 frmCfRmlr.left
'101 frmCfRmlr.top
'102 frmCfStats.left
'103 frmCfStats.top
'104 Explore Copy-To Folder Last
'105 mnuExShow (0).checked (Double List)
'106 mnuExShow (1).checked (Wide List)
'107 mnuExShow (2).checked (Files on Right)
'108 Reserved
'109 Reserved
'110 frmFolder.left
'111 frmFolder.top
'112 frmBook.left
'113 frmBook.top
'114 frmBook.width
'115 frmBook.height
'116 frmBook.windowstate
'117 frmNBook.left
'118 frmNBook.top
'119 frmNBook.width
'120 frmNBook.height
'119 frmNBoom.windowstate
'120 frmMain!txtRLatent(0).value
'121 Que|mnuPrevDumm BOOL
'122 UNUSED    was: Options|News|Filter Duplicate Posts
'123-137 News Last Article Numbers
'138 Viewer  Original Full chk
'139 Viewer  Original Raw chk
'140 Viewer  Original UNUSED
'141 Viewer  Original Reply/Followup
'142 Viewer  Decrypted Full chk
'143 Viewer  Decrypted Raw chk
'144 Viewer  Decrypted UNUSED
'145 Viewer  Decrypted Reply/Followup
'146 Viewer  Last Attach Path
'147-152 Viewer  lstMail.columnheaders.width 1-5 152 reserved
'153 Viewer  lstMail.SortKey
'154 Viewer  lstMail.SortOrder
'155 Viewer  Last Import File
'156 Viewer  Last Export File
'157 Viewer  Change Inbox Path List
'158 Viewer  Last Load/Insert Text
'159 Viewer  Last Save Text
'160 Viewer  Short List Checked
'161 Viewer left
'162 Viewer top
'163 Viewer width
'164 Viewer height
'165 Viewer windowstate
'166 CfRet left
'167 CfRet top
'168 Viewer Last Decrypt File
'169 Viewer Decrypt Diagnostic Mode
'170 Suspend Auto Functions
'171 Error Summary H
'172 Error Summary W

'---------------------------------------------------------------
'KEEPDATE 0-50
'0-15 Session Last Run
'16 RAS Last Dialed
'17 Rem Caps last flushed
'18 Last Cleaned Xpost file
'19 Last Clean XNym file
'20-34 Last Mail Check Profile 0 - 14
'35-49 Last Get News Profile 31-45


'---------------------------------------------------------------
'BKDATA
'0  Chains
'1  Cypherpunk/Mixmaster  0/1
'2  Hard Wrap Column
'3  UNUSED      Was: Remailer Test BOOL
'4  Local Signature
'5  Show Advanced mnuOption(0) BOOL
'6  Alternate TextBox BOOL
'7  Default Directive Cpunk
'8  Default Directive Mix
'9  CPunk Option|Expiration (Hours)
'10 Override SMTP
'11 FileOpt Auto-Save BOOL
'12 FileOpt Save Replay BOOL
'13 FileOpt Autoname on Load BOOL
'14 CPunk Option|Remix Compliant BOOL
'15 chkQue(2).value Preview
'16 Text MIME QP BOOL
'17 Text MIME 8bit
'18 Close on Queue BOOOL
'19 Show Attachment in Subject
'20- 24 BLANK
'25- ...  book data
    '34-35  UNUSED  were optArchive(1-2) BOOL
    '45  cboArcType.listindex
    
'---------------------------------------------------------------
'NKDATA
'0  Show Advanced Option0 BOOL
'1  Update NRegistry Option1 BOOL
'2  Update Log BOOL
'3  Automate/Nautomate     Was: Enumerate RBs (TEMPORARY IN BETA)
'4  Remix Compliant BOOL
'5-6 BLANK
'7  Default Directive CPunk
'8  Max-Date
'9  Max-Date Last Run
'10 cboFrom.text
'11 cboUserID.text
'12 chkAccount(0).value (Create New)
'13 chkAccount(1).value (Delete)
'14 chkAccount(2).value (Change Key)
'15 Max-Date Last #days      Was: chkNym(0)  Nym-Commands
'16 chkNym(1)  Repl-Blocks
'17 Name
'18 N-C
'19 chkQue(1).value Preview
'20-26 chkNymComm 0 - 6
'27 lblEncryptKey.Caption


'BLOCKDATA
'0  Active chk
'1  Folder txt
'2  Prob txt
'3  ToHead cbo txt
'4  ToAddress cbo txt
'5  Headers txt


'---------------------------------------------------------------
'USERPROF

'0-14   POP
'   0   Enable
'   1   Download every check
'   2   Delete retrieved
'   3   Folder opt
'   4   File opt
'   5   Profile
'   6   Server
'   7   User
'   8   Password
'   9   Check minutes
'   10  Folder/File
'   11  Filter Get
'   12  Filter Not Get
'   13  Get Index
'   14  Not Get Index
'   15  Ignore larger than chk
'   16  Ignore size txt

'15-29  SMTP
'   0   Enable
'   1   Profile
'   2   Server
'   3   From Header
'   4   Reply-To
'   5   SMTP From Address
'   6   Additional Headers
'   7   Default Profile (15,7 only) [0-14]
'   8   Generate CPunk Dummies chk
'   9   Generate Mix Dummies chk


'30     UNIX
'   0   Enable
'   1   Folder Opt
'   2   File Opt
'   3   Addresses
'   4   Folder/File
'   5   From Header
'   6   Additional Headers

'31-45  NNTP
'   0   Enable
'   1   Download every check
'   2   Fully retrieve check
'   3   Folder opt
'   4   File Opt
'   5   Profile
'   6   Server
'   7   User
'   8   Password
'   9   Check minutes
'   10  Save to File/Folder
'   11  Newsgroups
'   12  Contain
'   13  Not contain
'   14  Min Lines txt
'   15  Max Lines txt

'---------------------------------------------------------------
'NYMS
'   0   Account Address txt
'   1   Conv Pass txt
'   2   Conv Pass Prior txt
'   3   Key cbo txt



'---------------------------------------------------------------
'KEYPASS
'   0   Key
'   1   Passphrase


'---------------------------------------------------------------
'CNF

'0  GLOBAL
'   0   Global Work Folder
'   1   Mail Queue Folder
'   2   Wipe FIles With
'   3   PGP Version cbo 0 = 2.6.x; 1 = 5.5.x
'   4   DOS Mode
'           0 Hide
'           1 Paused
'           2 Min Focus
'           3 Min wo Focus
'   5   Preferred Font Size cbo  0 => 8; 4 => 12
'   6   Preferred Encryption cbo 0=RSA; 1=DH
'   7   BLANK
'   8   BLANK
'   9   BLANK
'   10  Dialer Connection
'   11  Dialer Conn, User, Pass vbcrlf delin multi
'   12  Dial Every Minutes txtGlobal(3)
'   13  Dialer Start the Apps txtGlobal(4)
'   14  PGP Version Report txtGlobal(5)


'1  REMAILERS
'   0   AUTO Ignore list cbo  11
'       0 The following list has no effect:
'       1 Ignore Uptime% of the following remailers:
'       2 Ignore Latency of the following remailers:
'       3 Ignore Uptime% and Latency of the following remailers:
'       4 Limit select to the following remailers only:
'   1   Mixmaster Version   0=2.0.3, 1=2.0.4, 2=3.0 DOS, 3=3.0 Windows
'   2   AUTO Consider History chk
'   3   Auto-Maintain Mix.con chk
'   4   BLANK chk
'   5   BLANK chk
'   6   BLANK chk
'   7   BLANK chk
'   8   BLANK chk
'   9   BLANK chk
'   10  AUTO Uptime% Min txt  22
'   11  AUTO Latency Max txt  23
'   12  AUTO Min Distance txt  24
'   13  AUTO Never Choose txt 25
'   14  AUTO Ignore List txt  26
'   15  Mix Program Folder txt  29
'   16  Mix MAXLAT txt   34
'   17  Mix MINREL txt   35
'   18  Mix DISTANCE txt   36
'   19  MIXPATH txt  30
'   20  Type2.lis txt
'   21  Pubring.mix txt
'   22  Mix RELLIST mixmaste.htm txt


'2  BOOKS
'   0   Confirm book overwrite chk
'   1   Confirm text overwrite chk
'   2   Prompt to save changes chk
'   3   Confirm clear chk
'   4   Zero remailers warning chk
'   5   Pop-up capability warnings chk
'   6   Alter PGP timestamp chk
'   7   Pop-up stats warnings chk
'   8   Uptime-Hist Preferred
'   9   Middleman warning chk
'   10  Double-click opens full chk
'   11  BLANK chk
'   12  BLANK chk
'   13  BLANK chk
'   14  BLANK chk
'   15  Quote reply Always opt
'   16  Quote reply Never opt
'   17  Quote reply Prompt opt
'   18  Quote character txt
'   19  Global Signature txt
'   20  Header Choice List txt
'   21  Directive Choice List txt
'   22  BLANK txt
'   23  BLANK txt
'   24  BLANK txt
'   25  Font Name
'   26  Font Size
'   27  Font Bold
'   28  Reply heading  Email  cboOpt(0).text
'   29  Reply heading  News   cboOpt(1).text

'3  STATS
'   0   Refresh stats chk
'   1   Refresh cap strings chk
'   2   Refresh machine and chain info chk
'   3   BLANK
'   4   BKANK
'   5   BLANK
'   6   BLANK
'   7   Text Color
'   8   Background Color
'   9   Link Color
'   10  Files To Cache cbo
'   11  UNUSED    was: Primary CPunk stats URL cbo
'   12  UNUSED    was: Primary Mix Stats URL cbo
'   13  Proxy A cbo
'   14  Proxy B cbo
'   15  BLANK
'   16  BLANK
'   17  BLANK
'   18  refresh hours txt
'   19  cache folder txt
'   20  CPunk URLs txt
'   21  CPunk Chain URLs txt
'   22  CPunk keys URLs txt
'   23  Mix URLs txt
'   24  Type2.lis/Pubring.mix URLs txt
'   25  BLANK                Was Pubring.mix URLs txt
'   26  BLANK                Was Key-Server URL txt

'4  RETRIEVAL
'   0   Mail Folder  txt
'   1   Reply Templates Folder  txt
'   2   Anti-SPAM Filters  txt
'   3   From Filters   txt
'   4   BLANK
'   5   BLANK
'   6   BLANK
'   7   BLANK
'   8   Date Display Format cbotxt
'   9   BLANK
'   10  BLANK
'   11  BLANK
'   12  Decrypt new messages chk
'   13    PGP Messages only  chk
'   14  Prompt for Private Pass chk
'   15  Decode Binary PGP Inline  chk
'   16  Update AckSend.TXT  chk
'   17  Trash Nym Duplicates  chk
'   18  Filter News Duplicates  chk


