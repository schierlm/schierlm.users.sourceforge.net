VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmNBook 
   Caption         =   "Nym Book"
   ClientHeight    =   6675
   ClientLeft      =   135
   ClientTop       =   390
   ClientWidth     =   7935
   Icon            =   "NBook.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   6675
   ScaleWidth      =   7935
   Begin VB.Timer tmrReload 
      Enabled         =   0   'False
      Interval        =   200
      Left            =   1980
      Top             =   6300
   End
   Begin VB.Frame fraRemEdit 
      Caption         =   "[Cracker]  (3)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3372
      Left            =   10000
      TabIndex        =   2
      Top             =   3300
      Visible         =   0   'False
      Width           =   7812
      Begin VB.ComboBox cboGarbage 
         Height          =   288
         Left            =   6960
         TabIndex        =   10
         Text            =   "Combo12"
         Top             =   3000
         Visible         =   0   'False
         Width           =   552
      End
      Begin VB.ComboBox cboHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   2100
         TabIndex        =   7
         Top             =   3024
         Width           =   4752
      End
      Begin VB.TextBox txtRemEdit 
         BackColor       =   &H00808000&
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   288
         Left            =   60
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   9
         Top             =   240
         Width           =   7632
      End
      Begin VB.TextBox txtHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2712
         Index           =   2
         Left            =   2100
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   8
         Text            =   "NBook.frx":0442
         Top             =   600
         Width           =   4752
      End
      Begin VB.CommandButton cmdRemEdit 
         Caption         =   "OK"
         Height          =   552
         Index           =   0
         Left            =   6972
         TabIndex        =   6
         Top             =   720
         Width           =   710
      End
      Begin VB.CommandButton cmdRemEdit 
         Caption         =   "Cancel"
         Height          =   552
         Index           =   1
         Left            =   6972
         TabIndex        =   5
         Top             =   1380
         Width           =   710
      End
      Begin VB.CommandButton cmdRemEdit 
         Caption         =   "Set as Default"
         Height          =   552
         Index           =   2
         Left            =   6972
         TabIndex        =   4
         Top             =   2040
         Width           =   710
      End
      Begin VB.TextBox txtCaps 
         Alignment       =   2  'Zentriert
         BackColor       =   &H00808000&
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   2712
         Left            =   60
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   3
         Text            =   "NBook.frx":04D2
         Top             =   600
         Width           =   1992
      End
      Begin VB.Label lblGarbage 
         Caption         =   "Garbage:"
         Height          =   252
         Left            =   6840
         TabIndex        =   11
         Top             =   2760
         Visible         =   0   'False
         Width           =   672
      End
   End
   Begin VB.CheckBox chkQue 
      Caption         =   "Prev&iew"
      Height          =   312
      Index           =   1
      Left            =   6600
      Style           =   1  'Grafisch
      TabIndex        =   14
      Top             =   6360
      Width           =   1272
   End
   Begin VB.CheckBox chkQue 
      Caption         =   "&Create"
      Height          =   312
      Index           =   0
      Left            =   5220
      Style           =   1  'Grafisch
      TabIndex        =   13
      Top             =   6360
      Width           =   1272
   End
   Begin ComctlLib.ProgressBar ProgressBar1 
      Height          =   216
      Left            =   3876
      TabIndex        =   12
      Top             =   6396
      Visible         =   0   'False
      Width           =   1212
      _ExtentX        =   2143
      _ExtentY        =   397
      _Version        =   327682
      Appearance      =   1
      Max             =   25
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   1080
      Top             =   6240
      _ExtentX        =   688
      _ExtentY        =   688
      _Version        =   393216
   End
   Begin VB.Frame fraNym 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame2"
      Height          =   5952
      Index           =   1
      Left            =   60
      TabIndex        =   38
      Top             =   300
      Width           =   7812
      Begin VB.CheckBox chkActive 
         Caption         =   "Active"
         Height          =   312
         Left            =   120
         Style           =   1  'Grafisch
         TabIndex        =   80
         TabStop         =   0   'False
         Top             =   360
         Width           =   1152
      End
      Begin VB.CheckBox chkUpRB 
         Caption         =   "Update Reply-Blocks"
         Height          =   192
         Left            =   5340
         TabIndex        =   69
         Top             =   5340
         Width           =   2352
      End
      Begin VB.ComboBox cboMaxDate 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   960
         TabIndex        =   67
         Top             =   5280
         Width           =   1692
      End
      Begin VB.Frame fraRB 
         BorderStyle     =   0  'Kein
         Caption         =   "      Reply-Blocks"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   4884
         Left            =   60
         TabIndex        =   39
         Top             =   300
         Width           =   7692
         Begin VB.OptionButton optDecrypt 
            Caption         =   "Folder"
            Height          =   192
            Index           =   0
            Left            =   1080
            TabIndex        =   82
            Top             =   4620
            Value           =   -1  'True
            Width           =   912
         End
         Begin VB.OptionButton optDecrypt 
            Caption         =   "File"
            Height          =   192
            Index           =   1
            Left            =   2040
            TabIndex        =   81
            Top             =   4620
            Width           =   792
         End
         Begin VB.ComboBox cboFolder 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            ItemData        =   "NBook.frx":0519
            Left            =   2820
            List            =   "NBook.frx":051B
            Sorted          =   -1  'True
            TabIndex        =   75
            Top             =   4560
            Width           =   4812
         End
         Begin VB.ComboBox cboRandHop 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            ItemData        =   "NBook.frx":051D
            Left            =   3000
            List            =   "NBook.frx":055D
            TabIndex        =   74
            Top             =   1320
            Width           =   852
         End
         Begin VB.ComboBox cboInflate 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            ItemData        =   "NBook.frx":05A9
            Left            =   720
            List            =   "NBook.frx":05E3
            TabIndex        =   73
            Top             =   1320
            Width           =   1122
         End
         Begin VB.ComboBox cboMaxCount 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            ItemData        =   "NBook.frx":0644
            Left            =   5520
            List            =   "NBook.frx":0696
            TabIndex        =   65
            Top             =   60
            Width           =   792
         End
         Begin VB.ComboBox cboMaxSize 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            ItemData        =   "NBook.frx":0713
            Left            =   3660
            List            =   "NBook.frx":076E
            TabIndex        =   63
            Top             =   60
            Width           =   792
         End
         Begin VB.CommandButton cmdRandom 
            Caption         =   "R"
            Height          =   264
            Left            =   7392
            TabIndex        =   54
            Top             =   972
            Width           =   240
         End
         Begin VB.CommandButton cmdRemailer 
            Caption         =   "Add"
            Height          =   312
            Index           =   0
            Left            =   4860
            TabIndex        =   53
            Top             =   600
            Width           =   852
         End
         Begin VB.ComboBox cboTo 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            Left            =   1860
            TabIndex        =   52
            Top             =   3060
            Width           =   5772
         End
         Begin VB.ComboBox cboToHead 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            ItemData        =   "NBook.frx":07FA
            Left            =   60
            List            =   "NBook.frx":080D
            TabIndex        =   51
            TabStop         =   0   'False
            Top             =   3060
            Width           =   1752
         End
         Begin VB.CommandButton cmdRemailer 
            Caption         =   "Clear"
            Height          =   312
            Index           =   2
            Left            =   6780
            TabIndex        =   49
            TabStop         =   0   'False
            Top             =   600
            Width           =   852
         End
         Begin VB.CommandButton cmdRemailer 
            Caption         =   "Remove"
            Height          =   312
            Index           =   1
            Left            =   5820
            TabIndex        =   48
            Top             =   600
            Width           =   852
         End
         Begin VB.TextBox txtPass 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            Left            =   3000
            MaxLength       =   1024
            TabIndex        =   47
            Top             =   960
            Width           =   4368
         End
         Begin VB.ComboBox cboLatent 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            ItemData        =   "NBook.frx":0847
            Left            =   720
            List            =   "NBook.frx":0896
            TabIndex        =   46
            Top             =   960
            Width           =   1122
         End
         Begin VB.ComboBox cboRemailer 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            Left            =   60
            TabIndex        =   45
            Top             =   600
            Width           =   4752
         End
         Begin VB.TextBox txtProb 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   288
            Left            =   6900
            MaxLength       =   10
            TabIndex        =   44
            Top             =   60
            Width           =   732
         End
         Begin VB.CheckBox chkTo 
            Caption         =   "Remix-To"
            Height          =   192
            Index           =   0
            Left            =   4116
            TabIndex        =   43
            Top             =   1380
            Width           =   1212
         End
         Begin VB.CheckBox chkTo 
            Caption         =   "Encrypt-To"
            Height          =   192
            Index           =   1
            Left            =   5376
            TabIndex        =   42
            Top             =   1380
            Width           =   1212
         End
         Begin VB.TextBox txtXHeaders 
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   1032
            Left            =   60
            MaxLength       =   30000
            MultiLine       =   -1  'True
            ScrollBars      =   3  'Beides
            TabIndex        =   41
            Top             =   3420
            Width           =   7572
         End
         Begin VB.CheckBox chkTo 
            Caption         =   "Anon-To"
            Height          =   192
            Index           =   2
            Left            =   6696
            TabIndex        =   40
            Top             =   1380
            Width           =   1032
         End
         Begin VB.ListBox lstRemailers 
            BackColor       =   &H00808000&
            BeginProperty Font 
               Name            =   "Courier New"
               Size            =   7.5
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   960
            ItemData        =   "NBook.frx":096C
            Left            =   60
            List            =   "NBook.frx":096E
            TabIndex        =   50
            TabStop         =   0   'False
            Top             =   1680
            Width           =   7572
         End
         Begin VB.Label lblBlock 
            Alignment       =   2  'Zentriert
            Caption         =   "Block 1"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   192
            Left            =   1380
            TabIndex        =   71
            Top             =   120
            Width           =   1272
         End
         Begin VB.Label lblRemailers 
            Caption         =   "Remailers"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   192
            Left            =   60
            TabIndex        =   70
            Top             =   410
            Width           =   1692
         End
         Begin VB.Label lblMaxCount 
            Caption         =   "Max-Count:"
            Height          =   192
            Left            =   4620
            TabIndex        =   66
            Top             =   120
            Width           =   792
         End
         Begin VB.Label lblMaxSize 
            Caption         =   "Max-Size:"
            Height          =   192
            Left            =   2880
            TabIndex        =   64
            Top             =   120
            Width           =   792
         End
         Begin VB.Label lblFolder 
            BackStyle       =   0  'Transparent
            Caption         =   "Decrypt To"
            Height          =   192
            Left            =   60
            TabIndex        =   61
            Top             =   4620
            Width           =   1032
         End
         Begin VB.Label lblFinal 
            BackStyle       =   0  'Transparent
            Caption         =   "Final Headers"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   192
            Left            =   60
            TabIndex        =   60
            Top             =   2870
            Width           =   2712
         End
         Begin VB.Label lblEncryptKey 
            BackStyle       =   0  'Transparent
            Caption         =   "Encrypt-Key:"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   -1  'True
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   192
            Left            =   1896
            TabIndex        =   59
            Top             =   1020
            Width           =   1152
         End
         Begin VB.Label lblLatent 
            BackStyle       =   0  'Transparent
            Caption         =   "Latency:"
            Height          =   192
            Left            =   60
            TabIndex        =   58
            Top             =   1020
            Width           =   912
         End
         Begin VB.Label lblProb 
            BackStyle       =   0  'Transparent
            Caption         =   "Prob:"
            Height          =   192
            Left            =   6480
            TabIndex        =   57
            Top             =   120
            Width           =   552
         End
         Begin VB.Label lblInflate 
            BackStyle       =   0  'Transparent
            Caption         =   "Inflate:"
            Height          =   192
            Left            =   60
            TabIndex        =   56
            Top             =   1380
            Width           =   1092
         End
         Begin VB.Label lblRandHop 
            BackStyle       =   0  'Transparent
            Caption         =   "Rand-Hop:"
            Height          =   192
            Left            =   1896
            TabIndex        =   55
            Top             =   1380
            Width           =   1092
         End
      End
      Begin ComctlLib.TabStrip tabRB 
         Height          =   5232
         Left            =   0
         TabIndex        =   62
         Top             =   0
         Width           =   7812
         _ExtentX        =   13785
         _ExtentY        =   9234
         TabWidthStyle   =   2
         TabFixedWidth   =   794
         TabFixedHeight  =   406
         _Version        =   327682
         BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
            NumTabs         =   30
            BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "1*"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "2"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "3"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab4 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "4"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab5 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "5"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab6 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "6"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab7 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "7"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab8 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "8"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab9 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "9"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab10 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "10"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab11 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "11"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab12 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "12"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab13 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "13"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab14 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "14"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab15 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "15"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab16 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "16"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab17 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "17"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab18 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "18"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab19 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "19"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab20 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "20"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab21 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "21"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab22 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "22"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab23 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "23"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab24 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "24"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab25 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "25"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab26 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "26"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab27 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "27"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab28 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "28"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab29 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "29"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab30 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "30"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
         EndProperty
      End
      Begin VB.Label lblLastDate 
         Caption         =   "Last: 21 Jan 1999"
         Height          =   192
         Left            =   2940
         TabIndex        =   72
         Top             =   5340
         Width           =   1992
      End
      Begin VB.Label lblMaxDate 
         Caption         =   "Max-Date:"
         Height          =   192
         Left            =   60
         TabIndex        =   68
         Top             =   5340
         Width           =   792
      End
   End
   Begin VB.Frame fraNym 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   5952
      Index           =   0
      Left            =   60
      TabIndex        =   16
      Top             =   300
      Width           =   7812
      Begin VB.TextBox txtNymComm 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   180
         MaxLength       =   1024
         TabIndex        =   33
         Top             =   5160
         Width           =   6552
      End
      Begin VB.CheckBox chkNymComm 
         Caption         =   "Disable   [Temporarily disable this account  (Uncheck to re-enable after an auto-disable)]"
         Height          =   252
         Index           =   6
         Left            =   180
         TabIndex        =   32
         Top             =   4500
         Width           =   7392
      End
      Begin VB.CheckBox chkNymComm 
         Caption         =   "Nobcc   [Do not accept messages which do not contain my address in the To header]"
         Height          =   252
         Index           =   5
         Left            =   180
         TabIndex        =   31
         Top             =   4140
         Width           =   7452
      End
      Begin VB.TextBox txtName 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   900
         MaxLength       =   256
         TabIndex        =   30
         Top             =   1920
         Width           =   4332
      End
      Begin VB.CheckBox chkNymComm 
         Caption         =   "Fingerkey   [Display my public key when my nym account is fingered]"
         Height          =   252
         Index           =   4
         Left            =   180
         TabIndex        =   29
         Top             =   3780
         Width           =   7392
      End
      Begin VB.CheckBox chkNymComm 
         Caption         =   "Fixedsize   [Pad all messages to 10K and break large messages into 10K pieces]"
         Height          =   252
         Index           =   3
         Left            =   180
         TabIndex        =   28
         Top             =   3420
         Width           =   7452
      End
      Begin VB.CheckBox chkNymComm 
         Caption         =   "Cryptrecv   [Encrypt all incoming messages with my public key]"
         Height          =   252
         Index           =   2
         Left            =   180
         TabIndex        =   27
         Top             =   3060
         Value           =   1  'Aktiviert
         Width           =   7392
      End
      Begin VB.CheckBox chkNymComm 
         Caption         =   "Signsend   [Auto-sign outgoing messages with nym-server key]"
         Height          =   252
         Index           =   1
         Left            =   180
         TabIndex        =   26
         Top             =   2700
         Width           =   7392
      End
      Begin VB.CheckBox chkNymComm 
         Caption         =   "Acksend   [Request acknowledgements that outgoing messages have been mailed]"
         Height          =   252
         Index           =   0
         Left            =   180
         TabIndex        =   25
         Top             =   2340
         Value           =   1  'Aktiviert
         Width           =   7392
      End
      Begin VB.ComboBox cboUserID 
         Height          =   288
         Left            =   1920
         Sorted          =   -1  'True
         TabIndex        =   22
         Top             =   540
         Width           =   4272
      End
      Begin VB.CheckBox chkAccount 
         Caption         =   "Change Account Key"
         Height          =   252
         Index           =   2
         Left            =   5280
         TabIndex        =   21
         Top             =   984
         Width           =   2352
      End
      Begin VB.CheckBox chkAccount 
         Caption         =   "Delete Account"
         Height          =   252
         Index           =   1
         Left            =   2940
         TabIndex        =   20
         Top             =   984
         Width           =   1692
      End
      Begin VB.CheckBox chkAccount 
         Caption         =   "Create New Account"
         Height          =   252
         Index           =   0
         Left            =   360
         TabIndex        =   19
         Top             =   984
         Width           =   2532
      End
      Begin VB.ComboBox cboNym 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   1920
         TabIndex        =   18
         Top             =   180
         Width           =   4272
      End
      Begin VB.CommandButton cmdFindKey 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   276
         Left            =   6180
         TabIndex        =   17
         TabStop         =   0   'False
         Top             =   540
         Width           =   276
      End
      Begin VB.Label Label5 
         Caption         =   "Nym-Commands:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   252
         Left            =   120
         TabIndex        =   37
         Top             =   1560
         Width           =   1992
      End
      Begin VB.Label lblNymComm 
         BackStyle       =   0  'Transparent
         Caption         =   "Additional Nym-Commands:  [Optional]"
         Height          =   192
         Left            =   180
         TabIndex        =   35
         Top             =   4920
         Width           =   6792
      End
      Begin VB.Label Label13 
         BackStyle       =   0  'Transparent
         Caption         =   "Name:"
         Height          =   192
         Left            =   180
         TabIndex        =   34
         Top             =   1980
         Width           =   672
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Caption         =   "Account PGP Key:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Left            =   120
         TabIndex        =   24
         Top             =   600
         Width           =   1812
      End
      Begin VB.Label Label1 
         BackStyle       =   0  'Transparent
         Caption         =   "Account Address:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Left            =   120
         TabIndex        =   23
         Top             =   240
         Width           =   1752
      End
   End
   Begin VB.Frame fraNym 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   5952
      Index           =   3
      Left            =   60
      TabIndex        =   78
      Top             =   300
      Width           =   7812
      Begin VB.TextBox txtLog 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   10.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   5772
         Left            =   60
         MaxLength       =   31000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   79
         Top             =   120
         Width           =   7692
      End
   End
   Begin VB.Frame fraNym 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   5952
      Index           =   2
      Left            =   60
      TabIndex        =   76
      Top             =   300
      Width           =   7812
      Begin VB.TextBox txtNotes 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   5772
         Left            =   60
         MaxLength       =   31000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   77
         Top             =   120
         Width           =   7692
      End
   End
   Begin ComctlLib.TabStrip tabNym 
      Height          =   6312
      Left            =   0
      TabIndex        =   15
      Top             =   0
      Width           =   7932
      _ExtentX        =   13996
      _ExtentY        =   11139
      TabWidthStyle   =   2
      TabFixedWidth   =   3528
      TabFixedHeight  =   423
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   4
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Account"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Reply-Blocks"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Notes"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab4 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Log"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin VB.TextBox txtNull 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   288
      Left            =   120
      Locked          =   -1  'True
      MaxLength       =   10
      TabIndex        =   83
      Top             =   180
      Width           =   852
   End
   Begin VB.Label Label3 
      Caption         =   "Label3"
      Height          =   252
      Left            =   60
      TabIndex        =   36
      Top             =   1680
      Width           =   2592
   End
   Begin VB.Label lblNym 
      BackStyle       =   0  'Transparent
      Caption         =   "Update Reply-Blocks"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   192
      Index           =   1
      Left            =   540
      TabIndex        =   1
      Top             =   1920
      Width           =   1812
   End
   Begin VB.Label lblStat 
      BorderStyle     =   1  'Fest Einfach
      Height          =   288
      Left            =   60
      TabIndex        =   0
      Top             =   6360
      Width           =   5052
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuDisk 
         Caption         =   "&Open"
         Index           =   0
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Re-Open"
         Index           =   1
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Save"
         Index           =   2
         Shortcut        =   ^S
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "Save &As..."
         Index           =   3
      End
      Begin VB.Menu mnuDisk 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuDisk 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuDisk 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuDisk 
         Caption         =   ""
         Index           =   7
         Visible         =   0   'False
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "-"
         Index           =   8
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Close"
         Index           =   9
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "Sav&e and Close"
         Index           =   10
      End
   End
   Begin VB.Menu mnuEdit 
      Caption         =   "&Edit"
      Begin VB.Menu mnuEditArray 
         Caption         =   "Und&o     [Ctrl+Z]"
         Index           =   0
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "&Copy     [Ctrl+C]"
         Index           =   1
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "Copy App&end"
         Index           =   2
         Shortcut        =   ^D
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "Cu&t     [Ctrl+X]"
         Index           =   3
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "&Paste     [Ctrl+V]"
         Index           =   4
      End
      Begin VB.Menu sepEdit1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuCopyPass 
         Caption         =   "Cop&y Passphrases"
      End
      Begin VB.Menu mnuRefresh 
         Caption         =   "Replace Pa&ssphrases"
      End
      Begin VB.Menu sepEdit4 
         Caption         =   "-"
      End
      Begin VB.Menu mnuCopyBlock 
         Caption         =   "Copy &Reply-Block"
         Index           =   0
         Shortcut        =   ^Y
      End
      Begin VB.Menu mnuCopyBlock 
         Caption         =   "Paste Reply-&Block"
         Index           =   1
         Shortcut        =   ^K
      End
      Begin VB.Menu sepEdit3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuClear 
         Caption         =   "C&lear Reply-Block"
         Index           =   0
         Shortcut        =   ^R
      End
      Begin VB.Menu mnuClear 
         Caption         =   "Clear &All Reply-Blocks"
         Index           =   1
      End
      Begin VB.Menu mnuClear 
         Caption         =   "Clear Boo&k"
         Index           =   2
      End
   End
   Begin VB.Menu mnuRemailers 
      Caption         =   "&Remailers"
      Begin VB.Menu mnuStats 
         Caption         =   "&Refresh Stats"
         Index           =   0
      End
      Begin VB.Menu mnuStats 
         Caption         =   "&View Stats"
         Index           =   1
      End
      Begin VB.Menu mnuStats 
         Caption         =   "Get CPunk &Keys"
         Index           =   2
      End
      Begin VB.Menu sepRem1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuShowAuto 
         Caption         =   "Show &AUTO"
      End
      Begin VB.Menu mnuChain 
         Caption         =   "&Chain"
         Visible         =   0   'False
         Begin VB.Menu mnuRemEdit 
            Caption         =   "&Add AUTO"
            Index           =   0
         End
         Begin VB.Menu mnuRemEdit 
            Caption         =   "Remo&ve"
            Index           =   1
         End
         Begin VB.Menu mnuRemEdit 
            Caption         =   "-"
            Index           =   2
         End
         Begin VB.Menu mnuRemEdit 
            Caption         =   "&Edit Directives..."
            Index           =   3
         End
      End
      Begin VB.Menu sepRem2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfigRem 
         Caption         =   "&Configuration..."
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "&Tools"
      Begin VB.Menu mnuPGPRing 
         Caption         =   "&View PGP Keyring"
         Index           =   0
      End
      Begin VB.Menu mnuPGPRing 
         Caption         =   "Create PGP &Key"
         Index           =   1
      End
      Begin VB.Menu sepTools1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExport 
         Caption         =   "E&xport Subject"
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   0
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   1
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   2
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   3
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   4
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   5
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   6
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   7
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   8
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   9
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   10
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   11
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   12
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   13
         End
         Begin VB.Menu mnuExportSub 
            Caption         =   ""
            Index           =   14
         End
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuOption 
         Caption         =   "Show &Advanced"
         Index           =   0
      End
      Begin VB.Menu mnuOption 
         Caption         =   "Update &Nym Registry"
         Index           =   1
      End
      Begin VB.Menu mnuOption 
         Caption         =   "Update &Log"
         Index           =   2
      End
      Begin VB.Menu mnuOption 
         Caption         =   "-"
         Index           =   3
      End
      Begin VB.Menu mnuOption 
         Caption         =   "Remi&x Compliant"
         Index           =   4
      End
      Begin VB.Menu sepOpt2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfigBook 
         Caption         =   "&Configuration..."
         Shortcut        =   {F7}
      End
   End
   Begin VB.Menu mnuWind 
      Caption         =   "&Window"
      Begin VB.Menu mnuWindow 
         Caption         =   "E&xplore"
         Index           =   0
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Queue"
         Index           =   1
         Shortcut        =   {F3}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Log"
         Index           =   2
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&View Mail"
         Index           =   3
         Shortcut        =   {F5}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Stats Browser"
         Index           =   4
         Shortcut        =   {F6}
      End
      Begin VB.Menu sepWindow1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Global Config"
         Index           =   0
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "R&etrieval Config"
         Index           =   1
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Books Config"
         Index           =   2
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Remailers Config"
         Index           =   3
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "S&tats Config"
         Index           =   4
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   5
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Sen&d Profiles"
         Index           =   6
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Retrieval &Profiles"
         Index           =   7
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Ne&ws Profiles"
         Index           =   8
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Nym Accounts Registry"
         Index           =   9
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Addresses"
         Index           =   10
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   11
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Check Configuration"
         Index           =   12
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&User's Manual              F1"
         Index           =   0
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Beginner's Guide"
         Index           =   1
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Troubleshooting Guide"
         Index           =   2
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Remailer Reference"
         Index           =   3
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "-"
         Index           =   7
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "Open Default &Browser"
         Index           =   8
      End
   End
End
Attribute VB_Name = "frmNBook"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim NoFlip As Boolean, NoClick As Boolean, BookX As Integer
Dim Blk As Integer, BkChange As Boolean
Const MaxBlk = 30
Dim Rmlr(MaxBlk, MaxChain) As String
Dim AllDirect(MaxBlk, MaxChain) As String
Dim RemDirect(MaxChain) As String
Const MaxBD = 8
Dim BlockData(MaxBlk, MaxBD) As String
    'BLOCKDATA
    '0  Active chk
    '1  Folder txt
    '2  Prob txt
    '3  ToHead cbo txt
    '4  ToAddress cbo txt
    '5  Headers txt
    '6  Max-Size
    '7  Max-Count
    '8  Decrypt File opt
Const MaxNk = 40
Dim NkData(MaxNk) As String
Dim RBTag(MaxBlk) As String, RBChain(MaxBlk) As String

Const MaxSeed = 799 '32 passphrases of 25 char
Dim Seeds(MaxSeed) As Byte, SeedIx As Integer, TimerLast As Double
Dim SeedMix As Double, KeyLast As Byte, RandomOnly As Byte
Dim DiffLast As Double, XLast As Long, YLast As Long, XDiffLast As Long
Dim YDiffLast As Long
Dim StatsWarned As Boolean, AutomatePass As Boolean
'Dim SeedValue(MaxSeed) As String   'Debug only
'Dim Rep(64) As Integer   'Debug only

Private Sub chkNymComm_Click(Index As Integer)
    txtNull.SetFocus
    If Index = 2 And chkNymComm(2).Value = 0 And Not NoClick Then
        If MsgBox(LMsg(551), vbInformation + vbOKCancel) = vbCancel Then chkNymComm(2).Value = 1
    End If
End Sub

Private Sub chkQue_Click(Index As Integer)
    If Index = 1 Then
        If chkQue(1).Value = 0 Then Unload frmPreview
        If Not BookBusy(1, BookX) Then
            If chkQue(1).Value = 1 Then lblStat.Caption = LMsg(202) Else lblStat.Caption = LMsg(234)
        End If
        Exit Sub
    Else
        If chkQue(Index).Value = 0 Then Exit Sub
    End If
    CreateReq
End Sub

Private Sub CreateReq()
    Dim i As Integer, Max As MaxType, RemixMode As Byte, a As String
    Dim TempDirect(MaxChain) As String, TempRmlr(MaxChain) As String
    Dim hdr(1000) As String, Hdrs As String, MsgLen As Long
    Dim Prevu As Boolean, NymLog As String, TempLog As String
    
    On Error GoTo BookError
    If BookBusy(1, BookX) Then chkQue(0) = 0: Exit Sub
            
    'Close Rem Editor
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    
    UpdateData
    
    If LCase(PlainName(NymBookName(BookX), 2)) = "default" Or NkData(3) = "Automate" Then
        If MsgBox(LMsg(445), vbInformation + vbOKCancel) = vbCancel Then chkQue(0).Value = 0: Exit Sub
        mnuDisk_Click (3)
    End If
    Prevu = chkQue(1).Value = 1
    
    Me.MousePointer = 11
    BookBusy(1, BookX) = True
    chkQue(0).Enabled = False
    Me.Enabled = False
    
    'Clean
    cboNym.Text = Trim(cboNym.Text)
    Nym = cboNym.Text
    keyid = cboUserID.Text
    
    'Check
    lblStat.Caption = LMsg(208): lblStat.Refresh 'Checking message
    If CleanAddress(Nym) = "" Or Nym <> CleanAddress(Nym) Or Nym = "" Or InStr(Nym, " ") + InStr(Nym, "<") + InStr(Nym, Chr(34)) <> 0 Then Msg = LMsg(249): GoTo BookError
    nymserver = "config" + Mid(Nym, InStr(Nym, "@"))
    If Trim(keyid) = "" Then Msg = LMsg(250): GoTo BookError
    If InStr(txtName.Text, "@") + InStr(txtName.Text, Chr(34)) + InStr(txtName.Text, "<") + InStr(txtName.Text, ">") <> 0 Then Msg = LMsg(251): GoTo BookError
    
    'Check RBs
    Actives = 0
    If chkUpRB.Value = 1 Then
        For i = 1 To MaxBlk
            If Val(BlockData(i, 0)) = 1 Then
                Actives = Actives + 1
                'Valid Destination
                If Trim(BlockData(i, 3)) = "" Or Trim(BlockData(i, 4)) = "" Then
                    Msg = LMsg(257) + Str(i) + " " + LMsg(258)
                    GoTo BookError
                End If
                'Zero remailers warning
                If Val(Cnf(2, 4)) = 1 And (Rmlr(i, 0) = "" Or Rmlr(i, 1) = "") And Not ZeroWarn Then
                    If MsgBox(LMsg(259), vbExclamation + vbOKCancel + vbDefaultButton2, LMsg(148)) = vbCancel Then GoTo Leave
                    ZeroWarn = True
                End If
            End If
        Next i
        If Actives = 0 Then Msg = LMsg(262): GoTo BookError
    End If
        
    'Automate Book Replaced Passphrases?
    If AutomatePass Then
        MsgBox LMsg(556), vbExclamation
        AutomatePass = False
        GoTo Leave
    End If

    'NAR Open?
    If NkData(1) = True2 And NARLoaded Then If MsgBox(LMsg(401), vbQuestion + vbOKCancel, LMsg(402)) = vbCancel Then GoTo Leave
    
    'Write Book
    WriteBook (NymBookName(BookX))
    Me.MousePointer = 11
    
    'Start Request File
    Erase RBTag: Erase RBChain
    reqfn = GetWork
    n = FreeFile
    Open reqfn For Output As n
    'Header
    Print #n, "Config:"
    Print #n, "From: "; Extract(Nym, "@")
    NymLog = String(60, "=") + vbCrLf + Format(SafeTime, "ddd  dd mmm yy  hh:nn:ss") + "     " + NymBookName(BookX) + vbCrLf
    'Nym-Commands
    If chkAccount(1).Value = 0 Then
        For i = 0 To 6
            Select Case i
            Case 0: a = "acksend"
            Case 1: a = "signsend"
            Case 2: a = "cryptrecv"
            Case 3: a = "fixedsize"
            Case 4: a = "fingerkey"
            Case 5: a = "nobcc"
            Case 6: a = "disable"
            End Select
            If chkNymComm(i).Value = 1 Then b = "+" Else b = "-"
            c = c + b + a + " "
        Next i
        a = "Nym-Commands: create? " + Trim(c + Trim(txtNymComm.Text)) + " name=" + Chr(34) + Trim(txtName.Text) + Chr(34)
    Else
        a = "Nym-Commands: delete"
    End If
    Print #n, a
    NymLog = NymLog + a + vbCrLf
    
    'Public-Key
    If chkAccount(0).Value = 1 Or chkAccount(2).Value = 1 Then
        lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(271): lblStat.Refresh
        Print #n, "Public-Key:"
        a = PGPKey(keyid, ErrMsg, False)
        If InStr(a, "-----BEGIN PGP") = 0 Then
            Close n: n = 0
            DelFile reqfn
            Msg = ErrMsg
            GoTo BookError
        End If
        Print #n, a;
        NymLog = NymLog + "Public Key Added: " + keyid + vbCrLf
    End If
    'Reply-Blocks
    DontRepeat = ""
    If chkUpRB.Value = 1 Then
        For i = 1 To MaxBlk
            If Val(BlockData(i, 0)) = 1 Then
                rbcount = rbcount + 1
                Parts = LMsg(257) + Str(i) + " (" + Trim(Str(rbcount)) + "/" + Trim(Str(Actives)) + ")"
                lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(273) + " " + LCase(Parts): lblStat.Refresh
                Parts = "[" + Parts + "]"
                'Clean To
                BlockData(i, 3) = Trim(BlockData(i, 3))
                If Right(BlockData(i, 3), 1) <> ":" Then BlockData(i, 3) = BlockData(i, 3) + ":"
                'Check for Auto and count remailers
                Auto = False
                TempRmlr(0) = nymserver
                TempDirect(0) = AllDirect(i, 0)
                For j = 1 To MaxChain
                    TempRmlr(j) = Extract(Rmlr(i, j), " ")
                    TempDirect(j) = AllDirect(i, j)
                    r = LCase(TempRmlr(j))
                    If r = "" Then Exit For
                    If r = "auto" Then Auto = True
                Next j
                RCount = j
                TempDirect(RCount - 1) = BlockData(i, 3) + " " + BlockData(i, 4) + vbCrLf + TempDirect(RCount - 1)
                'Set Max
                If (cboMaxDate.Text <> "" Or BlockData(i, 6) <> "" Or BlockData(i, 7) <> "") And RCount > 1 And NkData(0) <> False2 Then
                    Max.NeedMax = True
                    Max.MaxDate = cboMaxDate.Text
                    Max.MaxSize = BlockData(i, 6)
                    Max.MaxCount = BlockData(i, 7)
                Else
                    Max.NeedMax = False
                End If
                If Auto Then
                    If Not StatsWarned And SafeTime - KeepDate(3) > 1 Then StatsWarned = True: If MsgBox(LMsg(428), vbInformation + vbOKCancel, LMsg(148)) = vbCancel Then Close n: n = 0: DelFile reqfn: GoTo Leave
                    'Pre-Check Remailers
                    For j = 0 To RCount - 1
                        r = TempRmlr(j)
                        If j = RCount - 1 Then
                            gNext = "": gFinal = ""
                            If NkData(4) = True2 Then RemixMode = 2 Else RemixMode = 0
                        Else
                            gNext = TempRmlr(j)
                            gFinal = ""
                            If NkData(4) = True2 Then RemixMode = 1 Else RemixMode = 0
                        End If
                        If j = 0 Then rtype = 2 Else rtype = 0
                        If Not GetDirect(r, TempDirect(j), rtype, j + 1, gNext, gFinal, False, True, MsgLen, d, Garbage, Max, False, i + 1, RemixMode) Then Close n: n = 0: DelFile reqfn: GoTo Leave
                    Next j
                    'Select Auto Remailers
TryAuto:            RBChain(i) = ""
                    For j = 1 To 4
                        For k = 1 To RCount - 1
                            TempRmlr(k) = Extract(Rmlr(i, k), " ")
                        Next k
                        AutoFailx = GetRandom(TempRmlr(), TempDirect(), RCount, 0, "", 0, Max.NeedMax, NkData(4) = True2)
                        If AutoFailx = -1 Then Exit For
                    Next j
                    If j = 5 Then
                        'Insufficient random
                        If MsgBox(LMsg(177) + " " + Trim(Str(i)) + "," + Str(AutoFailx) + vbCr + vbCr + LMsg(411), vbRetryCancel + vbCritical + vbDefaultButton2, LMsg(4)) = vbRetry Then GoTo TryAuto
                        Close n: n = 0: DelFile reqfn
                        GoTo Leave
                    End If
                    'List Random remailers
                    ra = ""
                    For k = 0 To RCount - 1
                        If LCase(Extract(Rmlr(i, k), " ")) = "auto" Then b = "*" Else b = ""
                        ra = ra + "     " + UCase(Left(TempRmlr(k), 1)) + Mid(TempRmlr(k), 2) + " " + b + vbCrLf
                        If k <> 0 Then
                            If RBChain(i) <> "" Then RBChain(i) = RBChain(i) + "|"
                            RBChain(i) = RBChain(i) + UCase(Left(TempRmlr(k), 1)) + Mid(TempRmlr(k), 2) + b
                        End If
                    Next k
                    If Prevu Then
                        'Show Random Remailers
                        x = MsgBox(LMsg(238) + ":" + vbCr + LMsg(257) + Str(i) + ":" + vbCr + vbCr + ra + vbCr + LMsg(239), vbQuestion + vbYesNoCancel, LMsg(240))
                        If x = vbCancel Then
                            Close n: n = 0: DelFile reqfn
                            GoTo Leave
                        End If
                        If x = vbNo Then GoTo TryAuto
                    End If
                End If
                'Build Reply-Block
                'Headers
                Hdrs = "": Erase hdr
                hdrx = ParseString(BlockData(i, 5), hdr(), 1000, False)
                For j = 0 To hdrx
                    y = InStr(hdr(j), ":")
                    If y = 0 Then
                        If Left(hdr(j), 1) <> " " Then
                            If MsgBox(LMsg(150), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
                        End If
                        hdr(j) = "    " + LTrim(hdr(j))
                    Else
                        b = LTrim(Mid(hdr(j), y + 1))
                        If b <> "" Then
                            If b Like "*[" + BinChars + "]*" Then
                                While EncoderBusy
                                    DoEvents
                                Wend
                                EncoderBusy = True
                                frmMain!NetCode1.DecodedData = b
                                frmMain!NetCode1.Format = 2 'f_QuotedPrintable
                                frmMain!NetCode1.Action = 4 'a_EncodeToString
                                b = "=?ISO-8859-1?Q?" + Replace(frmMain!NetCode1.EncodedData, " ", "_") + "?="
                                EncoderBusy = False
                            End If
                            hdr(j) = Trim(Left(hdr(j), y - 1)) + ": " + b
                        Else
                            hdr(j) = ""
                        End If
                    End If
                    If hdr(j) <> "" Then Hdrs = Hdrs + hdr(j) + vbCrLf
                Next j
                If InStr(1, Hdrs, "Subject:", vbTextCompare) <> 0 And InStr(1, BlockData(i, 3), "post-to", vbTextCompare) = 0 And InStr(1, Hdrs, "Newsgroups:", vbTextCompare) = 0 And Not SubWarn Then
                    If MsgBox(LMsg(263), vbExclamation + vbOKCancel, LMsg(148)) = vbCancel Then Close n: n = 0: DelFile reqfn: GoTo Leave
                    SubWarn = True
                End If
                If InStr(1, Hdrs, "Subject:", vbTextCompare) = 0 And (InStr(1, BlockData(i, 3), "post-to", vbTextCompare) <> 0 Or InStr(1, Hdrs, "Newsgroups:", vbTextCompare) <> 0) Then
                    If MsgBox(LMsg(257) + Str(i) + " " + LMsg(270), vbInformation + vbOKCancel, LMsg(148)) = vbCancel Then Close n: n = 0: DelFile reqfn: GoTo Leave
                End If
                'Body
                bd = GetWork
                p = FreeFile
                Open bd For Output As p
                Print #p,
                Close p: p = 0
                'Make Chain
                f = ChainMsg(bd, "", TempRmlr(), TempDirect(), RCount, 2, Hdrs, PData(10), Not Auto, Prevu, Parts, Me, Max, ErrMsg, NkData(4) = True2, 0, i, TempLog)
                DelFile bd
                'Max Added?
                If Max.NeedMax And Not Max.GotMax And f <> "" Then
                    If MsgBox(LMsg(257) + Str(i) + ":" + vbCr + LMsg(268), vbExclamation + vbOKCancel, LMsg(148)) = vbCancel Then ErrMsg = "": DelFile f: f = ""
                End If
                If f = "" Then
                    Close n: n = 0
                    DelFile reqfn
                    If ErrMsg = "" Then GoTo Leave
                    Msg = ErrMsg
                    GoTo BookError
                End If
                'Write to Req
                p = FreeFile
                Open f For Input As p
                If Trim(BlockData(i, 2)) <> "" And NkData(0) <> False2 Then a = " " + Trim(BlockData(i, 2)) Else a = ""
                Print #n, "Reply-Block:"; a
                NymLog = NymLog + "Reply-Block:" + a + "   [#" + Trim(Str(i)) + "]"
                While Not EOF(p)
                    Line Input #p, a
                    Print #n, a
                Wend
                Close p: p = 0
                'Enum RB
                NeedNum = False
                For k = 0 To MaxChain
                    If Rmlr(i, k) = "" Then Exit For
                    If InStr(1, AllDirect(i, k), "Encrypt-Key: ", vbTextCompare) + InStr(1, AllDirect(i, k), "Encrypt-3DES: ", vbTextCompare) + InStr(1, AllDirect(i, k), "Encrypt-CAST: ", vbTextCompare) <> 0 Then NeedEnum = True: Exit For
                Next k
                If NeedEnum Then
                    RBTag(i) = MakeTag(10)
                    Print #n, "ReplyBlockTag: "; RBTag(i)
                    NymLog = NymLog + " [Tag: " + RBTag(i) + "]"
                End If
                NymLog = NymLog + vbCrLf + TempLog
                DelFile f
            End If
        Next i
    End If
    Close n: n = 0
    
    'Update Registry
    If NkData(1) = True2 Then UpdateReg (chkUpRB.Value = 1)
    
    'Update Run Data
    If chkUpRB.Value = 1 Then
        NkData(9) = cboMaxDate.Text
        If NkData(9) <> "" Then
            lblLastDate.Caption = LMsg(256) + ": " + NkData(9)
            If DateVal(NkData(9)) > Int(SafeTime - gmtoffset) Then
                NkData(15) = Str(Int(DateVal(NkData(9)) - Int(SafeTime - gmtoffset)))
            End If
        Else: lblLastDate.Caption = ""
        End If
    End If
    
    'Update Log
    If NkData(2) = True2 Then
        If Len(NymLog) > 30994 Then NymLog = Left(NymLog, 30989) + "[...]"
        NymLog = NymLog + vbCrLf + vbCrLf + vbCrLf
        If Len(txtLog.Text) + Len(NymLog) > 31000 Then
            a = Left(txtLog.Text, 31000 - Len(NymLog))
            x = 0
            Do
                y = x
                x = InStr(x + 1, a, String(60, "=") + vbCrLf)
            Loop Until x = 0
            If y <> 0 Then a = Left(a, y - 1)
            txtLog.Text = a
        End If
        txtLog.Text = Left(NymLog + txtLog.Text, 31000)
        'Write Book
        WriteBook (NymBookName(BookX))
    End If

    'Open Msg Book
    nbk = NymBookName(BookX)
    fn = PlainName(nbk, 0) + PlainName(nbk, 2) + ".TBK"
    If SDir(fn) = "" Then fn = PlainName(nbk, 0) + PlainName(nbk, 2) + ".BK"
    If SDir(fn) = "" Then fn = PlainName(nbk, 0) + "Default.TBK"
    If SDir(fn) = "" Then fn = ProgDir + "\Books\Default.TBK"
    If SDir(fn) = "" Then
        fn = PlainName(nbk, 0) + "Default.TBK"
        n = FreeFile
        Open fn For Output As n
        Print #n, "JBN2_MSGBOOK"
        Print #n, "Jack B. Nymble Message Book - DO NOT EDIT THIS FILE"
        Print #n, "Delete this file at will."
        Print #n, "---Version"
        Print #n, Version
        Print #n,
        Close n: n = 0
    End If
OpenBook:
    For i = 0 To 9
        If MsgBookName(i) <> "" Then Exit For
    Next i
    If i = 10 Then
        'New window
        i = 0
        NewWin = True
        MsgBookName(i) = fn
        Set MsgBook(i) = New frmBook
        MsgBook(i).Tag = Str(i)
        MsgBook(i).Show
    End If
    
    MsgBook(i)!txtSubject.Tag = reqfn
    MsgBook(i)!cboNC.Tag = keyid
    MsgBook(i)!cboTo(1).Tag = nymserver
    MsgBook(i)!cboTo(2).Tag = NymBookName(BookX)
    MsgBook(i)!cboNym.Tag = fn
    MsgBook(i)!tmrReload.Tag = MsgBook(i)!tmrReload.Tag + "N"
    MsgBook(i)!tmrReload.Enabled = True
    
    lblStat.Caption = Trim(Str(Actives)) + " " + LMsg(272): lblStat.Refresh
Leave:
    If InStr(lblStat.Caption, LMsg(272)) = 0 Then lblStat.Caption = LMsg(207)
    Me.MousePointer = 0
    chkQue(0).Enabled = True
    chkQue(0).Value = 0
    Me.Enabled = True
    DontRepeat = ""
    Unload frmPreview
    BookBusy(1, BookX) = False
    tmrReload.Enabled = True
    frmMain!filExplore(0).Refresh
    If frmMain!filExplore(1).Visible Then frmMain!filExplore(1).Refresh
Exit Sub
BookError:
    EncoderBusy = False
    If Msg = "" Then Msg = LMsg(0)
    MsgBox Msg + vbCrLf + Error, vbCritical, LMsg(241)
    CloseFile n
    CloseFile p
    GoTo Leave
End Sub

Private Sub UpdateReg(UpdateRB As Boolean)
    Const MaxChunk = 100
    Dim ChunkDate(MaxChunk, 1) As Date
    Dim Chunk(MaxChunk) As String
    Const MaxChunkLines = 1000
    Dim ChunkLine(MaxChunkLines) As String
    Dim LowDate As Date
    Const MaxPassLen = 31000
    
    While NymDataBusy: DoEvents: Wend
    NymDataBusy = True
    RBTagLocation = ""
    'Nym present?
    nx = -1
    For i = 0 To MaxNyms
        If Nyms(i, 0) = "" Then Exit For
        If cboNym.Text = Nyms(i, 0) Then nx = i: Exit For
    Next i
    If nx = -1 And i < MaxNyms + 1 Then
        'Add new nym
        nx = i
        Nyms(nx, 0) = cboNym.Text
        Nyms(nx, 1) = ""
        Nyms(nx, 2) = ""
        Nyms(nx, 3) = cboUserID.Text
        'Get Passphrase
        px = -1
        For i = 0 To MaxNyms
            If KeyPass(i, 0) = "" Then Exit For
            If Extract(KeyPass(i, 0), "   ") = cboUserID.Text Then px = i: Exit For
        Next i
        If i < MaxNyms + 1 Then
            If px = -1 Then px = i
PassTry:    a = GetConvPass(LMsg(128))
            If Trim(a) <> "" Then b = GetConvPass(LMsg(132))
            If Trim(a) <> "" And a <> b Then
                If MsgBox(LMsg(139), vbCritical + vbRetryCancel, LMsg(140)) = vbRetry Then GoTo PassTry
            End If
            If Trim(a) <> "" And a = b Then
                KeyPass(px, 0) = cboUserID.Text
                KeyPass(px, 1) = Mid(XCrypt(a, LeftWin), 4)
            End If
            a = String(Len(a), "@")
            b = String(Len(b), "@")
            UpdateBooks ("M")
        End If
    End If
    'Update KeyID
    If chkAccount(2).Value = 0 Then
        If LCase(Extract(Nyms(nx, 3), "   ")) <> LCase(Extract(cboUserID.Text, "   ")) Then
            If MsgBox(LMsg(133) + vbCr + vbCr + Nyms(nx, 3), vbYesNo + vbQuestion, LMsg(131)) = vbYes Then Nyms(nx, 3) = cboUserID.Text
        End If
    End If
    'Update passphrases
    If UpdateRB Then
        curpass = Nyms(nx, 1)
        oldpass = Nyms(nx, 2)
        If curpass <> "" And InStr(1, curpass, "---block", vbTextCompare) = 0 Then curpass = "---block" + vbCrLf + curpass
        If curpass <> "" And InStr(1, curpass, "---endblock", vbTextCompare) = 0 Then curpass = curpass + vbCrLf + "---endblock" + vbCrLf
        oldpass = curpass + vbCrLf + oldpass
        curpass = Passphrases
        If Len(curpass) > MaxPassLen Then
            MsgBox LMsg(468), vbCritical, LMsg(4)
            curpass = ""
        End If
        If Len(oldpass) > MaxPassLen Then
            'Clean Old Passphrases
            'Get Chunks
            chunkcount = 0
            y = 1
            x = InStr(1, oldpass, "---block", vbTextCompare)
            Do While x <> 0 And chunkcount <= MaxChunk
                'Get block chunk
                z = InStr(x + 8, oldpass, "---endblock", vbTextCompare)
                If z = 0 Then z = Len(oldpass) + 1
                tempchunk = Mid(oldpass, x, z - x)
                t = ParseString(tempchunk, ChunkLine(), MaxChunkLines, False)
                For i = 0 To t
                    u = InStr(ChunkLine(i), ":")
                    If (Left(ChunkLine(i), 1) = " " Or Left(ChunkLine(i), 1) = vbTab) And u <> 0 Then
                        a = LCase(Replace(Trim(Left(ChunkLine(i), u - 1)), vbTab, ""))
                        j = -1
                        If a = "created" Then
                            j = 0
                        ElseIf a = "used" Then
                            j = 1
                        End If
                        If j <> -1 Then
                            LowDate = DateVal(Trim(Mid(ChunkLine(i), u + 1)))
                            If LowDate > ChunkDate(chunkcount, j) Then ChunkDate(chunkcount, j) = LowDate
                        End If
                    End If
                    Chunk(chunkcount) = Chunk(chunkcount) + ChunkLine(i) + vbCrLf
                    If i = t And InStr(1, ChunkLine(i), "---endblock", vbTextCompare) = 0 Then Chunk(chunkcount) = Chunk(chunkcount) + "---endblock" + vbCrLf
                Next i
                chunkcount = chunkcount + 1
                y = z
                x = InStr(y, oldpass, "---block", vbTextCompare)
            Loop
            'Trim
            For desperate = 0 To 4
                repeatscan = True
                Do While repeatscan
                    Select Case desperate
                    Case 0
                        'Nothing, just reassemble
                        repeatscan = False
                    Case 1
                        'Remove No dates
                        repeatscan = True
                        For i = chunkcount - 1 To 0 Step -1
                            If Chunk(i) <> "" And ChunkDate(i, 0) = 0 And ChunkDate(i, 1) = 0 Then Chunk(i) = "": Exit For
                        Next i
                        If i = -1 Then Exit Do
                    Case 2
                        'No Dates have been removed
                        'Remove Oldest Unused
                        repeatscan = True
                        LowDate = 0: lowchunk = -1
                        For i = chunkcount - 1 To 0 Step -1
                            If Chunk(i) <> "" And ChunkDate(i, 1) = 0 And (ChunkDate(i, 0) < LowDate Or LowDate = 0) Then LowDate = ChunkDate(i, 0): lowchunk = i
                        Next i
                        If lowchunk = -1 Then Exit Do
                        Chunk(lowchunk) = ""
                    Case 3
                        'All unused have been removed
                        'Remove Oldest Used
                        repeatscan = True
                        LowDate = 0: lowchunk = -1
                        For i = chunkcount - 1 To 0 Step -1
                            If Chunk(i) <> "" Then
                                If ChunkDate(i, 1) <> 0 Then j = 1 Else j = 0
                                If (ChunkDate(i, j) < LowDate Or LowDate = 0) Then LowDate = ChunkDate(i, j): lowchunk = i
                            End If
                        Next i
                        If lowchunk = -1 Then Exit Do
                        Chunk(lowchunk) = ""
                    Case Else
                        'Clear
                        newpass = ""
                        Exit Do
                    End Select
                    'Reassemble chunks
                    newpass = ""
                    For i = 0 To chunkcount - 1
                        If Chunk(i) <> "" Then newpass = newpass + Chunk(i) + vbCrLf
                    Next i
                    If Len(newpass) <= MaxPassLen Then Exit For
                Loop
            Next desperate
        Else
            newpass = oldpass
        End If
        Nyms(nx, 1) = curpass
        Nyms(nx, 2) = newpass
    End If
    NymDataBusy = False
    SaveConfig
    If NARLoaded Then
        frmCfNym!tmrReload.Tag = frmCfNym!tmrReload.Tag + "P"
        frmCfNym!tmrReload.Enabled = True
    End If
End Sub

Private Sub WriteBook(fn)
    Me.MousePointer = 11
    lblStat.Caption = LMsg(124) + " " + fn: Me.Refresh

    'Set NkData
    NkData(3) = "Nautomate"
    NkData(8) = cboMaxDate.Text
    NkData(10) = cboNym.Text
    NkData(11) = cboUserID.Text
    For i = 0 To 2
        NkData(12 + i) = Str(chkAccount(i).Value)
    Next i
    NkData(16) = Str(chkUpRB.Value)
    NkData(17) = txtName.Text
    NkData(18) = txtNymComm.Text
    NkData(19) = Str(chkQue(1).Value)
    For i = 0 To 6
        NkData(20 + i) = Str(chkNymComm(i).Value)
    Next i
    'Clear Unused data
    For i = 0 To MaxBlk
        For j = 0 To MaxChain
            If Rmlr(i, j) = "" Then Exit For
        Next j
        For k = j To MaxChain
            Rmlr(i, k) = ""
            AllDirect(i, k) = ""
        Next k
    Next i

    On Error GoTo WriteError
    n = FreeFile
    Open fn For Output As n
    Print #n, "JBN2_NYMBOOK"
    Print #n, "Jack B. Nymble Nym Book - DO NOT EDIT THIS FILE"
    Print #n, "Delete this file at will."
    Print #n, "---Version"
    Print #n, Version
    Print #n,
    WriteArray n, NkData(), "NKData", MaxNk, -1, False
    WriteArray n, BlockData(), "BlockData", MaxBlk, MaxBD, False
    WriteArray n, Rmlr(), "Remailer", MaxBlk, MaxChain, False
    WriteArray n, AllDirect(), "AllDirect", MaxBlk, MaxChain, False
    Print #n, "---Notes"
    If InStr(txtNotes.Text, Chr(0)) <> 0 Then txtNotes.Text = Replace(txtNotes.Text, Chr(0), " ")
    If InStr(txtNotes.Text, Chr(26)) <> 0 Then txtNotes.Text = Replace(txtNotes.Text, Chr(26), " ")
    Print #n, txtNotes.Text;
    Print #n, EndPart
    If InStr(txtLog.Text, Chr(0)) <> 0 Then txtLog.Text = Replace(txtLog.Text, Chr(0), " ")
    If InStr(txtLog.Text, Chr(26)) <> 0 Then txtLog.Text = Replace(txtLog.Text, Chr(26), " ")
    Print #n, txtLog.Text;
    Close n: n = 0
    lblStat.Caption = LMsg(118) + " " + fn
    frmMain!filExplore(0).Refresh
    If frmMain!filExplore(1).Visible Then frmMain!filExplore(1).Refresh
    Me.MousePointer = 0
    BkChange = False
Exit Sub
WriteError:
    lblStat.Caption = LMsg(82) + " " + fn
    MsgBox LMsg(82) + " " + fn + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
    Me.MousePointer = 0
End Sub

Private Function ReadBook(fn) As Boolean
    Dim a As String, b As String
    
    Me.MousePointer = 11
    lblStat.Caption = LMsg(123) + " " + fn: Me.Refresh
    BkChange = False
    Erase NkData
    ClearData
    
    On Error GoTo ReadError
    n = FreeFile
    Open fn For Input As n
    Line Input #n, a
    Select Case a
    Case "JBN2_NYMBOOK"
        Do While Not EOF(n)
            Line Input #n, a
            Select Case a
            Case "-=-NKData"
                x = ReadArray(n, NkData(), MaxNk, -1)
            Case "-=-BlockData"
                ReadArray n, BlockData(), MaxBlk, MaxBD
            Case "-=-Remailer"
                ReadArray n, Rmlr(), MaxBlk, MaxChain
            Case "-=-AllDirect"
                ReadArray n, AllDirect(), MaxBlk, MaxChain
            Case "---Notes"
                b = Input(LOF(n) - Seek(n) + 1, n)
                x = InStr(b, EndPart): If x = 0 Then x = Len(b) + 1
                txtNotes.Text = Left(Left(b, x - 1), 31000)
                txtLog.Text = Left(Mid(b, x + Len(EndPart) + 2), 31000)
            End Select
        Loop
    Case "JBN_NYMBOOK"
        NkData(0) = True2
        NkData(1) = True2
        NkData(2) = True2
        NkData(7) = "Anon-To: $next" + vbCrLf
        Do While Not EOF(n)
            Line Input #n, a
            Select Case a
            Case "---Settings"
                While a <> NextPart
                    Line Input #n, a
                    If a = "Remix" Then NkData(4) = True2
                Wend
            Case "---Header"
                Do
                    Line Input #n, a
                    x = InStr(a, ": ")
                    If x <> 0 Then
                        b = Right(a, Len(a) - x - 1)
                        Select Case Left(a, x - 1)
                        Case "From"
                            NkData(10) = b
                        Case "UserID"
                            NkData(11) = b
                        Case "SendKey"
                            NkData(12) = b
                        Case "Delete"
                            If b = True2 Then NkData(13) = 1
                        Case "Name"
                            NkData(17) = b
                        Case "N-C"
                            NkData(18) = b
                        Case "Nym-Commands"
                            If InStr(b, "+acksend") <> 0 Then NkData(20) = "1"
                            If InStr(b, "+signsend") <> 0 Then NkData(21) = "1"
                            If InStr(b, "+cryptrecv") <> 0 Then NkData(22) = "1"
                            If InStr(b, "+fixedsize") <> 0 Then NkData(23) = "1"
                            If InStr(b, "+fingerkey") <> 0 Then NkData(24) = "1"
                            If InStr(b, "+nobcc") <> 0 Then NkData(25) = "1"
                            If InStr(b, "+disable") <> 0 Then NkData(26) = "1"
                        Case "Reply-Block"
                            NkData(16) = b
                        End Select
                    End If
                Loop Until a = ""
            Case "---Reply-Block"
                Line Input #n, a
                If Left(a, 8) = "Number: " Then
                    i = Val(Right(a, Len(a) - 8))
                    If i > 0 And i <= MaxBlk Then
                        Do
                            Line Input #n, a
                            x = InStr(a, ": ")
                            If x <> 0 Then
                                b = Right(a, Len(a) - x - 1)
                                Select Case Left(a, x - 1)
                                Case "Active"
                                    BlockData(i, 0) = b
                                Case "Prob"
                                    BlockData(i, 2) = b
                                Case "ToHead"
                                    If LCase(Trim(b)) = "request-remailing-to:" Then b = "Anon-To:"
                                    BlockData(i, 3) = b
                                Case "To"
                                    BlockData(i, 4) = b
                                Case "XHead0"
                                    xhead0 = b
                                Case "XHead1"
                                    xhead1 = b
                                Case "XHeadVal0"
                                    If xhead0 <> "" Then BlockData(i, 5) = BlockData(i, 5) + xhead0 + " " + b + vbCrLf
                                Case "XHeadVal1"
                                    If xhead1 <> "" Then BlockData(i, 5) = BlockData(i, 5) + xhead1 + " " + b + vbCrLf
                                Case "XXHead0"
                                    BlockData(i, 5) = BlockData(i, 5) + b + vbCrLf
                                Case "XXHead1"
                                    BlockData(i, 5) = BlockData(i, 5) + b + vbCrLf
                                Case "Remailers"
                                    t = 0
                                    Do
                                        Line Input #n, c
                                        Rmlr(i, t) = Extract(c, " ")
                                        If c <> "" Then
                                            Remix = False
                                            x = InStr(c, "     ;")
                                            While x <> 0
                                                h = Extract(Extract(Mid(c, x + 6), "     ;"), "::")
                                                If InStr(1, h, "Remail-To", vbTextCompare) <> 0 Then h = "Remail-To: $next": Remix = True
                                                If InStr(1, h, "Encrypt-To", vbTextCompare) <> 0 Then h = "Encrypt-To: $next": Remix = True
                                                If InStr(1, h, "Remix-To", vbTextCompare) <> 0 Then h = "Remix-To: $next": Remix = True
                                                AddHeader AllDirect(i, t), h
                                                x = InStr(x + 6, c, "     ;")
                                            Wend
                                            If Not Remix Then AllDirect(i, t) = "Anon-To: $next" + vbCrLf + AllDirect(i, t)
                                        End If
                                        t = t + 1: If t > MaxChain Then Exit Do
                                    Loop Until c = ""
                                End Select
                            End If
                        Loop Until a = ""
                    End If
                End If
            End Select
        Loop
        MsgBox LMsg(102), vbExclamation, LMsg(103)
    Case Else
        Close n: n = 0
        lblStat.Caption = LMsg(108) + " " + fn
        MsgBox LMsg(85) + " " + fn, vbCritical, LMsg(4)
        Me.MousePointer = 0
        ReadBook = False
        Exit Function
    End Select
    Close n: n = 0
    
    'Set
    cboNym.Text = NkData(10)
    cboUserID.Text = NkData(11)
    For i = 0 To 2
        chkAccount(i).Value = 0
    Next i
    chkUpRB.Value = Val(NkData(16))
    For i = 0 To 2
        If Val(NkData(12 + i)) = 1 Then chkAccount(i).Value = 1
        mnuOption(i).Checked = NkData(i) = True2
    Next i
    mnuOption(4).Checked = NkData(4) = True2
    mnuOption(0).Checked = Not mnuOption(0).Checked
    mnuOption_Click (0)
    
    If Trim(NkData(8)) <> "" Then
        If Val(NkData(15)) = 0 Then NkData(15) = "28"
        a = DateLine(0, SafeTime + Val(NkData(15)))
        x = 0
        For j = 1 To 3
            x = InStr(x + 1, a, " ")
        Next j
        If x <> 0 Then cboMaxDate.Text = Left(a, x - 1) Else cboMaxDate.Text = NkData(8)
    Else
        cboMaxDate.Text = ""
    End If
    If NkData(9) <> "" Then lblLastDate.Caption = LMsg(256) + ": " + NkData(9) Else lblLastDate.Caption = ""
    txtName.Text = NkData(17)
    txtNymComm.Text = NkData(18)
    If NkData(19) = True2 Then chkQue(1).Value = 1
    If NkData(27) = "" Then NkData(27) = lblEncryptKey.Caption
    lblEncryptKey.Caption = NkData(27)
    
    NoClick = True
    For i = 0 To 6
        chkNymComm(i).Value = Val(NkData(20 + i))
    Next i
    NoClick = False
    For i = 1 To MaxBlk
        tabRB.Tabs(i).Caption = Trim(Str(i)) + Left("*", Val(BlockData(i, 0)))
    Next i
    Blk = 1
    NoClick = True
    tabRB.Tabs(1).Selected = True
    NoClick = False
    UpdateBlock
    
    BkChange = False
    lblStat.Caption = LMsg(107) + " " + fn
    Me.Caption = PlainName(NymBookName(BookX), 2) + " - " + LMsg(368)
    If NkData(3) = "Automate" Then Set tabNym.SelectedItem = tabNym.Tabs(3)
    AutomatePass = NkData(3) = "Automate"
    Me.MousePointer = 0
    ReadBook = True
Exit Function
ReadError:
    lblStat.Caption = LMsg(108) + " " + fn
    MsgBox LMsg(106) + " " + fn + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
    BkChange = False
    Me.MousePointer = 0
    ReadBook = False
End Function




Private Sub cmdRemEdit_Click(Index As Integer)
    Select Case Index
    Case 0
        'OK
        If fraRemEdit.Visible Then
            BkChange = True
            If Right(txtHeaders(2).Text, 2) <> vbCrLf Then If txtHeaders(2).Text <> "" Then txtHeaders(2).Text = txtHeaders(2).Text + vbCrLf
            UpRemData Me, RemDirect(Val(lstRemailers.Tag))
            ShowRemEdit (False)
            lstRemailers_Click
        End If
    Case 1
        'Cancel
        If lstRemailers.ListIndex = -1 Then cmdRemEdit_Click (0): Exit Sub
        If lstRemailers.List(lstRemailers.ListIndex) = "" Then cmdRemEdit_Click (0): Exit Sub
        lstRemailers.Tag = ""
        lstRemailers.List(lstRemailers.ListIndex) = RemDisp(lstRemailers.List(lstRemailers.ListIndex), RemDirect(lstRemailers.ListIndex))
        ShowRemEdit (False)
        lstRemailers_Click
    Case 2
        'Set Default
        txtHeaders(2).SetFocus
        If MsgBox(LMsg(74) + vbCrLf + vbCrLf + LMsg(75), vbExclamation + vbYesNo + vbDefaultButton2, LMsg(76)) = vbNo Then Exit Sub
        If Replace(Replace(txtHeaders(2).Text, " ", ""), vbCrLf, "") = "" Then txtHeaders(2).Text = ""
        NkData(7) = txtHeaders(2).Text
        BkChange = True
    End Select
End Sub

Private Sub cboRemailer_click()
    BkChange = True
    x = lstRemailers.ListIndex
    If x = -1 Or x = 0 Then x = lstRemailers.ListCount - 1
    If x = lstRemailers.ListCount - 1 Then Job = 0 Else Job = 1
    If Job = 0 And lstRemailers.ListCount > MaxChain Then Exit Sub
    AddRemailer cboRemailer.Text, x, Job
End Sub

Private Sub cboRemailer_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = 38 Or KeyCode = 40 Then KeyCode = 0
End Sub

Private Sub cboRemailer_KeyUp(KeyCode As Integer, Shift As Integer)
    If KeyCode = 38 Or KeyCode = 40 Then KeyCode = 0: Exit Sub
    If cboRemailer.Text = "Nym-Server" Then Exit Sub
    x = lstRemailers.ListIndex
    If x = -1 Or x = 0 Then x = lstRemailers.ListCount - 1
    If x = lstRemailers.ListCount - 1 Then
        x = lstRemailers.ListIndex: If x = -1 Or x = 0 Then x = 1
        cboRemailer_click
        If x < lstRemailers.ListCount Then lstRemailers.ListIndex = x
        cboRemailer.SetFocus
        cboRemailer.SelStart = Len(cboRemailer.Text)
        cboRemailer.SelLength = 0
    Else
        rn = Extract(LTrim(cboRemailer.Text), " ")
        If rn = "" Or rn = "Nym-Server" Then rn = "AUTO"
        y = InStr(lstRemailers.List(x), " ")
        If y = 0 Then y = Len(lstRemailers.List(x)) + 1
        lstRemailers.List(x) = RemDisp(rn, RemDirect(x))
        If fraRemEdit.Visible Then ShowRemailer Me, x, BookRType
    End If
End Sub

Private Sub cboRemailer_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then lstRemailers_DblClick
End Sub

Private Sub AddRemailer(ByVal rn As String, x, Job)
    BkChange = True
    rn = Extract(LTrim(rn), " ")
    If rn = "" Then rn = "AUTO"
    If Job = 0 Then
        'Add remailer
        If fraRemEdit.Visible Then UpRemData Me, RemDirect(Val(lstRemailers.Tag))
        If NkData(7) = "" Then NkData(7) = "Anon-To: $next" + vbCrLf
        rd = NkData(7)
        If rn <> "AUTO" Then
            cboLatent.Text = Trim(cboLatent.Text)
            If cboLatent.Text <> "" Then AddHeader rd, "Latent-Time: " + cboLatent.Text
            If txtPass.Text <> "" Then AddHeader rd, lblEncryptKey.Caption = " " + txtPass.Text
            If cboInflate.Text <> "" Then AddHeader rd, "Inflate: " + cboInflate.Text
            If cboRandHop.Text <> "" Then AddHeader rd, "Rand-Hop: " + cboRandHop.Text
        End If
        lstRemailers.AddItem RemDisp(rn, rd), x
        For i = lstRemailers.ListCount - 2 To x Step -1
            RemDirect(i + 1) = RemDirect(i)
        Next i
        RemDirect(lstRemailers.NewIndex) = rd
        If fraRemEdit.Visible Then lstRemailers.Tag = Str(x + 1)
        If rn = "AUTO" Then
            lstRemailers.ListIndex = lstRemailers.NewIndex
        Else
            lstRemailers.ListIndex = x + 1
        End If
        lstRemailers_Click
    Else
        'Change remailer
        y = InStr(lstRemailers.List(x), " ")
        If y = 0 Then y = Len(lstRemailers.List(x)) + 1
        lstRemailers.List(x) = RemDisp(rn, RemDirect(x))
        lstRemailers.ListIndex = x + 1
        lstRemailers_Click
    End If
End Sub

Private Sub cmdRemailer_Click(Index As Integer)
    BkChange = True
    Select Case Index
    Case 0
        'Add
        x = lstRemailers.ListIndex
        If x = -1 Or x = 0 Then x = lstRemailers.ListCount - 1
        If lstRemailers.ListCount > MaxChain Then Exit Sub
        AddRemailer "AUTO", x, 0
    Case 1
        'Remove
        x = lstRemailers.ListIndex
        If x = -1 Or x = 0 Then Exit Sub
        If lstRemailers.List(x) = "" Then Exit Sub
        lstRemailers.RemoveItem x
        For i = x To lstRemailers.ListCount - 2
            RemDirect(i) = RemDirect(i + 1)
        Next i
        lstRemailers.Tag = ""
        lstRemailers.ListIndex = x
    Case 2
        'Clear
        lstRemailers.Clear
        lstRemailers.AddItem "Nym-Server"
        lstRemailers.AddItem ""
        cboLatent.Text = ""
        cboRemailer.Text = ""
        Erase RemDirect
        If NkData(7) = "" Then NkData(7) = "Anon-To: $next" + vbCrLf
        RemDirect(0) = NkData(7)
        If fraRemEdit.Visible Then ShowRemData Me, "", 0: cboRemEdit.Locked = x = 0
    End Select
End Sub

Private Sub cboLatent_Click()
    If NoClick Then Exit Sub
    BkChange = True
    UpdateHeader "Latent-Time: ", cboLatent.Text
End Sub

Private Sub cboLatent_Change()
    cboLatent_Click
End Sub












Private Sub mnuConfigBook_Click()
    ShowConfig (ConfigBooks)
End Sub

Private Sub mnuConfigRem_Click()
    ShowConfig (ConfigRemailers)
End Sub

Private Sub mnuDisk_Click(Index As Integer)
    On Error GoTo DiskError
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    UpdateData
    Select Case Index
    Case 0
        'Open
Query:
        If BkChange And Val(Cnf(2, 2)) = 1 Then
            Select Case MsgBox(LMsg(119), vbQuestion + vbYesNoCancel, NymBookName(BookX))
            Case vbCancel
                Exit Sub
            Case vbYes
                WriteBook (NymBookName(BookX))
                GoTo Query
            End Select
        End If
        a = OpenDialog(PlainName(NymBookName(BookX), 0), "", LMsg(67), _
            cdlOFNHideReadOnly + cdlOFNFileMustExist, _
            "Nym Books (*.NBK)|*.NBK|All Files (*.*)|*.*", 1, Me)
        If a <> "" Then
            NymBookName(BookX) = a
            ReadBook (a)
        End If
    Case 1
        'Reopen
        a = NymBookName(BookX)
        If SDir(a) = "" Then MsgBox LMsg(66) + vbCr + a, vbCritical, LMsg(66): Exit Sub
        If BkChange And Val(Cnf(2, 2)) = 1 Then If MsgBox(LMsg(120), vbQuestion + vbOKCancel, NymBookName(BookX)) = vbCancel Then Exit Sub
        NymBookName(BookX) = a
        ReadBook (a)
    Case 2
        'Save
        WriteBook (NymBookName(BookX))
    Case 3
        'Save As
        ext = LCase(PlainName(NymBookName(BookX), 3))
        If ext = "nbk" Then fx = 1 Else fx = 2
        If fx = 2 Then a = PlainName(NymBookName(BookX), 1) Else a = PlainName(NymBookName(BookX), 2)
        If Val(Cnf(2, 0)) = 1 Then x = cdlOFNOverwritePrompt Else x = 0
        b = SaveDialog(PlainName(NymBookName(BookX), 0), a, LMsg(109), _
            cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn + x, _
            "Nym Books (*.NBK)|*.NBK|All Files (*.*)|*.*", fx, Me)
        If b <> "" Then
            For i = 0 To 9
                If LCase(a) = LCase(NymBookName(i)) And i <> BookX Then
                    MsgBox LMsg(110), vbCritical, LMsg(4)
                    Exit Sub
                End If
            Next i
            WriteBook (b)
            NymBookName(BookX) = b
            lblStat.Caption = LMsg(111) + " " + b
            Me.Caption = PlainName(NymBookName(BookX), 2) + " - " + LMsg(368)
            'UpdateDisp
        End If
    Case 9, 10
        'Close / Save and Close
        If Index = 10 Then WriteBook (NymBookName(BookX))
        Unload Me
    End Select
Exit Sub
DiskError:
    MsgBox LMsg(0) + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
End Sub

Private Sub mnuEnumRB_Click()
    mnuEnumRB.Checked = Not mnuEnumRB.Checked
    NkData(3) = mnuEnumRB.Checked
End Sub

Private Sub mnuPGPRing_Click(Index As Integer)
    If Index = 0 Then
        SelectKey (LMsg(415))
    Else
        If Val(PData(12)) = 0 Then
            'PGP 2.6.x
            DOSShell "pgp -kg", 99, "NUL", "", "", 1
        Else
            MsgBox LMsg(416), vbInformation
        End If
    End If
End Sub

Private Sub mnuShowAuto_Click()
    GetRandom RemDirect(), RemDirect(), 0, BookRType, "", 0, False, False
End Sub

Private Sub mnuStats_Click(Index As Integer)
    Select Case Index
    Case 0  'Refresh Stats
        lblStat.Caption = LMsg(394)
        CallBrowser 1, ""
    Case 1  'View Stats
        CallBrowser 0, ProgDir + "\Stats\stats.htm"
    Case 2 'Update CPunk Keys
        CallBrowser 2, ""
    End Select
End Sub

Private Sub mnuTools_Click()
    x = InStr(1, txtXHeaders.Text, "subject:", vbTextCompare)
    If x <> 0 Then If LTrim(Extract(Mid(txtXHeaders.Text, x + 8), vbCrLf)) = "" Then x = 0
    mnuExport.Enabled = (tabNym.SelectedItem.Index = 2 And x <> 0)
End Sub

Private Sub mnuExportSub_Click(Index As Integer)
    Dim Tmp(20) As String
    x = InStr(1, txtXHeaders.Text, "subject:", vbTextCompare)
    If x <> 0 Then
        s = Trim(Extract(Mid(txtXHeaders.Text, x + 8), vbCrLf))
        If s <> "" Then
            If lstRemailers.ListCount > 2 Then
                y = InStr(1, RemDirect(lstRemailers.ListCount - 2), "encrypt-subject:", vbTextCompare)
                If y <> 0 Then
                    es = Trim(Extract(Mid(RemDirect(lstRemailers.ListCount - 2), y + 16), vbCrLf))
                    If es <> "" Then s = "Esub: " + s + " % " + es
                End If
            End If
        Else
            x = 0
        End If
    End If
    If s <> "" Then
        'Add Subject
        If InStr(UserProf(31 + Index, 12), s + vbCrLf) = 0 Then
            If Right(UserProf(31 + Index, 12), 2) <> vbCrLf And UserProf(31 + Index, 12) <> "" Then UserProf(31 + Index, 12) = UserProf(31 + Index, 12) + vbCrLf
            UserProf(31 + Index, 12) = UserProf(31 + Index, 12) + s + vbCrLf
        End If
        'Add Newsgroups
        x = InStr(1, txtXHeaders.Text, "newsgroups:", vbTextCompare)
        If x <> 0 Then
            ng = Trim(Extract(Mid(txtXHeaders.Text, x + 11), vbCrLf))
        Else
            If InStr(1, cboToHead.Text, "post-to:", vbTextCompare) <> 0 Then ng = Trim(cboTo.Text)
        End If
        If Right(UserProf(31 + Index, 11), 2) <> vbCrLf And UserProf(31 + Index, 11) <> "" Then UserProf(31 + Index, 11) = UserProf(31 + Index, 11) + vbCrLf
        ng = Replace(ng, ",", vbCrLf)
        x = ParseString(ng, Tmp(), 20, False)
        For i = 0 To x
            If Trim(Tmp(i)) <> "" Then
                If InStr(1, UserProf(31 + Index, 11), Trim(Tmp(i)) + vbCrLf) = 0 Then
                    UserProf(31 + Index, 11) = UserProf(31 + Index, 11) + Trim(Tmp(i)) + vbCrLf
                End If
            End If
        Next i
        s = LMsg(553) + vbCr + vbCr + UserProf(31 + Index, 5) + ":" + vbCr + vbCr + "    " + s + vbCr + vbCr + ng
        If Not CheckingConfig Then CheckConfig ("News")
    Else
        s = LMsg(554)
    End If
    MsgBox s, vbInformation
End Sub

'MS ingenuity: Doesn't fire if click current tab
'Private Sub tabNym_BeforeClick(Cancel As Integer)
'    If tabNym.SelectedItem.Index = 2 Then
'        If fraRemEdit.Visible Then cmdRemEdit_Click (0)
'        UpdateData
'    End If
'End Sub

Private Sub tabNym_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If tabNym.SelectedItem.Index = 2 Then
        If fraRemEdit.Visible Then cmdRemEdit_Click (0)
        UpdateData
    End If
End Sub

Private Sub tabNym_Click()
    fraNym(tabNym.SelectedItem.Index - 1).ZOrder
    If tabNym.SelectedItem.Index = 2 Then
        chkUpRB_Click
        tabRB_Click
    Else
        CountRB
    End If
    If tabNym.SelectedItem.Index = 3 Then txtNotes.SetFocus
    If tabNym.SelectedItem.Index = 4 Then txtLog.SetFocus
End Sub

Private Sub txtLog_Change()
    BkChange = True
End Sub

Private Sub txtNotes_Change()
    BkChange = True
End Sub

Private Sub lblEncryptKey_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    If lblEncryptKey.Font.Underline Then
        If Button = vbLeftButton Then x = 1 Else x = 2
        For i = 1 To x
            Select Case lblEncryptKey.Caption
            Case "Encrypt-Key:"
                lblEncryptKey.Caption = "Encrypt-3DES:"
            Case "Encrypt-3DES:"
                lblEncryptKey.Caption = "Encrypt-CAST:"
            Case "Encrypt-CAST:"
                lblEncryptKey.Caption = "Encrypt-Key:"
            End Select
        Next i
    Else
        lblEncryptKey.Caption = "Encrypt-Key:"
    End If
    NkData(27) = lblEncryptKey.Caption
    lstRemailers_Click
End Sub

Private Sub txtPass_Change()
    If NoClick Then Exit Sub
    UpdateHeader lblEncryptKey.Caption + " ", txtPass.Text
End Sub

Private Sub cboInflate_Click()
    If NoClick Then Exit Sub
    UpdateHeader "Inflate: ", cboInflate.Text
End Sub

Private Sub cboInflate_Change()
    cboInflate_Click
End Sub

Private Sub cboRandHop_Click()
    If NoClick Then Exit Sub
    UpdateHeader "Rand-Hop: ", cboRandHop.Text
End Sub

Private Sub cboRandHop_Change()
    cboRandHop_Click
End Sub

Private Sub chkTo_Click(Index As Integer)
    If NoClick Then Exit Sub
    If chkTo(Index).Value = 1 Then a = "$next" Else a = ""
    Select Case Index
    Case 0: UpdateHeader "Remix-To: ", a
    Case 1: UpdateHeader "Encrypt-To: ", a
    Case 2: UpdateHeader "Anon-To: ", a
    End Select
End Sub

Private Sub UpdateHeader(h, hh)
    BkChange = True
    x = lstRemailers.ListIndex
    If x = -1 Then Exit Sub
    If lstRemailers.List(x) = "" Then Exit Sub
    If fraRemEdit.Visible Then rd = txtHeaders(2).Text Else rd = RemDirect(x)
    AddHeader rd, h + hh
    If fraRemEdit.Visible Then
        txtHeaders(2).Text = rd
    Else
        RemDirect(x) = rd
        lstRemailers.List(x) = RemDisp(lstRemailers.List(x), rd)
    End If
End Sub

Private Sub lstRemailers_Click()
    Dim temp(100) As String

    x = lstRemailers.ListIndex
    If x = -1 Then Exit Sub
    If fraRemEdit.Visible Then
        UpRemData Me, RemDirect(Val(lstRemailers.Tag))
        ShowRemData Me, RemDirect(x), 0
        BkChange = True
        'X? txtRemEdit.tag = X = 0
    End If
    l = lstRemailers.List(x)
    
    NoClick = True
    cboLatent.Text = ""
    txtPass.Text = ""
    cboInflate.Text = ""
    cboRandHop.Text = ""
    For i = 0 To 2
        chkTo(i).Value = 0
    Next i

    If l = "" Then x = -1 Else x = ParseString(RemDirect(x), temp(), 100, False)
    For i = 0 To x
        x = InStr(temp(i), ":")
        If x <> 0 Then
            a = LCase(Trim(Left(temp(i), x - 1)))
            b = Trim(Extract(Mid(temp(i), x + 1), vbCrLf))
            If b <> "" Then
                Select Case a
                Case "latent-time"
                    cboLatent.Text = b
                Case LCase(Extract(lblEncryptKey.Caption, ":")) ' "encrypt-key"
                    txtPass.Text = b
                Case "inflate"
                    cboInflate.Text = b
                Case "rand-hop"
                    cboRandHop.Text = b
                Case "remix-to"
                    chkTo(0).Value = 1
                Case "encrypt-to"
                    chkTo(1).Value = 1
                Case "anon-to"
                    chkTo(2).Value = 1
                End Select
            End If
        End If
    Next i
    NoClick = False
    cboRemailer.Text = Extract(lstRemailers.List(lstRemailers.ListIndex), " ")
End Sub

Private Sub lstRemailers_DblClick()
    x = lstRemailers.ListIndex
    If fraRemEdit.Visible Then
        cmdRemEdit_Click (0)
    Else
        If mnuOption(0).Checked Then
            ShowRemEdit (True)
            If x = -1 Then rd = "" Else rd = RemDirect(x)
            ShowRemData Me, rd, 0
        End If
    End If
End Sub










Private Sub cboHeaders_Change(Index As Integer)
    Dim a As String, b As String, c As String, h As String
    Dim x As Long, y As Long, y2 As Long, z As Long
    
    If NoClick Then Exit Sub
    BkChange = True
    a = cboHeaders(Index).Text
    x = InStr(a, ":")
    If x <> 0 Then
        b = Trim(Mid(a, 1, x - 1)) + ":"
        If InStr(b, " ") = 0 Then
            c = UCase(Left(b, 1))
            For i = 2 To Len(b)
                If d = "-" Then c = c + UCase(Mid(b, i, 1)) Else c = c + LCase(Mid(b, i, 1))
                d = Mid(b, i, 1)
            Next i
            b = c
            h = b + " " + LTrim(Mid(a, x + 1))
            y = InStr(1, vbCrLf + txtHeaders(Index).Text, vbCrLf + b, vbTextCompare)
            If y = 0 Then
                If Right(txtHeaders(Index).Text, 2) <> vbCrLf And Len(txtHeaders(Index).Text) <> 0 Then txtHeaders(Index).Text = txtHeaders(Index).Text + vbCrLf
                txtHeaders(Index).Text = txtHeaders(Index).Text + h + vbCrLf
                z = Len(txtHeaders(Index).Text) - 2
            Else
                y2 = InStr(y, txtHeaders(Index).Text, vbCrLf)
                If y2 = 0 Then txtHeaders(Index).Text = txtHeaders(Index).Text + vbCrLf: y2 = Len(txtHeaders(Index).Text) - 1
                'z = y2 - 1
                txtHeaders(Index).Text = Left(txtHeaders(Index).Text, y - 1) + h + Mid(txtHeaders(Index).Text, y2)
                z = y + Len(h) - 1
                x = z
                Do
                    y = InStr(x, txtHeaders(Index).Text, vbCrLf + b, vbTextCompare)
                    If y <> 0 Then
                        y2 = InStr(y + 1, txtHeaders(Index).Text, vbCrLf)
                        If y2 = 0 Then txtHeaders(Index).Text = txtHeaders(Index).Text + vbCrLf: y2 = Len(txtHeaders(Index).Text) - 1
                        txtHeaders(Index).Text = Left(txtHeaders(Index).Text, y - 1) + Mid(txtHeaders(Index).Text, y2)
                        x = y2
                    End If
                Loop Until y = 0
            End If
            If RTrim(cboHeaders(Index).Text) <> RTrim(h) Then
                NoClick = True
                cboHeaders(Index).Text = h
                cboHeaders(Index).SelLength = 0
                cboHeaders(Index).SelStart = Len(h)
                NoClick = False
            End If
            txtHeaders(Index).SelLength = 0
            txtHeaders(Index).SelStart = z
        End If
    End If
End Sub

Private Sub cboHeaders_Click(Index As Integer)
    If cboHeaders(Index).ListIndex = -1 Then Exit Sub
    a = cboHeaders(Index).List(cboHeaders(Index).ListIndex)
    If InStr(a, ":") = 0 And LTrim(a) <> "" Then
        cboHeaders(Index).ListIndex = -1: Exit Sub
    End If
    cboHeaders_Change (Index)
    txtHeaders(Index).SetFocus
End Sub

Private Sub cboHeaders_KeyPress(Index As Integer, KeyAscii As Integer)
    If KeyAscii = 13 Then If InStr(cboHeaders(Index).Text, ":") <> 0 Then cboHeaders(Index).Text = ""
    If KeyAscii = Asc(":") Then
        If InStr(cboHeaders(Index).Text, ":") = 0 Then
            x = InStr(1, vbCrLf + txtHeaders(Index).Text, vbCrLf + Trim(cboHeaders(Index).Text) + ":", vbTextCompare)
            If x <> 0 Then
                txtHeaders(Index).SelLength = 0 'Len(cboHeaders.Text)
                txtHeaders(Index).SelStart = x
                cboHeaders(Index).Text = Extract(Mid(txtHeaders(Index).Text, x), vbCrLf)
                cboHeaders(Index).SelStart = Len(Extract(cboHeaders(Index).Text, ":")) + 2
                cboHeaders(Index).SelLength = Len(cboHeaders(Index).Text) - cboHeaders(Index).SelStart
                KeyAscii = 0
            End If
        End If
    End If
End Sub

Private Sub cboHeaders_LostFocus(Index As Integer)
    cboHeaders(Index).Text = ""
End Sub

Private Sub mnuClear_Click(Index As Integer)
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    BkChange = True
    Select Case Index
    Case 0
        If Val(Cnf(2, 3)) = 1 Then _
         If MsgBox(LMsg(129) + " " + Trim(Str(Blk)) + "?", vbOKCancel + vbQuestion, LMsg(95)) = vbCancel Then Exit Sub
        For i = 1 To MaxBD
            BlockData(Blk, i) = ""
        Next i
        Rmlr(Blk, 0) = ""
        UpdateBlock
        cboToHead.ListIndex = 0
        txtXHeaders.Text = "Subject: " + vbCrLf + "Newsgroups: " + vbCrLf
    Case 1
        If Val(Cnf(2, 3)) = 1 Then _
         If MsgBox(LMsg(130), vbQuestion + vbOKCancel, LMsg(95)) = vbCancel Then Exit Sub
        For i = 1 To MaxBlk
            For j = 0 To MaxBD
                BlockData(i, j) = ""
            Next j
            For j = 0 To MaxChain
                Rmlr(i, j) = ""
                AllDirect(i, j) = ""
        Next j, i
        BlockData(1, 0) = "1"
        Blk = 1
        UpdateBlock
        cboToHead.ListIndex = 0
        txtXHeaders.Text = "Subject: " + vbCrLf + "Newsgroups: " + vbCrLf
        For i = 2 To MaxBlk
            tabRB.Tabs(i).Caption = Trim(Str(i))
        Next i
        tabRB.Tabs(1).Selected = True
    Case 2
        'Clear Book
        If Val(Cnf(2, 3)) = 1 Then _
         If MsgBox(LMsg(96), vbQuestion + vbOKCancel, LMsg(95)) = vbCancel Then Exit Sub
        ClearData
        BlockData(1, 0) = "1"
        Blk = 1
        UpdateBlock
        For i = 2 To MaxBlk
            tabRB.Tabs(i).Caption = Trim(Str(i))
        Next i
        tabRB.Tabs(1).Selected = True
        cboToHead.ListIndex = 0
        txtXHeaders.Text = "Subject: " + vbCrLf + "Newsgroups: " + vbCrLf
        txtNotes.Text = ""
        txtLog.Text = ""
        chkNymComm(0).Value = 1
        chkNymComm(2).Value = 1
        chkAccount(0).Value = 1
        AutomatePass = False
    End Select
End Sub

Private Sub mnuEditArray_Click(Index As Integer)
    On Error Resume Next
    Select Case Index
    Case 0
        SendKeys "^z", True
    Case 1
        SendKeys "^c", True
    Case 2
        a = Clipboard.GetText
        SendKeys "^c", True
        a = a + Clipboard.GetText
        Clipboard.Clear
        Clipboard.SetText a
    Case 3
        SendKeys "^x", True
    Case 4
        SendKeys "^v", True
    End Select
End Sub

Private Sub cmdFindKey_Click()
    SecretOnly = True
    a = SelectKey(LMsg(126), cboNym.Text)
    If a <> "" Then cboUserID.Text = a
    UpdateBooks ("K")
End Sub

Private Sub cboUserID_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = 38 Or KeyCode = 40 Then KeyCode = 0
    If KeyCode = 8 And Val(PData(12)) <> 0 Then cboUserID.Text = ""
End Sub

Private Sub cboUserID_KeyPress(KeyAscii As Integer)
    BkChange = True
    If Val(PData(12)) <> 0 Then KeyAscii = 0
End Sub

Private Sub cmdRandom_Click()
    txtNull.SetFocus
    If SeedIx > 24 Then
        txtPass.Text = AddPass + txtPass.Text
    Else
        RandomOnly = 1
        ProgressBar1.Value = SeedIx
        ProgressBar1.Visible = True
        lblStat.Caption = LMsg(127)
        Me.KeyPreview = True
    End If
End Sub

Private Sub mnuRefresh_Click()  'Replace all passphrases
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    UpdateData
    cmdRandom.Enabled = False
    txtNull.SetFocus
    AutomatePass = False
    RandomOnly = 0
    For i = 1 To MaxBlk
        If Val(BlockData(i, 0)) <> 0 Then
            ActBlk = ActBlk + 1
            For t = 0 To MaxChain
                If Rmlr(i, t) = "" Then Exit For
                For alg = 1 To 3
                    Select Case alg
                    Case 1: eks = "Encrypt-Key:"
                    Case 2: eks = "Encrypt-3DES:"
                    Case 3: eks = "Encrypt-CAST:"
                    End Select
                    x = InStr(1, AllDirect(i, t), eks + " ", vbTextCompare)
                    While x <> 0
                        y = InStr(x, AllDirect(i, t), vbCrLf): If y = 0 Then y = Len(AllDirect(i, t)) + 1
                        a = Trim(Mid(AllDirect(i, t), x + Len(eks), y - (x + Len(eks))))
                        If a <> "" Then
                            RandomOnly = 2
                            If SeedIx <= ProgressBar1.Max Then ProgressBar1.Value = SeedIx
                            ProgressBar1.Visible = True
                            lblStat.Caption = LMsg(127)
                            Me.KeyPreview = True
                            While RandomOnly = 2 And SeedIx < 25
                                DoEvents
                            Wend
                            If RandomOnly = 0 Then
                                cmdRandom.Enabled = True
                                UpdateBlock
                                lblStat.Caption = LMsg(136) + Str(RepPass) + " " + LMsg(134) + Str(ActBlk) + " " + LMsg(137)
                                Exit Sub
                            End If
                            If RandomOnly = 2 Or RandomOnly = 3 Then
                                AddHeader AllDirect(i, t), eks + " " + AddPass
                                RandomOnly = 0
                                RepPass = RepPass + 1
                            End If
                            lblStat.Caption = ""
                        End If
                        x = InStr(x + Len(eks), AllDirect(i, t), eks + " ", vbTextCompare)
                    Wend
                Next alg
            Next t
        End If
    Next i
    cmdRandom.Enabled = True
    UpdateBlock
    lblStat.Caption = "Replaced" + Str(RepPass) + " passphrases in" + Str(ActBlk) + " active blocks."
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    RandomData KeyAscii, 0, 0
End Sub

Private Sub fraNym_MouseMove(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    If Me.KeyPreview Then RandomData x, y, 1
End Sub

Private Sub fraRemEdit_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Me.KeyPreview Then RandomData x, y, 1
End Sub

Private Sub fraRB_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Me.KeyPreview Then RandomData x, y, 1
End Sub

Private Sub txtHeaders_MouseMove(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    If Me.KeyPreview Then RandomData x, y, 1
End Sub

Private Sub txtNotes_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Me.KeyPreview Then RandomData x, y, 1
End Sub

Private Sub lstRemailers_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Me.KeyPreview Then RandomData x, y, 1
End Sub

Private Sub txtXHeaders_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Me.KeyPreview Then RandomData x, y, 1
End Sub

Private Sub RandomData(x, y, Job As Byte)
    Dim SeedVal As Double, Tmr As Double, Diff As Double, dX As Double
    Dim XDiff As Double, YDiff As Double
        
    If SeedIx > MaxSeed Then
        Me.KeyPreview = False
        ProgressBar1.Visible = False
    Else
        On Error GoTo ErrorRandom
        Tmr = Timer
        If Tmr <> TimerLast Then Diff = Abs(Log(Abs(Tmr - TimerLast))) Else Diff = 0
        If Diff <> 0 And Diff <> DiffLast Then
            If Job = 0 Then
                'X = KeyAscii
                dX = x + Abs(x - KeyLast)
                If x = 27 Then RandomOnly = 0: lblStat.Caption = "": ProgressBar1.Visible = False
                If x = KeyLast Then dX = 0
                KeyLast = x
            Else
                XDiff = Abs(x - XLast)
                YDiff = Abs(y - YLast)
                If XDiff * YDiff <> 0 And XDiff <> XDiffLast And YDiff <> YDiffLast Then
                    dX = (x * y) + XLast + YLast + XDiff + YDiff + XDiffLast + YDiffLast
                    While dX > 1000
                        dX = dX / 13
                    Wend
                    'Debug.Print X, Y, XLast, YLast, XDiffLast, YDiffLast, dX;
                    XDiffLast = XDiff
                    YDiffLast = YDiff
                    XLast = x
                    YLast = y
                Else
                    dX = 0
                End If
            End If
            If dX <> 0 Then
                TimerLast = Tmr
                DiffLast = Diff
                Tmr = ((Tmr / 1000) - Int(Tmr / 1000)) * 1000
                SeedVal = Abs(Tmr * Diff * DiffLast * dX * SeedMix)
                While SeedVal > 1000000000
                    SeedVal = SeedVal / 13
                Wend
                Seeds(SeedIx) = (SeedVal Mod 64) + 1
                'SeedValue(SeedIx) = Str(Tmr) + Str(Diff) + Str(X) + Str(SeedMix) + "=" + Str(SeedVal) + " (" + Str(Seeds(SeedIx))
                'Rep(Seeds(SeedIx)) = Rep(Seeds(SeedIx)) + 1
                SeedMix = (SeedMix + SeedVal) Mod 1000 + (Timer / 1000)
                'Debug.Print SeedVal, SeedMix
                SeedIx = SeedIx + 1
            End If
        End If
    End If
    If RandomOnly = 1 Then
        If Job = 0 Then x = 0
        If SeedIx > 24 Then
            txtPass.Text = AddPass + txtPass.Text
            RandomOnly = 0
            lblStat.Caption = ""
        Else
            ProgressBar1.Value = SeedIx
        End If
    End If
    If RandomOnly = 2 Then
        If Job = 0 Then x = 0
        If SeedIx > 24 Then
            RandomOnly = 3
        Else
            ProgressBar1.Value = SeedIx
        End If
    End If
Exit Sub
ErrorRandom:
End Sub

Private Function AddPass() As String
    On Error GoTo ErrorAddPass
    Dim a As String
    If SeedIx > 24 Then
        For i = 0 To 24
            a = a + Mid(Radix64, Seeds(i), 1)
        Next i
        For i = 25 To MaxSeed
            Seeds(i - 25) = Seeds(i)
        Next i
        SeedIx = SeedIx - 25
    End If
    AddPass = a
    ProgressBar1.Visible = False
    Me.KeyPreview = True
Exit Function
ErrorAddPass:
End Function

Private Sub lblStat_Click()
    If RandomOnly <> 2 Then
        UpdateData
        CountRB
    End If
    ProgressBar1.Visible = False
    RandomOnly = 0
End Sub

Private Sub chkActive_Click()
    Const Red = &HFF&
    Const NotRed = &H80000012
    txtNull.SetFocus
    chkActive.FontBold = chkActive.Value = 1
    If chkActive.FontBold Then chkActive.ForeColor = Red Else chkActive.ForeColor = NotRed
    If chkActive.FontBold Then a = "*"
    chkActive.Enabled = chkUpRB.Value = 1
    tabRB.SelectedItem.Caption = Trim(Str(Blk)) + a
    'Enable RB
    lblBlock.Enabled = (chkUpRB.Value = 1)
    fraRB.Enabled = chkActive.FontBold And (chkUpRB.Value = 1)
    x = chkUpRB.Value = 1
    'Advanced
    If lblMaxCount.Visible Then
        lblMaxCount.Enabled = fraRB.Enabled
        lblMaxSize.Enabled = fraRB.Enabled
        lblProb.Enabled = fraRB.Enabled
        lblInflate.Enabled = fraRB.Enabled
        lblRandHop.Enabled = fraRB.Enabled
        lblFolder.Enabled = fraRB.Enabled
        optDecrypt(0).Enabled = fraRB.Enabled
        optDecrypt(1).Enabled = fraRB.Enabled
        cboMaxCount.Enabled = x
        cboMaxSize.Enabled = x
        txtProb.Enabled = x
        cboInflate.Enabled = fraRB.Enabled
        cboRandHop.Enabled = fraRB.Enabled
        chkTo(0).Enabled = fraRB.Enabled
        chkTo(1).Enabled = fraRB.Enabled
        chkTo(2).Enabled = fraRB.Enabled
        cboFolder.Enabled = x
    End If
    'Standard
    lblRemailers.Enabled = fraRB.Enabled
    lblLatent.Enabled = fraRB.Enabled
    lblEncryptKey.Enabled = fraRB.Enabled
    lblFinal.Enabled = fraRB.Enabled
    cboRemailer.Enabled = fraRB.Enabled
    lstRemailers.Enabled = x
    cmdRemailer(0).Enabled = fraRB.Enabled
    cmdRemailer(1).Enabled = fraRB.Enabled
    cmdRemailer(2).Enabled = fraRB.Enabled
    cboLatent.Enabled = fraRB.Enabled
    txtPass.Enabled = fraRB.Enabled
    cmdRandom.Enabled = fraRB.Enabled
    cboToHead.Enabled = x
    cboTo.Enabled = x
    txtXHeaders.Enabled = x
    CountRB
End Sub

Private Sub tabRB_BeforeClick(Cancel As Integer)
    If NoClick Then Exit Sub
    If fraRemEdit.Visible Then UpRemData Me, RemDirect(Val(lstRemailers.Tag))
    lstRemailers.Tag = ""
    UpdateData
    tabRB.SelectedItem.Tag = lstRemailers.ListIndex
End Sub

Private Sub tabRB_Click()
    If NoClick Then Exit Sub
    Blk = tabRB.SelectedItem.Index
    UpdateBlock
    x = Val(tabRB.SelectedItem.Tag)
    If x > lstRemailers.ListCount - 1 Then x = 0
    lstRemailers.ListIndex = x
    CountRB
End Sub

Private Sub CountRB()
    If chkUpRB.Value = 1 And tabNym.SelectedItem.Index = 2 Then
        x = 0
        For i = 1 To MaxBlk
            If i <> tabRB.SelectedItem.Index Then x = x + Val(BlockData(i, 0))
        Next i
        x = x + chkActive.Value
        lblStat.Caption = Trim(Str(x)) + " " + LMsg(274)
    Else
        lblStat.Caption = ""
    End If
End Sub

Private Sub mnuCopyBlock_Click(Index As Integer)
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    If Index = 0 Then
        UpdateData
        For i = 0 To MaxBD
            BlockData(0, i) = BlockData(Blk, i)
        Next i
        Do
            Rmlr(0, t) = Rmlr(Blk, t)
            AllDirect(0, t) = AllDirect(Blk, t)
            t = t + 1
        Loop Until Rmlr(0, t - 1) = "" Or t > MaxChain
    Else
        For i = 0 To MaxBD
            BlockData(Blk, i) = BlockData(0, i)
        Next i
        Do
            Rmlr(Blk, t) = Rmlr(0, t)
            AllDirect(Blk, t) = AllDirect(0, t)
            t = t + 1
        Loop Until Rmlr(0, t - 1) = "" Or t > MaxChain
        UpdateBlock
    End If
End Sub

Private Sub mnuCopyPass_Click()
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    UpdateData
    Clipboard.Clear
    Clipboard.SetText Passphrases()
End Sub

Private Function Passphrases()
    If BkChange Then Erase RBChain, RBTag
    For i = 1 To MaxBlk
        a = "": rms = ""
        If Val(BlockData(i, 0)) <> 0 Then
            ActBlk = ActBlk + 1
            For t = 0 To MaxChain
                If Rmlr(i, t) = "" Then Exit For
                If t > 0 And RBChain(i) = "" Then
                    If t <> 1 Then rms = rms + "|"
                    rms = rms + Extract(Rmlr(i, t), " ")
                End If
                For alg = 3 To 1 Step -1
                    Select Case alg
                    Case 1: eks = "Encrypt-Key:"
                    Case 2: eks = "Encrypt-3DES:"
                    Case 3: eks = "Encrypt-CAST:"
                    End Select
                    x = InStr(1, AllDirect(i, t), eks + " ", vbTextCompare)
                    While x <> 0
                        y = InStr(x, AllDirect(i, t), vbCrLf): If y = 0 Then y = Len(AllDirect(i, t)) + 1
                        h = Trim(Mid(AllDirect(i, t), x + Len(eks), y - (x + Len(eks))))
                        If h <> "" Then
                            CP = CP + 1
                            a = h + vbCrLf + a
                        End If
                        x = InStr(x + Len(eks), AllDirect(i, t), eks + " ", vbTextCompare)
                    Wend
                Next alg
            Next t
        End If
        If a <> "" Then
            If b = "" Then c = "  " + Trim(cboNym.Text) Else c = ""
            If Trim(cboMaxDate.Text) <> "" Then e = vbTab + "Expires: " + Trim(cboMaxDate.Text) + vbCrLf Else e = ""
            If RBChain(i) <> "" Then rms = RBChain(i)
            If rms <> "" Then rms = vbTab + "Chain:   " + rms + vbCrLf
            b = b + "---block" + c + vbCrLf + vbTab + _
                "Tag:     " + RBTag(i) + "  #" + Trim(Str(i)) + vbCrLf + vbTab + _
                "Created: " + Format(SafeTime, "dd-mmm-yyyy hh:nn") + vbCrLf + vbTab + _
                "Used:    N/A" + vbCrLf + e + rms
            If NkData(0) = True2 And Trim(BlockData(i, 1)) <> "" Then
                b = b + vbTab
                If BlockData(i, 8) = True2 Then b = b + "File:    " Else b = b + "Folder:  "
                b = b + Trim(BlockData(i, 1)) + vbCrLf
            End If
            b = b + a
        End If
    Next i
    If b <> "" Then b = b + "---endblock" + vbCrLf
    lblStat.Caption = Trim(Str(CP)) + " " + LMsg(134) + " " + Trim(Str(ActBlk)) + " " + LMsg(135)
    Passphrases = b
End Function

Private Sub UpdateData()
    BlockData(Blk, 0) = Str(chkActive.Value)
    BlockData(Blk, 1) = cboFolder.Text
    BlockData(Blk, 2) = txtProb.Text
    BlockData(Blk, 3) = cboToHead.Text
    BlockData(Blk, 4) = cboTo.Text
    BlockData(Blk, 5) = txtXHeaders.Text
    BlockData(Blk, 6) = cboMaxSize.Text
    BlockData(Blk, 7) = cboMaxCount.Text
    BlockData(Blk, 8) = optDecrypt(1).Value
    For i = 0 To lstRemailers.ListCount - 2
        Rmlr(Blk, i) = Extract(lstRemailers.List(i), " ")
        AllDirect(Blk, i) = RemDirect(i)
    Next i
    If i <= MaxChain Then Rmlr(Blk, i) = ""
End Sub

Private Sub UpdateBlock()
    x = chkActive.Value
    chkActive.Value = Val(BlockData(Blk, 0))
    cboFolder.Text = BlockData(Blk, 1)
    cboMaxSize.Text = BlockData(Blk, 6)
    cboMaxCount.Text = BlockData(Blk, 7)
    txtProb.Text = BlockData(Blk, 2)
    cboToHead.Text = BlockData(Blk, 3)
    cboTo.Text = BlockData(Blk, 4)
    txtXHeaders.Text = BlockData(Blk, 5)
    optDecrypt(0).Value = Not (BlockData(Blk, 8) = True2)
    optDecrypt(1).Value = Not optDecrypt(0).Value
    lblBlock.Caption = LMsg(255) + Str(Blk)
    lstRemailers.Clear
    If Rmlr(Blk, 0) = "" Then
        Rmlr(Blk, 0) = "Nym-Server": Rmlr(Blk, 1) = ""
        If NkData(7) = "" Then NkData(7) = "Anon-To: $next" + vbCrLf
        AllDirect(Blk, 0) = NkData(7)
    End If
    If cboToHead.Text = "" Then cboToHead.Text = cboToHead.List(0)
    If txtXHeaders.Text = "" Then txtXHeaders.Text = "Subject: " + vbCrLf + "Newsgroups: " + vbCrLf
    t = 0
    Do While Rmlr(Blk, t) <> ""
        RemDirect(t) = AllDirect(Blk, t)
        lstRemailers.AddItem RemDisp(Rmlr(Blk, t), RemDirect(t))
        t = t + 1: If t > MaxChain Then Exit Do
    Loop
    lstRemailers.AddItem ""
    lstRemailers.ListIndex = 0
    If fraRemEdit.Visible Then ShowRemailer Me, lstRemailers.ListIndex, 0
End Sub

Private Sub ClearData()
    txtNotes.Text = ""
    cboNym.Text = ""
    cboUserID.Text = ""
    txtName.Text = ""
    txtNymComm.Text = ""
    NoClick = True
    For i = 0 To 6
        chkNymComm(i).Value = 0
    Next i
    NoClick = False
    For i = 0 To 2
        chkAccount(i).Value = 0
    Next i
    For i = 1 To MaxBlk
        For j = 0 To MaxBD
            BlockData(i, j) = ""
        Next j
        For j = 0 To MaxChain
            Rmlr(i, j) = ""
            AllDirect(i, j) = ""
    Next j, i
    Blk = 1
    Erase RBTag, RBChain
End Sub

Private Sub ShowRemEdit(state As Boolean)
    If state Then fraRemEdit.ZOrder
    fraRemEdit.Visible = state
    If state Then Form_Resize
End Sub

Private Sub chkAccount_Click(Index As Integer)
    If Not chkAccount(Index).Enabled Then Exit Sub
    x = chkAccount(Index).Value
    Select Case Index
    Case 0
        If x = 1 Then
            chkAccount(1).Value = 0
            chkAccount(2).Value = 0
            chkUpRB.Value = 1
        End If
        chkAccount(1).Enabled = x = 0
        chkAccount(2).Enabled = x = 0
        chkUpRB.Enabled = x = 0
    Case 1
        If x = 1 Then
            chkAccount(0).Value = 0
            chkAccount(2).Value = 0
            chkUpRB.Value = 0
        End If
        chkAccount(0).Enabled = x = 0
        chkAccount(2).Enabled = x = 0
        chkUpRB.Enabled = x = 0
    Case 2
        If x = 1 Then
            chkAccount(0).Value = 0
            chkAccount(1).Value = 0
        End If
        chkAccount(0).Enabled = x = 0
        chkAccount(1).Enabled = x = 0
        chkUpRB.Enabled = True
        If x = 1 Then MsgBox LMsg(398), vbInformation
    End Select
End Sub

Private Sub chkUpRB_Click()
    If chkUpRB.Value = 1 Then a = "*"
    tabNym.Tabs(2).Caption = LMsg(254) + a
    tabRB.Enabled = chkUpRB.Value = 1
    fraRB.Enabled = chkUpRB.Value = 1
    cboMaxDate.Enabled = chkUpRB.Value = 1
    lblMaxDate.Enabled = chkUpRB.Value = 1
    lblLastDate.Enabled = chkUpRB.Value = 1
    If tabNym.SelectedItem.Index = 2 Then chkActive_Click
    CountRB
End Sub

Private Sub mnuOption_Click(Index As Integer)
    If Index = 1 And mnuOption(Index).Checked Then
        x = MsgTime(LMsg(543), 0, "Jack B. Nymble v2", 999, 2, 0, "&OK", "&Cancel", "&Help")
        If x = 3 Then ShowHelp 0, "#UpdateReg"
        If x = 2 Or x = 3 Then Exit Sub
    End If
    mnuOption(Index).Checked = Not mnuOption(Index).Checked
    NkData(Index) = mnuOption(Index).Checked
    If Index = 0 Then
        'Show Advanced
        x = mnuOption(0).Checked
        If Not x Then
            cboMaxDate.Text = ""
            chkAccount(2).Value = 0
            If fraRemEdit.Visible Then cmdRemEdit_Click (0)
        End If
        lblEncryptKey.Font.Underline = x
        If Not x Then lblEncryptKey_MouseUp 0, 0, 0, 0
        lblMaxSize.Visible = x
        lblMaxCount.Visible = x
        cboMaxSize.Visible = x
        cboMaxCount.Visible = x
        lblMaxDate.Visible = x
        lblLastDate.Visible = x
        cboMaxDate.Visible = x
        lblInflate.Visible = x
        lblRandHop.Visible = x
        lblProb.Visible = x
        lblFolder.Visible = x
        lblNymComm.Visible = x
        cboInflate.Visible = x
        cboRandHop.Visible = x
        txtProb.Visible = x
        optDecrypt(0).Visible = x
        optDecrypt(1).Visible = x
        cboFolder.Visible = x
        txtNymComm.Visible = x
        chkTo(0).Visible = x
        chkTo(1).Visible = x
        chkTo(2).Visible = x
        chkAccount(2).Visible = x
    End If
End Sub

Private Sub mnuChain_Click()
    mnuRemEdit(3).Enabled = mnuOption(0).Checked
    mnuRemEdit(3).Checked = fraRemEdit.Visible
End Sub

Private Sub lstRemailers_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        PopupMenu mnuChain
    End If
End Sub

Private Sub mnuRemEdit_Click(Index As Integer)
    If Index < 2 Then
        cmdRemailer_Click (Index)
    Else
        If mnuOption(0).Checked And Not fraRemEdit.Visible Then
            ShowRemEdit (True)
            x = lstRemailers.ListIndex
            If x = -1 Then rd = "" Else rd = RemDirect(x)
            ShowRemData Me, rd, 0
        Else
            cmdRemEdit_Click (0)
        End If
    End If
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    Select Case Shift
    Case 0
        Select Case KeyCode
        Case vbKeyF1: mnuHelpSub_Click (0): KeyCode = 0
        Case vbKeyF7: ShowConfig (ConfigBooks): KeyCode = 0
        End Select
    Case 1 'Shift
    Case 2  'Ctrl
        Select Case KeyCode
        Case vbKeyD: mnuEditArray_Click (2): KeyCode = 0
        Case vbKeyK: mnuCopyBlock_Click (1): KeyCode = 0
        Case vbKeyR: mnuClear_Click (0): KeyCode = 0
        Case vbKeyS: mnuDisk_Click (2): KeyCode = 0
        Case vbKeyY: mnuCopyBlock_Click (0): KeyCode = 0
        End Select
    Case 3 'Ctrl-Shift
    End Select
End Sub

Private Sub mnuHelpSub_Click(Index As Integer)
    Dim Topic As String
    
    Select Case tabNym.SelectedItem.Index
    Case 1: Topic = "#NymBook"
    Case 2: Topic = "#NymBookRB"
    Case 3: Topic = "#NymBookNotes"
    Case 4: Topic = "#NymBookLog"
    End Select
    ShowHelp Index, Topic
End Sub

Private Sub mnuConfig_Click(Index As Integer)
    ShowConfig (Index)
End Sub

Private Sub mnuWindow_Click(Index As Integer)
    ShowWindow (Index)
End Sub

Private Sub tmrReload_Timer()
    If BookX = -1 Then Exit Sub
    tmrReload.Enabled = False
    If BookBusy(1, BookX) Then Exit Sub
    a = tmrReload.Tag: tmrReload.Tag = ""
    If a <> "" And fraRemEdit.Visible Then cmdRemEdit_Click (0)
    If InStr(a, "X") <> 0 Then
        LoadList ("")
    Else
        If InStr(a, "H") <> 0 Then LoadList ("HeaderChoice")
        If InStr(a, "A") <> 0 Then LoadList ("Addresses")
        If InStr(a, "R") <> 0 Then LoadList ("Remailers")
        If InStr(a, "K") <> 0 Then LoadList ("Keys")
        If InStr(a, "M") <> 0 Then LoadList ("Nyms")
        If InStr(a, "F") <> 0 Then LoadList ("Fonts")
        If InStr(a, "P") <> 0 Then LoadList ("Profiles")
    End If
    If InStr(a, "L") <> 0 Then
        'Reload
        fn = cboNym.Tag: cboNym.Tag = ""
        If SDir(fn) = "" Then Exit Sub
Query:  If BkChange And Val(Cnf(2, 2)) = 1 Then
            Select Case MsgBox(LMsg(119), vbQuestion + vbYesNoCancel, MsgBookName(BookX))
            Case vbCancel
                Exit Sub
            Case vbYes
                WriteBook (NymBookName(BookX))
                GoTo Query
            End Select
        End If
        NymBookName(BookX) = fn
        ReadBook (fn)
    End If
End Sub

Private Sub LoadList(Job As String)
    Dim temp(1000) As String
    
    If Job = "HeaderChoice" Or Job = "" Then
        cboHeaders(2).Clear
        Tmp = cboLatent.Text
        If InStr(1, Cnf(2, 21), "latent-time:", vbTextCompare) <> 0 Then cboLatent.Clear
        x = ParseString(Cnf(2, 21), temp(), 1000, False)
        For i = 0 To x
            cboHeaders(2).AddItem temp(i)
            If InStr(1, temp(i), "latent-time:", vbTextCompare) = 1 Then
                a = Trim(Mid(temp(i), InStr(temp(i), ":") + 1))
                If a <> "" Then cboLatent.AddItem a
            End If
        Next i
        cboLatent.Text = Tmp
    
        Tmp = cboFolder.Text
        cboFolder.Clear
        a = SDir(Cnf(4, 0) + "\*.*", vbDirectory)
        While a <> ""
            f = Cnf(4, 0) + "\" + a
            If IsDir(f) And a <> "." And a <> ".." Then cboFolder.AddItem f
            a = Dir
        Wend
        cboFolder.Text = Tmp
    End If
    
    If Job = "Addresses" Or Job = "" Then
        Tmp = cboTo.Text
        cboTo.Clear
        For i = 0 To AddrCount - 1
            cboTo.AddItem Addr(i)
        Next i
        cboTo.Text = Tmp
    End If
    
    If Job = "Nyms" Or Job = "" Then
        Tmp = cboNym.Text
        cboNym.Clear
        For i = 0 To MaxRemailers
            If Nyms(i, 0) = "" Then Exit For
            cboNym.AddItem Nyms(i, 0)
        Next i
        For i = 0 To MaxRemailers
            If RString(i) = "" Then Exit For
            RemailerString RString(i), "", raddress, roptions
            If raddress <> "" And InStr(roptions, " newnym ") <> 0 Then
                cboNym.AddItem "example@" + Mid(raddress, InStr(raddress, "@") + 1)
            End If
        Next i
        cboNym.Text = Tmp
    End If
    
    If Job = "Remailers" Or Job = "" Then
        GetRemailers cboRemailer, 0
        If Job = "Remailers" Then lblStat.Caption = LMsg(393)
    End If

    If Job = "Keys" Or Job = "" Then
        LoadKeyList cboUserID, True, True
    End If

    If Job = "Fonts" Or Job = "" Then
        On Error Resume Next
        txtNotes.Font.Name = Cnf(2, 25)
        txtNotes.Font.Size = Val(Cnf(2, 26))
        txtNotes.Font.Bold = (Cnf(2, 27) = True2)
        x = SVal(Cnf(0, 5)) + 8
        txtLog.FontSize = x
        cboNym.FontSize = x
        cboUserID.FontSize = x
        txtName.FontSize = x
        txtNymComm.FontSize = x
        cboRemailer.FontSize = x
        cboLatent.FontSize = x
        cboInflate.FontSize = x
        cboRandHop.FontSize = x
        txtPass.FontSize = x
        cboToHead.FontSize = x
        cboTo.FontSize = x
        cboHeaders(0).FontSize = x
        cboHeaders(2).FontSize = x
        txtHeaders(0).FontSize = x
        txtHeaders(2).FontSize = x
        cboFolder.FontSize = x
        cboMaxDate.FontSize = x
        cboMaxSize.FontSize = x
        cboMaxCount.FontSize = x
        txtProb.FontSize = x
        On Error GoTo 0
    End If
    
    If Job = "Profiles" Or Job = "" Then
        For j = 31 To 45
            If UserProf(j, 6) <> "" Then
                For i = 31 To 45
                    a = UserProf(i, 5)
                    If a = "" Then a = "NNTP" + Str(i + 1)
                    mnuExportSub(i - 31).Caption = a
                    mnuExportSub(i - 31).Checked = (Val(UserProf(i, 0)) = 1)
                    mnuExportSub(i - 31).Visible = (UserProf(i, 6) <> "")
                Next i
                Exit For
            End If
        Next j
        If j = 46 Then
            mnuExportSub(0).Visible = True
            mnuExportSub(0).Checked = False
            mnuExportSub(0).Caption = "None"
            mnuExportSub(0).Enabled = False
            For i = 1 To 14
                mnuExportSub(i).Visible = False
            Next i
        End If
    End If
End Sub

Private Sub Form_Resize()
    Dim sh As Long, sw As Long, x As Long, fh As Long, fw As Long
    
    If Me.WindowState <> 1 Then
        If Me.Height < 5304 Then Me.Height = 5304
        If Me.Width < 4152 Then Me.Width = 4152
        sh = Me.ScaleHeight
        sw = Me.ScaleWidth
        tabNym.Height = sh - 372
        tabNym.Width = sw - 12
        tabNym.TabFixedWidth = (tabNym.Width / 4) - 24
        fh = sh - 732
        fw = sw - 132
        For i = 0 To 3
            fraNym(i).Height = fh
            fraNym(i).Width = fw
        Next i
        txtNotes.Width = fw - 120
        txtNotes.Height = fh - 180
        txtLog.Width = txtNotes.Width
        txtLog.Height = txtNotes.Height
        tabRB.Width = fw
        fraRB.Width = fw - 120
        x = fraRB.Width - 120
        lstRemailers.Width = x
        txtXHeaders.Width = x
        cboTo.Width = x - cboToHead.Width - 60
        cboFolder.Width = fraRB.Width - 2880
        cmdRemailer(2).Left = fraRB.Width - 912
        cmdRemailer(1).Left = fraRB.Width - 1872
        cmdRemailer(0).Left = fraRB.Width - 2832
        cboRemailer.Width = fraRB.Width - 2940
        cmdRandom.Left = fraRB.Width - 300
        txtPass.Width = fraRB.Width - 3324
        lblStat.Top = sh - 324
        lblStat.Width = sw - 2892
        ProgressBar1.Left = lblStat.Width - 1176
        ProgressBar1.Top = lblStat.Top + 36
        chkQue(0).Left = sw - 2724
        chkQue(1).Left = sw - 1344
        chkQue(0).Top = sh - 325
        chkQue(1).Top = sh - 325
        If fraRemEdit.Visible Then
            fraRemEdit.Width = fw
            fraRemEdit.Height = sh - fraRemEdit.Top - 12
            txtRemEdit.Width = fw - 180
            txtCaps.Height = fraRemEdit.Height - 660
            txtHeaders(2).Height = txtCaps.Height
            txtHeaders(2).Width = fw - 3060
            cboHeaders(2).Width = txtHeaders(2).Width
            cboHeaders(2).Top = fraRemEdit.Height - 348
            cmdRemEdit(0).Left = fw - 840
            cmdRemEdit(1).Left = cmdRemEdit(0).Left
            cmdRemEdit(2).Left = cmdRemEdit(0).Left
        End If
    End If
End Sub

Private Sub Form_Activate()
    If BookX = -1 Then
        BookX = Val(Me.Tag)
        If Not ReadBook(NymBookName(BookX)) Then
            NymBookName(BookX) = ""
            Unload Me
            Exit Sub
        End If
    End If
End Sub

Private Sub Form_Load()
    frmMain.MousePointer = 11
    
    Randomize Timer
    Me.Left = Val(PData(117))
    Me.Top = Val(PData(118))
    If Val(PData(119)) <> 0 And Val(PData(120)) <> 0 Then
        Me.Width = Val(PData(119))
        Me.Height = Val(PData(120))
    End If
    If Val(PData(121)) <> 1 Then Me.WindowState = Val(PData(121))
    
    fraNym(0).Left = 60
    fraNym(1).Left = 60
    fraNym(2).Left = 60
    fraRemEdit.Left = 120
    
    'Load Max-Dates
    cboMaxDate.AddItem DateLine(0, SafeTime + 7)
    cboMaxDate.AddItem DateLine(0, SafeTime + 14)
    cboMaxDate.AddItem DateLine(0, SafeTime + 21)
    cboMaxDate.AddItem DateLine(0, SafeTime + 28)
    cboMaxDate.AddItem DateLine(0, SafeTime + 42)
    cboMaxDate.AddItem DateLine(0, SafeTime + 56)
    cboMaxDate.AddItem DateLine(0, SafeTime + 70)
    cboMaxDate.AddItem DateLine(0, SafeTime + 84)
    For i = 0 To cboMaxDate.ListCount - 1
        a = cboMaxDate.List(i)
        x = 0
        For j = 1 To 3
            x = InStr(x + 1, a, " ")
        Next j
        If x <> 0 Then cboMaxDate.List(i) = Left(a, x - 1)
    Next i
    
    NkData(27) = lblEncryptKey.Caption
    LoadList ("")
    Blk = 1
    tabRB_Click
    tabNym_Click
    Me.KeyPreview = True
    BookX = -1
    frmMain.MousePointer = 0
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If BookX <> -1 Then
        If fraRemEdit.Visible Then cmdRemEdit_Click (0)
Query:
        If BkChange And Val(Cnf(2, 2)) = 1 Then
            Select Case MsgBox(LMsg(119), vbQuestion + vbYesNoCancel, NymBookName(BookX))
            Case vbCancel
                Cancel = 1
                Exit Sub
            Case vbYes
                WriteBook (NymBookName(BookX))
                GoTo Query
            End Select
        End If
        If BookBusy(1, BookX) Then
            If MsgBox(LMsg(440), vbYesNo + vbDefaultButton2 + vbExclamation, LMsg(441)) = vbNo Then
                Cancel = 1
                GlobalCancel = 1
            Else
                BookBusy(1, BookX) = False
                frmMain!tmrDOS.Enabled = False
                DOSTag = ""
            End If
        End If
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Erase RemDirect, NkData, AllDirect, BlockData
    If BookX <> -1 Then NymBookName(BookX) = ""
    BookX = -1
    If Me.WindowState = 0 Then
        PData(117) = Str(Me.Left)
        PData(118) = Str(Me.Top)
        PData(119) = Str(Me.Width)
        PData(120) = Str(Me.Height)
    End If
    PData(121) = Str(Me.WindowState)
End Sub


