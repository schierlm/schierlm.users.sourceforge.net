VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmCfProf 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Retrieval Profiles - Configuration"
   ClientHeight    =   6915
   ClientLeft      =   30
   ClientTop       =   330
   ClientWidth     =   6705
   Icon            =   "CfProf.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6915
   ScaleWidth      =   6705
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   372
      Left            =   4560
      TabIndex        =   77
      Top             =   6480
      Width           =   1992
   End
   Begin VB.Timer tmrProgBusy 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   4320
      Top             =   6480
   End
   Begin VB.CommandButton cmdProf 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   372
      Index           =   1
      Left            =   2340
      TabIndex        =   45
      Top             =   6480
      Width           =   1992
   End
   Begin VB.CommandButton cmdProf 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Index           =   0
      Left            =   120
      TabIndex        =   44
      Top             =   6480
      Width           =   1992
   End
   Begin VB.Frame fraProf 
      BorderStyle     =   0  'Kein
      Height          =   5412
      Index           =   2
      Left            =   120
      TabIndex        =   60
      Top             =   900
      Width           =   6432
      Begin VB.CommandButton cmdResetNews 
         Caption         =   "Reset Index"
         Height          =   312
         Left            =   4980
         TabIndex        =   85
         Top             =   0
         Width           =   1452
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   10
         Left            =   2460
         MaxLength       =   8
         TabIndex        =   82
         Top             =   1860
         Width           =   672
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   9
         Left            =   1020
         MaxLength       =   8
         TabIndex        =   81
         Top             =   1860
         Width           =   672
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   672
         Index           =   6
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   31
         Top             =   2460
         Width           =   6372
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   60
         MaxLength       =   12
         TabIndex        =   22
         Top             =   600
         Width           =   3072
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   3360
         MaxLength       =   256
         TabIndex        =   23
         Top             =   600
         Width           =   3072
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   60
         MaxLength       =   256
         TabIndex        =   24
         Top             =   1200
         Width           =   3072
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         IMEMode         =   3  'DISABLE
         Index           =   3
         Left            =   3360
         MaxLength       =   256
         PasswordChar    =   "*"
         TabIndex        =   25
         Top             =   1200
         Width           =   3072
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         IMEMode         =   3  'DISABLE
         Index           =   5
         Left            =   3360
         MaxLength       =   512
         TabIndex        =   30
         Top             =   1860
         Width           =   3072
      End
      Begin VB.OptionButton optNNTP 
         Caption         =   "Folder"
         Height          =   192
         Index           =   0
         Left            =   4680
         TabIndex        =   28
         TabStop         =   0   'False
         Top             =   1644
         Width           =   852
      End
      Begin VB.OptionButton optNNTP 
         Caption         =   "File"
         Height          =   192
         Index           =   1
         Left            =   5640
         TabIndex        =   29
         TabStop         =   0   'False
         Top             =   1644
         Width           =   672
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   4
         Left            =   2460
         MaxLength       =   4
         TabIndex        =   27
         Top             =   1548
         Width           =   672
      End
      Begin VB.CheckBox chkNNTP 
         Caption         =   "Fully retrieve all articles in lines range  (for greater anonymity)"
         Height          =   192
         Index           =   2
         Left            =   60
         TabIndex        =   34
         TabStop         =   0   'False
         Top             =   5220
         Width           =   6312
      End
      Begin VB.CheckBox chkNNTP 
         Caption         =   "Enable"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Index           =   0
         Left            =   60
         TabIndex        =   21
         TabStop         =   0   'False
         Top             =   60
         Width           =   2112
      End
      Begin VB.CheckBox chkNNTP 
         Caption         =   "Get news every (minutes):"
         Height          =   192
         Index           =   1
         Left            =   60
         TabIndex        =   26
         TabStop         =   0   'False
         Top             =   1608
         Width           =   3012
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   912
         Index           =   7
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   32
         Top             =   3420
         Width           =   6372
      End
      Begin VB.TextBox txtNNTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   552
         Index           =   8
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   33
         Top             =   4620
         Width           =   6372
      End
      Begin VB.Label lblNNTP 
         Alignment       =   1  'Rechts
         Caption         =   "to Max:"
         Height          =   192
         Index           =   9
         Left            =   1740
         TabIndex        =   84
         Top             =   1920
         Width           =   672
      End
      Begin VB.Label lblNNTP 
         Caption         =   "Lines Min:"
         Height          =   192
         Index           =   8
         Left            =   60
         TabIndex        =   83
         Top             =   1920
         Width           =   972
      End
      Begin VB.Label lblNNTP 
         Caption         =   "Newsgroups:"
         Height          =   192
         Index           =   5
         Left            =   60
         TabIndex        =   68
         Top             =   2220
         Width           =   2652
      End
      Begin VB.Label lblNNTP 
         Caption         =   "Don't save the following articles:"
         Height          =   192
         Index           =   7
         Left            =   60
         TabIndex        =   67
         Top             =   4380
         Width           =   5712
      End
      Begin VB.Label lblNNTP 
         Caption         =   "Save the following articles:"
         Height          =   192
         Index           =   6
         Left            =   60
         TabIndex        =   66
         Top             =   3180
         Width           =   5832
      End
      Begin VB.Label lblNNTP 
         Caption         =   "NNTP Password: (If required)"
         Height          =   192
         Index           =   3
         Left            =   3360
         TabIndex        =   65
         Top             =   960
         Width           =   3012
      End
      Begin VB.Label lblNNTP 
         Caption         =   "Profile Nickname:"
         Height          =   192
         Index           =   0
         Left            =   60
         TabIndex        =   64
         Top             =   360
         Width           =   2952
      End
      Begin VB.Label lblNNTP 
         Caption         =   "NNTP Server:"
         Height          =   192
         Index           =   1
         Left            =   3360
         TabIndex        =   63
         Top             =   360
         Width           =   3012
      End
      Begin VB.Label lblNNTP 
         Caption         =   "NNTP User: (If required)"
         Height          =   192
         Index           =   2
         Left            =   60
         TabIndex        =   62
         Top             =   960
         Width           =   3012
      End
      Begin VB.Label lblNNTP 
         Caption         =   "Save News To:"
         Height          =   192
         Index           =   4
         Left            =   3360
         TabIndex        =   61
         Top             =   1620
         Width           =   1212
      End
   End
   Begin VB.Frame fraProf 
      BorderStyle     =   0  'Kein
      Height          =   5412
      Index           =   0
      Left            =   120
      TabIndex        =   46
      Top             =   900
      Width           =   6432
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   8
         Left            =   2520
         MaxLength       =   4
         TabIndex        =   7
         Top             =   2040
         Width           =   612
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   4
         Left            =   2520
         MaxLength       =   4
         TabIndex        =   6
         Top             =   1620
         Width           =   612
      End
      Begin VB.CheckBox chkPOP 
         Caption         =   "Ignore mail larger than (k):"
         Height          =   252
         Index           =   3
         Left            =   60
         TabIndex        =   80
         TabStop         =   0   'False
         Top             =   2100
         Width           =   2412
      End
      Begin VB.CheckBox chkPOP 
         Caption         =   "Delete saved mail from server"
         Height          =   192
         Index           =   2
         Left            =   3360
         TabIndex        =   78
         TabStop         =   0   'False
         Top             =   2160
         Width           =   3012
      End
      Begin VB.ComboBox cboPOP 
         Height          =   288
         Index           =   1
         ItemData        =   "CfProf.frx":0442
         Left            =   60
         List            =   "CfProf.frx":044F
         Style           =   2  'Dropdown-Liste
         TabIndex        =   12
         TabStop         =   0   'False
         Top             =   4080
         Width           =   6360
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1032
         Index           =   7
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   13
         Top             =   4380
         Width           =   6372
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1032
         Index           =   6
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   11
         Top             =   3000
         Width           =   6372
      End
      Begin VB.ComboBox cboPOP 
         Height          =   288
         Index           =   0
         ItemData        =   "CfProf.frx":04D3
         Left            =   60
         List            =   "CfProf.frx":04E0
         Style           =   2  'Dropdown-Liste
         TabIndex        =   10
         TabStop         =   0   'False
         Top             =   2700
         Width           =   6360
      End
      Begin VB.CheckBox chkPOP 
         Caption         =   "Check mail every (minutes):"
         Height          =   252
         Index           =   1
         Left            =   60
         TabIndex        =   5
         TabStop         =   0   'False
         Top             =   1668
         Width           =   2412
      End
      Begin VB.CheckBox chkPOP 
         Caption         =   "Enable"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Index           =   0
         Left            =   60
         TabIndex        =   0
         TabStop         =   0   'False
         Top             =   60
         Width           =   2112
      End
      Begin VB.OptionButton optPOP 
         Caption         =   "File"
         Height          =   192
         Index           =   1
         Left            =   5640
         TabIndex        =   8
         TabStop         =   0   'False
         Top             =   1584
         Width           =   672
      End
      Begin VB.OptionButton optPOP 
         Caption         =   "Folder"
         Height          =   192
         Index           =   0
         Left            =   4680
         TabIndex        =   79
         TabStop         =   0   'False
         Top             =   1584
         Value           =   -1  'True
         Width           =   852
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         IMEMode         =   3  'DISABLE
         Index           =   5
         Left            =   3360
         MaxLength       =   512
         TabIndex        =   9
         Top             =   1800
         Width           =   3072
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         IMEMode         =   3  'DISABLE
         Index           =   3
         Left            =   3360
         MaxLength       =   256
         PasswordChar    =   "*"
         TabIndex        =   4
         Top             =   1200
         Width           =   3072
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   60
         MaxLength       =   256
         TabIndex        =   3
         Top             =   1200
         Width           =   3072
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   3360
         MaxLength       =   256
         TabIndex        =   2
         Top             =   600
         Width           =   3072
      End
      Begin VB.TextBox txtPOP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   60
         MaxLength       =   12
         TabIndex        =   1
         Top             =   600
         Width           =   3072
      End
      Begin VB.Label lblPOP 
         Caption         =   "Filtering:"
         Height          =   264
         Index           =   5
         Left            =   96
         TabIndex        =   52
         Top             =   2472
         Width           =   2412
      End
      Begin VB.Label lblPOP 
         Caption         =   "Save Mail To:"
         Height          =   192
         Index           =   4
         Left            =   3360
         TabIndex        =   51
         Top             =   1560
         Width           =   1212
      End
      Begin VB.Label lblPOP 
         Caption         =   "POP3 User:"
         Height          =   192
         Index           =   2
         Left            =   60
         TabIndex        =   49
         Top             =   960
         Width           =   3012
      End
      Begin VB.Label lblPOP 
         Caption         =   "POP3 Server:"
         Height          =   192
         Index           =   1
         Left            =   3360
         TabIndex        =   48
         Top             =   360
         Width           =   3012
      End
      Begin VB.Label lblPOP 
         Caption         =   "Profile Nickname:"
         Height          =   192
         Index           =   0
         Left            =   60
         TabIndex        =   47
         Top             =   360
         Width           =   2952
      End
      Begin VB.Label lblPOP 
         Caption         =   "POP3 Password:"
         Height          =   192
         Index           =   3
         Left            =   3360
         TabIndex        =   50
         Top             =   960
         Width           =   3012
      End
   End
   Begin VB.Frame fraProf 
      BorderStyle     =   0  'Kein
      Height          =   5412
      Index           =   1
      Left            =   120
      TabIndex        =   54
      Top             =   900
      Width           =   6432
      Begin VB.CheckBox chkSMTP 
         Caption         =   "Generate Mix Dummies"
         Height          =   192
         Index           =   2
         Left            =   3420
         TabIndex        =   43
         TabStop         =   0   'False
         Top             =   4920
         Width           =   2712
      End
      Begin VB.CheckBox chkSMTP 
         Caption         =   "Generate CPunk Dummies"
         Height          =   192
         Index           =   1
         Left            =   180
         TabIndex        =   42
         TabStop         =   0   'False
         Top             =   4920
         Width           =   2712
      End
      Begin VB.TextBox txtSMTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   4
         Left            =   60
         MaxLength       =   256
         TabIndex        =   40
         Top             =   2400
         Width           =   6372
      End
      Begin VB.TextBox txtSMTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1848
         Index           =   5
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   41
         Top             =   3000
         Width           =   6372
      End
      Begin VB.TextBox txtSMTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   3
         Left            =   60
         MaxLength       =   1024
         TabIndex        =   39
         Top             =   1800
         Width           =   6372
      End
      Begin VB.TextBox txtSMTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   60
         MaxLength       =   1024
         TabIndex        =   38
         Top             =   1200
         Width           =   6372
      End
      Begin VB.TextBox txtSMTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   60
         MaxLength       =   12
         TabIndex        =   36
         Top             =   600
         Width           =   3072
      End
      Begin VB.TextBox txtSMTP 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   3360
         MaxLength       =   256
         TabIndex        =   37
         Top             =   600
         Width           =   3072
      End
      Begin VB.CheckBox chkSMTP 
         Caption         =   "Enable"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Index           =   0
         Left            =   60
         TabIndex        =   35
         TabStop         =   0   'False
         Top             =   60
         Width           =   2352
      End
      Begin VB.Label lblSMTP 
         Caption         =   "SMTP From Address: (Optional - Press F1 for usage)"
         Height          =   192
         Index           =   4
         Left            =   60
         TabIndex        =   76
         Top             =   2160
         Width           =   6012
      End
      Begin VB.Label lblSMTP 
         Caption         =   "* IMPORTANT: Before pressing OK, be sure your Default Send tab is on top."
         Height          =   252
         Index           =   6
         Left            =   60
         TabIndex        =   69
         Top             =   5220
         Width           =   6312
      End
      Begin VB.Label lblSMTP 
         Caption         =   "Additional Headers: (Optional)"
         Height          =   192
         Index           =   5
         Left            =   60
         TabIndex        =   59
         Top             =   2760
         Width           =   4812
      End
      Begin VB.Label lblSMTP 
         Caption         =   "Reply-To Header: (Optional)"
         Height          =   192
         Index           =   3
         Left            =   60
         TabIndex        =   58
         Top             =   1560
         Width           =   5952
      End
      Begin VB.Label lblSMTP 
         Caption         =   "From Header:"
         Height          =   192
         Index           =   2
         Left            =   60
         TabIndex        =   57
         Top             =   960
         Width           =   3012
      End
      Begin VB.Label lblSMTP 
         Caption         =   "Profile Nickname:"
         Height          =   192
         Index           =   0
         Left            =   60
         TabIndex        =   56
         Top             =   360
         Width           =   2952
      End
      Begin VB.Label lblSMTP 
         Caption         =   "SMTP Server:"
         Height          =   192
         Index           =   1
         Left            =   3360
         TabIndex        =   55
         Top             =   360
         Width           =   3012
      End
   End
   Begin ComctlLib.TabStrip tabProf 
      Height          =   6372
      Left            =   60
      TabIndex        =   53
      Top             =   60
      Width           =   6612
      _ExtentX        =   11668
      _ExtentY        =   11245
      MultiRow        =   -1  'True
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   15
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "1"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "2"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "3"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab4 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "4"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab5 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "5"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab6 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "6"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab7 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "7"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab8 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "8"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab9 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "9"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab10 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "10"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab11 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "11"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab12 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "12"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab13 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "13"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab14 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "14"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab15 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "15"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin VB.Frame fraProf 
      BorderStyle     =   0  'Kein
      Height          =   5412
      Index           =   3
      Left            =   120
      TabIndex        =   70
      Top             =   900
      Width           =   6432
      Begin VB.TextBox txtUNIX 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1308
         Index           =   3
         Left            =   60
         MaxLength       =   20000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   20
         Top             =   4080
         Width           =   6372
      End
      Begin VB.TextBox txtUNIX 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   60
         MaxLength       =   1024
         TabIndex        =   19
         Top             =   3360
         Width           =   6372
      End
      Begin VB.OptionButton optUNIX 
         Caption         =   "File"
         Height          =   252
         Index           =   1
         Left            =   960
         TabIndex        =   17
         TabStop         =   0   'False
         Top             =   2340
         Width           =   972
      End
      Begin VB.OptionButton optUNIX 
         Caption         =   "Folder"
         Height          =   252
         Index           =   0
         Left            =   60
         TabIndex        =   16
         TabStop         =   0   'False
         Top             =   2340
         Width           =   972
      End
      Begin VB.TextBox txtUNIX 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   648
         Index           =   0
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   15
         Top             =   1320
         Width           =   6372
      End
      Begin VB.CheckBox chkUNIX 
         Caption         =   "Enable UNIX"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Index           =   0
         Left            =   60
         TabIndex        =   14
         TabStop         =   0   'False
         Top             =   60
         Width           =   2832
      End
      Begin VB.TextBox txtUNIX 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   60
         MaxLength       =   512
         TabIndex        =   18
         Top             =   2640
         Width           =   6372
      End
      Begin VB.Label lblUNIX 
         Caption         =   "override the default profile and write the message directly to:"
         Height          =   192
         Index           =   2
         Left            =   60
         TabIndex        =   75
         Top             =   2040
         Width           =   6312
      End
      Begin VB.Label lblUNIX 
         Caption         =   "When sending to the following addresses:"
         Height          =   252
         Index           =   1
         Left            =   60
         TabIndex        =   74
         Top             =   1080
         Width           =   6072
      End
      Begin VB.Label lblUNIX 
         Caption         =   "From Header:"
         Height          =   192
         Index           =   3
         Left            =   60
         TabIndex        =   73
         Top             =   3120
         Width           =   3012
      End
      Begin VB.Label lblUNIX 
         Caption         =   "Additional Headers: (Optional)"
         Height          =   192
         Index           =   4
         Left            =   60
         TabIndex        =   72
         Top             =   3840
         Width           =   5172
      End
      Begin VB.Label lblUNIX 
         Caption         =   $"CfProf.frx":0549
         Height          =   612
         Index           =   0
         Left            =   60
         TabIndex        =   71
         Top             =   480
         Width           =   6312
      End
   End
End
Attribute VB_Name = "frmCfProf"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim AProf As Byte, TempProf() As String
Dim NoClick As Boolean

Private Sub cmdProf_Click(Index As Integer)
    If Index = 0 Then
        tb = tabProf.SelectedItem.Index - 1
        If tb = 15 Then MsgBox LMsg(5), vbCritical, LMsg(6): Exit Sub
        Me.MousePointer = 11
        cmdProf(0).Enabled = False
        For i = 0 To 3
            fraProf(i).Enabled = False
        Next i
        PendingCfg(3) = True
        Select Case AProf
            Case 0: a = "Retrieval"
            Case 1: a = "Send"
            Case 2: a = "News"
        End Select
        If ProgBusy(a) Then
            tmrProgBusy.Tag = a
            tmrProgBusy.Enabled = True
            Exit Sub
        End If
        UpdateData (tb)
        If AProf = 1 Then TempProf(15, 7) = Str(tb)
        'Check for profile name duplication
        Select Case AProf
            Case 0: x = 5: y = 0: names = vbCr
            Case 1: x = 1: y = 15: names = vbCr + "UNIX" + vbCr
            Case 2: x = 5: y = 31: names = vbCr
        End Select
        For i = 0 To 14
            TempProf(i + y, x) = Trim(TempProf(i + y, x))
            If TempProf(i + y, x) = "" Then TempProf(i + y, x) = Trim(Str(i + 1))
            names = names + Replace(TempProf(i + y, x), "&", "") + vbCr
        Next i
        For i = 0 To 14
            z = InStr(1, names, vbCr + Replace(TempProf(i + y, x), "&", "") + vbCr, vbTextCompare)
            z = InStr(z + 1, names, vbCr + Replace(TempProf(i + y, x), "&", "") + vbCr, vbTextCompare)
            If z <> 0 Then
                MsgBox LMsg(100), vbCritical, LMsg(6)
                Exit Sub
            End If
        Next i
        For i = 0 To MaxProfile
            For j = 0 To MaxProfileItem
                UserProf(i, j) = TempProf(i, j)
        Next j, i
        Select Case AProf
            Case 0: a = "Retrieval"
            Case 1: a = "Send"
            Case 2: a = "News"
        End Select
        If Not CheckConfig(a) Then
            PendingCfg(3) = False
            Me.MousePointer = 0
            For i = 0 To 3
                fraProf(i).Enabled = True
            Next i
            cmdProf(0).Enabled = True
            Exit Sub
        End If
        Me.MousePointer = 0
    End If
    Unload Me
End Sub

Private Sub tmrProgBusy_Timer()
    If Not ProgBusy(tmrProgBusy.Tag) Then tmrProgBusy.Enabled = False: cmdProf_Click (0)
End Sub

Private Sub tabProf_BeforeClick(Cancel As Integer)
    If NoClick Then Exit Sub
    UpdateData (tabProf.SelectedItem.Index - 1)
End Sub

Private Sub tabProf_Click()
    If NoClick Then Exit Sub
    tb = tabProf.SelectedItem.Index - 1
    NoClick = True
    'UpdateView
    Select Case AProf
    Case 0
        'POP
        'TempProf (0-14,0-)
        '0-2
        For i = 0 To 2
            chkPOP(i).Value = Val(TempProf(tb, i))
        Next i
        chkPOP(3).Value = Val(TempProf(tb, 15))
        '3-4
        optPOP(0).Value = True
        optPOP(1).Value = TempProf(tb, 4) = True2
        '5-12
        For i = 0 To 7
            txtPOP(i).Text = TempProf(tb, i + 5)
        Next i
        txtPOP(8).Text = TempProf(tb, 16)
        '13-14
        For i = 0 To 1
            If Val(TempProf(tb, i + 13)) <= cboPOP(i).ListCount - 1 Then cboPOP(i).ListIndex = Val(TempProf(tb, i + 13)) Else cboPOP(i).ListIndex = 0
        Next i
        NoClick = False
        chkPOP_Click (0)
        If txtPOP(0).Enabled Then txtPOP(0).SetFocus
    Case 1
        If tb <> 15 Then
            'SMTP
            fraProf(1).ZOrder
            'TempProf (15-29,0-)
            tb = tb + 15
            '0
            chkSMTP(0).Value = Val(TempProf(tb, 0))
            '1-6
            For i = 0 To 5
                txtSMTP(i).Text = TempProf(tb, i + 1)
            Next i
            For i = 1 To 2
                chkSMTP(i).Value = Val(TempProf(tb, i + 7))
            Next i
            NoClick = False
            chkSMTP_Click (0)
            If txtSMTP(0).Enabled Then txtSMTP(0).SetFocus
            SetCaption
        Else
            'UNIX
            fraProf(3).ZOrder
            'TempProf (30,0-)
            tb = 30
            '0
            chkUNIX(0).Value = Val(TempProf(tb, 0))
            '1-2
            optUNIX(0).Value = True
            optUNIX(1).Value = TempProf(tb, 2) = True2
            '3-6
            For i = 0 To 3
                txtUNIX(i).Text = TempProf(tb, i + 3)
            Next i
            NoClick = False
            chkUNIX_Click (0)
            If txtUNIX(0).Enabled Then txtUNIX(0).SetFocus
            SetCaption
        End If
    Case 2
        'NNTP
        'TempProf (31-45,0-)
        tb = tb + 31
        '0-2
        For i = 0 To 2
            chkNNTP(i).Value = Val(TempProf(tb, i))
        Next i
        '3-4
        optNNTP(0).Value = True
        optNNTP(1).Value = TempProf(tb, 4) = True2
        '5-15
        For i = 0 To 10
            txtNNTP(i).Text = TempProf(tb, i + 5)
        Next i
        NoClick = False
        chkNNTP_Click (0)
        If txtNNTP(0).Enabled Then txtNNTP(0).SetFocus
    End Select
End Sub

Private Sub UpdateData(tb)
    Select Case AProf
    Case 0
        'POP
        'TempProf (0-14,0-)
        '0-2
        For i = 0 To 2
            TempProf(tb, i) = Str(chkPOP(i).Value)
        Next i
        TempProf(tb, 15) = Str(chkPOP(3).Value)
        '3-4
        TempProf(tb, 3) = optPOP(0).Value
        TempProf(tb, 4) = optPOP(1).Value
        '5-12
        For i = 0 To 7
            TempProf(tb, i + 5) = Trim(txtPOP(i).Text)
        Next i
        TempProf(tb, 16) = Trim(txtPOP(8).Text)
        '13-14
        For i = 0 To 1
            TempProf(tb, i + 13) = Str(cboPOP(i).ListIndex)
        Next i
    Case 1
        If tb <> 15 Then
            'SMTP
            'TempProf (15-29,0-)
            tb = tb + 15
            '0
            TempProf(tb, 0) = Str(chkSMTP(0).Value)
            '1-6
            For i = 0 To 5
                TempProf(tb, i + 1) = Trim(txtSMTP(i).Text)
            Next i
            '8-9
            For i = 1 To 2
                TempProf(tb, i + 7) = Str(chkSMTP(i).Value)
            Next i
        Else
            'UNIX
            'TempProf (30,0-)
            tb = 30
            '0
            TempProf(tb, 0) = Str(chkUNIX(0).Value)
            '1-2
            For i = 0 To 1
                TempProf(tb, i + 1) = optUNIX(i).Value
            Next i
            '3-6
            For i = 0 To 3
                TempProf(tb, i + 3) = Trim(txtUNIX(i).Text)
            Next i
        End If
    Case 2
        'NNTP
        'TempProf (31-45,0-)
        tb = tb + 31
        '0-2
        For i = 0 To 2
            TempProf(tb, i) = Str(chkNNTP(i).Value)
        Next i
        '3-4
        For i = 0 To 1
            TempProf(tb, i + 3) = optNNTP(i).Value
        Next i
        '5-15
        For i = 0 To 10
            TempProf(tb, i + 5) = Trim(txtNNTP(i).Text)
        Next i
    End Select
End Sub

Private Sub chkUNIX_Click(Index As Integer)
    tabProf.SetFocus
    If NoClick Then Exit Sub
    If Index <> 0 Then Exit Sub
    state = chkUNIX(0).Value = 1
    For i = 0 To 3
        txtUNIX(i).Enabled = state
    Next i
    For i = 0 To 1
        optUNIX(i).Enabled = state
    Next i
    For i = 1 To 4
        lblUNIX(i).Enabled = state
    Next i
    a = "UNI&X" + Left(" *", chkUNIX(0).Value * 2)
    If tabProf.Tabs(tabProf.SelectedItem.Index).Caption <> a Then tabProf.Tabs(tabProf.SelectedItem.Index).Caption = a
End Sub

Private Sub chkNNTP_Click(Index As Integer)
    If NoClick Then Exit Sub
    If Index <> 0 And Index <> 1 Then Exit Sub
    state = chkNNTP(0).Value = 1
    For i = 0 To 10
        txtNNTP(i).Enabled = state
        If i < 10 Then lblNNTP(i).Enabled = state
    Next i
    For i = 0 To 1
        optNNTP(i).Enabled = state
    Next i
    txtNNTP(4).Enabled = state And (chkNNTP(1).Value = 1)
    For i = 1 To 2
        chkNNTP(i).Enabled = state
    Next i
    cmdResetNews.Enabled = state
    txtNNTP_Change (Index)
End Sub

Private Sub cmdResetNews_Click()
    If MsgBox(LMsg(540), vbOKCancel, LMsg(541)) = vbOK Then
        PData(tabProf.SelectedItem.Index + 122) = ""
        WriteData
    End If
End Sub

Private Sub txtNNTP_Change(Index As Integer)
    If NoClick Then Exit Sub
    If Index = 0 Then
        If txtNNTP(0).Text <> "" Then a = Trim(txtNNTP(0).Text) + Mid("   *", chkNNTP(0).Value * 2 + 1, 3) Else a = Trim(Str(tabProf.SelectedItem.Index)) + Mid("   *", chkNNTP(0).Value * 2 + 1, 3)
        If tabProf.Tabs(tabProf.SelectedItem.Index).Caption <> a Then tabProf.Tabs(tabProf.SelectedItem.Index).Caption = a
    End If
End Sub

Private Sub chkSMTP_Click(Index As Integer)
    If NoClick Then Exit Sub
    If Index <> 0 Then Exit Sub
    state = chkSMTP(0).Value = 1
    For i = 1 To 2
        chkSMTP(i).Enabled = state
    Next i
    For i = 0 To 5
        txtSMTP(i).Enabled = state
        lblSMTP(i).Enabled = state
    Next i
    txtSMTP_Change (0)
End Sub

Private Sub txtSMTP_Change(Index As Integer)
    If NoClick Then Exit Sub
    If Index = 0 Then
        If txtSMTP(0).Text <> "" Then a = Trim(txtSMTP(0).Text) + Mid("   *", chkSMTP(0).Value * 2 + 1, 3) Else a = Trim(Str(tabProf.SelectedItem.Index)) + Mid("   *", chkSMTP(0).Value * 2 + 1, 3)
        If tabProf.Tabs(tabProf.SelectedItem.Index).Caption <> a Then tabProf.Tabs(tabProf.SelectedItem.Index).Caption = a
        SetCaption
    End If
End Sub

Private Sub chkPOP_Click(Index As Integer)
    If NoClick Then Exit Sub
    If Index <> 0 And Index <> 1 And Index <> 3 Then Exit Sub
    state = chkPOP(0).Value = 1
    For i = 1 To 3
        chkPOP(i).Enabled = state
    Next i
    For i = 0 To 1
        optPOP(i).Enabled = state
        cboPOP(i).Enabled = state
    Next i
    For i = 0 To 5
        txtPOP(i).Enabled = state
    Next i
    txtPOP(4).Enabled = state And (chkPOP(1).Value = 1)
    txtPOP(8).Enabled = state And (chkPOP(3).Value = 1)
    If Index = 1 And txtPOP(4).Enabled Then txtPOP(4).SetFocus
    If Index = 3 And txtPOP(8).Enabled Then txtPOP(8).SetFocus
    For i = 0 To 5
        lblPOP(i).Enabled = state
    Next i
    txtPOP_Change (Index)
    cboPOP_Click (0): cboPOP_Click (1)
End Sub

Private Sub txtPOP_Change(Index As Integer)
    If NoClick Then Exit Sub
    If Index = 0 Then
        If txtPOP(0).Text <> "" Then a = Trim(txtPOP(0).Text) + Mid("   *", chkPOP(0).Value * 2 + 1, 3) Else a = Trim(Str(tabProf.SelectedItem.Index)) + Mid("   *", chkPOP(0).Value * 2 + 1, 3)
        If tabProf.Tabs(tabProf.SelectedItem.Index).Caption <> a Then tabProf.Tabs(tabProf.SelectedItem.Index).Caption = a
    End If
End Sub

Private Sub cboPOP_Click(Index As Integer)
    If NoClick Then Exit Sub
    txtPOP(6).Enabled = cboPOP(0).ListIndex = 2 And (chkPOP(0).Value = 1)
    txtPOP(7).Enabled = cboPOP(1).ListIndex <> 0 And (chkPOP(0).Value = 1)
End Sub

Private Sub cmdHelp_Click()
    Dim Topic As String
    
    Select Case AProf
    Case 0: Topic = "#CfgRetProf"
    Case 1: If tabProf.SelectedItem.Index = 16 Then Topic = "#CfgUNIXProf" Else Topic = "#CfgSMTPProf"
    Case 2: Topic = "#CfgNewsProf"
    End Select
    ShowHelp 0, Topic, "2"
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    If KeyCode = vbKeyF1 And Shift = 0 Then cmdHelp_Click: KeyCode = 0
End Sub

Private Sub SetCaption()
    cmdProf(0).Caption = "&OK  [" + tabProf.Tabs(tabProf.SelectedItem.Index).Caption + "]"
End Sub

Private Sub Form_Activate()
    If Me.Tag <> "" Then
        AProf = Val(Me.Tag)
        Me.Tag = ""
        fraProf(AProf).ZOrder
        ReDim TempProf(MaxProfile, MaxProfileItem)
        For i = 0 To MaxProfile
            For j = 0 To MaxProfileItem
                TempProf(i, j) = UserProf(i, j)
        Next j, i
        NoClick = True
        Select Case AProf
        Case 0
            Me.Caption = "Configuration - [Retrieval Profiles]"
            For i = 0 To 14
                If TempProf(i, 5) <> "" Then a = Trim(TempProf(i, 5)) + Mid("   *", Val(TempProf(i, 0)) * 2 + 1, 3) Else a = Trim(Str(i + 1)) + Mid("   *", Val(TempProf(i, 0)) * 2 + 1, 3)
                tabProf.Tabs(i + 1).Caption = a
            Next i
        Case 1
            Me.Caption = "Configuration - [Send Profiles]"
            If tabProf.Tabs.Count < 16 Then tabProf.Tabs.Add 16, "", "UNI&X" + Mid("   *", Val(TempProf(30, 0)) * 2 + 1, 3)
            For i = 15 To 29
                If TempProf(i, 1) <> "" Then a = Trim(TempProf(i, 1)) + Mid("   *", Val(TempProf(i, 0)) * 2 + 1, 3) Else a = Trim(Str(i - 14)) + Mid("   *", Val(TempProf(i, 0)) * 2 + 1, 3)
                tabProf.Tabs(i - 14).Caption = a
            Next i
            tabProf.Tabs(Val(TempProf(15, 7)) + 1).Selected = True
        Case 2
            Me.Caption = "Configuration - [News Profiles]"
            For i = 31 To 45
                If TempProf(i, 5) <> "" Then a = Trim(TempProf(i, 5)) + Mid("   *", Val(TempProf(i, 0)) * 2 + 1, 3) Else a = Trim(Str(i - 30)) + Mid("   *", Val(TempProf(i, 0)) * 2 + 1, 3)
                tabProf.Tabs(i - 30).Caption = a
            Next i
        End Select
        NoClick = False
        tabProf_Click
    End If
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(98))
    Me.Top = Val(PData(99))
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PendingCfg(3) = False
    Erase TempProf
    PData(98) = Str(Me.Left)
    PData(99) = Str(Me.Top)
End Sub

