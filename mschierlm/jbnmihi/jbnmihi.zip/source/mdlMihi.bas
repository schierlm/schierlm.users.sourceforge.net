Attribute VB_Name = "mdlMihi"
Option Explicit
'' ### my modifications to JBN: ###

'' In Main, change Version number to
'' "2.1.4mihi1"

'' ## againt i18n bug: ##

'' In Sub Form_Load in frmMain, add as first line:
'' mihiInitialize

'' in Sub WriteArray in Standard, replace the two lines
''            If InStr(a, "&&") <> 0 Then a = Replace(a, "&&", "===AMPAMP===")
''            If InStr(a, vbCrLf) <> 0 Then a = Replace(a, vbCrLf, "&&")
'' by
''            a = ConvertForSaving(a)

'' in Sub ReadArray in Standard, replace the two lines
''            If InStr(a, "&&") <> 0 Then a = Replace(a, "&&", vbCrLf)
''            If InStr(a, "===AMPAMP===") <> 0 Then a = Replace(a, "===AMPAMP===", "&&")
'' by
''            a = ConvertForLoading(a)

'' in *the*whole*project* (!), replace all
'' " F a l s e "
'' by
'' False2
'' and all
'' " T r u e "
'' by
'' True2
'' (without the spaces).

'' ## to make keyboard use simpler: ##
'' Added to frmMain
''    Private Sub filExplore_KeyPress(Index As Integer, KeyAscii As Integer)
''        cboRecent_KeyPress KeyAscii
''    End Sub

'' removed last line from Private Sub filExplore_Click(Index As Integer)
''    cboRecent.SetFocus

'' set Default and Cancel buttons -- use Ctrl+Return to add a
'' newline to a text box, when there is a default button.

'' #### speedup if not \JBN2 ####
'' commented out the two lines with program files hardcoded

'' in frmMain#ReadFolder, replaced
''    dirmax = dirmax + 10
'' by
''    dirmax = dirmax * 2 + 1
'' to use exponential growing - much faster if you have many dirs.
'' (btw - why has the original programmer not used a Collection there?)

'' in frmMain#ReadFolder, replaced
''        If Not RootDir Then ReadFolders pth + "\" + dirs(i), nod.Index
'' by
''        Dim doit As Boolean
''        doit = Not RootDir
''        If Left$(ProgDir, Len(pth)) = pth And ProgDir <> pth Then
''            If Left$(ProgDir, Len(nod.Tag)) <> nod.Tag Then
''                doit = False
''                nod.Tag = nod.Tag + "::"
''            End If
''        End If
''        If doit Then ReadFolders pth + "\" + dirs(i), nod.Index
'' to not show subfolders if folder is direct parent of JBN folder

'' in frmMain#trvFolder_NodeClick - added to beginning of else branch:
''        If Right$(Node.Tag, 2) = "::" Then
''            Node.Tag = Left$(Node.Tag, Len(Node.Tag) - 2)
''            ReadFolders Node.Tag, Node.Index
''        End If

'' somebody has to rewrite that shit with loading all folders to
'' use the "Expanded" events instead (only test if there are
'' subfolders and show them when necessary... But not now.

'' #####################################
'' for interpreted version, replaced
'' all "\VB\" by "\"

'' ### contact me at schierlm@gmx.de ###

'' string constants for representing False and True in memory and in files
'' I know that's a dirty hack - but it works.
Public False2 As String, True2 As String
Const SavedFalse2 = "Fal" + "se" ' so that it is not changed.
Const SavedTrue2 = "Tr" + "ue"
Const SavedProgDir2 = "C:\JBN2"

Public Sub mihiInitialize()
False2 = CStr(False)
True2 = CStr(True)
End Sub

Public Function ConvertForSaving(ByVal s As String) As String
Dim sbuf As String
sbuf = s
If InStr(sbuf, "&&") <> 0 Then sbuf = Replace(sbuf, "&&", "===AMPAMP===")
If InStr(sbuf, vbCrLf) <> 0 Then sbuf = Replace(sbuf, vbCrLf, "&&")
If False2 <> SavedFalse2 And sbuf = False2 Then sbuf = SavedFalse2
If True2 <> SavedTrue2 And sbuf = True2 Then sbuf = SavedTrue2
If ProgDir <> SavedProgDir2 And InStr(sbuf, ProgDir) <> 0 Then sbuf = Replace(sbuf, ProgDir, SavedProgDir2)
ConvertForSaving = sbuf
End Function

Public Function ConvertForLoading(ByVal s As String) As String
Dim sbuf As String
sbuf = s
If InStr(sbuf, "&&") <> 0 Then sbuf = Replace(sbuf, "&&", vbCrLf)
If InStr(sbuf, "===AMPAMP===") <> 0 Then sbuf = Replace(sbuf, "===AMPAMP===", "&&")
If False2 <> SavedFalse2 And sbuf = SavedFalse2 Then sbuf = False2
If True2 <> SavedTrue2 And sbuf = SavedTrue2 Then sbuf = True2
If ProgDir <> SavedProgDir2 And InStr(sbuf, SavedProgDir2) <> 0 Then sbuf = Replace(sbuf, SavedProgDir2, ProgDir)
ConvertForLoading = sbuf
End Function
