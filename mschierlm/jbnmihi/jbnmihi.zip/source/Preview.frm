VERSION 5.00
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "RICHTX32.OCX"
Begin VB.Form frmPreview 
   Caption         =   "Preview Cypherpunk - [Stage 1/1]"
   ClientHeight    =   6105
   ClientLeft      =   45
   ClientTop       =   315
   ClientWidth     =   8070
   Icon            =   "Preview.frx":0000
   LinkTopic       =   "Form1"
   MinButton       =   0   'False
   ScaleHeight     =   6105
   ScaleWidth      =   8070
   Begin RichTextLib.RichTextBox rtbBody 
      Height          =   2952
      Left            =   60
      TabIndex        =   0
      Top             =   2700
      Width           =   7932
      _ExtentX        =   13996
      _ExtentY        =   5212
      _Version        =   393217
      ReadOnly        =   -1  'True
      ScrollBars      =   3
      TextRTF         =   $"Preview.frx":0442
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.CommandButton cmdPreview 
      Caption         =   "&Finish  >>"
      Height          =   396
      Index           =   1
      Left            =   2124
      TabIndex        =   8
      Top             =   5700
      Width           =   1812
   End
   Begin VB.CommandButton cmdPreview 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   396
      Index           =   2
      Left            =   4104
      TabIndex        =   6
      Top             =   5700
      Width           =   1812
   End
   Begin VB.CommandButton cmdPreview 
      Caption         =   "&Next  >"
      Default         =   -1  'True
      Height          =   396
      Index           =   0
      Left            =   144
      TabIndex        =   5
      Top             =   5700
      Width           =   1812
   End
   Begin VB.TextBox txtInfo 
      BackColor       =   &H8000000F&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000012&
      Height          =   852
      Left            =   60
      Locked          =   -1  'True
      MaxLength       =   31035
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertikal
      TabIndex        =   2
      Top             =   120
      Width           =   7932
   End
   Begin VB.TextBox txtHeaders 
      BackColor       =   &H8000000F&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000012&
      Height          =   1272
      Left            =   60
      Locked          =   -1  'True
      MaxLength       =   31035
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Beides
      TabIndex        =   1
      Top             =   1200
      Width           =   7932
   End
   Begin VB.CommandButton cmdOpen 
      Caption         =   "&Open"
      Height          =   396
      Left            =   6084
      TabIndex        =   7
      Top             =   5700
      Width           =   1812
   End
   Begin VB.Label lblBody 
      Caption         =   "Body:   (Shown before encryption)"
      Height          =   192
      Left            =   60
      TabIndex        =   4
      Top             =   2508
      Width           =   7812
   End
   Begin VB.Label lblHeaders 
      Caption         =   "Headers:"
      Height          =   192
      Left            =   60
      TabIndex        =   3
      Top             =   1010
      Width           =   2832
   End
End
Attribute VB_Name = "frmPreview"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim NoResize  As Boolean

Private Sub cmdOpen_Click()
    rtbBody.SetFocus
    fn = cmdOpen.Tag
    If SDir(fn) = "" Then Err.Description = LMsg(66): GoTo OpenError
    a = OpenFileAPI("test1111.txt")
    a = Replace(a, "test1111.txt", fn)
    If a = "" Then a = "notepad " + fn
    Shell a, vbNormalFocus
Exit Sub
OpenError:
    MsgBox LMsg(0) + vbCr + Err.Description, vbCritical, LMsg(4)
End Sub

Private Sub cmdPreview_Click(Index As Integer)
    cmdPreview(0).Tag = Str(Index)
    rtbBody.Text = ""
    txtInfo.Text = ""
    txtHeaders.Text = ""
    Me.Hide
End Sub

Private Sub rtbBody_KeyDown(KeyCode As Integer, Shift As Integer)
    'To stop beeping
    If KeyCode < 41 Then
        Select Case KeyCode
        Case 40: If rtbBody.GetLineFromChar(rtbBody.SelStart) = rtbBody.GetLineFromChar(Len(rtbBody.Text)) Then KeyCode = 0
        Case 39: If rtbBody.SelStart = Len(rtbBody.Text) Then KeyCode = 0
        Case 38: If rtbBody.GetLineFromChar(rtbBody.SelStart) = 0 Then KeyCode = 0
        Case 37: If rtbBody.SelStart = 0 Then KeyCode = 0
        End Select
    End If
End Sub

Private Sub Form_Resize()
    Dim sh As Long, sw As Long
    
    If NoResize Then Exit Sub
    If Me.WindowState <> 1 Then
        NoResize = True
        If Me.WindowState <> 2 Then
            If Me.Height < 2832 Then Me.Height = 2832
            If Me.Width < 4848 Then Me.Width = 4848
        End If
        sh = Me.ScaleHeight
        sw = Me.ScaleWidth
        txtInfo.Height = sh * 0.139
        lblHeaders.Top = txtInfo.Top + txtInfo.Height + 38
        If txtHeaders.Top <> rtbBody.Top Then
            txtHeaders.Top = lblHeaders.Top + 190
            txtHeaders.Height = sh * 0.208
            lblBody.Top = txtHeaders.Top + txtHeaders.Height + 36
            rtbBody.Top = lblBody.Top + 192
            rtbBody.Height = sh - rtbBody.Top - 456
        Else
            txtHeaders.Top = lblHeaders.Top + 190
            txtHeaders.Height = sh * 0.208
            lblBody.Top = txtHeaders.Top + txtHeaders.Height + 36
            rtbBody.Top = txtHeaders.Top
            rtbBody.Height = sh - rtbBody.Top - 456
        End If
        txtInfo.Width = sw - 132
        txtHeaders.Width = sw - 132
        rtbBody.Width = sw - 132
        rtbBody.RightMargin = rtbBody.Width - 312
        cmdPreview(0).Top = sh - 408
        cmdPreview(1).Top = sh - 408
        cmdPreview(2).Top = sh - 408
        cmdOpen.Top = sh - 408
        cmdPreview(0).Left = sw / 2 - 3888
        cmdPreview(1).Left = cmdPreview(0).Left + 1980
        cmdPreview(2).Left = cmdPreview(0).Left + 3960
        cmdOpen.Left = cmdPreview(0).Left + 5940
        NoResize = False
    End If
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(25))
    Me.Top = Val(PData(26))
    If Val(PData(27)) <> 0 And Val(PData(28)) <> 0 Then
        Me.Width = Val(PData(27))
        Me.Height = Val(PData(28))
    End If
    If Val(PData(29)) <> 1 Then Me.WindowState = Val(PData(29))
    rtbBody.Font.Name = Cnf(2, 25)
    rtbBody.Font.Size = Val(Cnf(2, 26))
    rtbBody.Font.Bold = (Cnf(2, 27) = True2)
End Sub

Private Sub Form_Unload(Cancel As Integer)
    If Me.WindowState = 0 Then
        PData(25) = Str(Me.Left)
        PData(26) = Str(Me.Top)
        PData(27) = Str(Me.Width)
        PData(28) = Str(Me.Height)
    End If
    PData(29) = Str(Me.WindowState)
    If Me.Tag <> "" Then
        Cancel = 1
        Me.Hide
    End If
End Sub

