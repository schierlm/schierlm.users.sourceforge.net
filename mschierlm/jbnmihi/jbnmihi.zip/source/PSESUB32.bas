Attribute VB_Name = "PSESUB32"
'   PSESUB32.BAS
'   This module should be included in VB applications which use
'   PSESUB32.DLL.
'   When passing strings, use only null terminated fixed-length strings.
'   For example:  Dim SubjectString as string * 256
'                 SubjectString = "My Subject" + chr(0)

'Returns 0 if ok and places result in EncSubject.
'Returns -1 if parameters are invalid
Declare Function psEncryptSubject Lib "PSESUB32.DLL" _
    Alias "_psEncryptSubject@12" _
    (ByVal Subject As String, ByVal Key As String, _
    ByVal EncSubject As String) As Long

'Returns 0 if test result is a match
'Returns non-zero result if no match or if parameters invalid
Declare Function psTestSubject Lib "PSESUB32.DLL" _
    Alias "_psTestSubject@12" _
    (ByVal EncSubject As String, ByVal Subject As String, _
    ByVal Key As String) As Long

'Returns 0 and places MD5 hash of Buffer in Hash
Declare Function psMD5Hash Lib "PSESUB32.DLL" _
    Alias "_psMD5Hash@8" _
    (ByVal Buffer As String, ByVal Hash As String) As Long

'Returns 0 and places the version string of the DLL in VersionString
Declare Function psEsub32DLLVersion Lib "PSESUB32.DLL" _
    Alias "_psEsub32DLLVersion@4" _
    (ByVal VersionString As String) As Long

