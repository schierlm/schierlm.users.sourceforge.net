VERSION 5.00
Begin VB.Form frmMsgTime 
   BorderStyle     =   1  'Fest Einfach
   ClientHeight    =   2085
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   6240
   Icon            =   "MsgTime.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2085
   ScaleWidth      =   6240
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'Bildschirmmitte
   Begin VB.Timer tmrTime 
      Interval        =   50
      Left            =   5280
      Top             =   0
   End
   Begin VB.CheckBox chkTime 
      Height          =   192
      Left            =   300
      TabIndex        =   4
      Top             =   2076
      Visible         =   0   'False
      Width           =   5052
   End
   Begin VB.CommandButton cmdTime 
      Caption         =   "&Cancel"
      Height          =   432
      Index           =   2
      Left            =   4200
      TabIndex        =   3
      Top             =   1560
      Width           =   1572
   End
   Begin VB.CommandButton cmdTime 
      Caption         =   "&Cancel"
      Height          =   432
      Index           =   1
      Left            =   2280
      TabIndex        =   2
      Top             =   1560
      Width           =   1572
   End
   Begin VB.CommandButton cmdTime 
      Caption         =   "&OK [60]"
      Height          =   432
      Index           =   0
      Left            =   360
      TabIndex        =   1
      Top             =   1560
      Width           =   1572
   End
   Begin VB.Label lblMsg 
      AutoSize        =   -1  'True
      Height          =   192
      Left            =   180
      TabIndex        =   0
      Top             =   180
      Visible         =   0   'False
      Width           =   5892
      WordWrap        =   -1  'True
   End
End
Attribute VB_Name = "frmMsgTime"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim NoClick As Boolean

Private Sub cmdTime_Click(Index As Integer)
    Me.Tag = Str(Index)
    cmdTime(0).Tag = True2
    Me.Hide
End Sub

Private Sub Form_Activate()
    cmdTime(Val(Me.Tag)).SetFocus
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    If KeyAscii = 27 Then tmrTime.Enabled = False
End Sub

Private Sub tmrTime_Timer()
    tmrTime.Interval = 1000
    x = Val(tmrTime.Tag) - 1
    cmdTime(Val(Me.Tag)).Caption = Trim(Extract(cmdTime(Val(Me.Tag)).Caption, "[")) + "  [" + Trim(Str(x)) + "]"
    tmrTime.Tag = Str(x)
    If x = 0 Then Me.Hide
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If UnloadMode = vbFormControlMenu Then Cancel = 1
End Sub

Private Sub Form_Resize()
    If NoClick Then Exit Sub
    lw = lblMsg.Width
    If lw < 5280 Then lw = 5280
    If lblMsg.Height < 1152 Then lblMsg.Height = 1152
    Me.Width = lw + 432
    If chkTime.Visible Then
        Me.Height = lblMsg.Height + 1536
        For i = 0 To 2
            cmdTime(i).Top = Me.ScaleHeight - 768
        Next i
        chkTime.Top = Me.ScaleHeight - 252
    Else
        Me.Height = lblMsg.Height + 1296
        For i = 0 To 2
            cmdTime(i).Top = Me.ScaleHeight - 528
        Next i
    End If
    lblMsg.Left = (Me.ScaleWidth - lblMsg.Width) / 2
    NoClick = True
    If Me.Width > Screen.Width - 500 Then Me.Width = Screen.Width - 500
    If Me.Height > Screen.Height - 750 Then Me.Height = Screen.Height - 750
    NoClick = False
    If chkTime.Visible Then
        If lblMsg.Height > Me.ScaleHeight - 1092 Then lblMsg.Height = Me.ScaleHeight - 1092
    Else
        If lblMsg.Height > Me.ScaleHeight - 852 Then lblMsg.Height = Me.ScaleHeight - 852
    End If
    If cmdTime(1).Visible And cmdTime(2).Visible Then
        cmdTime(1).Left = (Me.ScaleWidth - cmdTime(1).Width) / 2
        cmdTime(0).Left = cmdTime(1).Left - 1920
        cmdTime(2).Left = cmdTime(1).Left + 1920
    ElseIf cmdTime(1).Visible Then
        cmdTime(0).Left = Me.ScaleWidth / 2 - cmdTime(0).Width - 384
        cmdTime(1).Left = Me.ScaleWidth / 2 + 384
    Else
        cmdTime(0).Left = (Me.ScaleWidth - cmdTime(1).Width) / 2
    End If
    Me.Left = (Screen.Width - Me.Width) / 2
    Me.Top = (Screen.Height - Me.Height) / 2
    lblMsg.Visible = True
End Sub


