VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "RICHTX32.OCX"
Begin VB.Form frmViewer 
   Caption         =   "View Mail"
   ClientHeight    =   6930
   ClientLeft      =   135
   ClientTop       =   420
   ClientWidth     =   8550
   Icon            =   "Viewer.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   6930
   ScaleWidth      =   8550
   Begin VB.Timer tmrUpdate 
      Enabled         =   0   'False
      Interval        =   300
      Left            =   420
      Top             =   1020
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   1380
      Top             =   960
      _ExtentX        =   688
      _ExtentY        =   688
      _Version        =   393216
   End
   Begin VB.Frame fraMessage 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4932
      Left            =   0
      TabIndex        =   5
      Top             =   1680
      Width           =   8556
      Begin VB.CommandButton cmdTrash 
         DisabledPicture =   "Viewer.frx":0442
         Height          =   372
         Index           =   0
         Left            =   6416
         MaskColor       =   &H00000000&
         MouseIcon       =   "Viewer.frx":0664
         Picture         =   "Viewer.frx":07B6
         Style           =   1  'Grafisch
         TabIndex        =   9
         TabStop         =   0   'False
         Top             =   0
         UseMaskColor    =   -1  'True
         Width           =   492
      End
      Begin VB.CommandButton cmdTrash 
         DisabledPicture =   "Viewer.frx":09D8
         Height          =   372
         Index           =   1
         Left            =   6956
         MaskColor       =   &H00000000&
         MouseIcon       =   "Viewer.frx":0BFA
         Picture         =   "Viewer.frx":0D4C
         Style           =   1  'Grafisch
         TabIndex        =   8
         TabStop         =   0   'False
         Top             =   0
         UseMaskColor    =   -1  'True
         Width           =   492
      End
      Begin VB.CommandButton cmdNavigate 
         Height          =   372
         Index           =   0
         Left            =   7496
         MaskColor       =   &H00000000&
         Picture         =   "Viewer.frx":0F6E
         Style           =   1  'Grafisch
         TabIndex        =   7
         TabStop         =   0   'False
         Top             =   0
         UseMaskColor    =   -1  'True
         Width           =   492
      End
      Begin VB.CommandButton cmdNavigate 
         Height          =   372
         Index           =   1
         Left            =   8036
         MaskColor       =   &H00000000&
         Picture         =   "Viewer.frx":1190
         Style           =   1  'Grafisch
         TabIndex        =   6
         TabStop         =   0   'False
         Top             =   0
         UseMaskColor    =   -1  'True
         Width           =   492
      End
      Begin VB.Frame fraView 
         BorderStyle     =   0  'Kein
         Caption         =   "Frame1"
         Height          =   4452
         Index           =   0
         Left            =   56
         TabIndex        =   10
         Top             =   420
         Width           =   8432
         Begin VB.CommandButton cmdOpenBook 
            Caption         =   "Open &Book"
            DisabledPicture =   "Viewer.frx":13B2
            Height          =   288
            Left            =   6840
            MaskColor       =   &H00000000&
            MouseIcon       =   "Viewer.frx":15D4
            TabIndex        =   25
            TabStop         =   0   'False
            Top             =   12
            UseMaskColor    =   -1  'True
            Width           =   1572
         End
         Begin VB.CheckBox chkView 
            Caption         =   "&Raw"
            Height          =   312
            Index           =   1
            Left            =   4728
            TabIndex        =   14
            TabStop         =   0   'False
            Top             =   12
            Width           =   972
         End
         Begin VB.CheckBox chkView 
            Caption         =   "Header&s"
            Height          =   312
            Index           =   0
            Left            =   3348
            TabIndex        =   12
            TabStop         =   0   'False
            Top             =   12
            Width           =   1332
         End
         Begin VB.ComboBox cboReply 
            Height          =   288
            Left            =   6780
            Sorted          =   -1  'True
            TabIndex        =   11
            TabStop         =   0   'False
            Top             =   0
            Width           =   1642
         End
         Begin RichTextLib.RichTextBox rtbView 
            Height          =   4152
            Left            =   0
            TabIndex        =   13
            Top             =   300
            Width           =   8430
            _ExtentX        =   14870
            _ExtentY        =   7329
            _Version        =   393217
            ScrollBars      =   2
            TextRTF         =   $"Viewer.frx":1726
         End
         Begin VB.Label lblView 
            BackStyle       =   0  'Transparent
            Height          =   192
            Left            =   24
            TabIndex        =   16
            Top             =   60
            Width           =   4152
         End
         Begin VB.Label lblReply 
            Alignment       =   1  'Rechts
            BackStyle       =   0  'Transparent
            Caption         =   "Reply Via:"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   -1  'True
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   192
            Left            =   5580
            TabIndex        =   15
            Top             =   60
            Width           =   1152
         End
      End
      Begin VB.Frame fraView 
         BorderStyle     =   0  'Kein
         Caption         =   "Frame1"
         Height          =   4452
         Index           =   1
         Left            =   56
         TabIndex        =   17
         Top             =   420
         Visible         =   0   'False
         Width           =   8432
         Begin VB.CommandButton cmdAttach 
            Caption         =   "Save As..."
            Height          =   432
            Index           =   0
            Left            =   1320
            TabIndex        =   19
            Top             =   3960
            Width           =   2172
         End
         Begin VB.CommandButton cmdAttach 
            Caption         =   "Save and Open As..."
            Height          =   432
            Index           =   1
            Left            =   4860
            TabIndex        =   18
            Top             =   3960
            Width           =   2172
         End
         Begin ComctlLib.ListView lstAttach 
            Height          =   3288
            Left            =   90
            TabIndex        =   20
            Top             =   180
            Width           =   8232
            _ExtentX        =   14526
            _ExtentY        =   5794
            View            =   3
            LabelEdit       =   1
            LabelWrap       =   -1  'True
            HideSelection   =   0   'False
            _Version        =   327682
            ForeColor       =   -2147483640
            BackColor       =   -2147483643
            BorderStyle     =   1
            Appearance      =   1
            NumItems        =   0
         End
         Begin VB.Label lblAttach 
            Alignment       =   2  'Zentriert
            BackStyle       =   0  'Transparent
            Caption         =   "Click here for important information about viruses."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   -1  'True
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FF0000&
            Height          =   252
            Index           =   1
            Left            =   120
            TabIndex        =   22
            Top             =   3660
            Width           =   8112
         End
         Begin VB.Label lblAttach 
            Alignment       =   2  'Zentriert
            Caption         =   "Unless an attachment is PGP signed by a trusted sender, it may contain a virus."
            Height          =   192
            Index           =   0
            Left            =   120
            TabIndex        =   21
            Top             =   3480
            Width           =   8112
         End
      End
      Begin VB.CommandButton cmdDecrypt 
         Caption         =   "Decrypt &Now"
         Height          =   432
         Left            =   720
         TabIndex        =   24
         Top             =   1020
         Visible         =   0   'False
         Width           =   2532
      End
      Begin ComctlLib.TabStrip tabView 
         Height          =   4872
         Left            =   0
         TabIndex        =   23
         TabStop         =   0   'False
         Top             =   48
         Width           =   8530
         _ExtentX        =   15055
         _ExtentY        =   8599
         TabWidthStyle   =   2
         TabFixedWidth   =   2699
         TabFixedHeight  =   572
         _Version        =   327682
         BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
            NumTabs         =   3
            BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "&Original"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "&Decrypted"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "&Info"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
         EndProperty
      End
   End
   Begin VB.Timer tmrOLE 
      Enabled         =   0   'False
      Interval        =   300
      Left            =   960
      Top             =   1020
   End
   Begin ComctlLib.TreeView trvFolder 
      Height          =   1668
      Left            =   36
      TabIndex        =   0
      Top             =   0
      Width           =   2112
      _ExtentX        =   3731
      _ExtentY        =   2937
      _Version        =   327682
      HideSelection   =   0   'False
      Indentation     =   176
      LineStyle       =   1
      Sorted          =   -1  'True
      Style           =   7
      Appearance      =   1
   End
   Begin ComctlLib.ListView lstMail 
      Height          =   1668
      Left            =   2172
      TabIndex        =   1
      Top             =   0
      Width           =   6372
      _ExtentX        =   11245
      _ExtentY        =   2937
      View            =   3
      Sorted          =   -1  'True
      MultiSelect     =   -1  'True
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      _Version        =   327682
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   0
   End
   Begin VB.Label lblStat 
      Alignment       =   2  'Zentriert
      BorderStyle     =   1  'Fest Einfach
      Caption         =   "000 / 000"
      Height          =   252
      Index           =   2
      Left            =   7800
      TabIndex        =   4
      Top             =   6624
      Width           =   732
   End
   Begin VB.Label lblStat 
      BorderStyle     =   1  'Fest Einfach
      Height          =   252
      Index           =   1
      Left            =   4680
      TabIndex        =   3
      Top             =   6624
      Width           =   3096
   End
   Begin VB.Label lblStat 
      BorderStyle     =   1  'Fest Einfach
      Height          =   252
      Index           =   0
      Left            =   24
      TabIndex        =   2
      Top             =   6624
      Width           =   4632
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuSave 
         Caption         =   "&Save Message"
         Index           =   0
         Shortcut        =   ^S
      End
      Begin VB.Menu mnuSave 
         Caption         =   "Save Message &As..."
         Index           =   1
      End
      Begin VB.Menu sepFile1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuSelected 
         Caption         =   "Selected Messa&ges"
         Begin VB.Menu mnuMoveTo 
            Caption         =   "&Move To"
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   0
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   1
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   2
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   3
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   4
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   5
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   6
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   7
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   8
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   9
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   10
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   11
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   12
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   13
               Visible         =   0   'False
            End
            Begin VB.Menu mnuMove 
               Caption         =   ""
               Index           =   14
               Visible         =   0   'False
            End
         End
         Begin VB.Menu mnuDecSel 
            Caption         =   "&Decrypt"
         End
         Begin VB.Menu sepFile6 
            Caption         =   "-"
         End
         Begin VB.Menu mnuSaveSel 
            Caption         =   "&Save As..."
            Index           =   0
         End
         Begin VB.Menu mnuSaveSel 
            Caption         =   "&Append As..."
            Index           =   1
         End
         Begin VB.Menu sepFile9 
            Caption         =   "-"
         End
         Begin VB.Menu mnuDeleteSel 
            Caption         =   "D&elete"
            Index           =   0
         End
         Begin VB.Menu mnuDeleteSel 
            Caption         =   "Delete &Original"
            Index           =   1
         End
         Begin VB.Menu mnuDeleteSel 
            Caption         =   "Delete De&crypted"
            Index           =   2
         End
         Begin VB.Menu mnuDeleteSel 
            Caption         =   "-"
            Index           =   3
         End
         Begin VB.Menu mnuDeleteSel 
            Caption         =   "&Wipe"
            Index           =   4
         End
         Begin VB.Menu mnuDeleteSel 
            Caption         =   "Wipe Ori&ginal"
            Index           =   5
         End
         Begin VB.Menu mnuDeleteSel 
            Caption         =   "Wi&pe Decrypted"
            Index           =   6
         End
         Begin VB.Menu sepFil8 
            Caption         =   "-"
         End
         Begin VB.Menu mnuMarkRead 
            Caption         =   "Mark &Read"
            Index           =   0
         End
         Begin VB.Menu mnuMarkRead 
            Caption         =   "Mark &Unread"
            Index           =   1
         End
      End
      Begin VB.Menu mnuImport 
         Caption         =   "I&mport Messages..."
      End
      Begin VB.Menu sepFile3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuText 
         Caption         =   "&New Text"
         Index           =   0
      End
      Begin VB.Menu mnuText 
         Caption         =   "&Load Text File"
         Index           =   1
         Shortcut        =   ^O
      End
      Begin VB.Menu mnuText 
         Caption         =   "&Insert Text File"
         Index           =   2
      End
      Begin VB.Menu mnuText 
         Caption         =   "Save Te&xt As..."
         Index           =   3
      End
      Begin VB.Menu sepFile7 
         Caption         =   "-"
      End
      Begin VB.Menu mnuPrint 
         Caption         =   "&Print"
         Shortcut        =   ^P
      End
      Begin VB.Menu sepFile4 
         Caption         =   "-"
      End
      Begin VB.Menu mnuHome 
         Caption         =   "&Default Inbox"
      End
      Begin VB.Menu mnuChangeDrik 
         Caption         =   "Open Mail &Folder..."
      End
      Begin VB.Menu mnuExplore 
         Caption         =   "&Explore Mail Folder"
      End
      Begin VB.Menu sepFile2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuEmpty 
         Caption         =   "Empt&y Trash"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuEdit 
      Caption         =   "&Edit"
      Begin VB.Menu mnuEditArray 
         Caption         =   "Und&o     [Ctrl+Z]"
         Index           =   0
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "&Copy     [Ctrl+C]"
         Index           =   1
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "Copy Appen&d"
         Index           =   2
         Shortcut        =   ^D
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "Cu&t     [Ctrl+X]"
         Index           =   3
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "&Paste     [Ctrl+V]"
         Index           =   4
      End
      Begin VB.Menu sepEdit2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuClipMsg 
         Caption         =   "Cop&y Message"
         Shortcut        =   ^Y
      End
      Begin VB.Menu mnuSelAll 
         Caption         =   "Select &All Text"
         Shortcut        =   ^A
      End
      Begin VB.Menu mnuSelAllMsg 
         Caption         =   "&Select All Messages"
         Shortcut        =   ^T
      End
      Begin VB.Menu sepEdit1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFind 
         Caption         =   "&Find..."
         Index           =   0
         Shortcut        =   ^F
      End
      Begin VB.Menu mnuFind 
         Caption         =   "Find In &Messages..."
         Index           =   1
         Shortcut        =   ^M
      End
      Begin VB.Menu mnuFind 
         Caption         =   "Find A&gain"
         Index           =   2
         Shortcut        =   ^G
      End
   End
   Begin VB.Menu mnuView 
      Caption         =   "&View"
      Begin VB.Menu mnuViewChoice 
         Caption         =   "&Short List"
         Index           =   0
      End
      Begin VB.Menu mnuViewChoice 
         Caption         =   "&Long List"
         Index           =   1
         Shortcut        =   ^L
      End
      Begin VB.Menu mnuViewChoice 
         Caption         =   "&Full Text"
         Index           =   2
         Shortcut        =   ^U
      End
      Begin VB.Menu sepView0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfiguration 
         Caption         =   "&Configuration..."
         Shortcut        =   {F7}
      End
   End
   Begin VB.Menu mnuFolder 
      Caption         =   "F&older"
      Begin VB.Menu mnuRefresh 
         Caption         =   "Re&fresh"
         Index           =   0
      End
      Begin VB.Menu mnuRefresh 
         Caption         =   "&Rebuild Index"
         Index           =   1
      End
      Begin VB.Menu sepFold2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFold 
         Caption         =   "&New Folder"
         Index           =   0
      End
      Begin VB.Menu mnuFold 
         Caption         =   "&Rename Folder"
         Index           =   1
      End
      Begin VB.Menu mnuFold 
         Caption         =   "&Delete Folder"
         Index           =   2
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "&Tools"
      Begin VB.Menu mnuCheckMail 
         Caption         =   "&Check Email"
         Index           =   0
         Shortcut        =   ^E
      End
      Begin VB.Menu mnuCheckMail 
         Caption         =   "Get &News"
         Index           =   1
         Shortcut        =   ^N
      End
      Begin VB.Menu mnuCheckMail 
         Caption         =   "Check Email And Ne&ws"
         Index           =   2
         Shortcut        =   ^W
      End
      Begin VB.Menu mnuCheckMail 
         Caption         =   "&Abort Connection"
         Index           =   3
         Shortcut        =   {F8}
      End
      Begin VB.Menu sepTools2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuDecrypt 
         Caption         =   "&Decrypt"
         Begin VB.Menu mnuDec 
            Caption         =   "&Clipboard"
            Index           =   0
            Shortcut        =   ^B
         End
         Begin VB.Menu mnuDec 
            Caption         =   "&File..."
            Index           =   1
            Shortcut        =   ^H
         End
         Begin VB.Menu mnuDec 
            Caption         =   "&Selected Messages"
            Index           =   2
         End
         Begin VB.Menu mnuDec 
            Caption         =   "Ca&ncel"
            Index           =   3
         End
         Begin VB.Menu mnuDec 
            Caption         =   "&Diagnostic Mode"
            Index           =   4
         End
      End
      Begin VB.Menu mnuTestEsub 
         Caption         =   "&Test Esub"
      End
      Begin VB.Menu sepTools0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "&View PGP Keying"
         Index           =   0
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "View Mi&x Keyring"
         Index           =   1
      End
      Begin VB.Menu mnuClipKey 
         Caption         =   "Add &Key From Clipboard"
      End
      Begin VB.Menu sepEdit5 
         Caption         =   "-"
      End
      Begin VB.Menu mnuWriteClip 
         Caption         =   "Load Clip&board..."
         Index           =   0
      End
      Begin VB.Menu mnuWriteClip 
         Caption         =   "Save Cl&ipboard As..."
         Index           =   1
      End
      Begin VB.Menu mnuWriteClip 
         Caption         =   "App&end Clipboard As..."
         Index           =   2
      End
      Begin VB.Menu mnuPGPClip 
         Caption         =   "PGP Clipboa&rd"
         Visible         =   0   'False
         Begin VB.Menu mnuAddKey 
            Caption         =   "Add &Key To Keyring"
         End
         Begin VB.Menu mnuClipDecrypt 
            Caption         =   "&Decrypt"
            Begin VB.Menu mnuClipDec 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipDec 
               Caption         =   "To &File"
               Index           =   1
            End
         End
         Begin VB.Menu mnuClipEncrypt 
            Caption         =   "&Encrypt"
            Begin VB.Menu mnuClipEnc 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipEnc 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuClipEnc 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuClipSign 
            Caption         =   "&Sign"
            Begin VB.Menu mnuClipSig 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipSig 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuClipSig 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuClipEncSig 
            Caption         =   "Sign &and Encrypt"
            Begin VB.Menu mnuClipES 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipES 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuClipES 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
      End
      Begin VB.Menu mnuPGPFile 
         Caption         =   "PGP &File"
         Visible         =   0   'False
         Begin VB.Menu mnuAddKeyFile 
            Caption         =   "Add &Key To Keyring"
         End
         Begin VB.Menu mnuFileDecrypt 
            Caption         =   "&Decrypt"
            Begin VB.Menu mnuFileDec 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileDec 
               Caption         =   "To &File"
               Index           =   1
            End
         End
         Begin VB.Menu mnuFileEncrypt 
            Caption         =   "&Encrypt"
            Begin VB.Menu mnuFileEnc 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileEnc 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuFileEnc 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuFileSign 
            Caption         =   "&Sign"
            Begin VB.Menu mnuFileSig 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileSig 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuFileSig 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuFileEncSig 
            Caption         =   "Encrypt &and Sign"
            Begin VB.Menu mnuFileES 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileES 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuFileES 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
      End
   End
   Begin VB.Menu mnuWind 
      Caption         =   "&Window"
      Begin VB.Menu mnuWindow 
         Caption         =   "E&xplore"
         Index           =   0
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Queue"
         Index           =   1
         Shortcut        =   {F3}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Log"
         Index           =   2
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&View Mail"
         Index           =   3
         Shortcut        =   {F5}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Stats Browser"
         Index           =   4
         Shortcut        =   {F6}
      End
      Begin VB.Menu sepWindow1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Global Config"
         Index           =   0
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "R&etrieval Config"
         Index           =   1
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Books Config"
         Index           =   2
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Remailers Config"
         Index           =   3
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "S&tats Config"
         Index           =   4
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   5
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Sen&d Profiles"
         Index           =   6
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Retrieval &Profiles"
         Index           =   7
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Ne&ws Profiles"
         Index           =   8
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Nym Accounts Registry"
         Index           =   9
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Addresses"
         Index           =   10
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   11
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Check Configuration"
         Index           =   12
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&User's Manual              F1"
         Index           =   0
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Beginner's Guide"
         Index           =   1
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Troubleshooting Guide"
         Index           =   2
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Remailer Reference"
         Index           =   3
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "-"
         Index           =   7
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "Open Default &Browser"
         Index           =   8
      End
   End
End
Attribute VB_Name = "frmViewer"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Type MsgType
    Filename As String
    Subject As String
    Sender As String
    DateHeader As Date
    FileDate As Date
    Bytes As Long
    Kind As Byte
    NewMsg As Boolean
    DecQ As Boolean
    Changed As Boolean
End Type
Const KindUnknown = 0
Const KindPlain = 1
Const KindPGP = 2
Const KindDecrypted = 3
Const KindSent = 4
Const KindText = 5
Const KindFile = 6
Const KindKeep = 7
Const KindNews = 8

Private Type FolderType
    Pathname As String
    NewCount As Long
End Type

Private Type AttachType
    Filename As String
    ContentType As String
    Encoding As String
    seekstart As Long
    seekend As Long
End Type
Dim Attach() As AttachType, AttachCount As Long, MaxAttach As Long
Dim AttachSource As String

Dim NoClick As Boolean
Dim Msg() As MsgType, msgCount As Integer, MaxMsg As Integer
Dim Folder() As FolderType, FolderCount As Integer
Dim MailFolder As String
Dim FullHdrs As String, ShortHdrs As String
Dim TextStart As Long
Dim CurRBTag As String, CurRBNum As String, CurRBConv As String, CurRBPK As String
Dim MailListIndex As Long, DragShift As Integer
Dim MoveMenuCount As Byte
Dim LastFindString As String, LastFindMode As Byte
Dim ViewSelStart As Long, ViewSelLength As Long, ViewDblClick As Boolean
Dim FromAlias() As String, FromAliasX As Long
Dim VBusy As Boolean

Private Sub mnuClipKey_Click()
    ClipKey
End Sub

Private Sub mnuConfiguration_Click()
    ShowConfig (ConfigRetrieval)
End Sub

Private Sub mnuHelpSub_Click(Index As Integer)
    ShowHelp Index, "#ViewMail", "2"
End Sub

Private Sub mnuConfig_Click(Index As Integer)
    ShowConfig (Index)
End Sub

Private Sub mnuTestEsub_Click()
    Dim subj As String, ret As Long
    Dim EncSubject As String * 256
    Dim Subject As String * 1024
    Dim Key As String * 256
    
    'Test for ESUB support
    On Error Resume Next
    EncSubject = Chr(0)
    psEsub32DLLVersion (EncSubject)
    If Left(EncSubject, 1) = Chr(0) Then
        MsgBox LMsg(569), vbInformation
        Exit Sub
    End If
    On Error GoTo 0
    
    'Get Subject
    For i = 0 To 1
        subj = ""
        If i = 0 Then
            sh = ShortHdrs
        Else
            sh = ""
            On Error Resume Next
            sh = vbCrLf + Clipboard.GetText
            On Error GoTo 0
        End If
        x = InStr(sh, "Subject:")
        If x <> 0 Then
            subj = Trim(Extract(Mid(sh, x + 8), vbCr))
            If Len(subj) <> 48 Then subj = ""
        End If
        If subj <> "" Then Exit For
    Next i
    subj = Trim(InputBox(LMsg(477), LMsg(478), subj))
    If subj = "" Then Exit Sub
    If LCase(Left(subj, 8)) = "subject:" Then subj = Trim(Mid(subj, 9))
    If Len(subj) <> 48 Then MsgBox LMsg(566), vbInformation, LMsg(478): Exit Sub
    
    'Test
    For i = 31 To 45
        a = UserProf(i, 12)
        x = InStr(1, a, "esub:", vbTextCompare)
        While x <> 0
            EsubPass = Trim(Extract(Mid(a, x + 5), vbCr))
            u = InStr(EsubPass, "%")
            If u <> 0 And Not (Right(EsubPass, 1) = "%" Or Left(EsubPass, 1) = "%") Then
                EncSubject = Left(subj, 255) + Chr(0)
                Subject = Left(Trim(Left(EsubPass, u - 1)), 1023) + Chr(0)
                Key = Left(Trim(Mid(EsubPass, u + 1)), 255) + Chr(0)
                ret = psTestSubject(EncSubject, Subject, Key)
                If ret = 0 Then
                    MsgBox LMsg(567) + " " + UserProf(i, 5) + ":" + vbCr + vbCr + "Subject: " + subj + vbCr + vbCr + EsubPass, vbInformation, LMsg(478)
                    Exit Sub
                End If
            End If
            x = InStr(x + 5, a, "esub:", vbTextCompare)
        Wend
    Next i
    MsgBox LMsg(568), vbInformation, LMsg(478)
End Sub

Private Sub mnuViewRing_Click(Index As Integer)
    If Index = 0 Then
        SelectKey (LMsg(415))
    Else
        ShowConfig ConfigRemailers, 3
    End If
End Sub

Private Sub mnuWindow_Click(Index As Integer)
    ShowWindow (Index)
End Sub

Private Sub cmdOpenBook_Click()
    If MailListIndex = 0 Then Exit Sub
    bookfile = ViewerCurBox + "\" + PlainName(Msg(Val(lstMail.ListItems.Item(MailListIndex).Tag)).Filename, 2) + ".BK"
    If SDir(bookfile) = "" Then
        MsgBox LMsg(66)
        cmdOpenBook.Enabled = False
        Exit Sub
    Else
        OpenSpec bookfile, False
    End If
End Sub

Private Sub cmdDecrypt_Click()
    On Error GoTo ErrorDecrypt
    lstMail.SetFocus
    cmdDecrypt.Visible = False
    If MailListIndex = 0 Then
        If rtbView.Tag = "Text" Then
            dfile = GetWork
            n = FreeFile
            Open dfile For Output As n
            Print #n, rtbView.Text;
            Close n: n = 0
        Else
            Exit Sub
        End If
    Else
        dfile = ViewerCurBox + "\" + Msg(Val(lstMail.ListItems.Item(MailListIndex).Tag)).Filename
    End If
    QueueDec dfile
    UpdateList False
    If Not Decrypting And DecQCount <> 0 Then StartSession 6
Exit Sub
ErrorDecrypt:
    MsgBox Error, vbCritical
    CloseFile n
End Sub

Private Sub lblStat_Click(Index As Integer)
    If Index < 2 Then mnuCheckMail_Click (Index)
End Sub

Private Sub mnuCheckMail_Click(Index As Integer)
    Select Case Index
    Case 0, 1
        StartSession (4 + Index)
    Case 2
        CheckNewsAll = True
        StartSession (4)
    Case 3
        AbortConnection
    End Select
End Sub

Private Sub mnuDec_Click(Index As Integer)
    On Error GoTo ErrorDec
    Select Case Index
    Case 0
        'Decrypt Clipboard
        dfile = GetWork
        n = FreeFile
        Open dfile For Output As n
        Print #n, Clipboard.GetText
        Close n: n = 0
        n = FreeFile
        Open dfile For Input As n
        dfile2 = GetWork
        n2 = FreeFile
        Open dfile2 For Output As n2
        While Not EOF(n)
            Line Input #n, a
            Print #n2, Trim(a)
        Wend
        Close n2: n2 = 0
        Close n: n = 0
        DelFile dfile
        QueueDec dfile2
    Case 1
        'Decrypt File
        dfile = OpenDialog(PlainName(PData(168), 0), PlainName(PData(168), 1), LMsg(67), _
            cdlOFNHideReadOnly + cdlOFNFileMustExist, _
            "All Files (*.*)|*.*", 1, Me)
        If dfile = "" Then Exit Sub
        PData(168) = dfile
        dfile2 = ConvertEOL(dfile, ErrMsg)
        If dfile2 = "" Then
            MsgBox ErrMsg, vbCritical
        Else
            dfilecount = 0
            dfile3 = ""
            n2 = FreeFile
            Open dfile2 For Input As n2
            While Not EOF(n2)
                Line Input #n2, a
                If a = BeginPGP Or a = BeginSig Then
                    If dfilecount <> 0 Then QueueDec dfile3
                    dfile3 = GetWork
                    n3 = FreeFile
                    Open dfile3 For Output As n3
                    Do
                        Print #n3, a
                        If EOF(n2) Or a = EndPGP Then Exit Do
                        Line Input #n2, a
                    Loop
                    Close n3: n3 = 0
                    dfilecount = dfilecount + 1
                End If
            Wend
            Close n2: n2 = 0
            If dfilecount < 2 Then
                DelFile dfile3
                QueueDec dfile2
            Else
                QueueDec dfile3
                DelFile dfile2
            End If
        End If
    Case 2
        'Selected Messages
        mnuDecSel_Click
    Case 3
        'Cancel
        While DecQBusy: DoEvents: Wend
        DecQBusy = True
        DecQCount = 0
        DecQBusy = False
        CancelDecrypt = True
        lblStat(1).Caption = LMsg(479)
    Case 4
        'Diag Mode
        mnuDec(4).Checked = Not mnuDec(4).Checked
        PData(169) = mnuDec(4).Checked
    End Select
    If Not Decrypting And DecQCount <> 0 Then StartSession 6
Exit Sub
ErrorDec:
    MsgBox Error, vbCritical
    CloseFile n
    CloseFile n2
    CloseFile n3
End Sub

Private Sub tmrUpdate_Timer()
    If VBusy Or Not ViewerLoaded Then Exit Sub
    tmrUpdate.Enabled = False
    If InStr(tmrUpdate.Tag, "R") <> 0 Then
        'Reload
        LoadList ""
        mnuHome_Click
    ElseIf InStr(tmrUpdate.Tag, "D") <> 0 Then
        'Readfolders
        ReadFolders MailFolder, 0
    ElseIf InStr(tmrUpdate.Tag, "F") <> 0 Then
        'Refresh
        UpdateList False
    End If
    tmrUpdate.Tag = ""
End Sub

Private Sub cboReply_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        If PlainName(cboReply.Text, 3) = "" Then cboReply.Text = Trim(cboReply.Text) + ".TBK"
        cboReply_Click
    End If
End Sub

Private Sub cboReply_Click()
    On Error GoTo ErrorReply
    If Trim(cboReply.Text) = "" Or cboReply.Text = "-- Cancel --" Or MailListIndex = 0 Then cboReply.Text = "": Exit Sub
    fn = Cnf(4, 1) + "\" + Trim(cboReply.Text)
    If SDir(fn) = "" Then
        MsgBox LMsg(66) + vbCrLf + fn, vbCritical
        ReadFolders MailFolder, 0
        Exit Sub
    End If
    cboReply.Text = ""
    Me.Refresh
    Me.MousePointer = 11
    'Get File
    If chkView(1).Value = 1 Then
        idx = Val(lstMail.ListItems.Item(MailListIndex).Tag)
        rfile = Msg(idx).Filename
        If tabView.SelectedItem.Index = 1 And UCase(PlainName(Msg(idx).Filename, 3)) = "ML1" Then _
          rfile = PlainName(Msg(idx).Filename, 2) + ".ML0"
        rfile = ViewerCurBox + "\" + rfile
        If SDir(rfile) = "" Then
            MsgBox LMsg(480) + vbCr + vbCr + rfile, vbCritical
            UpdateList False
            Me.MousePointer = 0
            Exit Sub
        End If
    Else
        rfile = GetWork
        n = FreeFile
        Open rfile For Output As n
        Print #n, FullHdrs
        Print #n, Mid(rtbView.Text, TextStart)
        Close n: n = 0
    End If
    'Open Book
    For i = 0 To 9
        If MsgBookName(i) <> "" Then Exit For
    Next i
    If i = 10 Then
        'New window
        i = 0
        NewWin = True
        MsgBookName(i) = fn
        Set MsgBook(i) = New frmBook
        MsgBook(i).Tag = Str(i)
        MsgBook(i).Show
    End If
    MsgBook(i)!cboNym.Tag = fn
    MsgBook(i)!txtSubject.Tag = rfile
    If PData(141 + 4 * (tabView.SelectedItem.Index - 1)) <> False2 Then
        MsgBook(i)!cboNC.Tag = "0" 'Reply
    Else
        MsgBook(i)!cboNC.Tag = "1" 'Followup
    End If
    MsgBook(i)!tmrReload.Tag = MsgBook(i)!tmrReload.Tag + "LY"
    MsgBook(i)!tmrReload.Enabled = True
Done:
    Me.MousePointer = 0
Exit Sub
ErrorReply:
    MsgBox Error, vbCritical
    CloseFile n
    GoTo Done
End Sub

'============================================================
'File Functions

Private Sub mnuFile_Click()
    mstate = Not (tabView.SelectedItem.Index > 2 Or Not fraView(0).Visible Or MailListIndex = 0)
    mnuSave(0).Enabled = mstate And chkView(1).Value = 1
    mnuSave(1).Enabled = mstate
    mnuText(2).Enabled = fraView(0).Visible
    mnuText(3).Enabled = fraView(0).Visible
    mnuPrint.Enabled = fraView(0).Visible
End Sub

Private Sub mnuFold_Click(Index As Integer)
    On Error GoTo ErrorFold
    a = UCase(ViewerCurBox)
    If (a = UCase(Cnf(4, 0) + "\Inbox") Or a = UCase(Cnf(4, 0) + "\Multi") Or a = UCase(Cnf(4, 0) + "\Trash")) And Index <> 0 Then
        MsgBox LMsg(481), vbInformation
        Exit Sub
    End If
    Select Case Index
    Case 0
        'New Folder
        f = InputBox(LMsg(482) + ":", LMsg(483), ViewerCurBox + "\NewFolder")
        If f <> "" Then
            If InStr(f, "\") = 0 Then f = MailFolder + "\" + f
            MkDir (f)
        End If
    Case 1
        'Rename Folder
        f = ViewerCurBox
        f2 = InputBox(LMsg(484) + ":", LMsg(485), f)
        If f2 <> "" Then
            If InStr(f2, "\") = 0 Then f2 = MailFolder + "\" + f2
            Name f As f2
        End If
        ViewerCurBox = MailFolder + "\Inbox"
    Case 2
        'Delete Folder
        DelFile ViewerCurBox + "\JBN*.IDX"
        a = SDir(ViewerCurBox + "\*.*", vbDirectory + vbHidden + vbSystem)
        While a <> ""
            If a <> "." And a <> ".." Then
                MsgBox LMsg(486), vbInformation
                Exit Sub
            End If
            a = Dir
        Wend
        RmDir ViewerCurBox
        ViewerCurBox = MailFolder + "\Inbox"
    End Select
    ReadFolders MailFolder, 0
Exit Sub
ErrorFold:
    MsgBox Error, vbCritical
    ReadFolders MailFolder, 0
End Sub

Private Sub mnuPrint_Click()
    On Error GoTo PrintError
    Printer.Print ""
    rtbView.SelPrint (Printer.hDC)
Exit Sub
PrintError:
    MsgBox Error, vbCritical
End Sub

Private Sub mnuWriteClip_Click(Index As Integer)
    Dim a As String
    
    On Error GoTo ClipError
    If Index <> 0 Then
        'Save Clip As
        If Index = 1 Then x = cdlOFNOverwritePrompt Else x = 0
        b = SaveDialog(PlainName(PData(40), 0), PlainName(PData(40), 1), LMsg(117), _
            cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn + x, _
            "All Files (*.*)|*.*", 1, Me)
        If b <> "" Then
            n = FreeFile
            If Index = 1 Then
                Open b For Output As n
            Else
                Open b For Append As n
            End If
            Print #n, Clipboard.GetText;
            Close n: n = 0
            'lblStat.Caption = LMsg(118) + " " + b
            PData(40) = b
        End If
    Else
        'Load Clipboard
        b = OpenDialog(PlainName(PData(40), 0), PlainName(PData(40), 1), LMsg(67), _
            cdlOFNHideReadOnly + cdlOFNFileMustExist, _
            "All Files (*.*)|*.*", 1, Me)
        If b <> "" Then
            n = FreeFile
            Open b For Input As n
            a = Input(LOF(n), n)
            Close n: n = 0
            PData(40) = b
        End If
        Clipboard.Clear
        Clipboard.SetText a
        'lblStat.Caption = LMsg(275) + " " + b
    End If
Exit Sub
ClipError:
    MsgBox Error, vbCritical
    CloseFile n
End Sub

Private Sub mnuClipMsg_Click()
    mstate = Not (tabView.SelectedItem.Index > 2 Or Not fraView(0).Visible Or MailListIndex = 0)
    If Not mstate Then Exit Sub
    On Error GoTo ErrorClipMsg
    If chkView(1).Value = 0 Then
        idx = Val(lstMail.ListItems.Item(MailListIndex).Tag)
        f = Msg(idx).Filename
        If tabView.SelectedItem.Index = 1 Then
            If UCase(PlainName(f, 3)) = "ML1" Then f = PlainName(f, 2) + ".ML0"
        End If
        f = ViewerCurBox + "\" + f
        If SDir(f) = "" Or f = "" Then
            MsgBox LMsg(480), vbCritical
            UpdateList False
            Exit Sub
        End If
        n = FreeFile
        Open f For Input As n
        a = Input(LOF(n), n)
        Close n: n = 0
        Clipboard.Clear
        Clipboard.SetText a
    Else
        Clipboard.Clear
        Clipboard.SetText rtbView.Text
    End If
Exit Sub
ErrorClipMsg:
    MsgBox Error, vbCritical
    CloseFile n
End Sub

Private Sub mnuText_Click(Index As Integer)
    On Error GoTo ErrorText
    If Index > 1 And Not fraView(0).Visible Then Exit Sub
    If Index <= 2 Then
        'Load/Insert
        If Index <> 0 Then
            f = OpenDialog(PlainName(PData(158), 0), PlainName(PData(158), 1), LMsg(67), _
                cdlOFNHideReadOnly + cdlOFNFileMustExist, _
                "All Files (*.*)|*.*|Text File (*.TXT)|*.TXT", 1, Me)
            If f = "" Then Exit Sub
            PData(158) = f
        End If
        If Index < 2 Then
            'Clear
            OpenMessage (0)
            tabView.Tabs.Item(1).Selected = True
            fraView(0).Visible = True
            chkView(0).Visible = False
            chkView(1).Visible = False
            lblReply.Visible = False
            cboReply.Visible = False
            cmdOpenBook.Visible = False
            lblView.Caption = f
            rtbView.Tag = "Text"
            rtbView.Locked = False
            rtbView.SetFocus
            UpdateDisp
        End If
        If Index = 0 Then Exit Sub
        If Index = 1 Then
            rtbView.LoadFile f
        ElseIf Index = 2 Then
            n = FreeFile
            Open f For Input As n
            rtbView.SelText = Input(LOF(n), n)
            Close n: n = 0
        End If
    Else
        If MailListIndex <> 0 Then
            If rtbView.Tag = "Text" Or Msg(Val(lstMail.ListItems.Item(MailListIndex).Tag)).Kind = KindText Then PData(159) = ViewerCurBox + "\" + Msg(Val(lstMail.ListItems.Item(MailListIndex).Tag)).Filename
        End If
        f = SaveDialog(PlainName(PData(159), 0), PlainName(PData(159), 1), _
             LMsg(117), cdlOFNOverwritePrompt + cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn, _
             "All Files (*.*)|*.*|Text File (*.TXT)|*.TXT", 1, Me)
        If f = "" Then Exit Sub
        PData(159) = f
        rtbView.SaveFile f, 1
    End If
    UpdateList False
Exit Sub
ErrorText:
    MsgBox Error, vbCritical
    CloseFile n
    UpdateList False
End Sub

Private Sub mnuSave_Click(Index As Integer)
    mstate = Not (tabView.SelectedItem.Index > 2 Or Not fraView(0).Visible Or MailListIndex = 0)
    If Not mstate Or (Index = 0 And chkView(1).Value = 0) Then Exit Sub
    On Error GoTo ErrorSave
    idx = Val(lstMail.ListItems.Item(MailListIndex).Tag)
    f = Msg(idx).Filename
    If tabView.SelectedItem.Index = 1 Then
        If UCase(PlainName(f, 3)) = "ML1" Then f = PlainName(f, 2) + ".ML0"
    End If
    f = ViewerCurBox + "\" + f
    If Index = 1 Then
        f2 = SaveDialog(ViewerCurBox, PlainName(f, 1), _
             LMsg(487), cdlOFNOverwritePrompt + cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn, _
             "All Files (*.*)|*.*|Text File (*.TXT)|*.TXT", 1, Me)
        If f2 = "" Then Exit Sub
    Else
        f2 = f
    End If
    If chkView(1).Value = 0 Then
        If SDir(f) = "" Or f = "" Then
            MsgBox LMsg(480), vbCritical
            UpdateList False
            Exit Sub
        End If
        FileCopy f, f2
    Else
        n = FreeFile
        Open f2 For Output As n
        Print #n, rtbView.Text;
        Close n: n = 0
    End If
    UpdateList False
Exit Sub
ErrorSave:
    MsgBox Error, vbCritical
    CloseFile n
    UpdateList False
End Sub

Private Sub mnuSaveSel_Click(Index As Integer)
    Dim a As String, Locn As Long
    On Error GoTo ErrorSaveSel
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then SelCount = SelCount + 1
    Next i
    If SelCount = 0 Then Exit Sub
    If Index = 0 Then
        a = LMsg(488)
        x = cdlOFNOverwritePrompt
    Else
        a = LMsg(489)
        x = 0
    End If
    fn = SaveDialog(PlainName(PData(156), 0), PlainName(PData(156), 1), _
         a, x + cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn, _
         "All Files (*.*)|*.*|Text File (*.TXT)|*.TXT", 1, Me)
    If fn = "" Then Exit Sub
    PData(156) = fn
    Me.Refresh
    Me.MousePointer = 11
    nout = FreeFile
    If Index = 0 Then
        Open fn For Output As nout
    Else
        Open fn For Append As nout
    End If
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then
            idx = Val(lstMail.ListItems.Item(i).Tag)
            Locn = 0
            nin = FreeFile
            Open ViewerCurBox + "\" + Msg(idx).Filename For Input As nin
            While Not EOF(nin)
                Line Input #nin, a
                Print #nout, a
            Wend
            Close nin: nin = 0
            Print #nout,
            Print #nout,
            Print #nout,
        End If
    Next i
    Close nout: nout = 0
Done:
    UpdateList False
    Me.MousePointer = 0
Exit Sub
ErrorSaveSel:
    MsgBox LMsg(490) + vbCr + Error, vbCritical
    CloseFile nin
    CloseFile nout
    GoTo Done
End Sub

Private Sub mnuImport_Click()
    Dim a As String
    On Error GoTo ErrorImport
    importfile = OpenDialog(PlainName(PData(155), 0), _
                 PlainName(PData(155), 1), LMsg(491), _
                 cdlOFNHideReadOnly + cdlOFNFileMustExist, _
                 "All Files (*.*)|*.*|UNIX Message Files (*.*)|*.*|PGP Messages (*.*)|*.*|Single Message Files (*.*)|*.*", _
                 1, Me)
    If importfile = "" Then Exit Sub
    PData(155) = importfile
    Me.Refresh
    Me.MousePointer = 11
    Select Case CommonDialog1.FilterIndex
    Case 3
        x = 1
    Case 4
        x = 2
    Case Else
        x = 0
    End Select
    AssumeBinary = False
Parse:
    On Error GoTo ErrorParse
    For Job = x To 2
        Found = False
        If Job = 0 Then
            a1 = "From "
            lblStat(0).Caption = LMsg(492)  'Scanning for UNIX messages...
        Else
            a1 = "-----BEGIN PGP MESSAGE-----"
            lblStat(0).Caption = LMsg(493)  'Scanning for PGP messages...
        End If
        lblStat(0).Refresh
        n = FreeFile
        Open importfile For Input As n
        While Not EOF(n)
            Line Input #n, a
            Do While (InStr(a, a1) = 1 Or Job = 2) And Not EOF(n)
                Found = True
                mcount = mcount + 1
                lblStat(0).Caption = LMsg(494) + " " + Trim(Str(mcount)) + "..."
                lblStat(0).Refresh
                Do
                    newfile = ViewerCurBox + "\" + MakeTag
                Loop Until SDir(newfile + ".*") = ""
                newfile = newfile + ".ML0"
                nn = FreeFile
                Open newfile For Output As nn
                If Job = 1 Or Job = 2 Then
                    Print #nn, "From imported.file@Jack.B.Nymble "; DateLine(1)
                    Print #nn, "From: Imported Message"
                    Print #nn, "Date: "; DateLine(0)
                    Print #nn,
                End If
                Print #nn, a
                Do While Not EOF(n)
                    Line Input #n, a
                    If InStr(a, a1) = 1 And Job <> 2 Then Exit Do
                    Print #nn, a
                    If Job = 1 And a = "-----END PGP MESSAGE-----" Then Exit Do
                Loop
                Close nn: nn = 0
                newfile = ""
            Loop
        Wend
        Close: n = 0
        If Found Then Exit For
        If Not Found And Job = 1 Then
            If MsgBox(LMsg(495) + " " + importfile + vbCr + LMsg(496), vbQuestion + vbYesNo) = vbNo Then Exit For
        End If
        DoEvents
    Next Job
Done:
    On Error GoTo ErrorImport
    If importfile = newimportfile Then DelFile newimportfile
    lblStat(0).Caption = ""
    UpdateList False
    Me.MousePointer = 0
Exit Sub
ErrorParse:
    Resume ErrorParse2
ErrorParse2:
    If Err.Number = 62 And Not AssumeBinary Then
        CloseFile n: n = 0
        CloseFile nn: nn = 0
        DelFile newfile
        newimportfile = ConvertEOL(importfile, ErrMsg, True)
        If newimportfile = "" Then MsgBox ErrMsg, vbCritical: GoTo Done
        importfile = newimportfile
        AssumeBinary = True
        GoTo Parse
    End If
ErrorImport:
    MsgBox LMsg(497) + vbCrLf + Error, vbCritical
    CloseFile n
    CloseFile nn
    GoTo Done
End Sub
'============================================================

Private Sub mnuFind_Click(Index As Integer)
    Dim initpos As Long, x As Long
    On Error GoTo ErrorFind
    If (Not fraView(0).Visible) And Not (Index = 1 Or (Index = 2 And LastFindMode = 1)) Then Exit Sub
    If Index = 2 And LastFindString = "" Then Index = 0
    If Index = 0 Or Index = 1 Then
        f = InputBox(LMsg(92), LMsg(93 + (Index * 378)), LastFindString)
        If f = "" Then Exit Sub
        LastFindString = f
        LastFindMode = Index
        If Index = 1 Then rtbView.SelStart = 0
    End If
    If LastFindMode = 0 Then
        'Search Text
        initpos = rtbView.SelStart + 1
        x = InStr(initpos + 1, rtbView.Text, LastFindString, vbTextCompare)
        If x = 0 Then x = InStr(1, rtbView.Text, LastFindString, vbTextCompare)
        If x <> 0 Then
            rtbView.SelStart = x - 1
            rtbView.SelLength = Len(LastFindString)
        Else
            Beep
            rtbView.SelLength = 0
        End If
    Else
        'Search Messages
        'Search current text
        If MailListIndex <> 0 And fraView(0).Visible Then
            x = InStr(rtbView.SelStart + 2, rtbView.Text, LastFindString, vbTextCompare)
            If x <> 0 Then
                rtbView.SelStart = x - 1
                rtbView.SelLength = Len(LastFindString)
                NoClick = True: rtbView.SetFocus: NoClick = False
                Exit Sub
            End If
        End If
        'Search Files
        If Not lstMail.SelectedItem Is Nothing Then initpos = lstMail.SelectedItem.Index + 1 Else initpos = 1
        curpos = initpos
        Me.MousePointer = 11
        Me.Refresh
        Do
            If curpos > lstMail.ListItems.Count Then
                curpos = 1
                If curpos = initpos Then Exit Do
            End If
            idx = Val(lstMail.ListItems.Item(curpos).Tag)
            f = ViewerCurBox + "\" + Msg(idx).Filename
            ext = UCase(PlainName(Msg(idx).Filename, 3))
            If (ext = "ML0" Or ext = "ML1" Or ext = "TXT") And SDir(f) <> "" Then
                n = FreeFile
                Open f For Input As n
                Do While Not EOF(n)
                    Line Input #n, a
                    If InStr(1, a, LastFindString, vbTextCompare) <> 0 Then
                        'Found In Raw
                        Close n: n = 0
                        OpenMessage (curpos)
                        If fraView(0).Visible Then
                            x = InStr(1, rtbView.Text, LastFindString, vbTextCompare)
                            If x <> 0 Then
                                rtbView.SelStart = x - 1
                                rtbView.SelLength = Len(LastFindString)
                                NoClick = True: rtbView.SetFocus: NoClick = False
                                Me.MousePointer = 0
                                Exit Sub
                            End If
                        End If
                        Exit Do
                    End If
                Loop
                If n <> 0 Then Close n: n = 0
            End If
            curpos = curpos + 1
        Loop Until curpos = initpos
        Beep
        rtbView.SelLength = 0
        Me.MousePointer = 0
    End If
    If rtbView.Visible Then NoClick = True: rtbView.SetFocus: NoClick = False
Exit Sub
ErrorFind:
    MsgBox Error, vbCritical
    CloseFile n
    Me.MousePointer = 0
End Sub

Private Sub mnuEditArray_Click(Index As Integer)
    On Error Resume Next
    Select Case Index
    Case 0
        SendKeys "^z", True
    Case 1
        SendKeys "^c", True
    Case 2
        a = Clipboard.GetText
        SendKeys "^c", True
        a = a + Clipboard.GetText
        Clipboard.Clear
        Clipboard.SetText a
    Case 3
        SendKeys "^x", True
    Case 4
        SendKeys "^v", True
    End Select
End Sub

Private Sub mnuSelAll_Click()
    rtbView.SelStart = 0
    rtbView.SelLength = Len(rtbView.Text)
End Sub

Private Sub cmdNavigate_Click(Index As Integer)
    If Index = 0 Then x = -1 Else x = 1
    y = MailListIndex + x
    If y < 1 Then y = 1
    If y > lstMail.ListItems.Count Then y = lstMail.ListItems.Count
    If y <> MailListIndex And y <> 0 Then
        On Error Resume Next
        MailListIndex = y
        Set lstMail.SelectedItem = lstMail.ListItems.Item(y)
        rtbView_GotFocus
        x = tabView.SelectedItem.Index
        NoClick = True
        If PlainName(lstMail.ListItems.Item(y).Key, 3) = "ML1" Then tabView.Tabs.Item(2).Selected = True Else tabView.Tabs.Item(1).Selected = True
        NoClick = False
        rtbView.Tag = "loading"
        tabView_Click
        If x > 2 And x <= tabView.Tabs.Count Then tabView.Tabs.Item(x).Selected = True
    Else
        Beep
    End If
End Sub

Private Sub mnuExit_Click()
    Unload Me
End Sub

Private Sub mnuRefresh_Click(Index As Integer)
    If Index = 1 Then DelFile ViewerCurBox + "\JBN2*.IDX"
    ReadFolders MailFolder, 0, Index = 1
End Sub

Private Sub mnuSelAllMsg_Click()
    If lstMail.SelectedItem Is Nothing Then x = 0 Else x = lstMail.SelectedItem.Index
    For i = 1 To lstMail.ListItems.Count
        lstMail.ListItems.Item(i).Selected = True
    Next i
    If x = 0 Then Set lstMail.SelectedItem = Nothing Else Set lstMail.SelectedItem = lstMail.ListItems.Item(x)
    lstMail.SetFocus
End Sub


'=======================================================
'Delete/Wipe/Move/Copy etc
Private Sub mnuDecSel_Click()
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then
            idx = Val(lstMail.ListItems.Item(i).Tag)
            f = ViewerCurBox + "\" + Msg(idx).Filename
            If UCase(PlainName(f, 3)) = "ML1" Then
                If SDir(ViewerCurBox + "\" + PlainName(f, 2) + ".ML0") <> "" Then
                    DelFile f
                    f = ViewerCurBox + "\" + PlainName(f, 2) + ".ML0"
                Else
                    f = ""
                End If
            End If
            If f <> "" Then QueueDec f
        End If
    Next i
    UpdateList False
    If Not Decrypting And DecQCount <> 0 Then StartSession 6
End Sub

Private Sub mnuMove_Click(Index As Integer)
    DestPath = MailFolder + "\" + Replace(mnuMove(Index).Caption, "&", "")
    CopyMoveMsgs DestPath, vbDropEffectMove
End Sub

Private Sub cmdTrash_Click(Index As Integer)
    lstMail.SetFocus
    If Index = 0 Then
        'Trash
        CopyMoveMsgs MailFolder + "\Trash", vbDropEffectMove
    Else
        'Delete
        mnuDeleteSel_Click (0)
    End If
End Sub

Private Sub cmdTrash_DragDrop(Index As Integer, Source As Control, x As Single, y As Single)
    If Source.Name = "lstMail" Then cmdTrash_Click (Index)
End Sub

Private Sub mnuEmpty_Click()
    'Empty Trash Folders
    For i = 0 To 3
        Select Case i
        Case 0: b = "Trash"
        Case 1: b = "Trash\Multi"
        Case 2: b = "Trash\Spam"
        Case 3: b = "Trash\Duplicates"
        End Select
        DelFile (MailFolder + "\" + b + "\*.*")
    Next i
    'Check Dates of Multi parts
    b = MailFolder + "\Multi\"
    First = True
    a = SDir(b + "*.ML*")
    Do While a <> ""
        If SafeTime - FileDateTime(b + a) > 10 Then
            If First Then If MsgBox(LMsg(529), vbQuestion + vbYesNo + vbDefaultButton2) = vbNo Then Exit Do
            First = False
            On Error Resume Next
            Kill b + a
            On Error GoTo 0
        End If
        a = Dir
    Loop
    If InStr(1, ViewerCurBox, MailFolder + "\Trash", vbTextCompare) = 1 Or InStr(1, ViewerCurBox, MailFolder + "\Multi", vbTextCompare) = 1 Then
        UpdateList False
    Else
        UpdateDisp
    End If
End Sub

Private Sub CopyMoveMsgs(ByVal DestPath As String, ByVal Effect As Double)
    Dim fs(1) As String, fd(1) As String
    On Error GoTo ErrorCopyMove
    DestPath = NoSlash(DestPath)
    SelCount = 0
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then SelCount = SelCount + 1
    Next i
    If SelCount = 0 Then Exit Sub
    If Not IsDir(DestPath) Then RereadFolders = True
    If Not CreateDir(DestPath) Or LCase(DestPath) = LCase(ViewerCurBox) Then
        MsgBox LMsg(498), vbCritical  '"Invalid destination folder."
        ReadFolders MailFolder, 0
        Exit Sub
    End If
    Me.Refresh
    Me.MousePointer = 11
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then
            idx = Val(lstMail.ListItems.Item(i).Tag)
            ext = UCase(PlainName(Msg(idx).Filename, 3))
            CancelMove = False
            If ext = "ML0" Or ext = "ML1" Then
                'Check if being decrypted
                If Effect = vbDropEffectMove Then
                    a = ViewerCurBox + "\" + PlainName(Msg(idx).Filename, 2)
                    If InStr(1, ReserveDecFile, a, vbTextCompare) <> 0 Then
                        CancelMove = True
                    Else
                        For j = 0 To DecQCount - 1
                            If InStr(1, DecQ(j), a, vbTextCompare) <> 0 Then CancelMove = True: Exit For
                        Next j
                    End If
                End If
                Do
                    a = MakeTag
                Loop Until SDir(DestPath + "\" + a + ".*") = ""
                fs(0) = PlainName(Msg(idx).Filename, 2) + ".ML0"
                fs(1) = PlainName(Msg(idx).Filename, 2) + ".ML1"
                fd(0) = a + ".ML0"
                fd(1) = a + ".ML1"
            Else
                'Check if being decrypted
                If Effect = vbDropEffectMove Then
                    a = ViewerCurBox + "\" + Msg(idx).Filename
                    For j = 0 To DecQCount - 1
                        If InStr(1, DecQ(j), a, vbTextCompare) <> 0 Then CancelMove = True: Exit For
                    Next j
                End If
                fs(0) = Msg(idx).Filename
                fs(1) = ""
                fd(0) = Msg(idx).Filename
            End If
            If Not CancelMove Then
                For j = 0 To 1
                    If fs(j) <> "" Then
                        Src = ViewerCurBox + "\" + fs(j)
                        Dst = DestPath + "\" + fd(j)
                        If SDir(Src) <> "" Then
                            If Effect = vbDropEffectMove Then
                                'Move
                                FileMoveX Src, Dst
                                'Move Book and Replay Files
                                If ext = "ML0" Then
                                    a = ViewerCurBox + "\" + PlainName(Msg(idx).Filename, 2)
                                    b = PlainName(Dst, 0) + PlainName(Dst, 2)
                                    If SDir(a + ".BK") <> "" Then FileMoveX a + ".BK", b + ".BK"
                                    c = SDir(a + "._*")
                                    While c <> "" And c <> clast
                                        FileMoveX ViewerCurBox + "\" + c, b + "." + PlainName(c, 3)
                                        clast = c
                                        c = SDir(a + "._*")
                                    Wend
                                End If
                            Else
                                'Copy
                                FileCopy Src, Dst
                            End If
                            mcount = mcount + 1
                            'New Msg
                            If Msg(idx).NewMsg Then
                                n = FreeFile
                                Open DestPath + "\JBN2NEW.IDX" For Append As n
                                Print #n, Msg(idx).Filename
                                Close n: n = 0
                                On Error Resume Next
                                trvFolder.Nodes.Item(UCase(DestPath)).Tag = True2
                                trvFolder.Nodes.Item(UCase(DestPath)).Image = "FoldClosedFlag"
                                On Error GoTo ErrorCopyMove
                            End If
                        End If
                    End If
                Next j
            Else
                CancelMoveFlag = True
            End If
        End If
    Next i
Done:
    If CancelMoveFlag Then MsgBox LMsg(547), vbInformation
    If RereadFolders Then ReadFolders MailFolder, 0 Else UpdateList False
    'If Effect = vbDropEffectMove Then a = "Moved" Else a = "Copied"
    'If MCount = 1 Then b = "message" Else b = "messages"
    'lblStat(0).Caption = a + Str(MCount) + " " + b
    Me.MousePointer = 0
    DoEvents
Exit Sub
ErrorCopyMove:
    MsgBox Error + vbCr + fs(j), vbCritical
    CloseFile n: n = 0
    GoTo Done
End Sub

Private Sub FileMoveX(Src, Dst)
    If SDir(Dst) = "" And UCase(Left(Src, 1)) = UCase(Left(Dst, 1)) Then
        Name Src As Dst
    Else
        FileCopy Src, Dst
        DelFile Src
    End If
End Sub

Private Sub mnuDeleteSel_Click(Index As Integer)
    'Index  0  Delete
    '       1  Delete Original
    '       2  Delete Decrypted
    On Error GoTo ErrorDelSel
    If Index = 3 Then Exit Sub 'N/A
    SelCount = 0
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then SelCount = SelCount + 1
    Next i
    If SelCount = 0 Then Exit Sub
    If Index > 3 Then
        Index = Index - 4
        DelAction = LMsg(342)  '"Wipe"
    Else
        DelAction = LMsg(341)  '"Delete"
    End If
    If SelCount = 1 Then c = LCase(LMsg(469)) Else c = LMsg(298)
    If Index = 1 Then a = vbCr + vbCr + LMsg(499): b = " " + LMsg(500) 'Original Only
    If Index = 2 Then a = vbCr + vbCr + LMsg(501): b = " " + LMsg(502) 'Decrypted Only
    If MsgBox(DelAction + Str(SelCount) + " " + LMsg(503) + " " + c + "?" + a, vbQuestion + vbOKCancel, LMsg(95) + " " + DelAction + b) = vbCancel Then Exit Sub
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then
            idx = Val(lstMail.ListItems.Item(i).Tag)
            ext = UCase(PlainName(Msg(idx).Filename, 3))
            If ext = "ML0" Or ext = "ML1" Then
                'Delete/Wipe Message Files
                If Index = 0 Then a = 0: b = 1
                If Index = 1 Then a = 0: b = 0
                If Index = 2 Then a = 1: b = 1
                For j = a To b
                    If Index = 1 And SDir(ViewerCurBox + "\" + PlainName(Msg(idx).Filename, 2) + ".ML1") = "" Then Exit For
                    srcfile = ViewerCurBox + "\" + PlainName(Msg(idx).Filename, 2) + ".ML" + Trim(Str(j))
                    If DelAction = LMsg(341) Then
                        If Not DelFile(srcfile) Then MsgBox LMsg(504) + " " + srcfile, vbCritical
                    Else
                        WipeFile srcfile
                    End If
                Next j
                If Index < 2 Then
                    'Delete/Wipe Book File
                    srcfile = ViewerCurBox + "\" + PlainName(Msg(idx).Filename, 2)
                    If SDir(srcfile + ".BK") <> "" Then
                        If DelAction = LMsg(341) Then
                            If Not DelFile(srcfile + ".BK") Then MsgBox LMsg(504) + " " + srcfile + ".BK", vbCritical
                        Else
                            WipeFile srcfile + ".BK"
                        End If
                    End If
                    'Delete Replay Files
                    If SDir(srcfile + "._*") <> "" Then
                        If Not DelFile(srcfile + "._*") Then MsgBox LMsg(504) + " " + srcfile + "._*", vbCritical
                    End If
                End If
            Else
                If Index = 0 Then
                    srcfile = ViewerCurBox + "\" + Msg(idx).Filename
                    If DelAction = LMsg(341) Then
                        If Not DelFile(srcfile) Then MsgBox LMsg(504) + " " + srcfile, vbCritical
                    Else
                        WipeFile srcfile
                    End If
                End If
            End If
        End If
    Next i
Done:
    UpdateList False
Exit Sub
ErrorDelSel:
    MsgBox Error, vbCritical
    GoTo Done
End Sub

Private Sub mnuMarkRead_Click(Index As Integer)
    For i = 1 To lstMail.ListItems.Count
        If lstMail.ListItems.Item(i).Selected Then _
          Msg(Val(lstMail.ListItems.Item(i).Tag)).NewMsg = Index = 1
    Next i
    UpdateList False
End Sub



'==========================================================
'Attachments
Private Sub cmdAttach_Click(Index As Integer)
    Dim a As String
    
    On Error GoTo ErrorAttach
    idx = lstAttach.SelectedItem.Index - 1
    If idx < 0 Or lstAttach.ListItems.Count <> AttachCount Then Exit Sub
    If SDir(AttachSource) = "" Then
        MsgBox LMsg(480), vbCritical
    Else
        'Get User Filename
        If Index = 0 Then a = LMsg(505) Else a = LMsg(506)
        ext = UCase(PlainName(Attach(idx).Filename, 3))
        If ext = "" And InStr(1, Attach(idx).ContentType, "text/html", vbTextCompare) <> 0 Then ext = "HTM"
        If ext <> "" Then fs = ext + " Files (*." + ext + ")|*." + ext + "|"
        fs = fs + "All Files (*.*)|*.*"
        If PData(146) = "" Then PData(146) = PData(10)
        attname = SaveDialog(PData(146), Attach(idx).Filename, a, _
                  cdlOFNHideReadOnly + cdlOFNPathMustExist + _
                  cdlOFNNoReadOnlyReturn + cdlOFNOverwritePrompt, _
                  fs, 1, Me)
        If attname = "" Then Exit Sub
        PData(146) = PlainName(attname, 0)
        DelFile attname
        'Read Encoded Data
        n = FreeFile
        Open AttachSource For Input As n
        Seek #n, Attach(idx).seekstart
        a = Input(Attach(idx).seekend - Attach(idx).seekstart, n)
        Close n: n = 0
        'Write encoded data
        If Attach(idx).Encoding <> "7bit" And Attach(idx).Encoding <> "8bit" Then
            encfile = GetWork(PData(10))
        Else
            encfile = attname
        End If
        n = FreeFile
        Open encfile For Output As n
        Print #n, a
        Close n: n = 0
        If Attach(idx).Encoding <> "7bit" And Attach(idx).Encoding <> "8bit" Then
            'Decode data
            decfile = DecodeFile(encfile, attname, Attach(idx).Encoding, ErrMsg)
            DelFile encfile
            If decfile = "" Then
                MsgBox ErrMsg, vbCritical
                Exit Sub
            End If
            encfile = decfile
        End If
        If Index = 1 Then OpenSpec encfile, True
    End If
    UpdateList False
Exit Sub
ErrorAttach:
    MsgBox Error, vbCritical
    CloseFile n
    UpdateList False
End Sub

Private Sub lblAttach_Click(Index As Integer)
    ShowHelp 0, "#Virus", "2"
End Sub

Private Sub lstAttach_DblClick()
    cmdAttach_Click (0)
End Sub
'=======================================================

'=======================================================
'OLE Drag/Drop
Private Sub lstMail_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If (Button And vbRightButton) Then PopupMenu mnuSelected
End Sub

Private Sub lstMail_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    Dim Item As ListItem
    If Button = 0 Then
        lstMail.Drag vbCancel
    ElseIf (Button And vbLeftButton) <> 0 Then
        'Set correct selected item
        If MailListIndex = 0 Then
            Set Item = Nothing
        Else
            Set Item = lstMail.ListItems.Item(MailListIndex)
            temp = Item.Selected
        End If
        Set lstMail.SelectedItem = Item
        If Not Item Is Nothing Then Item.Selected = temp
        'Turn on Drag Mode
        lstMail.Drag vbBeginDrag
        If Shift = vbCtrlMask Then lstMail.DragIcon = cmdTrash(1).MouseIcon Else lstMail.DragIcon = cmdTrash(0).MouseIcon
        DragShift = Shift
    End If
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    If Shift = vbCtrlMask Then lstMail.DragIcon = cmdTrash(1).MouseIcon Else lstMail.DragIcon = cmdTrash(0).MouseIcon
    DragShift = Shift

    GlobalKeyDown KeyCode, Shift
    Select Case Shift
    Case 0
        Select Case KeyCode
        Case vbKeyF1: mnuHelpSub_Click (0): KeyCode = 0
        Case vbKeyF7: ShowConfig (ConfigRetrieval): KeyCode = 0
        End Select
    Case 1  'Shift
    Case 2  'Ctrl
        Select Case KeyCode
        Case vbKeyA: mnuSelAll_Click: KeyCode = 0
        Case vbKeyD: mnuEditArray_Click (2): KeyCode = 0
        Case vbKeyE: mnuCheckMail_Click (0): KeyCode = 0
        Case vbKeyF: mnuFind_Click (0): KeyCode = 0
        Case vbKeyG: mnuFind_Click (2): KeyCode = 0
        Case vbKeyL: mnuViewChoice_Click (1): KeyCode = 0
        Case vbKeyM: mnuFind_Click (1): KeyCode = 0
        Case vbKeyN: mnuCheckMail_Click (1): KeyCode = 0
        Case vbKeyO: mnuText_Click (1): KeyCode = 0
        Case vbKeyP: mnuPrint_Click: KeyCode = 0
        Case vbKeyS: mnuSave_Click (0): KeyCode = 0
        Case vbKeyT: mnuSelAllMsg_Click: KeyCode = 0
        Case vbKeyU: mnuViewChoice_Click (2): KeyCode = 0
        Case vbKeyW: mnuCheckMail_Click (2): KeyCode = 0
        Case vbKeyY: mnuClipMsg_Click: KeyCode = 0
        Case vbKeyDelete: cmdTrash_Click (1): KeyCode = 0
        Case vbKeyInsert: cmdTrash_Click (0): KeyCode = 0
        End Select
    Case 3  'Ctrl-Shift
    Case 4  'Alt
    End Select
End Sub

Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
    If Shift = vbCtrlMask Then lstMail.DragIcon = cmdTrash(1).MouseIcon Else lstMail.DragIcon = cmdTrash(0).MouseIcon
    DragShift = Shift
End Sub

Private Sub rtbView_GotFocus()
    For i = 1 To lstMail.ListItems.Count
        lstMail.ListItems.Item(i).Selected = i = MailListIndex
    Next i
End Sub

Private Sub tmrOLE_Timer()
    tmrOLE.Enabled = False
End Sub

Private Sub trvFolder_DragOver(Source As Control, x As Single, y As Single, state As Integer)
    Dim nod As Node
    Set nod = trvFolder.HitTest(x, y)
    If Not trvFolder.DropHighlight Is nod Then
        Set trvFolder.DropHighlight = nod
        tmrOLE.Enabled = True
    End If
    If y < 250 Or y > trvFolder.Height - 250 Then
        If Not tmrOLE.Enabled And Not trvFolder.DropHighlight Is Nothing Then
            If y < 250 Then
                Set nod = trvFolder.DropHighlight.Previous
                If nod Is Nothing Then Set nod = trvFolder.DropHighlight.Parent
                If Not nod Is Nothing Then
                    nod.EnsureVisible
                    Set trvFolder.DropHighlight = nod
                    tmrOLE.Enabled = True
                End If
            Else
                Set nod = trvFolder.DropHighlight.Next
                If nod Is Nothing Then Set nod = trvFolder.DropHighlight.Child
                If Not nod Is Nothing Then
                    nod.EnsureVisible
                    Set trvFolder.DropHighlight = nod
                    tmrOLE.Enabled = True
                End If
            End If
        End If
    End If
End Sub

Private Sub trvFolder_DragDrop(Source As Control, x As Single, y As Single)
    On Error Resume Next
    If Source.Name = "lstMail" And Not trvFolder.DropHighlight Is Nothing Then
        If DragShift And vbCtrlMask <> 0 Then
            CopyMoveMsgs trvFolder.DropHighlight.Key, vbDropEffectCopy
        Else
            CopyMoveMsgs trvFolder.DropHighlight.Key, vbDropEffectMove
        End If
        Set trvFolder.DropHighlight = Nothing
    End If
End Sub
'========================================================

Private Sub trvFolder_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If (Button And vbRightButton) Then PopupMenu mnuFolder
    If NewMessages <> 0 Then
        NewMessages = 0
        If InStr(StatMain, LMsg(456)) <> 0 Then StatMain = ""
        Stat StatMain, StatDec
    End If
End Sub

Private Sub trvFolder_NodeClick(ByVal Node As ComctlLib.Node)
    WriteIndex (ViewerCurBox)
    If IsDir(Node.Key) Then
        ViewerCurBox = Node.Key
        For i = 1 To trvFolder.Nodes.Count
            If i = Node.Index Then
                If trvFolder.Nodes.Item(i).Tag = True2 Then trvFolder.Nodes.Item(i).Image = "FoldOpenFlag" Else trvFolder.Nodes.Item(i).Image = "FoldOpen"
            Else
                If trvFolder.Nodes.Item(i).Tag = True2 Then trvFolder.Nodes.Item(i).Image = "FoldClosedFlag" Else trvFolder.Nodes.Item(i).Image = "FoldClosed"
            End If
        Next i
        trvFolder.Refresh
        UpdateList True
    Else
        ReadFolders MailFolder, 0, True
    End If
End Sub

Private Sub UpdateList(Scratch As Boolean)
    Dim MsgIdx() As MsgType, IdxCount As Integer, MaxIdx As Integer
    Dim Files() As String, FileCount As Integer, MaxFile As Integer
    Dim NewMail As String
    Dim litem As ListItem, sicon As String
    Dim CurItem As ListItem
    Dim rl As Double, rl2 As Double

    On Error GoTo ErrorUpdate
    Me.MousePointer = 11
    If Scratch Then
        lstMail.ListItems.Clear
        MailListIndex = 0
        msgCount = 0
        MaxMsg = 20
        ReDim Msg(MaxMsg)
        'Set FromAlias
        ReDim FromAlias(300)
        FromAliasX = ParseString(Cnf(4, 3), FromAlias(), 300, False)
        For i = 0 To FromAliasX
            If InStr(FromAlias(i), "[") <> 0 Then Replace FromAlias(i), "[", "[[]"
        Next i
        'Read Index File
        MaxIdx = 20
        ReDim MsgIdx(MaxIdx)
        If SDir(ViewerCurBox + "\JBN2Mail.IDX") <> "" Then
            n = FreeFile
            Open ViewerCurBox + "\JBN2Mail.IDX" For Input As n
            If Not EOF(n) Then Line Input #n, a
            If Not EOF(n) Then Line Input #n, b
            If a <> "JBN2_MAILINDEX" Or b <> UCase(ViewerCurBox) Then
                Close n: n = 0
                DelFile ViewerCurBox + "\JBN2Mail.IDX"
            Else
                While Not EOF(n)
                    Line Input #n, a
                    If a = Chr(4) Then
                        If IdxCount > MaxIdx Then MaxIdx = MaxIdx + 40: ReDim Preserve MsgIdx(MaxIdx)
                        If Not EOF(n) Then Line Input #n, MsgIdx(IdxCount).Filename
                        If Not EOF(n) Then Input #n, MsgIdx(IdxCount).NewMsg
                        If Not EOF(n) Then Input #n, MsgIdx(IdxCount).Kind
                        If Not EOF(n) Then Input #n, MsgIdx(IdxCount).DateHeader
                        If Not EOF(n) Then Input #n, MsgIdx(IdxCount).FileDate
                        If Not EOF(n) Then Line Input #n, MsgIdx(IdxCount).Subject
                        If Not EOF(n) Then Line Input #n, MsgIdx(IdxCount).Sender
                        If Not EOF(n) Then Input #n, MsgIdx(IdxCount).Bytes
                        IdxCount = IdxCount + 1
                    End If
                Wend
                Close n: n = 0
            End If
        End If
        Set CurItem = Nothing
    Else
        Set CurItem = lstMail.SelectedItem
    End If
    If CurItem Is Nothing Then
        MailListIndex = 0
        curitemkey = ""
        curlistindex = 0
    ElseIf MailListIndex <> CurItem.Index Then
        MailListIndex = 0
        curitemkey = ""
        curlistindex = 0
        Set CurItem = Nothing
    Else
        curitemkey = CurItem.Key
        curlistindex = CurItem.Index
    End If
    
    'Read Files
    MaxFile = 20
    ReDim Files(MaxFile)
    a = SDir(ViewerCurBox + "\*.*")
    While a <> ""
        b = UCase(PlainName(a, 3))
        If b <> "IDX" And b <> "BK" And Left(b, 1) <> "_" And UCase(ViewerCurBox + "\" + a) <> UCase(ReserveMailFile) Then
            If FileCount > MaxFile Then MaxFile = MaxFile + 40: ReDim Preserve Files(MaxFile)
            Files(FileCount) = a
            FileCount = FileCount + 1
        End If
        a = Dir
    Wend
    
    'Update Data
    For i = 0 To FileCount - 1
        'Remove Paired ML0 Files
        f = UCase(Files(i))
        Tag = PlainName(f, 2)
        ext = PlainName(f, 3)
        If ext = "ML0" Then
            For j = 0 To FileCount - 1
                If Tag + ".ML1" = UCase(PlainName(Files(j), 1)) Then Files(i) = "": Exit For
            Next j
        End If
        'Add Msg
        If Files(i) <> "" Then
            'Search Current Data
            nodex = GetNodeIndex(f)
            If nodex = -1 Then
                'Not Current Item
                'Find Idx Entry
                For j = 0 To IdxCount - 1
                    If UCase(MsgIdx(j).Filename) = f Then Exit For
                Next j
                If j = IdxCount Then idx = -1 Else idx = j
                'Create New Entry
                'Look for hole
                For j = 0 To msgCount - 1
                    If Msg(j).Filename = "" Then Exit For
                Next j
                If j = msgCount Then
                    'No holes, add new entry
                    newidx = msgCount
                    If msgCount > MaxMsg Then MaxMsg = MaxMsg + 20: ReDim Preserve Msg(MaxMsg)
                Else
                    'Fill hole
                    newidx = j
                End If
                'Set entry data
                Msg(newidx).Filename = Files(i)
                If idx = -1 Then
                    Msg(newidx).Kind = 0
                Else
                    'Copy Index Data
                    Msg(newidx).NewMsg = MsgIdx(idx).NewMsg
                    Msg(newidx).Kind = MsgIdx(idx).Kind
                    Msg(newidx).DateHeader = MsgIdx(idx).DateHeader
                    Msg(newidx).FileDate = MsgIdx(idx).FileDate
                    Msg(newidx).Subject = MsgIdx(idx).Subject
                    Msg(newidx).Sender = MsgIdx(idx).Sender
                    Msg(newidx).Bytes = MsgIdx(idx).Bytes
                End If
                Msg(newidx).Changed = True
                If newidx = msgCount Then msgCount = msgCount + 1
                If Msg(newidx).Kind = 0 Then
                    'Get Kind Info
                    GetMsgInfo Msg(newidx).Filename, newidx, False
                End If
            End If
        End If
    Next i
    
    'Read New Index
    If SDir(ViewerCurBox + "\JBN2NEW.IDX") <> "" Then
        n = FreeFile
        Open ViewerCurBox + "\JBN2NEW.IDX" For Input As n
        NewMail = Input(LOF(n), n)
        Close n: n = 0
        DelFile ViewerCurBox + "\JBN2NEW.IDX"
    End If
    
    'Update List Data
    NewMsgs = False
    For i = 0 To msgCount - 1
        f = UCase(Msg(i).Filename)
        'Remove Expired Files
        If Msg(i).Filename <> "" Then
            For j = 0 To FileCount - 1
                If UCase(Files(j)) = f Then Exit For
            Next j
            If j = FileCount Then
                Msg(i).Filename = ""
                On Error Resume Next
                lstMail.ListItems.Remove f
                On Error GoTo ErrorUpdate
                If i = msgCount - 1 Then msgCount = msgCount - 1
            End If
        End If
        If Msg(i).Filename <> "" Then
            'Check Current Decryptions
            Msg(i).DecQ = False
            For j = 0 To DecQCount - 1
                If UCase(DecQ(j)) = UCase(ViewerCurBox) + "\" + f Then Msg(i).DecQ = True: Msg(i).Changed = True: Exit For
            Next j
            'Check New Messages
            If InStr(1, NewMail, ViewerCurBox + "\" + f + vbCrLf, vbTextCompare) <> 0 Then Msg(i).NewMsg = True: Msg(i).Changed = True
            If Msg(i).NewMsg Then NewMsgs = True
            'Add/Find Node
            nodex = GetNodeIndex(f)
            If nodex = -1 Then
                'Add
                Set litem = lstMail.ListItems.Add(, f, Msg(i).Subject)
            Else
                Set litem = lstMail.ListItems.Item(nodex)
            End If
            litem.Tag = Str(i)
            'Determine Icon
            sicon = MsgIcon(i)
            If litem.SmallIcon <> sicon Then Msg(i).Changed = True
            'Update
            If Msg(i).Changed Then
                litem.SmallIcon = sicon
                litem.SubItems(1) = Msg(i).Sender
                On Error Resume Next
                litem.SubItems(2) = Format(Msg(i).DateHeader, Cnf(4, 8))
                litem.SubItems(3) = Format(Msg(i).FileDate, Cnf(4, 8))
                On Error GoTo ErrorUpdate
                litem.SubItems(4) = Format(Int(Msg(i).Bytes / 1024 + 0.99999), "####")
                For j = 5 To 6
                    If j = 5 Then rl = Msg(i).DateHeader Else rl = Msg(i).FileDate
                    a = Trim(Str(rl))
                    x = InStr(a, "."): If x = 0 Then a = a + ".": x = Len(a)
                    litem.SubItems(j) = Right("00000000" + Left(a, x - 1), 8) + Left(Mid(a, x) + "0000000", 8)
                Next j
                litem.SubItems(7) = Right("00000000" + Trim(Str(Msg(i).Bytes)), 10)
                Msg(i).Changed = False
            End If
        End If
    Next i
    'Select/Update Current Message
    If curitemkey = "" Then
        'No current message
        If Not lstMail.SelectedItem Is Nothing Then lstMail.SelectedItem.Selected = False
        Set lstMail.SelectedItem = Nothing
        OpenMessage (0)
    Else
        'Find message
        newitemkey = curitemkey
        x = GetNodeIndex(curitemkey)
        If x = -1 Then
            If PlainName(curitemkey, 3) = "ML0" Then
                newitemkey = PlainName(curitemkey, 0) + PlainName(curitemkey, 2) + ".ML1"
            ElseIf PlainName(curitemkey, 3) = "ML1" Then
                newitemkey = PlainName(curitemkey, 0) + PlainName(curitemkey, 2) + ".ML0"
            End If
            If newitemkey <> curitemkey Then x = GetNodeIndex(newitemkey)
        End If
        If x = -1 Then
            'Message not found, use next
            If curlistindex <> 0 Then
                If curlistindex > lstMail.ListItems.Count Then curlistindex = lstMail.ListItems.Count
            End If
            OpenMessage (curlistindex)
        Else
            'Message found
            MailListIndex = x
            Set lstMail.SelectedItem = lstMail.ListItems.Item(x)
            If newitemkey <> curitemkey Then OpenMessage (x)
        End If
    End If
    UpdateDisp
    Me.MousePointer = 0
Exit Sub
ErrorUpdate:
    ErrMsg = Error
    CloseFile n: n = 0
    msgCount = 0
    DelFile ViewerCurBox + "\JBN2MAIL.IDX"
    MsgBox LMsg(507) + vbCr + vbCr + ErrMsg, vbCritical
    Me.MousePointer = 0
End Sub

Private Function GetNodeIndex(keypth) As Integer
    GetNodeIndex = -1
    On Error Resume Next
    GetNodeIndex = lstMail.ListItems.Item(keypth).Index
End Function

Private Function MsgIcon(idx) As String
    With Msg(idx)
        If .DecQ Then
            MsgIcon = "Key"
        ElseIf .NewMsg Then
            If .Kind = KindNews Then
                MsgIcon = "NewsRed"
            Else
                MsgIcon = "MailRed"
            End If
        Else
            Select Case .Kind
            Case KindUnknown, KindPlain: MsgIcon = "MailWhite"
            Case KindPGP: MsgIcon = "Lock"
            Case KindDecrypted: MsgIcon = "MailBlue"
            Case KindSent: MsgIcon = "MailYellow"
            Case KindNews: MsgIcon = "News"
            Case Else: MsgIcon = "Leaf"
            End Select
        End If
    End With
End Function

Private Sub UpdateDisp()
    Dim NewMsgs As Long
    On Error Resume Next
    'TrashFolder
    x = 1
    For i = 0 To 2
        Select Case i
        Case 0: b = "Trash"
        Case 1: b = "Trash\Multi"
        Case 2: b = "Trash\Spam"
        End Select
        a = UCase(SDir(MailFolder + "\" + b + "\*.*"))
        While a <> ""
            If a <> "JBN2MAIL.IDX" Then x = 0: Exit For
            a = Dir
        Wend
    Next i
    cmdTrash(0).Picture = cmdTrash(x).DisabledPicture
    If x = 1 Then
        trvFolder.Nodes.Item(UCase(MailFolder + "\" + "Trash")).Tag = False2
        trvFolder.Nodes.Item(UCase(MailFolder + "\" + "Trash\Multi")).Tag = False2
        trvFolder.Nodes.Item(UCase(MailFolder + "\" + "Trash")).Image = "FoldClosed"
        trvFolder.Nodes.Item(UCase(MailFolder + "\" + "Trash\Multi")).Image = "FoldClosed"
    End If
    'Update Folder Flag State
    For i = 1 To lstMail.ListItems.Count
        If Msg(Val(lstMail.ListItems.Item(i).Tag)).NewMsg Then NewMsgs = NewMsgs + 1
    Next i
    If NewMsgs = 0 Then
        trvFolder.Nodes.Item(UCase(ViewerCurBox)).Image = "FoldOpen"
    Else
        trvFolder.Nodes.Item(UCase(ViewerCurBox)).Image = "FoldOpenFlag"
    End If
    trvFolder.Nodes.Item(UCase(ViewerCurBox)).Tag = NewMsgs <> 0
    'Update Window Title    View Mail - [Inbox  5 messages, 2 unread]
    Me.Caption = LMsg(508) + " - [" + trvFolder.SelectedItem.Text + " " + Str(lstMail.ListItems.Count) + " " + LMsg(298) + "," + Trim(Str(NewMsgs)) + " " + LMsg(509) + "]"
    If MailListIndex <> 0 Then
        lblStat(2).Caption = Trim(Str(MailListIndex)) + "/" + Trim(Str(lstMail.ListItems.Count))
    ElseIf rtbView.Tag = "Text" Then
        lblStat(2).Caption = "Text"
    Else
        lblStat(2).Caption = ""
    End If
    Stat StatMain, StatDec
End Sub

Private Sub OpenMessage(x)
    'Programmatically opens message x
    'Will only select, not open non text files
    'If x is 0 or invalid, unselects current message
    'Load new message
    'Unselect all
    For i = 1 To lstMail.ListItems.Count
        lstMail.ListItems.Item(i).Selected = False
    Next i
    If Not (x = 0 Or x > lstMail.ListItems.Count) Then
        idx = Val(lstMail.ListItems.Item(x).Tag)
        ext = UCase(PlainName(Msg(idx).Filename, 3))
        Set lstMail.SelectedItem = lstMail.ListItems.Item(x)
        If ext = "ML0" Or ext = "ML1" Or ext = "TXT" Then
            'Open Message
            MailListIndex = x
            Set lstMail.SelectedItem = lstMail.ListItems.Item(x)
            t = tabView.SelectedItem.Index
            NoClick = True
            If ext = "ML1" Then tabView.Tabs.Item(2).Selected = True Else tabView.Tabs.Item(1).Selected = True
            NoClick = False
            rtbView.Tag = "loading"
            tabView_Click
            If t > 2 And t <= tabView.Tabs.Count Then tabView.Tabs.Item(t).Selected = True
            GoTo Done
        Else
            lstMail.SelectedItem.Selected = False
            MailListIndex = x
        End If
    Else
        Set lstMail.SelectedItem = Nothing
        MailListIndex = 0
    End If
    'Clear Current Message
    fraView(0).Visible = False
    fraView(1).Visible = False
    AttachCount = 0: AttachSource = ""
    rtbView.Tag = ""
    rtbView.Text = ""
    If tabView.Tabs.Count = 4 Then tabView.Tabs.Remove 4
    NoClick = True
    tabView.Tabs.Item(1).Selected = True
    NoClick = False
Done:
    If lstMail.Visible Then lstMail.SetFocus
End Sub

Private Sub lstMail_KeyUp(KeyCode As Integer, Shift As Integer)
    On Error Resume Next
    If lstMail.SelectedItem.Index <> MailListIndex Then lstMail_MouseUp 99, 0, 0, 0
End Sub

Private Sub lstMail_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Dim Item As ListItem
    If Button <> 99 Then
        If NewMessages <> 0 Then
            NewMessages = 0
            If InStr(StatMain, LMsg(456)) <> 0 Then StatMain = ""
            Stat StatMain, StatDec
        End If
        If (Button And vbLeftButton) = 0 Then Exit Sub
        Set Item = lstMail.HitTest(x, y)
    Else
        Set Item = lstMail.SelectedItem
    End If
    If Item Is Nothing Then Exit Sub
    MailListIndex = Item.Index
    f = UCase(Item.Key)
    idx = Val(Item.Tag)
    If SDir(ViewerCurBox + "\" + f) = "" Or UCase(Msg(idx).Filename) <> f Then  ''''errortrap msgbound?
        'Message no longer available
        MsgBox LMsg(480)
        UpdateList UCase(Msg(idx).Filename) <> f
    Else
        x = tabView.SelectedItem.Index
        NoClick = True
        If PlainName(f, 3) = "ML1" Then tabView.Tabs.Item(2).Selected = True Else tabView.Tabs.Item(1).Selected = True
        NoClick = False
        rtbView.Tag = "loading"
        tabView_Click
        If x > 2 And x <= tabView.Tabs.Count Then tabView.Tabs.Item(x).Selected = True
    End If
End Sub

Private Sub tabView_Click()
    Dim Block As String
    If NoClick Then Exit Sub
    Select Case tabView.SelectedItem.Index
    Case Is < 3
        'Hide Attachment frame
        fraView(1).Visible = False
        If rtbView.Tag = "" Then
            'No message loaded
            fraView(0).Visible = False
            cmdDecrypt.Visible = False
            Exit Sub
        ElseIf rtbView.Tag = "Text" Then
            'Text Mode
            fraView(0).Visible = tabView.SelectedItem.Index = 1
            cmdDecrypt.Visible = tabView.SelectedItem.Index = 2
            Exit Sub
        End If
        'Show correct checks
        NoClick = True
        For i = 0 To 1
            chkView(i).Value = Val(PData(138 + i + (tabView.SelectedItem.Index - 1) * 4))
        Next i
        NoClick = False
        chkView_Click (0)
        If MailListIndex <> 0 Then
            'Message is selected, show
            f = UCase(lstMail.ListItems(MailListIndex).Key)
            ext = PlainName(f, 3)
            If ext = "ML0" Or ext = "ML1" Then
                'Mail File
                f2 = PlainName(f, 2) + ".ML" + Trim(Str(tabView.SelectedItem.Index - 1))
                fraView(0).Visible = SDir(ViewerCurBox + "\" + f2) <> ""
                PData(141 + (tabView.SelectedItem.Index - 1) * 4) = (PData(141 + (tabView.SelectedItem.Index - 1) * 4) = False2)
                lblReply_Click
'                lblReply.Visible = True
'                cboReply.Visible = True
'                cmdOpenBook.Visible = False
                chkView(0).Visible = True
                chkView(1).Visible = True
                'Is Decrypt button visible?
                cmdDecrypt.Visible = False
                If Not fraView(0).Visible And tabView.SelectedItem.Index = 2 Then
                    dfile = UCase(ViewerCurBox + "\" + PlainName(f, 2) + ".ML0")
                    If SDir(dfile) <> "" Then
                        For i = 0 To DecQCount - 1
                            If dfile = UCase(DecQ(i)) Then Exit For
                        Next i
                        If i = DecQCount Then cmdDecrypt.Visible = True
                    End If
                End If
            Else
                'Other file
                If tabView.SelectedItem.Index = 1 Then
                    fraView(0).Visible = True
                    lblReply.Visible = False
                    cboReply.Visible = False
                    cmdOpenBook.Visible = False
                    chkView(0).Visible = False
                    chkView(1).Visible = False
                    f2 = f
                Else
                    fraView(0).Visible = False
                    cmdDecrypt.Visible = Msg(Val(lstMail.ListItems.Item(MailListIndex).Tag)).Kind = KindText
                    Exit Sub
                End If
            End If
            fraView(0).Refresh
            If fraView(0).Visible Then DisplayMessage f2, Val(lstMail.ListItems.Item(MailListIndex).Tag)
        Else
            'No message selected
            rtbView.Tag = ""
            fraView(0).Visible = False
            cmdDecrypt.Visible = False
        End If
    Case 3
        'Info
        wid = 16
        fraView(0).Visible = MailListIndex <> 0
        fraView(1).Visible = False
        cmdDecrypt.Visible = False
        lblReply.Visible = False
        cboReply.Visible = False
        cmdOpenBook.Visible = False
        chkView(0).Visible = False
        chkView(1).Visible = False
        If MailListIndex <> 0 Then
            idx = Val(lstMail.ListItems.Item(MailListIndex).Tag)
            ext = UCase(PlainName(Msg(idx).Filename, 3))
            If ext = "ML0" Or ext = "ML1" Then
                'Mail File Info
                a = LMsg(510) + vbCrLf + vbCrLf
                For i = 0 To 1
                    If i = 0 Then
                        a = a + LMsg(511) + ":  "  'Mail Message
                        If ext = "ML0" Then NameStart = Len(a)
                    Else
                        a = a + LMsg(512) + ":  " 'Decrypted File
                        If ext = "ML1" Then NameStart = Len(a)
                    End If
                    f = ViewerCurBox + "\" + PlainName(Msg(idx).Filename, 2) + ".ML" + Trim(Str(i))
                    If SDir(f) <> "" Then
                        flen = FileLen(f)
                        a = a + f + "    (" + Trim(Str(flen)) + " bytes)" + vbCrLf
                    Else
                        a = a + "[ " + LMsg(513) + " ]" + vbCrLf
                    End If
                Next i
                If Msg(idx).Kind = KindSent Then
                    f2 = ViewerCurBox + "\" + PlainName(Msg(idx).Filename, 2)
                    If SDir(f2 + ".BK") <> "" Then a = a + LMsg(575) + ":  " + f2 + ".BK"
                    If SDir(f2 + "._*") <> "" Then a = a + "   (With Replay)"
                    a = a + vbCrLf
                End If
                If CurRBTag <> "" Then
                    'RB Info
                    If SVal(CurRBPK) > 1 Then b = " [" + LMsg(570) + "]" Else b = ""
                    a = a + vbCrLf + LMsg(514) + ": " + CurRBConv
                    a = a + vbCrLf + LMsg(558) + ": " + CurRBPK + " " + b + vbCrLf
                    a = a + vbCrLf + LMsg(515) + ":  " + CurRBTag + vbCrLf
                    While NymDataBusy: DoEvents: Wend
                    NymDataBusy = True
                    FindRB CurRBTag, "", RBX, RBY, True, Block
                    If RBX <> -1 Then
                        a = a + vbTab + "Tag:     " + Block + vbCrLf
                    Else
                        a = a + "[ " + LMsg(516) + " ]" + vbCrLf
                    End If
                    NymDataBusy = False
                End If
            Else
                'other file
                f = ViewerCurBox + "\" + Msg(idx).Filename
                a = LMsg(517) + ":  "
                NameStart = Len(a)
                a = a + f
                If SDir(f) <> "" Then a = a + "    (" + Trim(Str(FileLen(f))) + " bytes)"
                a = a + vbCrLf
            End If
            rtbView.Text = a
            rtbView.SelStart = NameStart
            rtbView.SelLength = Len(f)
            rtbView.Locked = False
            NoClick = True
            rtbView.SetFocus
            NoClick = False
        End If
    Case 4
        'Attachments
        fraView(0).Visible = False
        fraView(1).Visible = True
        cmdDecrypt.Visible = False
        On Error Resume Next
        lstAttach.ListItems.Item(1).Selected = True
    End Select
End Sub

Private Sub chkView_Click(Index As Integer)
    If NoClick Or tabView.SelectedItem.Index > 2 Then Exit Sub
    NoClick = True
    If tabView.SelectedItem.Index = 1 Then viewwindow = 1 Else viewwindow = 2
    Select Case Index
    Case 0 'Full
        If chkView(0).Value = 1 Then
            rtbView.Text = FullHdrs + vbCrLf + Mid(rtbView.Text, TextStart)
            TextStart = Len(FullHdrs) + 3
        Else
            rtbView.Text = ShortHdrs + vbCrLf + Mid(rtbView.Text, TextStart)
            TextStart = Len(ShortHdrs) + 3
        End If
    Case 1 'Raw
        If chkView(1).Value = 1 Then
            chkView(viewwindow - 1).Tag = Str(chkView(0).Value)
            chkView(0).Value = 1
        Else
            'If TextChanged Then
                ''''''Prompt to save?
            'End If
            chkView(0).Value = Val(chkView(viewwindow - 1).Tag)
        End If
    End Select
    NoClick = False
    chkView(0).Enabled = chkView(1).Value = 0
    For i = 0 To 1
        PData(138 + i + (viewwindow - 1) * 4) = Str(chkView(i).Value)
    Next i
    If Index = 1 Then tabView_Click
End Sub

Private Sub lblReply_Click()
    If tabView.SelectedItem.Index = 1 Then viewwindow = 1 Else viewwindow = 2
    x = 141 + (viewwindow - 1) * 4
    If PData(x) = True2 Then
        PData(x) = False2
        lblReply.Caption = "Followup via:"
    Else
        PData(x) = True2
        lblReply.Caption = "Reply via:"
    End If
End Sub

Private Sub lstMail_ColumnClick(ByVal ColumnHeader As ColumnHeader)
    rtbView_GotFocus
    If MailListIndex <> 0 Then
        curitemkey = lstMail.ListItems.Item(MailListIndex).Key
    Else
        curitemkey = ""
    End If
    If ColumnHeader.Index > 2 Then
        x = ColumnHeader.Index + 3 - 1
    Else
        x = ColumnHeader.Index - 1
    End If
    If lstMail.SortKey = x Then
        lstMail.SortOrder = Abs(lstMail.SortOrder - 1)
    Else
        lstMail.SortKey = x
        lstMail.SortOrder = 0 'lvwAscending
    End If
    For i = 1 To 5
        If i = ColumnHeader.Index Then
            If lstMail.SortOrder = 0 Then a = "+" Else a = "-"
        Else: a = ""
        End If
        lstMail.ColumnHeaders.Item(i).Text = lstMail.ColumnHeaders.Item(i).Key + a
    Next i
    lstMail.Sorted = True
    If curitemkey <> "" Then
        MailListIndex = lstMail.ListItems.Item(curitemkey).Index
        Set lstMail.SelectedItem = lstMail.ListItems.Item(curitemkey)
        lstMail.SelectedItem.EnsureVisible
    Else
        Set lstMail.SelectedItem = Nothing
    End If
End Sub

Private Sub DisplayMessage(fmail, idx)
    Dim MIMEBnd As String, MIME As Boolean, MIMEMultipart As Boolean
    Dim MIMEType As String, MIMEEncoding As String, MIMEDisposition As String
    Dim MIMEFilename As String, MIMEDis As String
    Dim TempText As String, n As Integer
    Dim ShowRaw As Boolean, ShowFull As Boolean, FocusMail As Boolean
    Dim litem As ListItem, RBTag As String
    
    On Error GoTo ErrorDisplay
    Me.MousePointer = 11
    If tabView.SelectedItem.Index = 1 Then viewwindow = 1 Else viewwindow = 2
    ShowFull = Val(PData(138 + 4 * (viewwindow - 1))) = 1
    ShowRaw = Val(PData(139 + 4 * (viewwindow - 1))) = 1
    rtbView.Text = "": rtbView.Refresh: lstMail.Refresh
    rtbView.Locked = (Val(PData(139 + 4 * (viewwindow - 1))) = 0) Or Not ShowFull
    FocusMail = UCase(fmail) = UCase(Msg(idx).Filename)
    If FocusMail Then AttachCount = 0: lstAttach.ListItems.Clear: AttachSource = ViewerCurBox + "\" + fmail
    GetMsgInfo fmail, idx, True, MIMEType, MIMEEncoding, MIMEDisposition, RBTag, n
    rtbView.Tag = fmail
    
    If ShortHdrs <> "" Then rtbView.Text = ShortHdrs + vbCrLf
    If n = -1 Then GoTo ExitNow
    If n <> 0 Then
        'Mail File Open
        If Not ShowRaw Then
            If ShowFull Then
                rtbView.Text = FullHdrs + vbCrLf
                TextStart = Len(FullHdrs) + 3
            Else
                rtbView.Text = ShortHdrs + vbCrLf
                TextStart = Len(ShortHdrs) + 3
            End If
        End If
        'Check MIME Headers
        If MIMEType <> "" Then
            If InStr(1, MIMEType, "multipart", vbTextCompare) <> 0 Then
                'multipart
                x = InStr(1, MIMEType, "boundary", vbTextCompare)
                If x <> 0 Then
                    MIMEBnd = Trim(Extract(Mid(MIMEType, x + 8), ";"))
                    If Left(MIMEBnd, 1) = "=" Then MIMEBnd = Mid(MIMEBnd, 2)
                    MIMEBnd = "--" + Replace(MIMEBnd, Chr(34), "")
                Else: MIMEBnd = ""
                End If
                MIMEMultipart = MIMEBnd <> ""
                MIME = MIMEMultipart
            Else
                'explicit
                contentseek = Seek(n)
                MIMEMultipart = False
                MIME = True
            End If
        Else
            MIME = False
        End If
ParseMessage:
        Do While Not EOF(n)
            If MIMEMultipart Then
                'Scan for MIME boundary
                MIMEType = ""
                MIMEEncoding = ""
                MIMEDisposition = ""
                Do While Not EOF(n)
                    Line Input #n, a
                    If Left(a, 1) = "-" Then
                        If a = MIMEBnd + "--" Then
                            'End of Message, display hidden text
                            TempText = ""
                            While Not EOF(n)
                                Line Input #n, a
                                If LTrim(a) <> "" Then TempText = TempText + a + vbCrLf
                            Wend
                            If TempText <> "" And Not ShowRaw Then rtbView.Text = rtbView.Text + vbCrLf + TempText
                            GoTo ParseDone
                        End If
                        If a = MIMEBnd Then
                            'Get Content-Type
                            contentseek = Seek(n)
                            'Ignore blanks
                            a = ""
                            While Not EOF(n) And a = ""
                                Line Input #n, a
                            Wend
                            If InStr(1, a, "content-type:", vbTextCompare) = 1 Then
                                'Get Content headers (multiline)
                                Do
                                    b = a
                                    Do While Not EOF(n)
                                        Line Input #n, a
                                        If Left(a, 1) = vbTab Or Left(a, 1) = " " Then
                                            b = b + Replace(a, vbTab, "    ")
                                        Else
                                            Exit Do
                                        End If
                                    Loop
                                    c = LCase(Extract(b, ":"))
                                    Select Case c
                                    Case "content-type": MIMEType = Trim(Mid(b, 14))
                                    Case "content-transfer-encoding": MIMEEncoding = Trim(Mid(b, 27))
                                    Case "content-disposition": MIMEDisposition = Trim(Mid(b, 21))
                                    End Select
                                Loop Until a = "" Or EOF(n)
                                'Take up slack
                                bodyseek = -1
                                While Not EOF(n) And a = ""
                                    bodyseek = Seek(n)
                                    Line Input #n, a
                                Wend
                                If bodyseek <> -1 And a <> "" Then Seek #n, bodyseek
                            End If
                            Exit Do
                        Else
                            'Show hidden text
                            'X If LTrim(a) <> "" And Not ShowRaw  Then rtbView.Text = rtbView.Text + a + vbCrLf
                        End If
                    Else
                        'Show hidden text
                        'X If LTrim(a) <> "" And Not ShowRaw  Then rtbView.Text = rtbView.Text + a + vbCrLf
                    End If
                Loop
            End If
            If MIME And Not EOF(n) Then
                'Determine MIME action
                If MIMEType <> "" Then
                    'Type
                    'Clear out PGPMIME   application/pgp-encrypted
                    If LCase(Trim(Extract(MIMEType, ";"))) = "application/pgp-encrypted" Then
                        Do While Not EOF(n)
                            Line Input #n, b
                            If InStr(1, b, "content-type:", vbTextCompare) = 1 Then
                                'Take up slack
                                b = ""
                                bodyseek = -1
                                While Not EOF(n) And b = ""
                                    bodyseek = Seek(n)
                                    Line Input #n, b
                                Wend
                                If bodyseek <> -1 And b <> "" Then Seek #n, bodyseek: Exit Do
                            End If
                        Loop
                        MIMEType = "text/plain"
                        MIMEEncoding = "7bit"
                        MIMEDis = "inline"
                    End If
                    'Disposition
                    MIMEDis = LCase(Trim(Extract(MIMEDisposition, ";")))
                    If MIMEDis = "" Then
                        If InStr(1, Extract(MIMEType, ";"), "text/plain", vbTextCompare) <> 0 Then
                            MIMEDis = "inline"
                        Else
                            MIMEDis = "attachment"
                        End If
                    Else
                        If InStr(1, Extract(MIMEType, ";"), "text/plain", vbTextCompare) = 0 Then
                            MIMEDis = "attachment"
                        Else
                            If MIMEDis <> "inline" Then MIMEDis = "attachment"
                        End If
                    End If
                    'Filename
                    x = InStr(1, MIMEDisposition, "filename", vbTextCompare)
                    If x <> 0 Then
                        MIMEFilename = Trim(Extract(Mid(MIMEDisposition, x + 8), ";"))
                        If Left(MIMEFilename, 1) = "=" Then MIMEFilename = Mid(MIMEFilename, 2)
                        MIMEFilename = Replace(MIMEFilename, Chr(34), "")
                    Else: MIMEFilename = ""
                    End If
                    If MIMEFilename = "" Then
                        x = InStr(1, MIMEType, "name", vbTextCompare)
                        If x <> 0 Then
                            MIMEFilename = Trim(Extract(Mid(MIMEType, x + 8), ";"))
                            If Left(MIMEFilename, 1) = "=" Then MIMEFilename = Mid(MIMEFilename, 2)
                            MIMEFilename = Replace(MIMEFilename, Chr(34), "")
                        Else: MIMEFilename = ""
                        End If
                    End If
                    If MIMEFilename = "" Then MIMEFilename = "Attachment"
                    'Encoding
                    MIMEEncoding = LCase(Trim(Extract(MIMEEncoding, ";")))
                    If MIMEEncoding = "" Then If InStr(1, Extract(MIMEType, ";"), "text/plain", vbTextCompare) + InStr(1, Extract(MIMEType, ";"), "text/html", vbTextCompare) <> 0 Then MIMEEncoding = "7bit"
                    Select Case MIMEEncoding
                    Case "7bit", "8bit"
                        decodebody = False
                    Case "quoted-printable"
                        decodebody = True
                    Case "base64"
                        decodebody = True
                    Case "x-uuencode"
                        decodebody = True
                    Case Else
                        decodebody = False
                        MIMEEncoding = ""
                        GoTo ShowVerbatim
                    End Select
                    'Save/Parse Part
                    If decodebody And MIMEDis = "inline" Then
                        n2 = FreeFile
                        f2 = GetWork(ViewerCurBox)
                        Open f2 For Output As n2
                    End If
                    a = ""
                    startseek = Seek(n)
                    preendseek = Seek(n)
                    Do While Not EOF(n)
                        preendseek = Seek(n)
                        Line Input #n, a
                        If MIMEMultipart Then
                            If Left(a, 1) = "-" Then
                                If a = MIMEBnd Or a = MIMEBnd + "--" Then Seek #n, preendseek: Exit Do
                            End If
                        End If
                        If decodebody And MIMEDis = "inline" Then Print #n2, a
                    Loop
                    If MIMEDis = "inline" Then
                        'Inline
                        If decodebody Then
                            Close n2: n2 = 0
                            'Decode
                            If decodebody Then
                                f3 = DecodeFile(f2, GetWork(ViewerCurBox), MIMEEncoding, ErrMsg)
                                DelFile f2
                                If f3 = "" Then GoTo ShowVerbatim
                                f2 = f3
                            End If
                            'Load
                            n2 = FreeFile
                            Open f2 For Input As n2
                            LoadText rtbView, f2, n2, 1, LOF(n2) + 1, Not ShowRaw, FocusMail
                            CloseFile n2: n2 = 0
                            DelFile f2
                        Else
                            'No decode, load
                            endseek = Seek(n)
                            LoadText rtbView, ViewerCurBox + "\" + fmail, n, startseek, endseek, Not ShowRaw, FocusMail
                        End If
                    Else
                        'Attachment
                        If FocusMail Then
                            If MaxAttach = 0 Or AttachCount > MaxAttach Then MaxAttach = MaxAttach + 10: ReDim Preserve Attach(MaxAttach)
                            Attach(AttachCount).Filename = MIMEFilename
                            Attach(AttachCount).ContentType = MIMEType
                            Attach(AttachCount).Encoding = MIMEEncoding
                            Attach(AttachCount).seekstart = startseek
                            Attach(AttachCount).seekend = Seek(n)
                            AttachCount = AttachCount + 1
                        End If
                    End If
                Else
                    'No MIMEType
                    GoTo ShowVerbatim
                End If
                If Not MIMEMultipart Then Exit Do
            Else
                'Not MIME
                LoadText rtbView, ViewerCurBox + "\" + fmail, n, Seek(n), LOF(n) + 1, Not ShowRaw, FocusMail
                Exit Do
            End If
        Loop
ParseDone:
        Close n: n = 0
        If ShowRaw Then rtbView.LoadFile ViewerCurBox + "\" + fmail
    Else
        'Not a mail file
        If Msg(idx).Kind = KindText Then
            rtbView.LoadFile ViewerCurBox + "\" + fmail
            If InStr(1, fmail, "acksend.txt", vbTextCompare) <> 0 Then rtbView.SelStart = Len(rtbView.Text)
            rtbView.Locked = False
        Else
            'Open file
            OpenSpec ViewerCurBox + "\" + fmail, False
            fraView(0).Visible = False
            rtbView.Tag = ""
        End If
    End If
Done:
    'Update Attachments
    x = tabView.SelectedItem.Index
    If AttachCount <> 0 And tabView.Tabs.Count = 3 Then
        tabView.Tabs.Add 4, , "* &Attachments *"
    ElseIf AttachCount = 0 And tabView.Tabs.Count = 4 Then
        tabView.Tabs.Remove 4
    End If
    NoClick = True
    If x <= tabView.Tabs.Count Then tabView.Tabs.Item(x).Selected = True
    NoClick = False
    If FocusMail Then
        For i = 0 To AttachCount - 1
            Set litem = lstAttach.ListItems.Add(, , Attach(i).Filename)
            litem.SubItems(1) = Extract(Attach(i).ContentType, ";")
            litem.SubItems(2) = Attach(i).Encoding
            litem.SubItems(3) = Trim(Str(Int((Attach(i).seekend - Attach(i).seekstart) / 1024 + 0.9999)))
        Next i
    End If
    'Update Label
    If FocusMail Then
        CurRBTag = ""
        CurRBNum = ""
        CurRBConv = ""
        CurRBPK = ""
    End If
    Select Case tabView.SelectedItem.Index
    Case 1
        Select Case Msg(idx).Kind
        Case KindText
            a = LMsg(518)  '"Text File"
        Case KindPlain
            a = LMsg(519)  '"Plain Message"
        Case KindPGP, KindDecrypted
            a = LMsg(520)  '"Encrypted Message"
        Case KindSent
            a = LMsg(521)  '"Sent Message"
        Case KindNews
            a = LMsg(522)  ' "News Article"
        Case Else
            a = ""
        End Select
        lblView.Caption = a
    Case 2
        CurRB = ""
        If RBTag = "" Then
            lblView.Caption = LMsg(523) '"Decrypted Message"
        Else
            'Find reply-block
            CurRBTag = Extract(RBTag, ".")
            x = InStr(RBTag, ".")
            If x <> 0 Then
                CurRBConv = Mid(RBTag, x + 1)
                x = InStr(CurRBConv, "&")
                If x <> 0 Then CurRBPK = Mid(CurRBConv, x + 1): CurRBConv = Left(CurRBConv, x - 1)
            End If
            For k = 1 To 2
                For j = 0 To MaxNyms
                    If Nyms(j, 0) = "" Then Exit For
                    If InStr(Nyms(j, k), CurRBTag) <> 0 Then
                        y = 1
                        x = InStr(1, Nyms(j, k), "tag:", vbTextCompare)
                        While x <> 0
                            a = Trim(Extract(Mid(Nyms(j, k), x + 4), vbCrLf))
                            If Extract(a, " ") = CurRBTag Then
                                x = InStr(a, "#")
                                If x <> 0 Then CurRBNum = Mid(a, x)
                                Done = True: Exit For
                            End If
                            y = x + 1
                            x = InStr(y, Nyms(j, k), "tag:", vbTextCompare)
                        Wend
                    End If
                Next j
                If Done Then Exit For
            Next k
            a = LMsg(515) + ": "
            If CurRBNum <> "" Then
                a = a + CurRBNum
            Else
                a = a + CurRBTag
            End If
            If CurRBConv <> "" Then a = a + "  [" + CurRBConv + " Conv]"
            If SVal(CurRBPK) = 1 Then
                a = a + "  [PK]"
            ElseIf SVal(CurRBPK) > 1 Then
                a = a + "  [%%% PK " + LMsg(570) + " %%%]"
            End If
            lblView.Caption = a
        End If
    End Select
    'Open Book button
    If tabView.SelectedItem.Index = 1 And Msg(idx).Kind = KindSent Then
        lblReply.Visible = False
        cboReply.Visible = False
        cmdOpenBook.Visible = True
        cmdOpenBook.Enabled = SDir(ViewerCurBox + "\" + PlainName(fmail, 2) + ".BK") <> ""
    Else
        cmdOpenBook.Visible = False
        lblReply.Visible = True
        cboReply.Visible = True
    End If
    'Update Display
    On Error Resume Next
    Msg(idx).NewMsg = False
    lstMail.ListItems.Item(UCase(Msg(idx).Filename)).SmallIcon = MsgIcon(idx)
    UpdateDisp
    Me.MousePointer = 0
Exit Sub
ShowVerbatim:
    'Unable to decode MIME part, show all
    Seek #n, contentseek
    If InStr(1, MIMEType, "message/partial", vbTextCompare) = 0 Then TempText = "!!! " + LMsg(524) + " !!!" + vbCrLf Else TempText = ""
    Do While Not EOF(n)
        preendseek = Seek(n)
        Line Input #n, a
        If MIMEMultipart Then
            If Left(a, 1) = "-" Then
                If a = MIMEBnd Or a = MIMEBnd + "--" Then Seek #n, preendseek: Exit Do
            End If
        End If
    Loop
    preendseek = Seek(n)
    If Not ShowRaw Then
        Seek #n, contentseek
        rtbView.Text = rtbView.Text + TempText + Input(preendseek - contentseek, n)
        Seek #n, preendseek
    End If
    GoTo ParseMessage
ErrorDisplay:
    ErrMsg = Error
    CloseFile n: n = 0
    CloseFile n2: n2 = 0
    MsgBox ErrMsg, vbCritical
ExitNow:
    rtbView.Text = ""
    TextStart = 1
    rtbView.Tag = ""
    AttachCount = 0
    fraView(0).Visible = False
    GoTo Done
End Sub

Private Sub LoadText(ob As Object, f, n, seekstart, seekend, Display As Boolean, UUDecode As Boolean)
    'Loads file text into ob.text removing UUE parts
    AssumeBinary = False
TryLoad:
    On Error GoTo LoadTextError
    Seek #n, seekstart
    
    'Scan for UUE
    If UUDecode Then
        startseek = Seek(n)
        Do While Seek(n) < LOF(n)
            endseek = Seek(n)
            Line Input #n, a
            If LCase(Left(a, 6)) = "begin " Then
                If LCase(a) Like "begin ##*" Then
                    uueseek = Seek(n)
                    ValidUUE = False
                    If Seek(n) < LOF(n) Then Line Input #n, b Else b = ""
                    If Seek(n) < LOF(n) Then Line Input #n, c Else c = ""
                    If Len(b) > 50 And Len(c) = Len(b) Then
                        While Seek(n) < LOF(n) And LCase(c) <> "end"
                            Line Input #n, c
                        Wend
                        If LCase(c) = "end" Then
                            'Valid UUE
                            If FocusMail Then
                                If MaxAttach = 0 Or AttachCount > MaxAttach Then MaxAttach = MaxAttach + 10: ReDim Preserve Attach(MaxAttach)
                                For i = 0 To 1
                                    x = InStr(a, " "): If x = 0 Then x = Len(a)
                                    a = Trim(Mid(a, x + 1))
                                Next i
                                If a = "" Then a = "Attachment"
                                Attach(AttachCount).Filename = a
                                Attach(AttachCount).ContentType = "UUEncode"
                                Attach(AttachCount).Encoding = "x-uuencode"
                                Attach(AttachCount).seekstart = endseek
                                Attach(AttachCount).seekend = Seek(n)
                                AttachCount = AttachCount + 1
                            End If
                            ValidUUE = True
                        End If
                    End If
                    If Not ValidUUE Then
                        Seek #n, uueseek
                    Else
                        curseek = Seek(n)
                        Seek #n, startseek
                        ob.Text = ob.Text + Input(endseek - startseek, n)
                        Seek #n, curseek
                        startseek = curseek
                    End If
                End If
            End If
        Loop
        Seek #n, startseek
    End If
    If Display Then ob.Text = ob.Text + Input(seekend - startseek, n)
Exit Sub
LoadTextError:
    If Not AssumeBinary And Err.Number = 62 Then
        AssumeBinary = True
        Close n
        n = FreeFile
        Open f For Binary As n
        Resume TryLoad
    Else
        Err.Raise Err.Number
    End If
End Sub

Private Function DecodeFile(fn, fn2, Encoding, ErrMsg) As String
    On Error GoTo DecodeError
    Select Case Encoding
    Case "quoted-printable"
        frmMain!NetCode1.Format = 2 'f_QuotedPrintable
        frmMain!NetCode1.Filename = ""
        frmMain!NetCode1.DecodedData = fn2
    Case "base64"
        frmMain!NetCode1.Format = 1 'f_Base64
        frmMain!NetCode1.Filename = ""
        frmMain!NetCode1.DecodedData = fn2
    Case "x-uuencode"
        frmMain!NetCode1.Format = 0 'f_UUEncode
        frmMain!NetCode1.Filename = fn2
        frmMain!NetCode1.DecodedData = ""
    End Select
    While EncoderBusy
        DoEvents
    Wend
    EncoderBusy = True
    frmMain!NetCode1.EncodedData = fn
    frmMain!NetCode1.Action = 1 'a_DecodeToFile
    EncoderBusy = False
    If SDir(fn2) = "" Then GoTo DecodeError
    If FileLen(fn2) = 0 Then Err.Description = LMsg(217): GoTo DecodeError
    DecodeFile = fn2
Exit Function
DecodeError:
    EncoderBusy = False
    ErrMsg = LMsg(470) + vbCrLf + Err.Description
    DecodeFile = ""
    DelFile fn2
End Function

Private Sub GetMsgInfo(fmail, idx, FullRead As Boolean, Optional MIMEType As String, _
            Optional MIMEEncoding As String, _
            Optional MIMEDisposition As String, Optional RBTag As String, _
            Optional FileNum As Integer)
    Dim lastseek As Long, FocusMail As Boolean
    
    On Error GoTo ErrorGetMsgInfo
    FocusMail = UCase(fmail) = UCase(Msg(idx).Filename)
    If FullRead Then FullHdrs = "": ShortHdrs = "": MIMEType = "": MIMEEncoding = ""
    If SDir(ViewerCurBox + "\" + Msg(idx).Filename) <> "" Then
        If FocusMail Then
            Msg(idx).FileDate = FileDateTime(ViewerCurBox + "\" + Msg(idx).Filename)
            Msg(idx).Bytes = FileLen(ViewerCurBox + "\" + Msg(idx).Filename)
            Msg(idx).DateHeader = 0
            Msg(idx).Kind = 0
            Msg(idx).Subject = ""
            Msg(idx).Sender = ""
        End If
        ext = UCase(PlainName(fmail, 3))
        If ext = "ML0" Or ext = "ML1" Then
            n = FreeFile
            Open ViewerCurBox + "\" + fmail For Input As n
            a = ""
            While Not EOF(n) And a = ""
                lastseek = Seek(n)
                Line Input #n, a
            Wend
            If Not a Like "From *@* *:*" And InStr(a, ": ") < 3 Then
                'No headers, treat as text file
                If FocusMail Then
                    Msg(idx).Kind = KindText
                    Msg(idx).Subject = LMsg(518) + ": " + fmail
                End If
                Close n: n = 0
            Else
                'Looks like a mail file
                'Look for Reply-Block Tag
                If Left(a, 5) = "From " And FocusMail Then
                    If Left(a, 13) = "From user@dcv" Then
                        'JBN1 Reply-Block Enum
                        If InStr(a, "@JBN2.") > 3 Then
                            convdec = SVal(Replace(Mid(a, InStr(a, "@JBN2.") - 2, 2), ".", ""))
                        Else
                            convdec = SVal(Extract(Mid(a, InStr(a, "From user@dcv") + 13), "."))
                        End If
                        x = InStr(a, ".RBE.")
                        If x <> 0 Then RBEnum = Extract(Mid(a, x + 5), " "): RBEnum2 = " #" + Extract(RBEnum, ".")
                        RBTag = RBEnum2 + "." + Trim(Str(convdec))
                    ElseIf a Like "From *@JBN2.* *:*" Then
                        RBTag = Trim(Extract(Mid(a, 6), "@"))
                    ElseIf Left(a, 22) = "From sent.message@Jack" Then
                        Msg(idx).Kind = KindSent
                    ElseIf Left(a, 17) = "From NNTP-Server@" Then
                        Msg(idx).Kind = KindNews
                    End If
                End If
                'Get Short and Full Headers
                Do
                    If a <> "" Then
                        x = InStr(a, ":")
                        If x <> 0 Then
                            b = LTrim(Mid(a, x + 1))
                            Select Case LCase(Trim(Left(a, x - 1)))
                            Case "subject"
                                HSubject = UnQPHeader(b)
                                If FocusMail Then Msg(idx).Subject = HSubject
                            Case "to": HTo = b
                            Case "from"
                                b = UnQPHeader(b)
                                HFrom = b
                                If FocusMail Then
                                    'Get Sender Field
                                    y = InStr(b, Chr(34))
                                    If y <> 0 Then
                                        'Use part in quotes
                                        HFrom2 = Extract(Mid(b, y + 1), Chr(34))
                                    Else
                                        y = InStr(b, "(")
                                        If y <> 0 Then
                                            'Use part in parenthesis
                                            HFrom2 = Extract(Mid(b, y + 1), ")")
                                        Else
                                            If Left(Trim(b), 1) <> "<" And InStr(b, "<") <> 0 Then
                                                HFrom2 = Trim(Extract(b, "<"))
                                            End If
                                        End If
                                    End If
                                    If Left(HFrom2, 9) = "Anonymous" Then
                                        HFrom2 = ""
                                        y = InStr(b, "<")
                                        If y <> 0 Then HFrom2 = Extract(Mid(b, y + 1), ">")
                                    End If
                                    If HFrom2 = "" Then HFrom2 = b
                                    Msg(idx).Sender = HFrom2
                                    'Check From Alias
                                    For i = 0 To FromAliasX
                                        y = InStr(FromAlias(i), " ") - 1: If y = -1 Then y = 0
                                        If InStr(1, b, Left(FromAlias(i), y - 1), vbTextCompare) <> 0 Then
                                            Msg(idx).Sender = Trim(Mid(FromAlias(i), y + 1))
                                            Exit For
                                        End If
                                    Next i
                                End If
                            Case "newsgroups": HNewsgroups = b
                            Case "cc": HCC = b
                            Case "bcc": HBcc = b
                            Case "date"
                                HDate = b
                                If FocusMail Then Msg(idx).DateHeader = ResolveDate(HDate)
                            Case "mime-version"
                                MIMEVersion = True
                            Case "content-type"
                                MIMEType = b
                                curseek = Seek(n)
                                If Not EOF(n) Then Line Input #n, c Else c = ""
                                If Left(c, 1) = " " Or Left(c, 1) = vbTab Then
                                    MIMEType = MIMEType + c
                                    lastseek = curseek
                                Else
                                    Seek #n, curseek
                                End If
                            Case "content-transfer-encoding"
                                MIMEEncoding = b
                            Case "content-disposition"
                                MIMEDisposition = b
                            End Select
                            If FullRead Then FullHdrs = FullHdrs + a + vbCrLf
                        Else
                            If FullRead Then
                                If Trim(a) <> "" Then
                                    FullHdrs = FullHdrs + a + vbCrLf
                                Else
                                    'Looks like text started
                                    a = ""
                                End If
                            End If
                        End If
                    End If
                    If EOF(n) Or a = "" Then Exit Do
                    lastseek = Seek(n)
                    Line Input #n, a
                Loop
                If FocusMail And Msg(idx).Kind = KindSent Then Msg(idx).Sender = "To: " + HTo
                If FullRead Then
                    'Set ShortHdrs
                    If HSubject <> "" Then ShortHdrs = "Subject: " + HSubject + vbCrLf
                    If HTo <> "" Then ShortHdrs = ShortHdrs + "To: " + HTo + vbCrLf
                    If HCC <> "" Then ShortHdrs = ShortHdrs + "CC: " + HCC + vbCrLf
                    If HBcc <> "" Then ShortHdrs = ShortHdrs + "Bcc: " + HBcc + vbCrLf
                    If HNewsgroups <> "" Then ShortHdrs = ShortHdrs + "Newsgroups: " + HNewsgroups + vbCrLf
                    If HDate <> "" Then
                        ShortHdrs = ShortHdrs + "Date: " + HDate + vbCrLf
                    End If
                    If HFrom <> "" Then ShortHdrs = ShortHdrs + "From: " + HFrom + vbCrLf
                End If
                If ext = "ML1" Then
                    If FocusMail Then Msg(idx).Kind = KindDecrypted
                Else
                    If (Msg(idx).Kind = 0 Or Msg(idx).Kind = KindNews) And FocusMail Then
                        If Msg(idx).Kind = 0 Then Msg(idx).Kind = KindPlain
                        lastseek = Seek(n)
                        For i = 1 To 15
                            If EOF(n) Then Exit For
                            Line Input #n, a
                            If a = BeginPGP Or a = BeginSig Then Msg(idx).Kind = KindPGP: Exit For
                        Next i
                        Seek #n, lastseek
                    End If
                End If
                'Detect Acksend
                If FocusMail And (Msg(idx).Kind = KindDecrypted Or Msg(idx).Kind = KindPlain) Then
                    lastseek = Seek(n)
                    For i = 1 To 5
                        If Not EOF(n) Then Line Input #n, a
                        If InStr(a, "under your pseudonym:") <> 0 Then
                            If InStr(1, a, "not remailed", vbTextCompare) = 0 Then c = "---Ack" Else c = "!!!NAK"
                            Do While Not EOF(n) And i < 20
                                Line Input #n, a
                                If Left(a, 4) = "To: " Then Msg(idx).Sender = "To: " + Mid(a, 5)
                                If Left(a, 9) = "Subject: " And c <> "" Then Msg(idx).Subject = c + ": " + Mid(a, 10): c = ""
                                i = i + 1
                            Loop
                            If c <> "" Then Msg(idx).Subject = c
                            Exit For
                        End If
                    Next i
                    Seek #n, lastseek
                End If
            End If
        ElseIf ext = "TXT" And FocusMail Then
            Msg(idx).Kind = KindText
            Msg(idx).Subject = "Text File: " + Msg(idx).Filename
        ElseIf FocusMail Then
            Msg(idx).Kind = KindFile
            Msg(idx).Subject = "File: " + Msg(idx).Filename
        End If
        If Msg(idx).DateHeader = 0 Then Msg(idx).DateHeader = Msg(idx).FileDate
        If Not FullRead And n <> 0 Then Close n: n = 0
        FileNum = n
    End If
Exit Sub
ErrorGetMsgInfo:
    ErrMsg = Error
    CloseFile n
    If idx <> -1 Then Msg(idx).Kind = KindUnknown
    MsgBox LMsg(525) + " " + ViewerCurBox + "\" + fmail + vbCr + vbCr + ErrMsg, vbCritical
    FileNum = -1
End Sub

Private Function UnQPHeader(hdr) As String
    Dim qph As String, h As String
    x = InStr(1, hdr, "=?ISO-8859-1?Q?", vbTextCompare)
    y = InStr(x + 15, hdr, "?=")
    If x * y <> 0 Then
        qph = Replace(Mid(hdr, x + 15, y - (x + 15)), "_", " ")
        While EncoderBusy: DoEvents: Wend
        EncoderBusy = True
        frmMain!NetCode1.EncodedData = qph
        frmMain!NetCode1.Format = 2 'f_QuotedPrintable
        frmMain!NetCode1.Action = 3  'a_DecodeToString
        h = Replace(Replace(Extract(frmMain!NetCode1.DecodedData, vbCr), Chr(0), ""), Chr(26), "")
        EncoderBusy = False
        If h <> "" Then
            UnQPHeader = Trim(Left(hdr, x - 1) + h + Mid(hdr, y + 2))
        Else
            UnQPHeader = hdr
        End If
    Else
        UnQPHeader = hdr
    End If
End Function

Private Sub WriteIndex(Box)
    On Error GoTo ErrorWrite
    If msgCount = 0 Then DelFile Box + "\JBN2Mail.IDX": Exit Sub
    'Count new
    For i = 0 To msgCount - 1
        If Msg(i).Filename <> "" And Msg(i).NewMsg Then NewCount = NewCount + 1
    Next i
    n = FreeFile
    Open Box + "\JBN2Mail.IDX" For Output As n
    Print #n, "JBN2_MAILINDEX"
    Print #n, UCase(Box)
    Print #n, NewCount
    Print #n, "" 'For future use
    Print #n, "Jack B. Nymble v2 Mail Index - DO NOT EDIT THIS FILE"
    Print #n, "This file contains non-essential data used to improve speed of access."
    Print #n, "If this file is deleted, Jack B. Nymble will rebuild it."
    Print #n, ""
    For i = 0 To msgCount - 1
        Print #n, Chr(4)
        Print #n, Msg(i).Filename
        Write #n, Msg(i).NewMsg
        Print #n, Msg(i).Kind
        Write #n, Msg(i).DateHeader
        Write #n, Msg(i).FileDate
        Print #n, Msg(i).Subject
        Print #n, Msg(i).Sender
        Print #n, Msg(i).Bytes
    Next i
    Close n: n = 0
Exit Sub
ErrorWrite:
    MsgBox LMsg(526) + vbCr + Error, vbCritical
    CloseFile n
End Sub

Private Sub mnuHome_Click()
    MailFolder = Cnf(4, 0)
    ViewerCurBox = MailFolder + "\Inbox"
    ReadFolders MailFolder, 0, True
End Sub

Private Sub mnuChangeDrik_Click()
    d = SelectFolder(MailFolder, LMsg(527), PData(157))
    If d = "" Then Exit Sub
    If CreateDir(d) Then
        MailFolder = NoSlash(d)
        ViewerCurBox = MailFolder + "\Inbox"
        ReadFolders MailFolder, 0, True
    End If
End Sub

Private Sub mnuExplore_Click()
    On Error Resume Next
    Shell "EXPLORER.EXE /n,/e," + ViewerCurBox, vbNormalFocus
End Sub

Private Function ReadFolders(pth As String, parentnode As Integer, Optional ResetList As Boolean) As Boolean
    Dim nod As Node
    Dim dirs() As String, dirmax As Integer, dircount As Integer
    
    On Error GoTo ErrorReadFolders
    If parentnode = 0 Then
        trvFolder.Nodes.Clear
        'Clear Move Menu
        MoveMenuCount = 0
        For i = 1 To 14
            mnuMove(i).Visible = False
        Next i
        'Valid MailFolder
        If Not CreateDir(pth) Then
            ResetList = True
            If LCase(pth) = LCase(Cnf(4, 0)) Then Unload Me: Exit Function
            pth = Cnf(4, 0)
            If Not CreateDir(pth) Then Unload Me: Exit Function
            ViewerCurBox = pth + "\Inbox"
        End If
        MailFolder = pth
    End If
StartRead:
    dircount = 0: dirmax = 10
    ReDim dirs(dirmax)
    a = Dir(pth + "\*.*", vbDirectory)
    While a <> "" And dircount < 32000
        If IsDir(pth + "\" + a) And a <> "." And a <> ".." Then
            If dircount > dirmax Then dirmax = dirmax + 10: ReDim Preserve dirs(dirmax)
            dirs(dircount) = a
            dircount = dircount + 1
        End If
        a = Dir
    Wend
    If parentnode = 0 Then
        'Valid ViewerCurBox
        If Not IsDir(ViewerCurBox) Then
            ResetList = True
            If dircount = 0 Then
                If Not CreateDir(ViewerCurBox) Then
                    Unload Me: Exit Function
                Else: GoTo StartRead
                End If
            Else
                ViewerCurBox = pth + "\" + dirs(0)
            End If
        End If
    End If
    For i = 0 To dircount - 1
        'New Messages in this folder?
        NewMsgs = False
        On Error Resume Next
        f = pth + "\" + dirs(i) + "\" + "JBN2NEW.IDX"
        If SDir(f) <> "" Then
            n = FreeFile
            Open f For Input As n
            Do While Not EOF(n)
                Line Input #n, a
                If a <> "" Then
                    If SDir(a) <> "" Then NewMsgs = True: Exit Do
                End If
            Loop
            Close n: n = 0
        End If
        If Not NewMsgs Then
            f = pth + "\" + dirs(i) + "\" + "JBN2MAIL.IDX"
            If SDir(f) <> "" Then
                n = FreeFile
                Open f For Input As n
                If Not EOF(n) Then Line Input #n, a Else a = ""
                If a = "JBN2_MAILINDEX" Then
                    If Not EOF(n) Then Line Input #n, a Else a = ""
                    If Not EOF(n) Then Line Input #n, a Else a = ""
                    NewMsgs = SVal(a) <> 0
                End If
                Close n: n = 0
            End If
        End If
        On Error GoTo ErrorReadFolders
        'Add Node
        If parentnode = 0 Then
            'Add Root Node
            Set nod = trvFolder.Nodes.Add(, , UCase(pth + "\" + dirs(i)), dirs(i))
            'Add Move Menu
            If MoveMenuCount < 15 Then
                a = Left(dirs(i), 30)
                'Find insertion point
                For j = 0 To MoveMenuCount
                    If "&" + a < mnuMove(j).Caption Or j = MoveMenuCount Then
                        'Expand
                        For k = MoveMenuCount To j + 1 Step -1
                            mnuMove(k).Caption = mnuMove(k - 1).Caption
                        Next k
                        'Insert
                        mnuMove(j).Caption = "&" + a
                        mnuMove(MoveMenuCount).Visible = True
                        MoveMenuCount = MoveMenuCount + 1
                        Exit For
                    End If
                Next j
            End If
        Else
            Set nod = trvFolder.Nodes.Add(parentnode, tvwChild, UCase(pth + "\" + dirs(i)), dirs(i))
        End If
        nod.Sorted = True
        nod.Expanded = False
        nod.Tag = NewMsgs
        If UCase(pth + "\" + dirs(i)) = UCase(ViewerCurBox) Then
            If NewMsgs Then nod.Image = "FoldOpenFlag" Else nod.Image = "FoldOpen"
        ElseIf NewMsgs Then
            nod.Image = "FoldClosedFlag"
        Else
            nod.Image = "FoldClosed"
        End If
        ReadFolders pth + "\" + dirs(i), nod.Index
    Next i
    If parentnode = 0 Then
        trvFolder.Nodes(UCase(ViewerCurBox)).Selected = True
        'Add Reply Folder TBKs
        cboReply.Clear
        a = SDir(Cnf(4, 1) + "\*.TBK")
        While a <> ""
            cboReply.AddItem a
            a = Dir
        Wend
        cboReply.AddItem "-- Cancel --", cboReply.ListCount
        'Reset
        If ResetList Then UpdateList True Else UpdateList False
        ReadFolders = ResetList
    End If
Exit Function
ErrorReadFolders:
    MsgBox LMsg(537) + vbCr + Error, vbCritical
    CloseFile n
    Unload Me
End Function

Private Sub LoadList(Job As String)
    If BookX = -1 Then Exit Sub
    If Job = "Fonts" Or Job = "" Then
        On Error Resume Next
        rtbView.Font.Name = Cnf(2, 25)
        rtbView.Font.Size = Val(Cnf(2, 26))
        rtbView.Font.Bold = (Cnf(2, 27) = True2)
        x = SVal(Cnf(0, 5)) + 8
        lstMail.Font.Size = x
        lstMail.Font.Bold = True
        lstAttach.Font.Size = x
        lstAttach.Font.Bold = True
        trvFolder.Font.Size = x
        trvFolder.Font.Bold = True
        cboReply.Font.Size = x
    End If
End Sub

Private Sub mnuViewChoice_Click(Index As Integer)
    If Index < 2 Then
        If mnuViewChoice(2).Checked Or Not mnuViewChoice(Index).Checked Then x = Index Else x = Abs(Index - 1)
        mnuViewChoice(x).Checked = True
        mnuViewChoice(Abs(x - 1)).Checked = Not mnuViewChoice(x).Checked
        PData(160) = mnuViewChoice(0).Checked
        mnuViewChoice(2).Checked = False
    Else
        If mnuViewChoice(2).Checked Then
            mnuViewChoice(0).Checked = PData(160) <> False2
            mnuViewChoice(1).Checked = Not mnuViewChoice(0).Checked
        Else
            mnuViewChoice(0).Checked = False
            mnuViewChoice(1).Checked = False
        End If
        mnuViewChoice(2).Checked = Not mnuViewChoice(2).Checked
    End If
    Form_Resize
End Sub

Private Sub rtbView_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        PopupMenu mnuEdit
    Else
        ViewSelStart = rtbView.SelStart
        ViewSelLength = rtbView.SelLength
    End If
End Sub

Private Sub rtbView_DblClick()
    mnuViewChoice_Click (2)
    rtbView_GotFocus
    ViewDblClick = True
End Sub

Private Sub rtbView_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    If ViewDblClick Then
        rtbView.SelStart = ViewSelStart
        rtbView.SelLength = ViewSelLength
        ViewDblClick = False
    End If
End Sub

Private Sub Form_Resize()
    Dim x As Long
    If Me.WindowState = 1 Or NoClick Then Exit Sub
    If Me.Height < 4476 Then NoClick = True: Me.Height = 4476: NoClick = False
    If Me.Width < 5388 Then NoClick = True: Me.Width = 5388: NoClick = False
    sh = Me.ScaleHeight     '6924
    sw = Me.ScaleWidth      '8556
    viewmode = 0
    If mnuViewChoice(2).Checked Then
        'Full Text
        fraMessage.Top = 0
    ElseIf mnuViewChoice(0).Checked Then
        'Short List
        x = sh * 0.2484157
        If x < 1568 Then x = 1568
        trvFolder.Height = x
        fraMessage.Top = trvFolder.Height + 12
    Else
        'Long List
        x = sh * 0.41
        If x < 1568 Then x = 1568
        trvFolder.Height = x
        fraMessage.Top = trvFolder.Height + 12
    End If
    lstMail.Height = trvFolder.Height
    lstMail.Width = sw - 2184
    fraMessage.Height = sh - fraMessage.Top - 320
    fraMessage.Width = sw
    For i = 0 To 2
        lblStat(i).Top = sh - 300
    Next i
    x = sw - lblStat(2).Width - 4 * 24
    lblStat(0).Width = x * 0.7 '0.6
    lblStat(2).Left = sw - 756
    lblStat(1).Left = lblStat(0).Left + lblStat(0).Width + 24
    lblStat(1).Width = lblStat(2).Left - lblStat(1).Left - 2 * 24
    'Size fraMessage
    fh = fraMessage.Height  '4932
    fw = fraMessage.Width   '8568
    tabView.Height = fh - 60
    tabView.Width = fw - 38
    For i = 0 To 1
        fraView(i).Height = fh - 480
        fraView(i).Width = fw - 136
    Next i
    tabView.TabFixedWidth = fw * 0.1785714
    cmdTrash(0).Left = fw - 2152
    cmdTrash(1).Left = cmdTrash(0).Left + 540
    cmdNavigate(0).Left = cmdTrash(1).Left + 540
    cmdNavigate(1).Left = cmdNavigate(0).Left + 540
    'Size fraView
    fh = fraView(0).Height   '4452
    fw = fraView(0).Width    '8432
    rtbView.Height = fh - 300
    rtbView.Width = fw
    x = fw - 5084
    If x < 0 Then x = 0
    chkView(0).Left = x
    chkView(1).Left = x + 1380
    lblReply.Left = fw - 2852
    cboReply.Left = fw - 1652
    cmdOpenBook.Left = fw - 1592
    lstAttach.Height = fh - 1164
    lstAttach.Width = fw - 200
    lblAttach(0).Top = fh - 972
    lblAttach(1).Top = fh - 792
    lblAttach(0).Width = fw - 320
    lblAttach(1).Width = fw - 320
    cmdAttach(0).Top = fh - 492
    cmdAttach(1).Top = fh - 492
    x = fw * 0.0858634
    cmdAttach(0).Left = fw / 2 - x - cmdAttach(0).Width
    cmdAttach(1).Left = fw / 2 + x
    On Error Resume Next
    For i = 1 To 4
        Select Case i
        Case 1: x = 0.026642 * lstAttach.Width
        Case 2: x = 0.023966 * lstAttach.Width
        Case 3: x = 0.015085 * lstAttach.Width
        Case 4: x = 0.016788 * lstAttach.Width
        End Select
        'Required to correct bug in ListView columnheaders.width property
        'MSKB Article ID: Q179988
        SendMessage lstAttach.hwnd, LVM_SETCOLUMNWIDTH, i - 1, x
    Next i
End Sub

Private Sub Form_Load()
    Dim i As Long
    ViewerLoaded = True
    Randomize Timer
    TextStart = 1
    MailListIndex = 0
    FromAliasX = -1
    On Error GoTo ErrorLoad
    'Window Position and Size
    Me.Left = Val(PData(161))
    Me.Top = Val(PData(162))
    If Val(PData(163)) <> 0 And Val(PData(164)) <> 0 Then
        Me.Width = Val(PData(163))
        Me.Height = Val(PData(164))
    End If
    If Val(PData(165)) <> 1 Then Me.WindowState = Val(PData(165))
    mnuDec(4).Checked = PData(169) = True2
    trvFolder.ImageList = frmMain!ImageList1
    lstMail.SmallIcons = frmMain!ImageList1
    lstMail.ColumnHeaders.Add , , "      Subject", 100, 0
    lstMail.ColumnHeaders.Add , , "Sender", 100, 0
    lstMail.ColumnHeaders.Add , , "Sent", 100, 0
    lstMail.ColumnHeaders.Add , , "Recd", 100, 0
    lstMail.ColumnHeaders.Add , , "K", 100, 0
    lstMail.ColumnHeaders.Add , , "Priority-D", 0
    lstMail.ColumnHeaders.Add , , "Priority-R", 0
    lstMail.ColumnHeaders.Add , , "Priority-S", 0
    lstMail.ColumnHeaders.Item(1).Key = "      Subject"
    lstMail.ColumnHeaders.Item(2).Key = "Sender"
    lstMail.ColumnHeaders.Item(3).Key = "Sent"
    lstMail.ColumnHeaders.Item(4).Key = "Recd"
    lstMail.ColumnHeaders.Item(5).Key = "K"
    On Error Resume Next
    'lstMail Widths
    For i = 1 To 5
        'Required to correct bug in ListView columnheaders.width property
        'MSKB Article ID: Q179988
        If Val(PData(147 + i - 1)) <> 0 Then SendMessage lstMail.hwnd, LVM_SETCOLUMNWIDTH, i - 1, Val(PData(147 + i - 1))
    Next i
    'lstMail Sorting
    lstMail.SortKey = Val(PData(153))
    lstMail.SortOrder = Val(PData(154))
    x = lstMail.SortKey: If x > 4 Then x = x - 3
    If lstMail.SortOrder = lvwAscending Then a = "+" Else a = "-"
    lstMail.ColumnHeaders.Item(x + 1).Text = lstMail.ColumnHeaders.Item(x + 1).Text + a
    On Error GoTo ErrorLoad
    lstAttach.ColumnHeaders.Add , , "Filename"
    lstAttach.ColumnHeaders.Add , , "Content Type"
    lstAttach.ColumnHeaders.Add , , "Encoding"
    lstAttach.ColumnHeaders.Add , , "Encoded Size (k)"
    mnuViewChoice(0).Checked = PData(160) <> False2
    mnuViewChoice(1).Checked = Not mnuViewChoice(0).Checked
    LoadList ""
    If NewMessages <> 0 Then
        NewMessages = 0
        If InStr(StatMain, LMsg(456)) <> 0 Then StatMain = ""
        Stat StatMain, StatDec
    End If
    mnuHome_Click
Exit Sub
ErrorLoad:
    MsgBox Error, vbCritical
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Dim i As Long
    ViewerLoaded = False
    EsubPass = String(Len(EsubPass), "@")
    WriteIndex (ViewerCurBox)
    On Error Resume Next
    'lstMail Column Widths
    For i = 1 To 5
        'Required to correct bug in ListView columnheaders.width property
        'MSKB Article ID: Q179988
        PData(147 + i - 1) = Str(SendMessage(lstMail.hwnd, LVM_GETCOLUMNWIDTH, i - 1, 0))
    Next i
    'lstMail Sorting
    PData(153) = Str(lstMail.SortKey)
    PData(154) = Str(lstMail.SortOrder)
    If Me.WindowState = 0 Then
        PData(161) = Str(Me.Left)
        PData(162) = Str(Me.Top)
        PData(163) = Str(Me.Width)
        PData(164) = Str(Me.Height)
    End If
    PData(165) = Str(Me.WindowState)
End Sub

