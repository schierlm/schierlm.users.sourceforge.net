VERSION 5.00
Begin VB.Form frmFolder 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Select Folder"
   ClientHeight    =   4230
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   7080
   Icon            =   "Folder.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4230
   ScaleWidth      =   7080
   Begin VB.FileListBox filFolder 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3510
      Hidden          =   -1  'True
      Left            =   3300
      MousePointer    =   2  'Kreuz
      System          =   -1  'True
      TabIndex        =   6
      Top             =   210
      Width           =   1812
   End
   Begin VB.CommandButton cmdFolder 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   492
      Index           =   1
      Left            =   5220
      TabIndex        =   4
      Top             =   3180
      Width           =   1752
   End
   Begin VB.CommandButton cmdFolder 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   492
      Index           =   0
      Left            =   5220
      TabIndex        =   3
      Top             =   2520
      Width           =   1752
   End
   Begin VB.ComboBox cboFolder 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   288
      Left            =   120
      TabIndex        =   0
      Top             =   3840
      Width           =   6852
   End
   Begin VB.DriveListBox drvFolder 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   288
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   3132
   End
   Begin VB.DirListBox dirFolder 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3312
      Left            =   120
      TabIndex        =   2
      Top             =   420
      Width           =   3132
   End
   Begin VB.Label lblFolder 
      Alignment       =   2  'Zentriert
      Caption         =   "Please select a destination folder."
      Height          =   2172
      Left            =   5160
      TabIndex        =   5
      Top             =   240
      Width           =   1812
   End
End
Attribute VB_Name = "frmFolder"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim ClickTimer As Double, ClickLast As Long, NoClick As Boolean

Private Sub cmdFolder_Click(Index As Integer)
    If Index = 0 Then
        If Not CreateDir(cboFolder.Text) Then Exit Sub
    Else
        cboFolder.Text = ""
    End If
    Me.Hide
End Sub

Private Sub dirFolder_Change()
    cboFolder.Text = dirFolder.Path
    cboFolder.SelStart = 0
    cboFolder.SelLength = Len(cboFolder.Text)
    filFolder.Path = dirFolder.Path
    cboFolder.SetFocus
End Sub

Private Sub dirFolder_Click()
    dirFolder.Path = dirFolder.List(dirFolder.ListIndex)
End Sub

Private Sub cboFolder_Click()
    On Error Resume Next
    If Mid(cboFolder.Text, 2, 1) = ":" Then
        NoClick = True
        drvFolder.Drive = Left(cboFolder.Text, 1)
        NoClick = False
    End If
    
    r = cboFolder.Text
    If Not IsDir(r) And r <> "" Then
        If IsDir(NoSlash(dirFolder.Path) + "\" + r) Then r = NoSlash(dirFolder.Path) + "\" + r
    End If
    If Left(r, 1) = "\" Then r = Left(dirFolder.Path, 2) + r
    If IsDir(r) Then dirFolder.Path = r Else dirFolder.Path = Left(drvFolder.Drive, 1) + ":\"
End Sub

Private Sub cboFolder_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        a = LCase(dirFolder.Path)
        b = LCase(cboFolder.Text)
        cboFolder_Click
        dirFolder_Change
        If LCase(cboFolder.Text) = a And a = b Then cmdFolder_Click (0)
        KeyAscii = 0
    End If
End Sub

Private Sub dirFolder_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Timer - ClickTimer < 0.4 And ClickLast = dirFolder.ListIndex Then cmdFolder_Click (0)
    ClickTimer = Timer
    ClickLast = dirFolder.ListIndex
End Sub

Private Sub drvFolder_Change()
    If NoClick Then Exit Sub
    If LCase(drvFolder.Drive) = LCase(Left(CurDir, 1)) Then
        dirFolder.Path = CurDir
    Else
        dirFolder.Path = Left(drvFolder.Drive, 1) + ":\"
    End If
End Sub

Private Sub filFolder_Click()
    filFolder.ListIndex = -1
End Sub

Private Sub Form_Activate()
    cboFolder_Click
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(110))
    Me.Top = Val(PData(111))
    On Error Resume Next
    x = SVal(Cnf(0, 5)) + 8
    dirFolder.FontSize = x
    filFolder.FontSize = x
    drvFolder.FontSize = x
    cboFolder.FontSize = x
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PData(110) = Str(Me.Left)
    PData(111) = Str(Me.Top)
End Sub
