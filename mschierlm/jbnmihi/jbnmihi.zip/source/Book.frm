VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "RICHTX32.OCX"
Begin VB.Form frmBook 
   Caption         =   "Book"
   ClientHeight    =   7470
   ClientLeft      =   45
   ClientTop       =   645
   ClientWidth     =   9090
   Icon            =   "Book.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   7470
   ScaleWidth      =   9090
   Begin VB.Timer tmrReload 
      Enabled         =   0   'False
      Interval        =   200
      Left            =   2580
      Top             =   7080
   End
   Begin VB.CheckBox chkQue 
      Caption         =   "Prev&iew"
      Height          =   312
      Index           =   2
      Left            =   7740
      Style           =   1  'Grafisch
      TabIndex        =   68
      Top             =   7140
      Width           =   1212
   End
   Begin VB.CheckBox chkQue 
      Caption         =   "Re&play"
      Height          =   312
      Index           =   1
      Left            =   6480
      Style           =   1  'Grafisch
      TabIndex        =   67
      Top             =   7140
      Width           =   1212
   End
   Begin VB.CheckBox chkQue 
      Caption         =   "&Queue"
      Height          =   312
      Index           =   0
      Left            =   5220
      Style           =   1  'Grafisch
      TabIndex        =   66
      Top             =   7140
      Width           =   1212
   End
   Begin VB.Frame fraRemEdit 
      Caption         =   "[Cracker]  (3)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3072
      Left            =   10000
      TabIndex        =   47
      Top             =   3960
      Visible         =   0   'False
      Width           =   8952
      Begin VB.TextBox txtRemEdit 
         BackColor       =   &H00808000&
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   288
         Left            =   60
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   72
         Text            =   "Book.frx":0442
         Top             =   240
         Width           =   8844
      End
      Begin VB.TextBox txtCaps 
         Alignment       =   2  'Zentriert
         BackColor       =   &H00808000&
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   2412
         Left            =   60
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   69
         Text            =   "Book.frx":046D
         Top             =   600
         Width           =   1992
      End
      Begin VB.CommandButton cmdRemEdit 
         Caption         =   "Set as Default"
         Height          =   372
         Index           =   2
         Left            =   7440
         TabIndex        =   57
         Top             =   2640
         Width           =   1392
      End
      Begin VB.ComboBox cboGarbage 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         ItemData        =   "Book.frx":04B4
         Left            =   7560
         List            =   "Book.frx":0500
         TabIndex        =   53
         Top             =   960
         Width           =   1032
      End
      Begin VB.CommandButton cmdRemEdit 
         Caption         =   "Cancel"
         Height          =   372
         Index           =   1
         Left            =   7440
         TabIndex        =   51
         Top             =   2220
         Width           =   1392
      End
      Begin VB.CommandButton cmdRemEdit 
         Caption         =   "OK"
         Height          =   372
         Index           =   0
         Left            =   7440
         TabIndex        =   50
         Top             =   1800
         Width           =   1392
      End
      Begin VB.ComboBox cboHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   2100
         TabIndex        =   49
         Top             =   2720
         Width           =   4992
      End
      Begin VB.TextBox txtHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2412
         Index           =   2
         Left            =   2100
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   48
         Text            =   "Book.frx":0570
         Top             =   600
         Width           =   5232
      End
      Begin VB.Label lblGarbage 
         Caption         =   "Garbage:"
         Height          =   252
         Left            =   7560
         TabIndex        =   52
         Top             =   720
         Width           =   1152
      End
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   1560
      Top             =   6960
      _ExtentX        =   688
      _ExtentY        =   688
      _Version        =   393216
   End
   Begin VB.Frame fraBook 
      BorderStyle     =   0  'Kein
      Caption         =   "Message"
      Height          =   6732
      Index           =   0
      Left            =   60
      TabIndex        =   0
      Top             =   300
      Width           =   8952
      Begin RichTextLib.RichTextBox rtbMessage 
         Height          =   2652
         Left            =   0
         TabIndex        =   54
         Top             =   3720
         Width           =   8952
         _ExtentX        =   15796
         _ExtentY        =   4683
         _Version        =   393217
         Enabled         =   -1  'True
         ScrollBars      =   2
         TextRTF         =   $"Book.frx":0600
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.TextBox txtMessage 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2652
         Left            =   0
         MaxLength       =   31035
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   22
         Top             =   3720
         Visible         =   0   'False
         Width           =   8952
      End
      Begin VB.CommandButton cmdRemailer 
         Caption         =   "&Add"
         Height          =   312
         Index           =   0
         Left            =   6120
         TabIndex        =   71
         Top             =   2280
         Width           =   912
      End
      Begin VB.ComboBox cboRemailer 
         BackColor       =   &H00808000&
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   288
         Left            =   0
         TabIndex        =   15
         Top             =   2280
         Width           =   4932
      End
      Begin VB.CommandButton cmdStar 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   8640
         TabIndex        =   29
         Top             =   6420
         Width           =   312
      End
      Begin VB.CommandButton cmdStar 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   4260
         TabIndex        =   28
         Top             =   6420
         Width           =   312
      End
      Begin VB.ComboBox cboEncrypt 
         Height          =   288
         Index           =   1
         Left            =   5100
         Sorted          =   -1  'True
         TabIndex        =   24
         Top             =   6420
         Width           =   3552
      End
      Begin VB.ComboBox cboEncrypt 
         Height          =   288
         Index           =   0
         Left            =   660
         Sorted          =   -1  'True
         TabIndex        =   23
         Top             =   6420
         Width           =   3612
      End
      Begin VB.ListBox lstRemailers 
         BackColor       =   &H00808000&
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   960
         ItemData        =   "Book.frx":06D5
         Left            =   0
         List            =   "Book.frx":06D7
         TabIndex        =   21
         Top             =   2640
         Width           =   8952
      End
      Begin VB.ComboBox cboLatent 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         ItemData        =   "Book.frx":06D9
         Left            =   4980
         List            =   "Book.frx":06FE
         TabIndex        =   19
         Top             =   2280
         Width           =   1092
      End
      Begin VB.CommandButton cmdRemailer 
         Caption         =   "&Clear"
         Height          =   312
         Index           =   2
         Left            =   8040
         TabIndex        =   18
         Top             =   2280
         Width           =   912
      End
      Begin VB.CommandButton cmdRemailer 
         Caption         =   "Remo&ve"
         Height          =   312
         Index           =   1
         Left            =   7080
         TabIndex        =   17
         Top             =   2280
         Width           =   912
      End
      Begin VB.CommandButton cmdTo 
         Caption         =   "Bcc:"
         Height          =   288
         Index           =   2
         Left            =   4560
         TabIndex        =   14
         Top             =   780
         Width           =   492
      End
      Begin VB.CommandButton cmdTo 
         Caption         =   "To:"
         Height          =   312
         Index           =   0
         Left            =   0
         TabIndex        =   12
         Top             =   60
         Width           =   552
      End
      Begin VB.ComboBox cboHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         ItemData        =   "Book.frx":075A
         Left            =   0
         List            =   "Book.frx":076D
         TabIndex        =   11
         Top             =   1800
         Width           =   8712
      End
      Begin VB.TextBox txtHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   948
         HideSelection   =   0   'False
         Index           =   0
         Left            =   0
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   10
         Top             =   1140
         Width           =   8952
      End
      Begin VB.CommandButton cmdTo 
         Caption         =   "CC:"
         Height          =   288
         Index           =   1
         Left            =   4560
         TabIndex        =   9
         Top             =   420
         Width           =   492
      End
      Begin VB.ComboBox cboTo 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   5100
         TabIndex        =   6
         Top             =   780
         Width           =   3852
      End
      Begin VB.ComboBox cboTo 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   5100
         TabIndex        =   5
         Top             =   420
         Width           =   3852
      End
      Begin VB.ComboBox cboNC 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         ItemData        =   "Book.frx":07DC
         Left            =   6900
         List            =   "Book.frx":07F8
         TabIndex        =   4
         Top             =   60
         Width           =   2052
      End
      Begin VB.ComboBox cboNym 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   600
         TabIndex        =   2
         Top             =   420
         Width           =   3912
      End
      Begin VB.ComboBox cboTo 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   600
         TabIndex        =   1
         Top             =   60
         Width           =   5892
      End
      Begin VB.TextBox txtSubject 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   600
         TabIndex        =   3
         Top             =   780
         Width           =   3912
      End
      Begin VB.Label lblAttach 
         Caption         =   "Attachments: "
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   -1  'True
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Left            =   4560
         TabIndex        =   70
         Top             =   2100
         Width           =   1332
      End
      Begin VB.Label lblSign 
         Caption         =   "Sign:"
         Height          =   192
         Left            =   4680
         TabIndex        =   26
         Top             =   6480
         Width           =   792
      End
      Begin VB.Label lblEncrypt 
         Caption         =   "Encrypt:"
         Height          =   192
         Left            =   0
         TabIndex        =   25
         Top             =   6480
         Width           =   732
      End
      Begin VB.Label lblChains 
         Caption         =   "Chains: 0"
         Height          =   192
         Left            =   2340
         TabIndex        =   20
         Top             =   2100
         Width           =   1332
      End
      Begin VB.Label lblAddRemailer 
         Caption         =   "Add Remailer:"
         Height          =   192
         Left            =   60
         TabIndex        =   16
         Top             =   2100
         Width           =   1332
      End
      Begin VB.Label Label3 
         Caption         =   "Subject:"
         Height          =   192
         Left            =   0
         TabIndex        =   13
         Top             =   840
         Width           =   912
      End
      Begin VB.Label lblNC 
         Caption         =   "N-C:"
         Height          =   192
         Left            =   6540
         TabIndex        =   8
         Top             =   120
         Width           =   612
      End
      Begin VB.Label Label2 
         Caption         =   "Nym:"
         Height          =   192
         Left            =   96
         TabIndex        =   7
         Top             =   480
         Width           =   612
      End
   End
   Begin VB.Frame fraBook 
      BorderStyle     =   0  'Kein
      Height          =   6732
      Index           =   1
      Left            =   60
      TabIndex        =   31
      Top             =   300
      Visible         =   0   'False
      Width           =   8952
      Begin VB.ComboBox cboArcType 
         Height          =   288
         ItemData        =   "Book.frx":0876
         Left            =   60
         List            =   "Book.frx":088F
         Style           =   2  'Dropdown-Liste
         TabIndex        =   73
         Top             =   360
         Width           =   4272
      End
      Begin VB.CommandButton cmdAttach 
         Caption         =   "&Set"
         Height          =   312
         Index           =   1
         Left            =   5460
         TabIndex        =   65
         TabStop         =   0   'False
         Top             =   1320
         Width           =   612
      End
      Begin VB.ComboBox cboEncode 
         Height          =   288
         ItemData        =   "Book.frx":0959
         Left            =   3480
         List            =   "Book.frx":0978
         Style           =   2  'Dropdown-Liste
         TabIndex        =   64
         Top             =   1320
         Width           =   1332
      End
      Begin VB.TextBox txtSplit 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   6960
         MaxLength       =   8
         TabIndex        =   62
         Top             =   2760
         Width           =   852
      End
      Begin VB.CheckBox chkSplit 
         Caption         =   "Split message if larger than"
         Height          =   312
         Left            =   4500
         TabIndex        =   61
         Top             =   2760
         Width           =   2412
      End
      Begin VB.CheckBox chkEncrypt 
         Caption         =   "Sign Attachments"
         Height          =   312
         Index           =   1
         Left            =   2280
         Style           =   1  'Grafisch
         TabIndex        =   60
         Top             =   2700
         Width           =   1932
      End
      Begin VB.CheckBox chkEncrypt 
         Caption         =   "Encrypt Attachments"
         Height          =   312
         Index           =   0
         Left            =   120
         Style           =   1  'Grafisch
         TabIndex        =   59
         Top             =   2700
         Width           =   1932
      End
      Begin VB.ComboBox cboHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         ItemData        =   "Book.frx":09D8
         Left            =   60
         List            =   "Book.frx":09EB
         TabIndex        =   58
         Top             =   6430
         Width           =   8605
      End
      Begin VB.ComboBox cboArchive 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   60
         Sorted          =   -1  'True
         TabIndex        =   55
         Top             =   660
         Width           =   4272
      End
      Begin VB.TextBox txtArchive 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   60
         TabIndex        =   56
         Top             =   660
         Width           =   4272
      End
      Begin VB.TextBox txtWork 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   5904
         MaxLength       =   7
         TabIndex        =   46
         Top             =   600
         Width           =   2052
      End
      Begin VB.CommandButton cmdBrowse 
         Caption         =   "Browse"
         Height          =   288
         Index           =   0
         Left            =   4344
         TabIndex        =   42
         Top             =   660
         Width           =   732
      End
      Begin VB.CommandButton cmdAttach 
         Caption         =   "&Add"
         Height          =   312
         Index           =   0
         Left            =   4860
         TabIndex        =   41
         TabStop         =   0   'False
         Top             =   1320
         Width           =   612
      End
      Begin VB.CommandButton cmdAttach 
         Caption         =   "Re&move"
         Height          =   312
         Index           =   2
         Left            =   6120
         TabIndex        =   40
         TabStop         =   0   'False
         Top             =   1320
         Width           =   852
      End
      Begin VB.CommandButton cmdAttach 
         Caption         =   "&Clear"
         Height          =   312
         Index           =   3
         Left            =   7020
         TabIndex        =   39
         TabStop         =   0   'False
         Top             =   1320
         Width           =   852
      End
      Begin VB.CommandButton cmdBrowse 
         Caption         =   "*"
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   252
         Index           =   1
         Left            =   3180
         TabIndex        =   37
         Top             =   1356
         Width           =   252
      End
      Begin VB.TextBox txtAttach 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   60
         TabIndex        =   36
         Top             =   1332
         Width           =   3132
      End
      Begin VB.ListBox lstAttach 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   960
         ItemData        =   "Book.frx":0A5A
         Left            =   60
         List            =   "Book.frx":0A5C
         TabIndex        =   34
         TabStop         =   0   'False
         Top             =   1680
         Width           =   8832
      End
      Begin VB.TextBox txtHeaders 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3312
         Index           =   1
         Left            =   60
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   33
         Top             =   3420
         Width           =   8832
      End
      Begin VB.CommandButton cmdHeaderClear 
         Caption         =   "Clear"
         Height          =   252
         Left            =   5880
         TabIndex        =   32
         TabStop         =   0   'False
         Top             =   3180
         Width           =   1452
      End
      Begin VB.Label Label1 
         BackStyle       =   0  'Transparent
         Caption         =   "bytes"
         Height          =   252
         Left            =   7860
         TabIndex        =   63
         Top             =   2820
         Width           =   852
      End
      Begin VB.Label lblWorkSet 
         BackStyle       =   0  'Transparent
         Caption         =   "Work Settings:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   252
         Left            =   5910
         TabIndex        =   45
         Top             =   120
         Width           =   2232
      End
      Begin VB.Label Label9 
         BackStyle       =   0  'Transparent
         Caption         =   "Message Archive:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   252
         Left            =   96
         TabIndex        =   44
         Top             =   120
         Width           =   2832
      End
      Begin VB.Label lblWork 
         BackStyle       =   0  'Transparent
         Caption         =   "Work Folder: [Optional]"
         Height          =   192
         Left            =   5910
         TabIndex        =   43
         Top             =   360
         Width           =   2292
      End
      Begin VB.Label Label14 
         BackStyle       =   0  'Transparent
         Caption         =   "Attachments:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   252
         Left            =   96
         TabIndex        =   38
         Top             =   1080
         Width           =   1992
      End
      Begin VB.Label Label29 
         BackStyle       =   0  'Transparent
         Caption         =   "Headers:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   252
         Left            =   96
         TabIndex        =   35
         Top             =   3192
         Width           =   972
      End
   End
   Begin ComctlLib.TabStrip tabBook 
      Height          =   7092
      Left            =   0
      TabIndex        =   27
      Top             =   0
      Width           =   9072
      _ExtentX        =   16007
      _ExtentY        =   12515
      TabWidthStyle   =   2
      TabFixedWidth   =   5292
      TabFixedHeight  =   441
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   3
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Me&ssage"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "E&xtra"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "F&ull Text"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin VB.Label lblStat 
      BorderStyle     =   1  'Fest Einfach
      Caption         =   "Status"
      Height          =   288
      Left            =   60
      TabIndex        =   30
      Top             =   7140
      Width           =   5112
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuDisk 
         Caption         =   "&Open"
         Index           =   0
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Re-Open"
         Index           =   1
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Save"
         Index           =   2
         Shortcut        =   ^S
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "Save &As..."
         Index           =   3
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "Save As Te&mplate..."
         Index           =   4
      End
      Begin VB.Menu mnuDisk 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuDisk 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "-"
         Index           =   7
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "Na&me As..."
         Index           =   8
         Shortcut        =   +{F5}
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "A&uto-Name"
         Index           =   9
         Shortcut        =   +{F6}
      End
      Begin VB.Menu mnuDisk 
         Caption         =   ""
         Index           =   10
         Visible         =   0   'False
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "-"
         Index           =   11
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Load Text File"
         Index           =   12
         Shortcut        =   ^O
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Insert Text File"
         Index           =   13
         Shortcut        =   ^N
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "Save Te&xt As..."
         Index           =   14
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Print Text"
         Index           =   15
         Shortcut        =   ^P
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "-"
         Index           =   16
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "&Close"
         Index           =   17
      End
      Begin VB.Menu mnuDisk 
         Caption         =   "Sav&e and Close"
         Index           =   18
      End
   End
   Begin VB.Menu mnuEdit 
      Caption         =   "&Edit"
      Begin VB.Menu mnuEditArray 
         Caption         =   "Und&o     [Ctrl+Z]"
         Index           =   0
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "&Copy     [Ctrl+C]"
         Index           =   1
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "Copy Appen&d"
         Index           =   2
         Shortcut        =   ^D
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "Cu&t     [Ctrl+X]"
         Index           =   3
      End
      Begin VB.Menu mnuEditArray 
         Caption         =   "&Paste     [Ctrl+V]"
         Index           =   4
      End
      Begin VB.Menu mnuPasteQuote 
         Caption         =   "Paste As &Quote"
         Shortcut        =   ^Q
      End
      Begin VB.Menu mnuPasteSig 
         Caption         =   "Paste Signat&ure"
         Shortcut        =   ^H
      End
      Begin VB.Menu mnuSelectAll 
         Caption         =   "Select &All Text"
         Shortcut        =   ^A
      End
      Begin VB.Menu SepEdit6 
         Caption         =   "-"
      End
      Begin VB.Menu mnuWrap 
         Caption         =   "&Hard Wrap"
         Index           =   0
         Shortcut        =   ^W
      End
      Begin VB.Menu mnuWrap 
         Caption         =   "&Join Lines"
         Index           =   1
         Shortcut        =   ^J
      End
      Begin VB.Menu mnuWrap 
         Caption         =   "&Reformat Quote"
         Index           =   2
         Shortcut        =   ^T
      End
      Begin VB.Menu SepEdit5 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFind 
         Caption         =   "&Find"
         Index           =   0
         Shortcut        =   ^F
      End
      Begin VB.Menu mnuFind 
         Caption         =   "Find A&gain"
         Index           =   1
         Shortcut        =   ^G
      End
      Begin VB.Menu sepEdit2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuClear 
         Caption         =   "Clea&r All Text"
         Index           =   0
         Shortcut        =   ^R
      End
      Begin VB.Menu mnuClear 
         Caption         =   "Clear Boo&k"
         Index           =   1
      End
   End
   Begin VB.Menu mnuMessage 
      Caption         =   "&Message"
      Begin VB.Menu mnuQueVia 
         Caption         =   "&Queue Via"
         Begin VB.Menu mnuQueDef 
            Caption         =   "Default SMTP"
         End
         Begin VB.Menu sepQue 
            Caption         =   "-"
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 1"
            Index           =   0
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 2"
            Index           =   1
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 3"
            Index           =   2
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 4"
            Index           =   3
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 5"
            Index           =   4
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 6"
            Index           =   5
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 7"
            Index           =   6
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 8"
            Index           =   7
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 9"
            Index           =   8
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 10"
            Index           =   9
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 11"
            Index           =   10
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 12"
            Index           =   11
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 13"
            Index           =   12
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 14"
            Index           =   13
         End
         Begin VB.Menu mnuQue 
            Caption         =   "SMTP 15"
            Index           =   14
         End
         Begin VB.Menu mnuQue 
            Caption         =   "UNIX"
            Index           =   15
         End
      End
      Begin VB.Menu mnuReplayVia 
         Caption         =   "&Replay Via"
         Begin VB.Menu mnuReplayDef 
            Caption         =   "Default SMTP"
         End
         Begin VB.Menu sepReplay 
            Caption         =   "-"
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 1"
            Index           =   0
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 2"
            Index           =   1
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 3"
            Index           =   2
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 4"
            Index           =   3
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 5"
            Index           =   4
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 6"
            Index           =   5
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 7"
            Index           =   6
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 8"
            Index           =   7
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 9"
            Index           =   8
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 10"
            Index           =   9
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 11"
            Index           =   10
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 12"
            Index           =   11
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 13"
            Index           =   12
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 14"
            Index           =   13
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "SMTP 15"
            Index           =   14
         End
         Begin VB.Menu mnuReplay 
            Caption         =   "UNIX"
            Index           =   15
         End
      End
      Begin VB.Menu mnuConfigSMTP 
         Caption         =   "&Configuration..."
      End
      Begin VB.Menu sepMess1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuMessClear 
         Caption         =   "Clear &Attachments"
         Index           =   0
      End
      Begin VB.Menu mnuMessClear 
         Caption         =   "Clear &Headers"
         Index           =   1
      End
      Begin VB.Menu sepMess2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuReply 
         Caption         =   "Repl&y To Clipboard   [Ctrl-Y]"
         Index           =   0
      End
      Begin VB.Menu mnuReply 
         Caption         =   "&Follow-Up Clipboard   [Ctrl-U]"
         Index           =   1
      End
   End
   Begin VB.Menu mnuRemailers 
      Caption         =   "&Remailers"
      Begin VB.Menu mnuRType 
         Caption         =   "Mixmast&er"
         Shortcut        =   ^M
      End
      Begin VB.Menu sepRem3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuStats 
         Caption         =   "&Refresh Stats"
         Index           =   0
      End
      Begin VB.Menu mnuStats 
         Caption         =   "&View Stats"
         Index           =   1
      End
      Begin VB.Menu mnuStats 
         Caption         =   "Get CPunk &Keys"
         Index           =   2
      End
      Begin VB.Menu mnuStats 
         Caption         =   "Get &Mix Keys"
         Index           =   3
      End
      Begin VB.Menu sepRem1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuShowAuto 
         Caption         =   "Show &AUTO"
      End
      Begin VB.Menu mnuChain 
         Caption         =   "&Chain"
         Visible         =   0   'False
         Begin VB.Menu mnuRemEdit 
            Caption         =   "&Add AUTO"
            Index           =   0
         End
         Begin VB.Menu mnuRemEdit 
            Caption         =   "Remo&ve"
            Index           =   1
         End
         Begin VB.Menu mnuRemEdit 
            Caption         =   "-"
            Index           =   2
         End
         Begin VB.Menu mnuRemEdit 
            Caption         =   "&Edit Directives..."
            Index           =   3
         End
      End
      Begin VB.Menu sepRem2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfigRem 
         Caption         =   "&Configuration..."
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "&Tools"
      Begin VB.Menu mnuDecrypt 
         Caption         =   "D&ecrypt Clipboard"
         Visible         =   0   'False
         Begin VB.Menu mnuDecClip 
            Caption         =   "To &Clipboard"
            Index           =   0
            Shortcut        =   ^B
         End
         Begin VB.Menu mnuDecClip 
            Caption         =   "To &Inbox"
            Index           =   1
         End
         Begin VB.Menu mnuDecClip 
            Caption         =   "To &Output File"
            Index           =   2
         End
      End
      Begin VB.Menu sepTools5 
         Caption         =   "-"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "&View PGP Keyring..."
         Index           =   0
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "View Mi&x Keyring..."
         Index           =   1
      End
      Begin VB.Menu sepTools1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuPasteKey 
         Caption         =   "Paste PGP &Key..."
      End
      Begin VB.Menu sepEdit1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuWriteClip 
         Caption         =   "Load Clip&board..."
         Index           =   0
      End
      Begin VB.Menu mnuWriteClip 
         Caption         =   "Save Cl&ipboard As..."
         Index           =   1
      End
      Begin VB.Menu mnuWriteClip 
         Caption         =   "App&end Clipboard As..."
         Index           =   2
      End
      Begin VB.Menu mnuPasteKeyX 
         Caption         =   "Dele&te Key"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuCertKey 
         Caption         =   "Certify (&Sign) Key"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuPGPClip 
         Caption         =   "PGP &Clipboard"
         Visible         =   0   'False
         Begin VB.Menu mnuAddKey 
            Caption         =   "Add &Key To Keyring"
         End
         Begin VB.Menu mnuClipDecrypt 
            Caption         =   "&Decrypt"
            Begin VB.Menu mnuClipDec 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipDec 
               Caption         =   "To &File"
               Index           =   1
            End
         End
         Begin VB.Menu mnuClipEncrypt 
            Caption         =   "&Encrypt"
            Begin VB.Menu mnuClipEnc 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipEnc 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuClipEnc 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuClipSign 
            Caption         =   "&Sign"
            Begin VB.Menu mnuClipSig 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipSig 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuClipSig 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuClipEncSig 
            Caption         =   "Sign &and Encrypt"
            Begin VB.Menu mnuClipES 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuClipES 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuClipES 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
      End
      Begin VB.Menu mnuPGPFile 
         Caption         =   "PGP &File"
         Visible         =   0   'False
         Begin VB.Menu mnuAddKeyFile 
            Caption         =   "Add &Key To Keyring"
         End
         Begin VB.Menu mnuFileDecrypt 
            Caption         =   "&Decrypt"
            Begin VB.Menu mnuFileDec 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileDec 
               Caption         =   "To &File"
               Index           =   1
            End
         End
         Begin VB.Menu mnuFileEncrypt 
            Caption         =   "&Encrypt"
            Begin VB.Menu mnuFileEnc 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileEnc 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuFileEnc 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuFileSign 
            Caption         =   "&Sign"
            Begin VB.Menu mnuFileSig 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileSig 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuFileSig 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
         Begin VB.Menu mnuFileEncSig 
            Caption         =   "Encrypt &and Sign"
            Begin VB.Menu mnuFileES 
               Caption         =   "To &Clipboard"
               Index           =   0
            End
            Begin VB.Menu mnuFileES 
               Caption         =   "To &ASCII File"
               Index           =   1
            End
            Begin VB.Menu mnuFileES 
               Caption         =   "To &Binary File"
               Index           =   2
            End
         End
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuWrapOpt 
         Caption         =   "&Auto Wrap Long Lines..."
      End
      Begin VB.Menu mnuSetSig 
         Caption         =   "&Set Signature..."
      End
      Begin VB.Menu mnuOverrideSMTP 
         Caption         =   "&Override Default Profile..."
      End
      Begin VB.Menu mnuCPunkOpt 
         Caption         =   "Cypherpu&nk"
         Begin VB.Menu mnuRemixComp 
            Caption         =   "&Remix Compliant"
         End
         Begin VB.Menu mnuExpire 
            Caption         =   "E&xpiration"
         End
      End
      Begin VB.Menu mnuAttSubject 
         Caption         =   "Show A&ttachment In Subject"
      End
      Begin VB.Menu sepOpt3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOption 
         Caption         =   "Show &Advanced"
         Index           =   0
      End
      Begin VB.Menu mnuOption 
         Caption         =   "Alternate Text &Box"
         Index           =   1
      End
      Begin VB.Menu mnuTextEncode 
         Caption         =   "Text &Encoding"
         Begin VB.Menu mnuTextEnc 
            Caption         =   "MIME &Quoted Printable"
            Index           =   0
         End
         Begin VB.Menu mnuTextEnc 
            Caption         =   "MIME 8-&Bit"
            Index           =   1
         End
      End
      Begin VB.Menu sepOpt 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileOpt 
         Caption         =   "Auto-Sa&ve Book On Queue"
         Index           =   0
      End
      Begin VB.Menu mnuFileOpt 
         Caption         =   "Save &Replay"
         Index           =   1
      End
      Begin VB.Menu mnuFileOpt 
         Caption         =   "Auto-Name On Loa&d"
         Index           =   2
      End
      Begin VB.Menu mnuFileOpt 
         Caption         =   "C&lose Window On Queue"
         Index           =   3
      End
      Begin VB.Menu sepOpt4 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfigBooks 
         Caption         =   "&Configuration..."
         Shortcut        =   {F7}
      End
   End
   Begin VB.Menu mnuWind 
      Caption         =   "&Window"
      Begin VB.Menu mnuWindow 
         Caption         =   "E&xplore"
         Index           =   0
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Queue"
         Index           =   1
         Shortcut        =   {F3}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Log"
         Index           =   2
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&View Mail"
         Index           =   3
         Shortcut        =   {F5}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Stats Browser"
         Index           =   4
         Shortcut        =   {F6}
      End
      Begin VB.Menu sepWindow1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Global Config"
         Index           =   0
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "R&etrieval Config"
         Index           =   1
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Books Config"
         Index           =   2
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Remailers Config"
         Index           =   3
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "S&tats Config"
         Index           =   4
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   5
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Sen&d Profiles"
         Index           =   6
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Retrieval &Profiles"
         Index           =   7
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Ne&ws Profiles"
         Index           =   8
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Nym Accounts Registry"
         Index           =   9
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Addresses"
         Index           =   10
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   11
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Check Configuration"
         Index           =   12
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&User's Manual              F1"
         Index           =   0
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Beginner's Guide"
         Index           =   1
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Troubleshooting Guide"
         Index           =   2
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Remailer Reference"
         Index           =   3
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "-"
         Index           =   7
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "Open Default &Browser"
         Index           =   8
      End
   End
   Begin VB.Menu mnuText 
      Caption         =   "Text"
      Visible         =   0   'False
      Begin VB.Menu mnuTxt 
         Caption         =   "Und&o"
         Index           =   0
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Copy"
         Index           =   1
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Copy App&end"
         Index           =   2
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Cu&t"
         Index           =   3
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Paste"
         Index           =   4
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Paste As &Quote"
         Index           =   5
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Paste Signat&ure"
         Index           =   6
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "-"
         Index           =   7
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Find"
         Index           =   8
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Find &Next"
         Index           =   9
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "-"
         Index           =   10
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Hard Wrap"
         Index           =   11
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Join Lines"
         Index           =   12
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Select &All Text"
         Index           =   13
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Clea&r All Text"
         Index           =   14
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "-"
         Index           =   15
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Load Text File"
         Index           =   16
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Insert Text File"
         Index           =   17
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "Save Te&xt As..."
         Index           =   18
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "&Print Text"
         Index           =   19
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "-"
         Index           =   20
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "MIME Quoted Printable"
         Index           =   21
      End
      Begin VB.Menu mnuTxt 
         Caption         =   "MIME 8-bit"
         Index           =   22
      End
   End
End
Attribute VB_Name = "frmBook"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Type MHeadersType
    From As String
    ReplyTo As String
    AuthorAddress As String
    Subject As String
    MessageID As String
    References As String
    InReplyTo As String
    Newsgroups As String
    FollowupTo As String
    XNoArchive As String
    Date As String
End Type

Const ColorCPunk = &H808000
Const ColorMix = &H800080

Dim TextBox As Object, BookX As Integer, BkChange As Boolean
Dim Searchfound As String, Searchindex As Long, SearchString As String, SearchAddr As Integer
Dim NoClick As Boolean, StatsWarned As Boolean, NymRun As Boolean
Dim LastFindString As String
Dim RemDirect() As String, BookRType As Byte
Const MaxBK = 50
Dim BkData(MaxBK) As String
Dim ReplayDate As String
Dim ViewSelStart As Long, ViewSelLength As Long, ViewDblClick As Boolean
Dim NoProfWarning As Boolean

Private Sub chkQue_Click(Index As Integer)
    If Index = 2 Then
        If chkQue(2).Value = 0 Then Unload frmPreview
        If TextBox.Visible Then TextBox.SetFocus
        If Not BookBusy(0, BookX) Then
            If chkQue(2).Value = 1 Then lblStat.Caption = LMsg(202) Else lblStat.Caption = LMsg(234)
        End If
        Exit Sub
    Else
        If chkQue(Index).Value = 0 Then Exit Sub
    End If
    QueBook Index, 99
End Sub

Private Sub mnuAttSubject_Click()
    If Not mnuAttSubject.Checked Then
        mnuAttSubject.Checked = MsgBox(LMsg(573), vbOKCancel, LMsg(95)) = vbOK
    Else
        mnuAttSubject.Checked = False
    End If
    BkData(19) = mnuAttSubject.Checked
    BkChange = True
End Sub

Private Sub mnuPasteKey_Click()
    a = SelectKey(LMsg(431), cboNym.Text)
    If a <> "" Then
        a = PGPKey(Extract(a, "   "), ErrMsg)
        If a = "" Then
            MsgBox ErrMsg, vbCritical
        Else
            TextBox.SelText = vbCrLf + a + vbCrLf
        End If
    End If
End Sub

Private Sub mnuQue_Click(Index As Integer)
    QueBook 0, Index
End Sub

Private Sub mnuChain_Click()
    mnuRemEdit(3).Enabled = mnuOption(0).Checked
    mnuRemEdit(3).Checked = fraRemEdit.Visible
End Sub

Private Sub lstRemailers_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        PopupMenu mnuChain
    End If
End Sub

Private Sub mnuRemEdit_Click(Index As Integer)
    If Index < 2 Then
        cmdRemailer_Click (Index)
    Else
        If mnuOption(0).Checked And Not fraRemEdit.Visible Then
            fraRemEdit.Visible = True
            If x = -1 Then rd = "" Else rd = RemDirect(x)
            ShowRemData Me, rd, BookRType
        Else
            cmdRemEdit_Click (0)
        End If
    End If
End Sub

Private Sub mnuReplay_Click(Index As Integer)
    QueBook 1, Index
End Sub

Private Sub mnuQueDef_Click()
    chkQue(0).Value = 1
End Sub

Private Sub mnuReplayDef_Click()
    chkQue(1).Value = 1
End Sub

Private Sub QueBook(Index As Integer, Prof)
    'Prof = 99  (Default)
    Dim hdr(1000) As String, hdrx As Integer, Hdrs As String, NewHdrs As String
    Dim a As String, b As String, an As String
    Dim Att() As String, AttCount As Integer
    Dim MIME As Boolean, MIMEBnd As String, MIMEHead As String
    Dim WorkPath As String, SignKey As String, SignPass As String
    Dim RCount As Integer, Rmlr() As String, MsgLen As Long
    Dim KeepRmlr() As String, KeepDirect() As String
    Dim BinData As Boolean, EncOut As Boolean, ClearSig As Boolean
    Dim Prevu As Boolean, FinishOnly As Boolean
    Dim DoMixHash As Boolean, AlreadyMixHash As Boolean, MixHash As String
    Dim Max As MaxType, dt As Date, RemixMode As Byte, RemixComp As Boolean
    Dim ArcType As Integer, ArcDest As String
    Dim QTag As String, QNum As Integer
    Dim ArchiveBook() As String, ArchiveBookX As Integer
    Dim NewBookName As String
    
    Err.Clear
    On Error GoTo BookError
    If BookBusy(0, BookX) Then chkQue(Index) = 0: Exit Sub
        
    'Valid Prof?
    If Prof = 99 Then
        r = ""
        If lstRemailers.ListCount = 1 Then
            If InStr(cboTo(0).Text, ",") = 0 And Trim(cboNym.Text) = "" Then r = CleanAddress(cboTo(0).Text)
        Else
            r = Extract(lstRemailers.List(0), " ")
            If Remailer(Extract(r, " "), BookRType, "", raddress, "", "", "", "", "") Then r = raddress
        End If
        If r <> "" And InStr(UserProf(30, 3), r) <> 0 And Val(UserProf(30, 0)) = 1 Then Prof = 15 Else Prof = DefaultProf
    End If
    If Prof = -1 Then chkQue(Index) = 0: Exit Sub
    If Val(UserProf(Prof + 15, 0)) = 0 Then chkQue(Index) = 0: Exit Sub
    
    'Close Rem Editor
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
        
    'Update
    UpdateDisp
    Prevu = chkQue(2).Value = 1
    
    Me.MousePointer = 11
    BookBusy(0, BookX) = True
    chkQue(0).Enabled = False
    chkQue(1).Enabled = False
    tabBook.Enabled = False
    fraBook(0).Enabled = False
    fraBook(1).Enabled = False
    mnuMessage.Enabled = False
        
    'Erase Old Replay
    If Index = 0 Then
        If Not DelFile(PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*") Then
            Msg = LMsg(231) + vbCr + PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*"
            GoTo BookError
        End If
    End If

    lblStat.Caption = LMsg(208): lblStat.Refresh 'Checking message
    
    'Mixmaste Enabled?
    If lstRemailers.ListCount > 1 And BookRType = 1 And Cnf(1, 15) = "" Then Msg = LMsg(433): GoTo BookError
    
    cboNym.Text = Trim(cboNym.Text)
    Nym = cboNym.Text
    
    'Message Archive
    If Index <> 1 And cboArcType.ListIndex <> 0 Then
        '0 No archive.
        '1 Save message and book to Sent folder.
        '2 Save message to Sent folder.
        '3 Save message and book to folder:
        '4 Save message to folder:
        '5 Append message to text file:
        '6 Log message to text file:
        'Valid Archive Folder
        cboArchive.Text = Trim(cboArchive.Text)
        txtArchive.Text = Trim(txtArchive.Text)
        Select Case cboArcType.ListIndex
        Case 1, 2
            ArcDest = Cnf(4, 0) + "\Sent"
            If Not CreateDir(ArcDest) Then GoTo Leave
        Case 3, 4
            ArcDest = cboArchive.Text
            If Not CreateDir(ArcDest) Then GoTo Leave
        Case 5, 6
            ArcDest = txtArchive.Text
        End Select
        ArcType = cboArcType.ListIndex
        If ArcType > 2 And ArcDest = "" Then Msg = LMsg(574): GoTo BookError
    End If
    
    'Save Book
    If BkData(11) = True2 Or (Index = 0 And BkData(12) = True2 And Nym <> "" And ArcType <> 1 And ArcType <> 3) Then WriteBook (MsgBookName(BookX))
    Me.MousePointer = 11
    
    If Index = 1 Then
        'Check Replay
        If SDir(PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._@@") <> "" Then
            'Config request replay
            ToA = Trim(cboTo(0).Text)
            If Left(ToA, 7) <> "config@" Or CleanAddress(ToA) = "" Then
                Msg = LMsg(426)
                GoTo BookError
            End If
            a = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._@@"
        Else
            If SDir(PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._AA") = "" Then
                Msg = LMsg(229) + vbCr + PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._AA"
                GoTo BookError
            Else
                If CleanAddress(Nym) = "" Then
                    Msg = LMsg(230)
                    GoTo BookError
                End If
                ToA = "send@" + Mid(Nym, InStr(Nym, "@") + 1)
                a = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._AA"
            End If
        End If
        If SDir(a) <> "" Then If SafeTime - FileDateTime(a) > 6 Then If MsgBox(LMsg(427), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
    Else
        'Check To
        cboTo(0).Text = Trim(cboTo(0).Text)
        a = Extract(cboTo(0).Text, ":"): If InStr(cboTo(0).Text, ":") = 0 Then a = ""
        ToA = cboTo(0).Text
        If LCase(a) = "post" Or LCase(a) = "post-to" Or LCase(a) = "anon-post-to" Then
            If LCase(a) = "post" And BookRType = 0 Then Msg = LMsg(189): GoTo BookError
            If LCase(a) <> "post" And BookRType = 1 Then Msg = LMsg(191): GoTo BookError
            If Nym <> "" Then Msg = LMsg(432): GoTo BookError
            If InStr(ToA, ".") = 0 Then Msg = LMsg(146): GoTo BookError
            If lstRemailers.ListCount = 1 Then Msg = LMsg(192): GoTo BookError
            NewsPost = True
            ToA = Extract(ToA, ":") + ": " + Replace(Mid(ToA, InStr(ToA, ":") + 1), " ", "")
        Else
            If CleanAddress(ToA) = "" And LCase(a) <> "null" Then
                'Remailer name?
                If InStr(ToA, "@") + InStr(ToA, ",") = 0 And Trim(ToA) <> "" Then
                    If Remailer(Trim(ToA), 2, rname, raddress, "", "", "", "", "") Then ToA = raddress Else Msg = LMsg(146): GoTo BookError
                Else
                    Msg = LMsg(146): GoTo BookError
                End If
            End If
        End If
        'News Post?
        x = InStr(1, txtHeaders(0).Text, "Newsgroups:", vbTextCompare)
        If x <> 0 Then
            If Trim(Extract(Mid(txtHeaders(0).Text, x + 11), vbCrLf)) <> "" Then NewsPost = True
        End If
        If NewsPost And Trim(txtSubject.Text) = "" Then _
         If MsgBox(LMsg(147), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
        'Check Nym
        cboNC.Text = Trim(cboNC.Text)
        NC = cboNC.Text
        If CleanAddress(cboNym.Text) = "" And cboNym.Text <> "" Then Msg = LMsg(149): GoTo BookError
        'Nym Run?
        If NymRun And Nym <> "" And Left(ToA, 7) = "config@" Then If MsgBox(LMsg(429), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
        'Valid Headers
        If BookRType = 1 And lstRemailers.ListCount > 1 And Nym = "" Then
            'Do Mix Hash?
            r = Extract(LTrim(lstRemailers.List(lstRemailers.ListCount - 2)), " ")
            If Type2(r, "", "", "", "", a) <> 0 Then
                If Left(a, 5) <> "2.0.3" Then DoMixHash = True
            End If
        End If
        If InStr(txtHeaders(0).Text, Chr(0)) + InStr(txtHeaders(0).Text, Chr(26)) <> 0 Then txtHeaders(0).Text = Replace(Replace(txtHeaders(0).Text, Chr(0), " "), Chr(26), " ")
        hdrx = ParseString(txtHeaders(0).Text, hdr(), 1000, False)
        For i = 0 To hdrx
            y = InStr(hdr(i), ":")
            If y = 0 Then
                If Left(hdr(i), 1) <> " " Then
                    If MsgBox(LMsg(150), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
                End If
                hdr(i) = "    " + LTrim(hdr(i))
            Else
                b = LTrim(Mid(hdr(i), y + 1))
                If b <> "" Then
                    If b Like "*[" + BinChars + "]*" Then
                        While EncoderBusy
                            DoEvents
                        Wend
                        EncoderBusy = True
                        frmMain!NetCode1.DecodedData = b
                        frmMain!NetCode1.Format = 2 'f_QuotedPrintable
                        frmMain!NetCode1.Action = 4 'a_EncodeToString
                        b = "=?ISO-8859-1?Q?" + Replace(frmMain!NetCode1.EncodedData, " ", "_") + "?="
                        EncoderBusy = False
                    End If
                    If LCase(Left(hdr(i), y - 1)) = "newsgroups" Then b = Replace(b, " ", "")
                    hdr(i) = Trim(Left(hdr(i), y - 1)) + ": " + b
                    'Long Mix Header?
                    If Len(hdr(i)) > 79 And BookRType = 1 And lstRemailers.ListCount - 1 <> 0 And Nym = "" Then
                        If DoMixHash Then
                            MixHash = MixHash + hdr(i) + vbCrLf
                            hdr(i) = ""
                        Else
                            If Not AlreadyMixHash And Val(Cnf(2, 5)) = 1 Then If MsgBox(LMsg(227), vbQuestion + vbOKCancel, LMsg(168)) = vbCancel Then GoTo Leave
                            AlreadyMixHash = True
                        End If
                    End If
                Else
                    hdr(i) = ""
                End If
            End If
        Next i
    End If
    
    'Valid Work
    txtWork.Text = NoSlash(txtWork.Text)
    WorkPath = txtWork.Text: If WorkPath = "" Then WorkPath = PData(10)
    If Not CreateDir(WorkPath) Then GoTo Leave
    'No remailers
    If lstRemailers.ListCount < 2 Then
        If Val(Cnf(2, 4)) = 1 Then If MsgBox(LMsg(155), vbExclamation + vbOKCancel + vbDefaultButton2, LMsg(148)) = vbCancel Then GoTo Leave
    Else
        'RANDOM in Chains
        If BookRType = 1 And Val(BkData(0)) > 1 Then
            For i = 0 To lstRemailers.ListCount - 3
                If InStr(1, lstRemailers.List(i), "RANDOM", vbTextCompare) = 1 Then RandMix = True: Exit For
            Next i
            If Not RandMix Then If MsgBox(LMsg(156), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
        End If
        If InStr(1, lstRemailers.List(lstRemailers.ListCount - 2), "RANDOM", vbTextCompare) = 1 And Val(Cnf(2, 5)) = 1 Then If MsgBox(LMsg(237), vbQuestion + vbOKCancel, LMsg(168)) = vbCancel Then GoTo Leave
    End If
    
    Auto = False
    RCount = lstRemailers.ListCount - 1
    If RCount <> 0 Then ReDim KeepRmlr(RCount - 1), KeepDirect(RCount - 1)
    For i = 0 To RCount - 1
        If LCase(Extract(lstRemailers.List(i), " ")) = "auto" Then Auto = True
        KeepRmlr(i) = Extract(lstRemailers.List(i), " ")
        KeepDirect(i) = RemDirect(i)
    Next i
    If Auto And Not StatsWarned And SafeTime - KeepDate(3) > 1 Then StatsWarned = True: If MsgBox(LMsg(428), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
    
    txtSplit.Text = Trim(Str(Abs(Int(Val(txtSplit.Text)))))
    splitx = SVal(txtSplit.Text)
    If splitx < 1024 And chkSplit.Value = 1 Then Msg = LMsg(280): GoTo BookError
    IfSplit = chkSplit.Value
    
    Subject = txtSubject.Text
    Chains = Val(BkData(0)): If Chains > 5 Then Chains = 5
    rtype = BookRType
    'Max
    If rtype = 0 And RCount <> 0 And Val(BkData(9)) <> 0 Then
        Max.NeedMax = True
        Max.MaxHours = Val(BkData(9))
        Max.MaxCount = "1"
        Max.MaxSize = ""
        Max.MaxDate = ""
    End If
    RemixComp = (RCount <> 0 And rtype = 0 And BkData(14) = True2)
    
    'Pre-Check Remailers
    DontRepeat = ""
    If Auto Then
        lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(209): lblStat.Refresh
        For i = 0 To RCount - 1
            r = Extract(lstRemailers.List(i), " ")
            If i = RCount - 1 Then
                gNext = "": gFinal = ToA
                rd = RemDirect(i)
            Else
                gNext = Extract(lstRemailers.List(i + 1), " ")
                gFinal = ""
                If BookRType = 1 Then rd = "" Else rd = RemDirect(i)
            End If
            If RemixComp Then
                'Remix Compliant
                If i = RCount - 1 Then RemixMode = 2 Else RemixMode = 1
            End If
            If Not GetDirect(r, rd, BookRType, i + 1, gNext, gFinal, False, True, MsgLen, d, Garbage, Max, False, 0, RemixMode) Then GoTo Leave
        Next i
    End If
    
    'Single dot?
    If InStr(TextBox.Text, vbCrLf + "." + vbCrLf) <> 0 Then
        x = MsgBox(LMsg(399), vbQuestion + vbYesNoCancel, LMsg(148))
        If x = vbCancel Then GoTo Leave
        If x = vbYes Then TextBox.Text = Replace(TextBox.Text, vbCrLf + "." + vbCrLf, vbCrLf + " " + vbCrLf)
    End If
    
    If Index = 0 Then
        'MESSAGE
        'Attachments
        AttCount = lstAttach.ListCount - 1
        ReDim Att(AttCount, 3)
        cboEncrypt(0).Text = Trim(cboEncrypt(0).Text)
        cboEncrypt(1).Text = Trim(cboEncrypt(1).Text)
        If lstAttach.ListCount > 1 Then
            lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(210): lblStat.Refresh
            For i = 0 To 1
                If cboEncrypt(i).Text = "" And chkEncrypt(i).Value = 1 Then
                    If MsgBox(LMsg(151 + i), vbExclamation + vbOKCancel + vbDefaultButton2, LMsg(148)) = vbCancel Then GoTo Leave
                End If
            Next i
            For i = 0 To AttCount - 1
                PGPConv = False
                a = lstAttach.List(i)
                x = InStr(a, " Encode: ")
                If x = 0 Then Msg = LMsg(153): GoTo BookError
                an = Trim(Left(a, x - 1))
                If SDir(an) = "" Then Msg = LMsg(66) + vbCrLf + an: GoTo BookError
                e = Trim(Mid(a, x + 8))
                'Determine content type
                If (Not ((chkEncrypt(0).Value = 1 And cboEncrypt(0).Text <> "") Or (chkEncrypt(1).Value = 1 And cboEncrypt(1).Text <> ""))) Or e = "PGP Conv" Then
                    If e <> "PGP Conv" And e <> "UUEncode" Then m = MIMECheck(an)
                    Select Case e
                    Case "Text Auto"
                        If Left(m, 9) <> "MIME 7bit" And Left(m, 7) <> "MIME QP" Then m = "MIME QP"
                    Case "Text None"
                        If Left(m, 9) = "MIME 7bit" Then
                            m = "None"
                        Else
                            If InStr(m, "HTML") <> 0 Then m = "MIME 8bit HTML" Else m = "MIME 8bit"
                        End If
                    Case "Text 8Bit"
                        If InStr(m, "HTML") <> 0 Then m = "MIME 8bit HTML" Else m = "MIME 8bit"
                    Case "Text QP"
                        If Left(m, 7) <> "MIME QP" Then
                            If InStr(m, "HTML") <> 0 Then m = "MIME QP HTML" Else m = "MIME QP"
                        End If
                    Case "Text HTML"
                        If Left(m, 9) = "MIME 7bit" Then m = "MIME 7bit HTML" Else m = "MIME QP HTML"
                    Case "Base64"
                        If Left(m, 8) <> "MIME base64" Then m = "MIME base64 application/octet-stream"
                    Case "UUEncode"
                        m = "UUE"
                    Case "PGP Conv"
                        If (chkEncrypt(1).Value = 1 And cboEncrypt(1).Text <> "") Then If MsgBox(LMsg(193) + vbCr + vbCr + Att(i, 0), vbExclamation + vbOKCancel + vbDefaultButton2, LMsg(148)) = vbCancel Then GoTo Leave
                        m = "MIME base64 application/octet-stream"
                        Att(i + 1, 2) = vbTab + "Conventional"
                        Att(i + 1, 3) = ""
                        PGPConv = True
                    End Select
                Else
                    'Encrypted or Signed - determine MIME content type
                    If (Not (chkEncrypt(0).Value = 1 And cboEncrypt(0).Text <> "")) Then
                        'Signed without encryption
                        If BinFile(an) Then
                            If e = "Text 8Bit" Or e = "Text Auto" Then m = "MIME 8bit" Else m = "MIME base64 application/octet-stream"
                        ElseIf e = "MIME Auto" Or e = "Text Auto" Or e = "Test 8Bit" Or e = "Text QP" Then
                            m = "MIME 7bit"
                        Else
                            m = "None"
                        End If
                    Else
                        'Encrypted
                        m = "MIME base64 application/octet-stream"
                        If LCase(Extract(Trim(cboEncrypt(0).Text), " ")) = "-c" Then
                            'User has -c in encrypt box with Encrypt Attachments button pressed
                            'What is this?  Anyway?
                            Att(i + 1, 2) = vbTab + "Conventional"
                            Att(i + 1, 3) = ""
                            PGPConv = True
                        End If
                    End If
                End If
                If Left(m, 4) = "MIME" Then MIME = True
                If Val(PData(12)) = 0 Then
                    a = GetShortName(an)
                    If a <> "" Then an = a
                End If
                Att(i + 1, 0) = an
                Att(i + 1, 1) = m
                If Not PGPConv Then
                    For j = 0 To 1
                        If chkEncrypt(j).Value = 1 And cboEncrypt(j).Text <> "" Then Att(i + 1, 2 + j) = cboEncrypt(j).Text
                    Next j
                End If
            Next i
        End If

        'Show Attachment in Subject
        If AttCount = 1 And BkData(19) = True2 Then
            If Att(1, 2) = "" Then
                If Subject <> "" Then Subject = Subject + " - "
                Subject = Subject + PlainName(Att(1, 0), 1)
            End If
        End If

        'Text
        If TextBox.Text <> "" Or AttCount = 0 Then
            lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(211): lblStat.Refresh
            If InStr(TextBox.Text, Chr(0)) <> 0 Then TextBox.Text = Replace(TextBox.Text, Chr(0), " ")
            If InStr(TextBox.Text, Chr(26)) <> 0 Then TextBox.Text = Replace(TextBox.Text, Chr(26), " ")
            bl = Val(BkData(2)): If bl = 0 Then bl = 32000
            Att(0, 0) = SplitLines(TextBox.Text, bl, ErrMsg, "", GetWork(WorkPath))
            If Att(0, 0) = "" Then Msg = LMsg(157) + vbCrLf + ErrMsg: GoTo BookError
            If cboEncrypt(0).Text = "" And cboEncrypt(1).Text = "" Then
                If BkData(16) = True2 Or BkData(17) = True2 Then
                    If BkData(16) = True2 Then Att(0, 1) = "MIME QP" Else Att(0, 1) = "MIME 8bit"
                    If Left(TextBox.Text, 6) = "<HTML>" Then Att(0, 1) = Att(0, 1) + " HTML"
                Else
                    If TextBox.Text Like "*[" + BinChars + "]*" Then
                        Att(0, 1) = "MIME QP"
                        If Left(TextBox.Text, 6) = "<HTML>" Then Att(0, 1) = "MIME QP HTML"
                    Else
                        Att(0, 1) = "None"
                        If Left(TextBox.Text, 6) = "<HTML>" Then Att(0, 1) = "MIME 7bit HTML"
                    End If
                End If
            Else
                'Encrypted or Signed Text
                'None/MIME 8bit
                If BkData(17) <> True2 Or cboEncrypt(0).Text <> "" Then
                    Att(0, 1) = "None"
                Else
                    Att(0, 1) = "MIME 8bit"
                End If
            End If
            If Left(Att(0, 1), 4) = "MIME" Then MIME = True
            For j = 0 To 1
                If cboEncrypt(j).Text <> "" Then Att(0, 2 + j) = cboEncrypt(j).Text
            Next j
            If LCase(Extract(Att(0, 2), "   ")) = "-c" Then
                If Att(0, 3) <> "" Then If MsgBox(LMsg(439), vbExclamation + vbOKCancel, LMsg(148)) = vbCancel Then GoTo Leave
                Att(0, 1) = "None"
                Att(0, 2) = vbTab + "Conventional"
                Att(0, 3) = ""
            End If
        End If
        
        'Create Body
        lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(212): lblStat.Refresh
        If MIME And AttCount <> 0 Then
            'Multi-part MIME
            MIMEBnd = "---------Next_Part--" + MakeTag(12)
            MIMEHead = "Content-Type: multipart/mixed; boundary=" + Chr(34) + MIMEBnd + Chr(34) + vbCrLf
        Else
            If MIME Then MIMEHead = MIMEContent(Att(0, 1), "")
        End If
        bd = GetWork(WorkPath)
        n = FreeFile
        Open bd For Output As n
        'Headers
        If Trim(cboTo(1).Text) <> "" Then Hdrs = Hdrs + "CC: " + Trim(cboTo(1).Text) + vbCrLf
        If Trim(cboTo(2).Text) <> "" Then Hdrs = Hdrs + "Bcc: " + Trim(cboTo(2).Text) + vbCrLf
        For i = 0 To hdrx
            If hdr(i) <> "" Then Hdrs = Hdrs + hdr(i) + vbCrLf
        Next i
        'Encrypted: PGP
        If Not MIME And Left(TextBox.Text, 4) = "::" + vbCrLf And cboEncrypt(0).Text <> "" Then _
         Print #n, "::"; vbCrLf; "Encrypted: PGP"; vbCrLf
        
        'Release book window
        'All book data after this point must be local
        Me.MousePointer = 13
        tabBook.Enabled = True
        fraBook(0).Enabled = True
        fraBook(1).Enabled = True
        
        For i = 0 To AttCount
            If Att(i, 0) <> "" Then
                If i <> 0 Then
                    Print #n,
                    lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(213) + " " + Att(i, 0): lblStat.Refresh
                End If
                'MIME Section
                If MIMEBnd <> "" Then
                    Print #n, "--"; MIMEBnd
                    If i <> 0 And (Att(i, 2) <> "" Or (Att(i, 3) <> "" And Att(i, 1) = "MIME base64 application/octet-stream")) Then
                        attenum = attenum + 1
                        Print #n, MIMEContent(Att(i, 1), "Attach" + Trim(Str(attenum)) + ".pgp")
                    Else
                        Print #n, MIMEContent(Att(i, 1), PlainName(Att(i, 0), 1))
                    End If
                Else
                    If i <> 0 Then Print #n,
                End If
                'Encrypt/Encode
                EncOut = False
                If Att(i, 2) <> "" Then
                    'Encrypt
                    If Att(i, 2) = vbTab + "Conventional" Then
                        'Conv Encrypt
                        If Val(PData(12)) = 0 Then a = LMsg(162) + ".  " + LMsg(161) Else a = LMsg(162) + ":"
                        a = a + vbCrLf + vbCrLf + Att(i, 0)
                        CPass = GetConvPass(a)
                        If CPass = "" And Val(PData(12)) = 1 Then Close n: n = 0: DelFile bd: Msg = LMsg(163): GoTo BookError
                        anbin = Encrypt(Att(i, 0), CPass, 0, ErrMsg, "", "", False, False)
                        CPass = String(Len(CPass), "@")
                        EncOut = True
                    Else
                        EncOut = Att(i, 1) <> "MIME base64 application/octet-stream" Or i = 0
                        If Att(i, 3) <> "" Then
                            'Encrypt and Sign
                            If SignPass = "" Then SignPass = GetSignPass(Att(i, 3)): Me.Refresh
                            anbin = Encrypt(Att(i, 0), Trim(Extract(Att(i, 2), "   ")), 1, ErrMsg, Trim(Extract(Att(i, 3), "   ")), SignPass, False, Not EncOut)
                            'Save Replay
                            If BkData(12) = True2 And anbin <> "" And i = 0 And AttCount = 0 And Left(ToA, 7) = "config@" And Nym = "" Then
                                If Remailer(ToA, 2, "", raddress, roptions, "", "", "", "") Then
                                    If InStr(roptions, " newnym ") <> 0 Then
                                        FileCopy anbin, PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._@@"
                                        ReDim ArchiveBook(1)
                                        ArchiveBook(ArchiveBookX) = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._@@"
                                        ArchiveBookX = ArchiveBookX + 1
                                    End If
                                End If
                            End If
                        Else
                            'Encrypt Only
                            anbin = Encrypt(Att(i, 0), Trim(Extract(Att(i, 2), "   ")), 1, ErrMsg, "", "", False, Not EncOut)
                        End If
                    End If
                    If EncOut Then
                        an = anbin
                    Else
                        If anbin <> "" Then an = MsgEncode(anbin, GetWork(WorkPath), Att(i, 1), MIME, ErrMsg) Else an = ""
                        If anbin <> an Then DelFile anbin
                    End If
                ElseIf Att(i, 3) <> "" Then
                    'Sign Only
                    If SignPass = "" Then SignPass = GetSignPass(Att(i, 3)): Me.Refresh
                    'BinData?
                    If BinFile(Att(i, 0)) Then
                        EncOut = (Att(i, 1) = "MIME 8bit")
                        ClearSig = EncOut
                        If i = 0 Then
                            'If text is not explicit 8 bit MIME, do not clearsign but do armor
                            If Not ClearSig Then EncOut = True
                        End If
                    Else
                        EncOut = True
                        ClearSig = True
                    End If
                    anbin = Encrypt(Att(i, 0), "", 1, ErrMsg, Trim(Extract(Att(i, 3), "   ")), SignPass, ClearSig, Not EncOut)
                    If EncOut Then
                        an = anbin
                    Else
                        If anbin <> "" Then an = MsgEncode(anbin, GetWork(WorkPath), Att(i, 1), MIME, ErrMsg) Else an = ""
                        DelFile anbin
                    End If
                Else
                    'Encode
                    an = MsgEncode(Att(i, 0), GetWork(WorkPath), Att(i, 1), MIME, ErrMsg)
                End If
                If an = "" Then Close n: n = 0: DelFile bd: Msg = ErrMsg + vbCrLf + Att(i, 0): GoTo BookError
                p = FreeFile
                Open an For Input As p
                EncOK = PGPOK(n, p, EncOut)
                Close p: p = 0
                If EncOut And Not EncOK Then
                    Close n: n = 0
                    DelFile bd
                    Msg = LMsg(195) + vbCrLf + Att(i, 0)
                    GoTo BookError
                End If
                If i = 0 And ArcType <> 0 Then
                    If Att(0, 2) <> "" Then Body = Att(0, 0) Else Body = an
                End If
                If (an <> Att(i, 0) Or i = 0) And an <> Body Then DelFile an
            End If
        Next i
        SignPass = String(Len(SignPass), "@")
        If MIMEBnd <> "" Then Print #n, vbCrLf; "--"; MIMEBnd; "--"
        x = LOF(n)
        Close n: n = 0
            
        'Split Body
        If IfSplit = 1 And x > splitx + 16 Then
            splitn = Int(x / splitx + 0.99999)
            If splitn > 256 Then DelFile bd: Msg = LMsg(159): GoTo BookError
            If MsgBox(LMsg(221) + vbCr + vbCr + Str(splitn) + " X" + Str(splitx) + " " + LMsg(222), vbQuestion + vbOKCancel, LMsg(148)) = vbCancel Then DelFile bd: GoTo Leave
            lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(214) + "[" + Str(splitn) + "]": lblStat.Refresh
            Do
                fn = WorkPath + "\" + MakeTag(5)
            Loop Until SDir(fn + ".*") = ""
            n = FreeFile
            Open bd For Input As n
            x = 0
            Do
                z = 0
                p = FreeFile
                Open fn + "." + Right("00" + Trim(Str(x)), 3) For Output As p
                If MixHash <> "" Then Print #p, "##"; vbCrLf; MixHash
                If x = 0 And MIMEHead <> "" Then Print #p, MIMEHead
                While Not EOF(n) And z <= splitx
                    Line Input #n, a
                    Print #p, a
                    z = LOF(p): Debug.Assert (z <> 0)
                Wend
                Close p: p = 0
                x = x + 1
            Loop Until EOF(n)
            splitparts = x
            Close n: n = 0
            DelFile bd
        Else
            splitparts = 1
            fn = "@@@@@@@@@@@@@@@@@@@@@"
            If MixHash <> "" Then
                newbd = GetWork(WorkPath)
                n = FreeFile
                Open bd For Input As n
                p = FreeFile
                Open newbd For Output As p
                Print #p, "##"; vbCrLf; MixHash
                While Not EOF(n)
                    Line Input #n, a
                    Print #p, a
                Wend
                Close p: p = 0
                Close n: n = 0
                DelFile bd
                bd = newbd
                newbd = ""
            End If
        End If
        
        If Nym <> "" Then
            'Find Nym Key
            For i = 0 To MaxNyms
                If Nyms(i, 0) = "" Then Exit For
                If Nyms(i, 0) = Nym Then SignKey = Extract(Nyms(i, 3), "   "): Exit For
            Next i
            If SignKey = "" Then SignKey = Nym
            SignPass = GetSignPass(SignKey)
        End If
    Else
        'Replay
        'Release book window
        'All book data after this point must be local
        Me.MousePointer = 13
        tabBook.Enabled = True
        fraBook(0).Enabled = True
        fraBook(1).Enabled = True
        'Count Replay
        fr = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2)
        If SDir(fr + "._@@") <> "" Then
            splitparts = 1
        Else
            For splitparts = 0 To 255
                an = Chr(Int(splitparts / 26 + 65)) + Chr((splitparts Mod 26) + 65)
                If SDir(fr + "._" + an) = "" Then Exit For
            Next splitparts
        End If
    End If
    
    'Create Final Message(s)
    If Nym <> "" Then ReDim ArchiveBook(splitparts + 2)
    PartId = MakeTag(16)
    For i = 0 To splitparts - 1
        If splitparts > 1 Then Parts = "[" + LMsg(223) + Str(i + 1) + "/" + Trim(Str(splitparts)) + "]" Else Parts = ""
        FinalTo = ToA
        If Index = 0 Then
            'Add Headers
            If splitparts > 1 Then
                bd = fn + "." + Right("00" + Trim(Str(i)), 3)
                If MIME Then
                    MIMEHead = "Content-Type: message/partial; id=" + Chr(34) + PartId + Chr(34) + "; number=" + Trim(Str(i + 1)) + "; total=" + Trim(Str(splitparts)) + vbCrLf
                    sbj = Subject
                Else
                    sbj = Subject + " (" + Trim(Str(i + 1)) + "/" + Trim(Str(splitparts)) + ")"
                End If
            Else
                sbj = Subject
            End If
            If sbj Like "*[" + BinChars + "]*" Then
                While EncoderBusy
                    DoEvents
                Wend
                EncoderBusy = True
                frmMain!NetCode1.DecodedData = sbj
                frmMain!NetCode1.Format = 2 'f_QuotedPrintable
                frmMain!NetCode1.Action = 4 'a_EncodeToString
                sbj = "=?ISO-8859-1?Q?" + Replace(frmMain!NetCode1.EncodedData, " ", "_") + "?="
                EncoderBusy = False
            End If
            If Trim(sbj) <> "" Then NewHdrs = "Subject: " + sbj + vbCrLf Else NewHdrs = ""
            NewHdrs = NewHdrs + Hdrs
            If MIMEHead <> "" Then NewHdrs = NewHdrs + "MIME-Version: 1.0" + vbCrLf + MIMEHead
            n = FreeFile
            newbd = GetWork(WorkPath)
            Open newbd For Output As n
            p = FreeFile
            Open bd For Input As p
            If Nym <> "" Then
                'Nym Headers
                Print #n, "From: "; Extract(Nym, "@")
                Print #n, "To: "; FinalTo
                If NC <> "" Then Print #n, "Nym-Commands: "; NC
                Print #n, NewHdrs
                NewHdrs = ""
            End If
            While Not EOF(p)
                Line Input #p, a
                Print #n, a
            Wend
            Close p: p = 0
            DelFile bd
            Close n: n = 0
            'Encrypt/Sign to nym-server
            If Nym <> "" Then
                lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(218): lblStat.Refresh
                nlen = FileLen(newbd)
                FinalTo = "send" + Mid(Nym, InStr(Nym, "@"))
                nymmg = Encrypt(newbd, FinalTo, 1, ErrMsg, SignKey, SignPass, False)
                'Copy and Check PGP Integrity
                If nymmg <> "" Then
                    p = FreeFile
                    Open nymmg For Input As p
                    bd = GetWork(WorkPath)
                    n = FreeFile
                    Open bd For Output As n
                    EncOK = PGPOK(n, p, True)
                    Close p: p = 0
                    Close n: n = 0
                    DelFile nymmg
                    If EncOK Then
                        nymmg = bd
                        If FileLen(nymmg) > nlen Then nlen = FileLen(nymmg)
                    Else
                        nymmg = ""
                        DelFile bd
                    End If
                End If
                If nymmg = "" Then
                    DelFile newbd
                    DelFile fn + ".*"
                    Msg = ErrMsg
                    GoTo BookError
                End If
                'Find Nym-server
                If Not Remailer("config" + Mid(Nym, InStr(Nym, "@")), -1, rname, raddress, roptions, "", "", "", "") Then
                    rname = "config" + Mid(Nym, InStr(Nym, "@"))
                Else
                    'Check message length
                    x = InStr(roptions, " klen")
                    If x <> 0 Then
                        replen = SVal(Extract(Mid(roptions, x + 5), " ")) * 1024
                        If nlen + 1024 > replen Then
                            If MsgBox(LMsg(174) + " " + rname + " <" + raddress + ">" + vbCr + vbCr + LMsg(198) + ":" + Str(nlen + 1024) + vbCr + LMsg(220) + ":" + Str(replen), vbQuestion + vbOKCancel, LMsg(168)) = vbCancel Then
                                DelFile newbd: DelFile fn + ".*"
                                DelFile nymmg
                                If QTag <> "" Then DelFile Cnf(0, 1) + "\" + QTag + "*.T*"
                                GoTo Leave
                            End If
                        End If
                    End If
                End If
                'Show Preview
                If Prevu Then
                    b = LMsg(243)
                    x = PreviewMsg(b, b + "   " + Parts, rname, -1, False, "To: " + FinalTo + vbCrLf, newbd, False)
                    Me.MousePointer = 13
                    Me.Refresh
                    If x = -1 Or x = 2 Then
                        DelFile newbd: DelFile fn + ".*"
                        DelFile nymmg
                        If QTag <> "" Then DelFile Cnf(0, 1) + "\" + QTag + "*.T*"
                        GoTo Leave
                    End If
                    If x = 1 Then Prevu = False
                End If
                DelFile newbd
                newbd = nymmg
                'Save Replay
                If BkData(12) = True2 Then
                    an = Chr(Int(i / 26 + 65)) + Chr((i Mod 26) + 65)
                    FileCopy newbd, PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._" + an
                    ArchiveBook(ArchiveBookX) = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._" + an
                    ArchiveBookX = ArchiveBookX + 1
                End If
            End If
        Else
            'Get Replay File
            newbd = GetWork
            If SDir(fr + "._@@") <> "" Then an = "@@" Else an = Chr(Int(i / 26 + 65)) + Chr((i Mod 26) + 65)
            FileCopy fr + "._" + an, newbd
            NewHdrs = ""
        End If
        'Get Remailers
        If RCount <> 0 Then
            MsgLen = FileLen(newbd)
            If Auto Then lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(245): lblStat.Refresh
TryAuto:
            ReDim Rmlr(RCount - 1)
            For j = 1 To 4
                For k = 0 To RCount - 1
                    Rmlr(k) = KeepRmlr(k)
                Next k
                If Auto Then AutoFailx = GetRandom(Rmlr(), KeepDirect(), RCount, rtype, FinalTo, MsgLen, Max.NeedMax, RemixComp): If AutoFailx = -1 Then Exit For
                If Not Auto Then Exit For
            Next j
            If j = 5 Then
                'Insufficient random
                If MsgBox(LMsg(177) + Str(AutoFailx) + vbCr + vbCr + LMsg(411), vbRetryCancel + vbCritical + vbDefaultButton2, LMsg(4)) = vbRetry Then GoTo TryAuto
                DelFile newbd: DelFile fn + ".*"
                If QTag <> "" Then DelFile Cnf(0, 1) + "\" + QTag + "*.T*"
                If Index = 0 And BkData(12) = True2 Then DelFile PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*"
                GoTo Leave
            End If
            If Auto And Prevu Then
                'Show Random Remailers
                a = ""
                For k = 0 To RCount - 1
                    If LCase(KeepRmlr(k)) = "auto" Then b = "*" Else b = ""
                    a = a + "     " + UCase(Left(Rmlr(k), 1)) + Mid(Rmlr(k), 2) + " " + b + vbCrLf
                Next k
                x = MsgBox(LMsg(238) + ":" + vbCr + vbCr + a + vbCr + LMsg(239), vbQuestion + vbYesNoCancel, LMsg(240))
                If x = vbCancel Then
                    DelFile newbd: DelFile fn + ".*"
                    If QTag <> "" Then DelFile Cnf(0, 1) + "\" + QTag + "*.T*"
                    If Index = 0 And BkData(12) = True2 Then DelFile PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*"
                    GoTo Leave
                End If
                If x = vbNo Then GoTo TryAuto
            End If
            'Chain message
            f = ChainMsg(newbd, FinalTo, Rmlr(), KeepDirect(), RCount, rtype, NewHdrs, WorkPath, Not Auto, Prevu, Parts, Me, Max, ErrMsg, RemixComp, Chains)
            DelFile newbd
            NewHdrs = ""
            FinalTo = Rmlr(0)
            If Remailer(FinalTo, rtype, "", raddress, "", "", "", "", "") Then FinalTo = raddress
            'Max Added?
            If Max.NeedMax And Not Max.GotMax And f <> "" Then
                If MsgBox(LMsg(268), vbExclamation + vbOKCancel, LMsg(266)) = vbCancel Then ErrMsg = "": DelFile f: f = ""
            End If
            If f = "" Then
                DelFile fn + ".*"
                If QTag <> "" Then DelFile Cnf(0, 1) + "\" + QTag + "*.T*"
                If Index = 0 And BkData(12) = True2 Then DelFile PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*"
                If ErrMsg = "" Then GoTo Leave
                Msg = ErrMsg: GoTo BookError
            End If
                
        Else
            'Plain message
            f = newbd
        End If
        'Count Packets
        If rtype = 1 And SDir(f) = "" And RCount <> 0 Then
            g = f + ".1"
            packs = 0
            While SDir(f + "." + Trim(Str(packs + 1))) <> ""
                If FileLen(f + "." + Trim(Str(packs + 1))) < 28800 Then
                    DelFile (f + ".*")
                    DelFile fn + ".*"
                    Msg = LMsg(166) + vbCr + LMsg(217)
                    GoTo BookError
                End If
                packs = packs + 1
            Wend
        Else
            If rtype = 1 And RCount <> 0 Then
                If FileLen(f) < 28800 Then
                    Msg = LMsg(166) + vbCr + LMsg(217)
                    DelFile f
                    DelFile fn + ".*"
                    GoTo BookError
                End If
            End If
            g = f
            packs = 1
        End If
        totalpacks = totalpacks + packs
        'Prepare Preview
        If Prevu Then
            If RCount = 0 And Nym = "" And Index = 0 Then
                b = LMsg(244): temprtype = -1
                a = b
            Else
                b = LMsg(206): temprtype = rtype
                a = LMsg(197) + " " + b
            End If
            If rtype = 0 Or RCount = 0 Then sendto = "To: " + FinalTo + vbCrLf + NewHdrs Else sendto = NewHdrs
        End If
        For j = 1 To packs
            'Show Preview
            If Prevu Then
                FinishOnly = (i = splitparts - 1) And (j = packs)
                If packs = 1 Then
                    c = Parts
                    g = f
                Else
                    c = Parts + "   [" + LMsg(225) + Str(j) + "/" + Trim(Str(packs)) + "]"
                    g = f + "." + Trim(Str(j))
                End If
                y = PreviewMsg(a, b + "   " + c, "", temprtype, FinishOnly, sendto, g, rtype = 1 And RCount <> 0)
                If y = -1 Or y = 2 Then
                    DelFile fn + ".*"
                    If packs > 1 Then
                        DelFile f + ".*"
                    Else
                        DelFile g
                    End If
                    If QTag <> "" Then DelFile Cnf(0, 1) + "\" + QTag + "*.T*"
                    If Index = 0 And BkData(12) = True2 Then DelFile PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*"
                    GoTo Leave
                End If
                If y = 1 Then Prevu = False
            End If
        Next j
        If splitparts = 1 And rtype = 0 Then ln = FileLen(f)
        If QNum + packs > 1024 Then
            Msg = LMsg(228)
            DelFile fn + ".*"
            GoTo BookError
        End If
        If rtype = 1 And RCount <> 0 Then MsgType = 1 Else MsgType = 0
        Msg = QueMail(f, FinalTo, NewHdrs, MsgBookName(BookX), MsgType, Prof, QTag, QNum, True)
        If Msg <> "" Then
            DelFile fn + ".*"
            GoTo BookError
        End If
    Next i
    
    'Write Archive
    If ArcType <> 0 Then
        '0 No archive.
        '1 Save message and book to Sent folder.
        '2 Save message to Sent folder.
        '3 Save message and book to folder:
        '4 Save message to folder:
        '5 Append message to text file:
        '6 Log message to text file:
        lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(279): lblStat.Refresh
        Msg = LMsg(282)
        a = ""
        If ArcType > 4 Then
            fn = ArcDest
            If SDir(fn) <> "" Then a = vbCrLf + vbCrLf + vbCrLf + vbCrLf
        Else
            Do
                fn = NoSlash(ArcDest) + "\" + MakeTag(8)
            Loop Until SDir(fn + ".*") = ""
            fn = fn + ".ML0"
        End If
        n = FreeFile
        Open fn For Append As n
        'Write Headers
        Print #n, a; "From sent.message@Jack.B.Nymble "; DateLine(1)
        Print #n, "JBN-Book: "; MsgBookName(BookX)
        If Prof = 15 Then a = "UNIX" Else a = UserProf(15 + Prof, 1)
        Print #n, "JBN-Queued-Via: "; a
        a = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 0) + "_*"
        If SDir(a) <> "" Then Print #n, "JBN-Replay: "; a
        Print #n, "Date: "; DateLine(0)
        If splitparts > 1 Then a = "  [" + Trim(Str(splitparts)) + " " + LMsg(224) + "]" Else a = ""
        If Subject <> "" Then Hdrs = "Subject: " + Subject + a + vbCrLf + Hdrs
        If Nym <> "" Then Hdrs = "From: " + Nym + vbCrLf + Hdrs 'X  Else Hdrs = "From: Anonymous" + vbCrLf + Hdrs
        Hdrs = "To: " + ToA + vbCrLf + Hdrs + MixHash
        Print #n, Hdrs; "JBN-Attachments: "
        For i = 0 To AttCount
            If i = 0 Then Print #n, "     Message Body" Else Print #n, "     "; Att(i, 0); vbCrLf;
            Print #n, "          Encode- "; Att(i, 1)
            If Att(i, 2) <> "" Then Print #n, "          Encrypt- "; Att(i, 2)
            If Att(i, 3) <> "" Then Print #n, "          Sign-    "; Att(i, 3)
        Next i
        If RCount <> 0 Then If rtype = 0 Then Print #n, "JBN-Cypherpunk: " Else Print #n, "JBN-Mixmaster: "
        For i = 0 To RCount - 1
            If totalpacks = 1 Then
                r = Rmlr(i)
                If LCase(KeepRmlr(i)) = "auto" Then r = r + "*"
            Else: r = KeepRmlr(i)
            End If
            Print #n, "     "; RemDisp(r, KeepDirect(i), rtype = 1 And i < RCount - 1)
        Next i
        If rtype = 1 And Chains <> 1 Then Print #n, "JBN-Chains:"; Str(Chains)
        If splitparts > 1 Then Print #n, "JBN-Parts:"; Str(splitparts); "   @"; Str(splitx); " "; LMsg(222)
        If totalpacks > 1 And rtype = 1 Then Print #n, "JBN-Packets:"; Str(totalpacks)
        Print #n,
        If ArcType <> 6 And SDir(Att(0, 0)) <> "" And Att(0, 0) <> "" Then
            'Write Body
            p = FreeFile            'Writes body
            Open Att(0, 0) For Input As p
            While Not EOF(p)
                Line Input #p, a
                Print #n, a
            Wend
            Close p: p = 0
            If ArcType = 1 Or ArcType = 3 Then
                'Archive Book With Message
                a = PlainName(fn, 0) + PlainName(fn, 2)
                WriteBook a + ".BK", True
                For i = 0 To ArchiveBookX - 1
                    FileCopy ArchiveBook(i), a + "." + PlainName(ArchiveBook(i), 3)
                Next i
                If BkData(11) <> True2 And Nym <> "" And BkData(12) = True2 Then NewBookName = a + ".BK"
            End If
        End If
        Close n: n = 0
        Msg = ""
        
        'Alert VM Window
        'X  Can't use because of focus bug
        'If ArcType < 5 And ViewerLoaded Then
        '    frmViewer!tmrUpdate.Tag = frmViewer!tmrUpdate.Tag + "F"
        '    frmViewer!tmrUpdate.Enabled = True
        'End If
    End If
    
    'If book wasn't auto-saved, erase replay files
    If Index = 0 And Not (BkData(11) = True2 Or (BkData(12) = True2 And Nym <> "" And ArcType <> 1 And ArcType <> 3)) Then
        DelFile (PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*")
        If NewBookName <> "" Then
            MsgBookName(BookX) = NewBookName
            UpdateDisp
        End If
    End If
        
    'Final Queue Messages
    lblStat.Caption = "": lblStat.Refresh: lblStat.Caption = LMsg(246): lblStat.Refresh
    KeepDate(16) = 0  'Dial when needed
    QBusyTag(BookX) = QTag
    For i = 1 To QNum
        fn = Cnf(0, 1) + "\" + QTag + Right("000" + Trim(Str(i)), 4)
        Name fn + ".T0" As fn + ".Q0"
        Name fn + ".T1" As fn + ".Q1"
    Next i
    QTag = ""
    
    'Display Done
    If splitparts = 1 Then
        If rtype = 0 Then a = "   (" + Trim(Str(Int(ln / 1024 + 0.9999))) + "k)" Else a = ""
    Else
        a = "   [" + Trim(Str(splitparts)) + " " + LMsg(224) + "]"
    End If
    If rtype = 1 And totalpacks <> 1 Then a = a + "   [" + Trim(Str(totalpacks)) + " " + LMsg(226) + "]"
    If Prof = 15 Then b = "UNIX" Else b = UserProf(15 + Prof, 1)
    lblStat.Caption = LMsg(216) + " " + b + "." + a
    SignPass = String(Len(SignPass), "@")
    StartSession (0) 'Read Que
Leave:
    If InStr(lblStat.Caption, LMsg(216)) <> 1 Then lblStat.Caption = LMsg(207)
    Me.MousePointer = 0
    tabBook.Enabled = True
    fraBook(0).Enabled = True
    fraBook(1).Enabled = True
    chkQue(0).Enabled = True
    chkQue(1).Enabled = True
    chkQue(0).Value = 0
    chkQue(1).Value = 0
    mnuMessage.Enabled = True
    DontRepeat = ""
    Unload frmPreview
    LoadList ("Profiles")
    If BookX <> -1 Then QBusyTag(BookX) = "": BookBusy(0, BookX) = False
    NymRun = False
    tmrReload.Enabled = True
    DelFile Body
    On Error Resume Next 'Prevents subscript out of range error
    DelFile Att(0, 0)
    frmMain!filExplore(0).Refresh
    If frmMain!filExplore(1).Visible Then frmMain!filExplore(1).Refresh
    If InStr(lblStat.Caption, LMsg(216)) <> 0 And BkData(18) = True2 Then BkChange = False: tmrReload.Tag = "C": tmrReload.Enabled = True 'Unload me  (avoids page fault in VB6)
Exit Sub
BookError:
    EncoderBusy = False
    If Msg = "" Then Msg = LMsg(0)
    MsgBox Msg + vbCr + Error, vbCritical, LMsg(241)
    CloseFile n
    CloseFile p
    DelFile bd
    If QTag <> "" Then DelFile Cnf(0, 1) + "\" + QTag + "*.*"
    If Index = 0 And BkData(12) = True2 Then DelFile PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._*"
    GoTo Leave
End Sub

Private Function MIMECheck(an) As String
    Dim b As String, ext As String, x As Long
    
    ext = LCase(PlainName(an, 3))
    Select Case ext
    Case "jpg", "jpeg"
        MIMECheck = "MIME base64 image/jpeg"
    Case "gif"
        MIMECheck = "MIME base64 image/gif"
    Case "tiff", "tif"
        MIMECheck = "MIME base64 image/tiff"
    Case "basic", "aiff", "wav"
        MIMECheck = "MIME base64 audio/" + ext
    Case "mpeg", "avi"
        MIMECheck = "MIME base64 video/" + ext
    Case "zip", "exe", "com"
        MIMECheck = "MIME base64 application/octet-stream"
    Case Else
        If BinFile(an) Then
            If ext = "htm" Or ext = "html" Then
                MIMECheck = "MIME QP HTML"
            Else
                MIMECheck = "MIME base64 application/octet-stream"
            End If
        Else
            MIMECheck = "MIME 7bit"
            If ext = "htm" Or ext = "html" Then MIMECheck = "MIME 7bit HTML"
        End If
    End Select
End Function

Private Function MIMEContent(ByVal m As String, fn) As String
    If m = "PGPConv" Then m = "MIME 7bit"
    If m = "None" Then
        ext = LCase(PlainName(fn, 3))
        If ext = "htm" Or ext = "html" Then m = "MIME 7bit HTML" Else m = "MIME 7bit"
    End If
    If Left(m, 9) = "MIME 7bit" Or Left(m, 9) = "MIME 8bit" Or Left(m, 7) = "MIME QP" Then
        If InStr(m, "7bit") <> 0 Then cset = "us-ascii" Else cset = "ISO-8859-1"
        If InStr(m, "HTML") = 0 Then ttype = "plain" Else ttype = "html"
        If InStr(m, "QP") <> 0 Then tenc = "quoted-printable" Else tenc = Mid(m, 6, 4)
        MIMEContent = "Content-Type: text/" + ttype + "; charset=" + cset + vbCrLf + _
                      "Content-Transfer-Encoding: " + tenc + vbCrLf
        Exit Function
    End If
    If Left(m, 11) = "MIME base64" Then tenc = "base64": ttype = Mid(m, 13)
    If Left(m, 3) = "UUE" Then tenc = "x-uuencode": ttype = "application/octet-stream"
    
    If fn <> "" Then name1 = "; name=" + Chr(34) + PlainName(fn, 1) + Chr(34): name2 = "; filename=" + Chr(34) + PlainName(fn, 1) + Chr(34)
    MIMEContent = "Content-Type: " + ttype + name1 + vbCrLf + _
                  "Content-Transfer-Encoding: " + tenc + vbCrLf + _
                  "Content-Disposition: attachment" + name2 + vbCrLf
End Function

Private Function MsgEncode(fn, fn2, m, MIME As Boolean, ErrMsg) As String
    On Error GoTo EncodeError
    If m Like "MIME #bit*" Or m = "None" Then
        MsgEncode = fn
        Exit Function
    End If
    While EncoderBusy
        DoEvents
    Wend
    EncoderBusy = True
    frmMain!NetCode1.Format = 1 'f_Base64
    If InStr(m, "MIME QP") <> 0 Then frmMain!NetCode1.Format = 2 'f_QuotedPrintable
    If m = "UUE" Then frmMain!NetCode1.Format = 0 'f_UUEncode
    frmMain!NetCode1.Filename = PlainName(fn, 1)
    frmMain!NetCode1.DecodedData = fn
    frmMain!NetCode1.EncodedData = fn2
    frmMain!NetCode1.Action = 2 'a_EncodeToFile
    EncoderBusy = False
    If SDir(fn2) = "" Then GoTo EncodeError
    If FileLen(fn2) = 0 Then Err.Description = LMsg(217): GoTo EncodeError
    MsgEncode = fn2
Exit Function
EncodeError:
    EncoderBusy = False
    ErrMsg = LMsg(158) + vbCrLf + Err.Description
    MsgEncode = ""
    DelFile fn2
End Function

Private Sub UpdateDisp()
    If tabBook.SelectedItem.Index = 2 Then txtHeaders(0).Text = txtHeaders(1).Text
    Me.Caption = PlainName(MsgBookName(BookX), 2) + " - " + LMsg(121)
    If lstAttach.ListCount < 2 Then lblAttach.Caption = "" Else lblAttach.Caption = LMsg(122) + ":" + Str(lstAttach.ListCount - 1)
    lblAttach.FontItalic = (cboEncrypt(0).Text <> "") And (chkEncrypt(0).Value = 1)
    For i = 0 To 1
        chkEncrypt(i).FontItalic = (cboEncrypt(i).Text <> "") And (chkEncrypt(i).Value = 1)
    Next i
    If SVal(BkData(0)) < 1 Or SVal(BkData(0)) > 5 Or BkData(5) <> True2 Then BkData(0) = "1"
    lblChains.Caption = "Chains:" + Str(BkData(0))
    lblChains.FontBold = Val(BkData(0)) > 1
End Sub

Private Sub WriteBook(fn, Optional Archive As Boolean)
    Dim temp(MaxChain) As String
    
    Me.MousePointer = 11
    lblStat.Caption = LMsg(124) + " " + fn: Me.Refresh
    UpdateData

    If Archive Then
        tmp1 = BkData(11): BkData(11) = True2  'Turn on Auto-Save On Queue
        tmp3 = BkData(45): BkData(45) = ""       'Turn off Archive
    End If
    
    On Error GoTo WriteError
    n = FreeFile
    Open fn For Output As n
    Print #n, "JBN2_MSGBOOK"
    Print #n, "Jack B. Nymble Message Book - DO NOT EDIT THIS FILE"
    Print #n, "Delete this file at will."
    Print #n, "---Version"
    Print #n, Version
    Print #n,
    WriteArray n, BkData(), "BKData", MaxBK, -1, False
    If lstRemailers.ListCount > 1 Then
        Erase temp
        For i = 0 To lstRemailers.ListCount - 2
            temp(i) = lstRemailers.List(i)
        Next i
        For j = i To MaxChain
            RemDirect(j) = ""
        Next j
        WriteArray n, temp(), "Remailers", lstRemailers.ListCount - 2, -1, True
        WriteArray n, RemDirect(), "RemDirect", lstRemailers.ListCount - 1, -1, False
    End If
    If lstAttach.ListCount > 1 Then
        Erase temp
        For i = 0 To lstAttach.ListCount - 2
            temp(i) = lstAttach.List(i)
        Next i
        WriteArray n, temp(), "Attach", lstAttach.ListCount - 2, -1, True
    End If
    If Archive Then
        BkData(11) = tmp1
        BkData(45) = tmp3
    End If
    Print #n, "---Text"
    If InStr(TextBox.Text, Chr(0)) <> 0 Then TextBox.Text = Replace(TextBox.Text, Chr(0), " ")
    If InStr(TextBox.Text, Chr(26)) <> 0 Then TextBox.Text = Replace(TextBox.Text, Chr(26), " ")
    Print #n, TextBox.Text;
    Close n: n = 0
    lblStat.Caption = LMsg(118) + " " + fn
    frmMain!filExplore(0).Refresh
    If frmMain!filExplore(1).Visible Then frmMain!filExplore(1).Refresh
    Me.MousePointer = 0
    BkChange = False
Exit Sub
WriteError:
    lblStat.Caption = LMsg(82) + " " + fn
    MsgBox LMsg(82) + " " + fn + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
    Me.MousePointer = 0
End Sub

Private Function ReadBook(fn) As Boolean
    Dim temp(MaxChain) As String
    
    Me.MousePointer = 11
    lblStat.Caption = LMsg(123) + " " + fn: Me.Refresh
    BkChange = False
    ClearData
    
    On Error GoTo ReadError
    n = FreeFile
    Open fn For Input As n
    Line Input #n, a
    Select Case a
    Case "JBN2_MSGBOOK"
        Do While Not EOF(n)
            Line Input #n, a
            Select Case a
            Case "---Version"
                If Not EOF(n) Then Line Input #n, BookVersion
            Case "-=-BKData"
                x = ReadArray(n, BkData(), MaxBK, -1)
                If BkData(6) = True2 Then Set TextBox = txtMessage Else Set TextBox = rtbMessage
            Case "-=-Remailers"
                x = ReadArray(n, temp(), MaxChain, -1)
                lstRemailers.Clear
                For i = 0 To x
                    lstRemailers.AddItem temp(i)
                Next i
                lstRemailers.AddItem ""
            Case "-=-RemDirect"
                x = ReadArray(n, RemDirect(), MaxChain, -1)
            Case "-=-Attach"
                x = ReadArray(n, temp(), MaxChain, -1)
                lstAttach.Clear
                For i = 0 To x
                    lstAttach.AddItem temp(i)
                Next i
                lstAttach.AddItem ""
            Case "---Text"
ReadText:
                x = LOF(n) - Seek(n) + 1
                If BkData(6) = True2 And x > 31035 Then
                    MsgBox LMsg(104), vbExclamation, LMsg(105)
                    TextBox.Text = Input(31035, n)
                Else
                    TextBox.Text = Input(x, n)
                End If
                Exit Do
            End Select
        Loop
    Case "JBN_MSGBOOK"
            BkData(7) = "Anon-To: $final" + vbCrLf + "Anon-To: $next" + vbCrLf
            BkData(8) = ""
            BkData(5) = True2
            Do While Not EOF(n)
            Line Input #n, a
            Select Case a
            Case "---Settings"
                While a <> NextPart
                    Line Input #n, a
                    Select Case a
                    Case "Mix"
                        BkData(1) = "1"
                    Case "Rename"
                        BkData(13) = True2
                    Case "8Bit"
                        'chk8Bit.Value = 1
                    Case "AutoTest"
                        MsgBox LMsg(403), vbExclamation
                    Case "Split"
                        BkData(2) = 78
                    End Select
                Wend
            Case "---Headers"
                a = ""
                While a <> NextPart
                    Line Input #n, a
                    x = InStr(a, ": ")
                    If x > 0 Then
                        b = Right(a, Len(a) - x - 1)
                        Select Case Left(a, x - 1)
                        Case "To"
                            BkData(25) = b
                        Case "CC"
                            BkData(26) = b
                        Case "BCC"
                            BkData(27) = b
                        Case "From"
                            BkData(28) = b
                        Case "Nym-Commands"
                            BkData(30) = b
                        Case "Subject"
                            BkData(29) = b
                        End Select
                    End If
                Wend
                If a = NextPart Then
                    For i = 0 To 1
                        Line Input #n, a
                        If a <> NextPart Then
                            Line Input #n, b
                            BkData(31) = BkData(31) + a + " " + b + vbCrLf
                        End If
                    Next i
                End If
            Case "---X-Headers"
                b = ""
                While a <> NextPart
                    Line Input #n, a
                    If a <> NextPart And a <> "" Then BkData(31) = BkData(31) + a + vbCrLf
                Wend
            Case "---Remailers"
                lstRemailers.Clear
                While a <> NextPart
                    Line Input #n, a
                    If a <> NextPart Then
                        lstRemailers.AddItem Extract(a, " ")
                        RemDirect(lstRemailers.NewIndex) = BkData(7 + Val(BkData(1)))
                        If a <> "" Then
                            Remix = False
                            x = InStr(a, "     ;")
                            While x <> 0
                                h = Extract(Extract(Mid(a, x + 6), "     ;"), "::")
                                If InStr(1, h, "Remail-To", vbTextCompare) <> 0 Then h = "Remail-To: $next": Remix = True
                                If InStr(1, h, "Encrypt-To", vbTextCompare) <> 0 Then h = "Remail-To: $next": h = "Encrypt-To: $next": Remix = True
                                If InStr(1, h, "Remix-To", vbTextCompare) <> 0 Then h = "Remail-To: $next": h = "Remix-To: $next": Remix = True
                                AddHeader RemDirect(lstRemailers.NewIndex), h
                                x = InStr(x + 6, a, "     ;")
                            Wend
                            If Remix Then AddHeader RemDirect(lstRemailers.NewIndex), "Anon-To: "
                        End If
                    End If
                Wend
                lstRemailers.AddItem ""
            Case "---Chains"
                Line Input #n, BkData(0)
            Case "---Attachments"
                lstAttach.Clear
                While a <> NextPart
                    Line Input #n, a
                    If a <> NextPart Then
                        If InStr(a, "Encode") <> 0 Then
                            c = Extract(Mid(a, InStr(a, "Encode")), "     ;")
                            c = Trim(Mid(c, InStr(c, ":") + 1))
                            Select Case c
                            Case "UUEncode"
                            Case "PGP Armor": c = "MIME Auto"
                            Case "PGP Conv"
                            Case "None": c = "Text None"
                            Case "MIME TXT": c = "Text Auto"
                            Case "MIME JPG": c = "Base64"
                            Case "MIME GIF": c = "Base64"
                            Case "MIME XXX": c = "Base64"
                            Case "MIME HTM": c = "Text HTML"
                            Case "MIME ALT": c = "Text HTML"
                            Case "MIME 8Bit Text": c = "Text 8Bit"
                            Case Else: c = "MIME Auto"
                            End Select
                            b = "     Encode: " + c
                        Else
                            b = ""
                        End If
                        lstAttach.AddItem Extract(a, "     ") + b
                        If InStr(a, "Encrypt") <> 0 Then BkData(41) = "1"
                        If InStr(a, "Sign") <> 0 Then BkData(42) = "1"
                    End If
                Wend
                lstAttach.AddItem ""
            Case "---Archive"
                While a <> NextPart
                    Line Input #n, a
                    x = InStr(a, ": ")
                    If x > 0 Then
                        b = Right(a, Len(a) - x - 1)
                        Select Case Left(a, x - 1)
                        Case "ArchiveTo"
                            BkData(37) = b
                            BkData(36) = b
                        Case "Mode"
                            If Val(b) = 1 Or Val(b) = 2 Then BkData(33 + Val(b)) = True2
                        End Select
                    End If
                Wend
            Case "---Text"
                While a <> NextPart
                    Line Input #n, a
                    x = InStr(a, ": ")
                    If x > 0 And a <> NextPart Then
                        b = Right(a, Len(a) - x - 1)
                        Select Case Left(a, x - 1)
                        Case "Encrypt"
                            BkData(32) = b
                        Case "Sign"
                            BkData(33) = b
                        End Select
                    End If
                Wend
                GoTo ReadText
            End Select
        Loop
        MsgBox LMsg(102), vbExclamation, LMsg(103)
    Case Else
        Close n: n = 0
        lblStat.Caption = LMsg(108) + " " + fn
        MsgBox LMsg(85) + " " + fn, vbCritical, LMsg(4)
        Me.MousePointer = 0
        ReadBook = False
        Exit Function
    End Select
    Close n: n = 0
    
    'Set
    If SVal(BookVersion) < 2.1 Or (SVal(BookVersion) = 2.1 And SVal(Mid(BookVersion, 5, 1)) = 0) Then
        'Old Archive < 2.1.1
        If BkData(34) = True2 Or BkData(35) = True2 Then
            'Append or log file
            If Trim(BkData(37)) = "" Then
                cboArcType.ListIndex = 0
            Else
                If BkData(34) = True2 Then cboArcType.ListIndex = 5 Else cboArcType.ListIndex = 6
            End If
        Else
            'Copy to folder
            If Trim(BkData(36)) = "" Then
                cboArcType.ListIndex = 0
            Else
                cboArcType.ListIndex = 3
            End If
        End If
        BkData(45) = Str(cboArcType.ListIndex)
        BkData(34) = ""
        BkData(35) = ""
    Else
        If Val(BkData(45)) > cboArcType.ListCount - 1 Then BkData(45) = ""
        cboArcType.ListIndex = Val(BkData(45))
    End If
    cboArcType_Change
    
    For i = 0 To 2
        cboTo(i).Text = BkData(25 + i)
    Next i
    cboNym.Text = BkData(28)
    txtSubject.Text = BkData(29)
    cboNC.Text = BkData(30)
    txtHeaders(0).Text = BkData(31)
    txtHeaders(1).Text = BkData(31)
    cboEncrypt(0).Text = BkData(32)
    cboEncrypt(1).Text = BkData(33)
    cboArchive.Text = BkData(36)
    txtArchive.Text = BkData(37)
    txtWork.Text = BkData(38)
    txtAttach.Text = BkData(39)
    cboEncode.ListIndex = Val(BkData(40))
    chkEncrypt(0).Value = Val(BkData(41))
    chkEncrypt(1).Value = Val(BkData(42))
    chkSplit.Value = Val(BkData(43))
    txtSplit.Text = BkData(44)
    chkSplit_Click
    
    mnuWrapOpt.Checked = Val(BkData(2)) <> 0
    mnuSetSig.Checked = BkData(4) <> ""
    mnuOverrideSMTP.Checked = BkData(10) <> ""
    mnuRemixComp.Checked = BkData(14) = True2
    mnuExpire.Checked = Val(BkData(9)) <> 0
    mnuExpire.Caption = LMsg(267)
    If mnuExpire.Checked Then mnuExpire.Caption = mnuExpire.Caption + "  [" + BkData(9) + "]"
    mnuOption(0).Checked = Not (BkData(5) = True2): mnuOption_Click (0)
    mnuOption(1).Checked = BkData(6) = True2
    If mnuOption(1).Checked Then
        txtMessage.Visible = True
        rtbMessage.Visible = False
    Else
        txtMessage.Visible = False
        rtbMessage.Visible = True
    End If
    For i = 0 To 2
        mnuFileOpt(i).Checked = BkData(11 + i) = True2
    Next i
    mnuFileOpt(3).Checked = BkData(18) = True2
    mnuAttSubject.Checked = BkData(19) = True2
    x = BookRType
    BookRType = Val(BkData(1))
    If Cnf(1, 15) = "" And BookRType = 1 Then MsgBox LMsg(433), vbInformation
    If x <> Val(BkData(1)) Then LoadList ("Remailers")
    If BookRType = 0 Then clr = ColorCPunk Else clr = ColorMix
    cboRemailer.BackColor = clr
    txtCaps.BackColor = clr
    txtRemEdit.BackColor = clr
    lstRemailers.BackColor = clr
    lblAddRemailer.Caption = LMsg(79 + BookRType) + ":"
    If BookRType = 1 Then mnuRType.Caption = LMsg(77) Else mnuRType.Caption = LMsg(78)
    mnuRType.Enabled = BookRType = 1 Or (Cnf(1, 15) <> "")
    cboLatent.Visible = (BookRType = 0) Or mnuOption(0).Checked
    lblChains.Visible = (BookRType = 1) And mnuOption(0).Checked
    If Val(BkData(15)) = 1 Then chkQue(2).Value = 1
    mnuTextEnc(0).Checked = BkData(16) = True2
    mnuTextEnc(1).Checked = BkData(17) = True2
    mnuTxt(21).Checked = mnuTextEnc(0).Checked
    mnuTxt(22).Checked = mnuTextEnc(1).Checked
    
    UpdateDisp
    BkChange = False
    lblStat.Caption = LMsg(107) + " " + fn
    LoadList ("Profiles")
    Me.MousePointer = 0
    ReadBook = True
Exit Function
ReadError:
    lblStat.Caption = LMsg(108) + " " + fn
    MsgBox LMsg(106) + " " + fn + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
    BkChange = False
    Me.MousePointer = 0
    ReadBook = False
End Function

Private Sub UpdateData()
    UpdateDisp
    For i = 0 To 2
        BkData(25 + i) = cboTo(i).Text
    Next i
    BkData(15) = Str(chkQue(2).Value)
    BkData(28) = cboNym.Text
    BkData(29) = txtSubject.Text
    BkData(30) = cboNC.Text
    If InStr(txtHeaders(0).Text, Chr(0)) + InStr(txtHeaders(0).Text, Chr(26)) <> 0 Then txtHeaders(0).Text = Replace(Replace(txtHeaders(0).Text, Chr(0), " "), Chr(26), " ")
    BkData(31) = txtHeaders(0).Text
    BkData(32) = cboEncrypt(0).Text
    BkData(33) = cboEncrypt(1).Text
    BkData(36) = cboArchive.Text
    BkData(37) = txtArchive.Text
    BkData(38) = txtWork.Text
    BkData(39) = txtAttach.Text
    BkData(40) = Str(cboEncode.ListIndex)
    BkData(41) = Str(chkEncrypt(0).Value)
    BkData(42) = Str(chkEncrypt(1).Value)
    BkData(43) = Str(chkSplit.Value)
    BkData(44) = txtSplit.Text
    BkData(45) = Str(cboArcType.ListIndex)
    If InStr(TextBox.Text, Chr(26)) <> 0 Then TextBox.Text = Replace(TextBox.Text, Chr(26), " ")
    If InStr(TextBox.Text, Chr(0)) <> 0 Then TextBox.Text = Replace(TextBox.Text, Chr(0), " ")
End Sub

Private Sub ClearData()
    Erase BkData
    ReDim RemDirect(MaxChain)
    lstRemailers.Clear
    lstRemailers.AddItem ""
    lstAttach.Clear
    lstAttach.AddItem ""
    TextBox.Text = ""
    Set TextBox = rtbMessage
    For i = 0 To 2
        cboTo(i).Text = ""
    Next i
    txtSubject.Text = ""
    cboNC.Text = ""
    cboNym.Text = ""
    cboEncrypt(0).Text = ""
    cboEncrypt(1).Text = ""
    txtHeaders(0).Text = "": txtHeaders(1).Text = ""
    cboRemailer.Text = ""
    cboLatent.Text = ""
End Sub

Private Sub cmdStar_Click(Index As Integer)
    If Index = 0 Then
        em = CleanAddress(Extract(cboTo(0).Text, ","))
    Else
        em = cboNym.Text
    End If
    x = -1
    If em <> "" Then
        For i = 0 To cboEncrypt(0).ListCount - 1
            If InStr(1, cboEncrypt(Index).List(i), em, vbTextCompare) <> 0 Then x = i: Exit For
        Next i
    End If
    If x <> -1 Then
        If cboEncrypt(Index).Text = cboEncrypt(Index).List(x) Then x = -1
    End If
    If x <> -1 Then
        cboEncrypt(Index).ListIndex = x
    Else
        If em = "" Then em = Extract(cboEncrypt(Index), "   ")
        SecretOnly = Index = 1
        cboEncrypt(Index).Text = SelectKey("Select Keys", em)
    End If
End Sub

Private Sub lblAttach_Click()
    tabBook_BeforeClick (0)
    tabBook.Tabs(2).Selected = True
End Sub

Private Sub mnuClear_Click(Index As Integer)
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    If Index = 0 And Val(Cnf(2, 3)) = 1 Then If MsgBox(LMsg(97), vbQuestion + vbOKCancel, LMsg(95)) = vbCancel Then Exit Sub
    If Index = 1 And Val(Cnf(2, 3)) = 1 Then If MsgBox(LMsg(96), vbQuestion + vbOKCancel, LMsg(95)) = vbCancel Then Exit Sub
    TextBox.Text = ""
    BkChange = True
    If Index = 1 Then
        mnuMessClear_Click (0)
        mnuMessClear_Click (1)
        cmdRemailer_Click (1)
        cboEncrypt(0).Text = ""
        cboEncrypt(1).Text = ""
        BkData(0) = "1"
    End If
    UpdateDisp
End Sub

Private Sub mnuConfigBooks_Click()
    ShowConfig (ConfigBooks)
End Sub

Private Sub mnuConfigRem_Click()
    ShowConfig (ConfigRemailers)
End Sub

Private Sub mnuConfigSMTP_Click()
    ShowConfig (ConfigSendProf)
End Sub

Private Sub mnuDisk_Click(Index As Integer)
    On Error GoTo DiskError
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    Select Case Index
    Case 0
        'Open
Query:
        If BkChange And Val(Cnf(2, 2)) = 1 Then
            Select Case MsgBox(LMsg(119), vbQuestion + vbYesNoCancel, MsgBookName(BookX))
            Case vbCancel
                Exit Sub
            Case vbYes
                WriteBook (MsgBookName(BookX))
                GoTo Query
            End Select
        End If
        a = OpenDialog(PlainName(MsgBookName(BookX), 0), "", LMsg(67), _
            cdlOFNHideReadOnly + cdlOFNFileMustExist, _
            "Message Books (*.BK; *.TBK)|*.BK;*.TBK|All Files (*.*)|*.*", 1, Me)
        If a <> "" Then OpenBook a
    Case 1
        'Reopen
        a = MsgBookName(BookX)
        If SDir(a) = "" Then MsgBox LMsg(66) + vbCr + a, vbCritical, LMsg(66): Exit Sub
        If BkChange And Val(Cnf(2, 2)) = 1 Then If MsgBox(LMsg(120), vbQuestion + vbOKCancel, MsgBookName(BookX)) = vbCancel Then Exit Sub
        MsgBookName(BookX) = a
        ReadBook (a)
    Case 2
        'Save
        WriteBook (MsgBookName(BookX))
    Case 3, 4
        'Save As / Template
        ext = LCase(PlainName(MsgBookName(BookX), 3))
        If ext = "bk" Or ext = "tbk" Then fx = 1 Else fx = 3
        If Index = 4 Then fx = 2
        If fx = 3 Then a = PlainName(MsgBookName(BookX), 1) Else a = PlainName(MsgBookName(BookX), 2)
        If Val(Cnf(2, 0)) = 1 Then x = cdlOFNOverwritePrompt Else x = 0
        b = SaveDialog(PlainName(MsgBookName(BookX), 0), a, LMsg(109), _
            cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn + x, _
            "Message Book (*.BK)|*.BK|Template (*.TBK)|*.TBK|All Files (*.*)|*.*", fx, Me)
        If b <> "" Then
            If LCase(PlainName(b, 3)) = "tbk" Then a = PlainName(b, 0) + PlainName(b, 2) + ".BK" Else a = b
            For i = 0 To 9
                If LCase(a) = LCase(MsgBookName(i)) And i <> BookX Then
                    MsgBox LMsg(110), vbCritical, LMsg(4)
                    Exit Sub
                End If
            Next i
            WriteBook (b)
            If LCase(PlainName(b, 3)) = "tbk" Then
                MsgBookName(BookX) = PlainName(b, 0) + PlainName(b, 2) + ".BK"
                lblStat.Caption = LMsg(112) + " " + b
            Else
                MsgBookName(BookX) = b
                lblStat.Caption = LMsg(111) + " " + b
            End If
            UpdateDisp
        End If
    Case 8
        'Name As
        ext = LCase(PlainName(MsgBookName(BookX), 3))
        If ext = "bk" Then a = PlainName(MsgBookName(BookX), 2) Else a = PlainName(MsgBookName(BookX), 1)
        b = Trim(InputBox(LMsg(113), LMsg(114), a))
        If b <> "" Then
            If LCase(PlainName(b, 3)) = "tbk" Then MsgBox LMsg(115), vbCritical, LMsg(4): Exit Sub
            If LCase(PlainName(b, 3)) = "" Then b = b + ".BK"
            If InStr(b, "\") = 0 Then b = PlainName(MsgBookName(BookX), 0) + b
            For i = 0 To 9
                If LCase(b) = LCase(MsgBookName(i)) And i <> BookX Then
                    MsgBox LMsg(110), vbCritical, LMsg(4)
                    Exit Sub
                End If
            Next i
            MsgBookName(BookX) = b
            lblStat.Caption = LMsg(116) + " " + b
            BkChange = True
            UpdateDisp
        End If
    Case 9
        'Autoname
        MsgBookName(BookX) = AutoName(MsgBookName(BookX))
        lblStat.Caption = LMsg(116) + " " + MsgBookName(BookX)
        BkChange = True
        UpdateDisp
    Case 12, 13
        'Load/Insert Text
        a = OpenDialog(PlainName(PData(40), 0), PlainName(PData(40), 1), LMsg(67), _
            cdlOFNHideReadOnly + cdlOFNFileMustExist, _
            "All Files (*.*)|*.*", 1, Me)
        If a <> "" Then
            If Index = 12 Then TextBox.Text = ""
            InsertFile a
            PData(40) = a
        End If
    Case 14
        'Save Text As
        If Val(Cnf(2, 1)) = 1 Then x = cdlOFNOverwritePrompt Else x = 0
        b = SaveDialog(PlainName(PData(40), 0), PlainName(PData(40), 1), LMsg(117), _
            cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn + x, _
            "All Files (*.*)|*.*", 1, Me)
        If b <> "" Then
            n = FreeFile
            Open b For Output As n
            Print #n, TextBox.Text;
            Close n: n = 0
            lblStat.Caption = LMsg(118) + " " + b
            PData(40) = b
        End If
    Case 15
        'Print
        Printer.Print ""
        TextBox.SelPrint (Printer.hDC)
    Case 17, 18
        'Close / Save and Close
        If Index = 18 Then WriteBook (MsgBookName(BookX))
        Unload Me
    End Select
Exit Sub
DiskError:
    MsgBox LMsg(0) + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
End Sub

Private Sub OpenBook(fn)
    MsgBookName(BookX) = fn
    ReadBook (fn)
    If LCase(PlainName(MsgBookName(BookX), 3)) = "tbk" Then
        a = MsgBookName(BookX)
        If BkData(13) = True2 Then
            MsgBookName(BookX) = AutoName(MsgBookName(BookX))
        Else
            MsgBookName(BookX) = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + ".BK"
        End If
        lblStat.Caption = a + " " + LMsg(125) + " " + PlainName(MsgBookName(BookX), 1)
    End If
    UpdateDisp
End Sub

Private Sub InsertFile(fn)
    On Error GoTo InsertError
    n = FreeFile
    Open fn For Input As n
    If BkData(6) = True2 And LOF(n) + Len(TextBox.Text) - Len(TextBox.SelText) > 31035 Then
        MsgBox LMsg(104), vbExclamation, LMsg(105)
        TextBox.SelText = Input(31035, n)
    Else
        TextBox.SelText = Input(LOF(n), n)
    End If
    Close n: n = 0
Exit Sub
InsertError:
    xErr = Err.Number
    CloseFile n
    Err.Raise xErr
End Sub

Private Function AutoName(bk) As String
    Dim i As Long
    bkpath = PlainName(bk, 0)
    ext = PlainName(bk, 3)
    If LCase(ext) = "tbk" Or ext = "" Then ext = "BK"
    bn = Trim(PlainName(bk, 2))
    If bn = "" Then bn = "book"
    For i = Len(bn) To 1 Step -1
        If Not IsNumeric(Mid(bn, i, 1)) Then Exit For
    Next i
    If i > 0 Then bnr = Left(bn, i) Else bnr = "book"
    If Right(bnr, 1) <> "_" Then bnr = bnr + "_"
    For i = 0 To 99999
        If i < 100 Then b = Right("0" + Trim(Str(i)), 2) Else b = Trim(Str(i))
        If i = 0 Then a = bkpath + Left(bnr, Len(bnr) - 1) + "." + ext Else a = bkpath + bnr + b + "." + ext
        If SDir(a) = "" Then
            AutoName = a
            Exit Function
        End If
    Next i
    AutoName = bk
End Function

Private Sub mnuEditArray_Click(Index As Integer)
    On Error Resume Next
    Select Case Index
    Case 0
        SendKeys "^z", True
    Case 1
        SendKeys "^c", True
    Case 2
        a = Clipboard.GetText
        SendKeys "^c", True
        a = a + Clipboard.GetText
        Clipboard.Clear
        Clipboard.SetText a
    Case 3
        SendKeys "^x", True
    Case 4
        SendKeys "^v", True
    End Select
End Sub

Private Sub mnuFileOpt_Click(Index As Integer)
    mnuFileOpt(Index).Checked = Not mnuFileOpt(Index).Checked
    Select Case Index
    Case Is < 3
        BkData(11 + Index) = mnuFileOpt(Index).Checked
    Case 3
        BkData(18) = mnuFileOpt(Index).Checked
    End Select
    BkChange = True
End Sub

Private Sub mnuFind_Click(Index As Integer)
    Dim initpos As Long, x As Long
    If tabBook.SelectedItem.Index = 2 Then Exit Sub
    If Index = 1 And LastFindString = "" Then Index = 0
    If Index = 0 Then
        f = InputBox(LMsg(92), LMsg(93), LastFindString)
        If f = "" Then Exit Sub
        LastFindString = f
    End If
    initpos = TextBox.SelStart + 1
    x = InStr(initpos + 1, TextBox.Text, LastFindString, vbTextCompare)
    If x = 0 Then x = InStr(1, TextBox.Text, LastFindString, vbTextCompare)
    If x <> 0 Then
        TextBox.SelStart = x - 1
        TextBox.SelLength = Len(LastFindString)
    Else
        TextBox.SelLength = 0
        Beep
    End If
End Sub

Private Sub mnuOverrideSMTP_Click()
    BkData(10) = Trim(InputBox(LMsg(98) + vbCr + vbCr + LMsg(83), LMsg(99), BkData(10)))
    mnuOverrideSMTP.Checked = BkData(10) <> ""
    BkChange = True
    LoadList ("Profiles")
End Sub

Private Sub mnuPasteQuote_Click()
    Dim b As String, bl As Integer
    Dim cb As String
    
    On Error GoTo PasteError
    a = Clipboard.GetText
    If a = "" Then Exit Sub
    bl = Val(BkData(2)): If bl = 0 Then bl = 80
    fn = SplitLines(a, bl, ErrMsg, Cnf(2, 18))
    If fn <> "" Then
        n = FreeFile
        Open fn For Input As n
        b = Input(LOF(n), n)
        Close n: n = 0
        DelFile fn
        On Error Resume Next
        TextBox.SelText = b
    Else
        Err.Description = ErrMsg
        GoTo PasteError
    End If
Exit Sub
PasteError:
    MsgBox LMsg(0) + vbCrLf + Err.Description, vbCritical, LMsg(4)
    CloseFile n
End Sub

Private Sub mnuPasteSig_Click()
    On Error Resume Next
    If BkData(4) <> "" Then TextBox.SelText = BkData(4) Else TextBox.SelText = Cnf(2, 19)
End Sub

Private Sub mnuRemixComp_Click()
    mnuRemixComp.Checked = Not mnuRemixComp.Checked
    BkData(14) = mnuRemixComp.Checked
    BkChange = True
End Sub

Private Sub mnuExpire_Click()
    BkData(9) = Trim(Str(Abs(SVal(InputBox(LMsg(264) + vbCrLf + vbCrLf + LMsg(265), LMsg(266), BkData(9))))))
    mnuExpire.Checked = Val(BkData(9)) <> 0
    mnuExpire.Caption = LMsg(267)
    If mnuExpire.Checked Then mnuExpire.Caption = mnuExpire.Caption + "  [" + BkData(9) + "]"
    BkChange = True
End Sub

Private Sub mnuSelectAll_Click()
    TextBox.SelStart = 0
    TextBox.SelLength = Len(TextBox.Text)
End Sub

Private Sub mnuSetSig_Click()
    BkData(4) = MultiBox(LMsg(86) + vbCr + vbCr + LMsg(83), LMsg(87), BkData(4))
    If Trim(Replace(BkData(4), vbCrLf, "")) = "" Then BkData(4) = ""
    mnuSetSig.Checked = BkData(4) <> ""
    BkChange = True
End Sub

Private Sub mnuShowAuto_Click()
    GetRandom RemDirect(), RemDirect(), 0, BookRType, "", 0, False, False
End Sub

Private Sub mnuStats_Click(Index As Integer)
    Select Case Index
    Case 0  'Refresh Stats
        lblStat.Caption = LMsg(394)
        CallBrowser 1, ""
    Case 1  'View Stats
        CallBrowser 0, ProgDir + "\Stats\stats.htm"
    Case 2, 3 'Update CPunk/Mix Keys
        CallBrowser Index, ""
    End Select
End Sub

Private Sub mnuTextEnc_Click(Index As Integer)
    mnuTextEnc(Index).Checked = Not mnuTextEnc(Index).Checked
    If mnuTextEnc(Index).Checked Then mnuTextEnc(Abs(Index - 1)).Checked = False
    BkData(16) = mnuTextEnc(0).Checked
    BkData(17) = mnuTextEnc(1).Checked
    mnuTxt(21).Checked = mnuTextEnc(0).Checked
    mnuTxt(22).Checked = mnuTextEnc(1).Checked
End Sub

Private Sub mnuTxt_Click(Index As Integer)
    Select Case Index
    Case 0, 1, 2, 3, 4: mnuEditArray_Click (Index)
    Case 5: mnuPasteQuote_Click
    Case 6: mnuPasteSig_Click
    Case 8: mnuFind_Click (0)
    Case 9: mnuFind_Click (1)
    Case 11, 12: mnuWrap_Click (Index - 11)
    Case 13: mnuSelectAll_Click
    Case 14: mnuClear_Click (0)
    Case 16, 17, 18, 19: mnuDisk_Click (Index - 4)
    Case 21, 22: mnuTextEnc_Click (Index - 21)
    End Select
End Sub

Private Sub mnuViewRing_Click(Index As Integer)
    If Index = 0 Then
        SelectKey (LMsg(415))
    Else
        ShowConfig ConfigRemailers, 3
    End If
End Sub

Private Sub rtbMessage_DblClick()
    If tabBook.Enabled And Val(Cnf(2, 10)) = 1 Then
        If tabBook.SelectedItem.Index = 1 Then x = 3 Else x = 1
        tabBook.Tabs(x).Selected = True
        TextBox.SetFocus
        ViewDblClick = True
    End If
End Sub

Private Sub txtMessage_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        txtMessage.Enabled = False
        DoEvents
        Me.PopupMenu mnuText
        txtMessage.Enabled = True
    Else
        ViewSelStart = TextBox.SelStart
        ViewSelLength = TextBox.SelLength
    End If
End Sub

Private Sub txtMessage_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    If ViewDblClick Then
        TextBox.SelStart = ViewSelStart
        TextBox.SelLength = ViewSelLength
        ViewDblClick = False
    End If
End Sub

Private Sub rtbMessage_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        PopupMenu mnuText
    Else
        ViewSelStart = TextBox.SelStart
        ViewSelLength = TextBox.SelLength
    End If
End Sub

Private Sub rtbMessage_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    If ViewDblClick Then
        TextBox.SelStart = ViewSelStart
        TextBox.SelLength = ViewSelLength
        ViewDblClick = False
    End If
End Sub

Private Sub txtMessage_DblClick()
    rtbMessage_DblClick
End Sub

Private Sub txtHeaders_MouseDown(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    ViewSelStart = txtHeaders(Index).SelStart
    ViewSelLength = txtHeaders(Index).SelLength
End Sub

Private Sub txtHeaders_DblClick(Index As Integer)
    If Index = 2 Or Val(Cnf(2, 10)) <> 1 Then Exit Sub
    y = txtHeaders(Index).SelStart
    If tabBook.SelectedItem.Index = 1 Then x = 2 Else x = 1
    tabBook.Tabs(x).Selected = True
    txtHeaders(tabBook.SelectedItem.Index - 1).SelLength = 0
    txtHeaders(tabBook.SelectedItem.Index - 1).SelStart = y
    txtHeaders(tabBook.SelectedItem.Index - 1).SetFocus
    ViewDblClick = True
End Sub

Private Sub txtHeaders_MouseUp(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    If ViewDblClick Then
        txtHeaders(Abs(Index - 1)).SelStart = ViewSelStart
        txtHeaders(Abs(Index - 1)).SelLength = ViewSelLength
        ViewDblClick = False
    End If
End Sub

Private Sub txtAttach_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then cmdAttach_Click (0)
End Sub

Private Sub mnuReply_Click(Index As Integer)
    On Error Resume Next
    Msg = Clipboard.GetText
    On Error GoTo 0
    ReplyMsg Msg, Index
End Sub

Private Sub ReplyMsg(Msg, ByVal Job As Byte)
    'Job = 0 Reply to Clip
    'Job = 1 Followup clip
    'Job = 2 Reply to file
    'Job = 3 Followup file
    
    Dim x As Long, MH As MHeadersType
    
    Debug.Print "Reply"
    Err.Clear
    On Error GoTo ReplyError
    Me.MousePointer = 11
    If Job < 2 Then
        If InStr(Msg, Chr(0)) <> 0 Then Msg = Replace(Msg, Chr(0), " ")
        If InStr(Msg, Chr(26)) <> 0 Then Msg = Replace(Msg, Chr(26), " ")
        fn = GetWork
        n = FreeFile
        Open fn For Output As n
        Print #n, Msg;
        Close n: n = 0
    Else
        fn = Msg
    End If
    
    'Parse Headers
    n = FreeFile
    Open fn For Input As n
    Do While Not EOF(n)
        Line Input #n, a
Parse:  x = InStr(a, ":")
        If x <> 0 Then h = Trim(Left(a, x - 1)) Else h = ""
        b = Trim(Mid(a, x + 1))
        If x = 0 Then
            If b = "" Then Exit Do
        Else
            c = "": a2 = EndPart
            Do While Not EOF(n)
                Line Input #n, a
                If InStr(a, ":") <> 0 Or Left(a, 1) <> " " Or Trim(a) = "" Then a2 = a: Exit Do
                c = c + a + " "
            Loop
            If b = "" Then b = Trim(c) Else b = Trim(b + " " + Trim(c))
            Select Case LCase(h)
            Case "from": MH.From = b
            Case "reply-to": MH.ReplyTo = b
            Case "subject": MH.Subject = b
            Case "newsgroups": MH.Newsgroups = Replace(b, " ", "")
            Case "followup-to": MH.FollowupTo = Replace(b, " ", "")
            Case "x-no-archive": MH.XNoArchive = b
            Case "message-id": MH.MessageID = b
            Case "references": MH.References = b
            Case "in-reply-to": MH.InReplyTo = b
            Case "author-address": MH.AuthorAddress = b
            Case "date": MH.Date = b
            End Select
            headersfound = True
            If a2 <> EndPart Then a = a2: GoTo Parse
        End If
    Loop
    Do
        If EOF(n) Then a = "": Exit Do
        Line Input #n, a
    Loop Until Trim(a) <> ""
    
    'Prompt Quote in Reply
    If Cnf(2, 17) <> False2 Then
        qr = MsgBox(LMsg(277), vbYesNoCancel, LMsg(278))
        If qr = vbCancel Then Exit Sub
    Else
        If Cnf(2, 15) <> False2 Then qr = vbYes Else qr = vbNo
    End If
        
    'Read Body
    If qr = vbYes Then
        If Not headersfound Then
            x = 0
            a = ""
            Close n: n = 0
            n = FreeFile
            Open fn For Input As n
        Else
            x = Seek(n) - 1
        End If
        If a <> "" Then a = a + vbCrLf
        Body = a + Input(LOF(n) - x, n)
        Close n: n = 0
        Do While Right(Body, 2) = vbCrLf
            Body = RTrim(Left(Body, Len(Body) - 2))
        Loop
        '~~~
        'This PGP signature only certifies the receipt and date of the message.
        x = InStr(Body, vbCrLf + "~~~" + vbCrLf + "This PGP signature only certifies the receipt and date of the message." + vbCrLf)
        If x <> 0 Then Body = Left(Body, x + 1)
    End If
    Close n: n = 0
    If Job < 2 Then DelFile fn
    
    'Knead Headers
    OFrom = MH.From
    OSubject = MH.Subject
    If MH.ReplyTo <> "" Then MH.From = MH.ReplyTo
    If MH.AuthorAddress <> "" Then MH.From = Replace(Replace(MH.AuthorAddress, " <DOT> ", "."), " <AT> ", "@")
    If LCase(Left(MH.Subject, 3)) <> "re:" Then MH.Subject = "Re: " + MH.Subject
    If MH.FollowupTo <> "" Then MH.Newsgroups = MH.FollowupTo
    If MH.InReplyTo <> "" And MH.InReplyTo <> MessageID And MH.InReplyTo <> MH.References Then MH.References = MH.References + " " + MH.InReplyTo
    If MH.References <> "" Then MH.References = MH.References + " " + MH.MessageID Else MH.References = MH.MessageID
    If Len(MH.References) > 256 Then
        MH.References = Right(MH.References, 256)
        x = InStr(MH.References, ">")
        y = InStr(MH.References, "<")
        If x <> 0 And (y = 0 Or x < y) Then MH.References = LTrim(Mid(MH.References, x + 1))
    End If
    If MH.Newsgroups = "" Then MH.Newsgroups = " "
    If MH.References = "" Then MH.References = " "
    
    'Set Headers
    If Job = 0 Or Job = 2 Or cboTo(0).Text = "" Then cboTo(0).Text = CleanAddress(MH.From)
    txtSubject.Text = MH.Subject
    cboHeaders(0).Text = ""
    If (Job = 1 Or Job = 3) And (LCase(cboTo(0).Text) Like "anon-post-to:*" Or LCase(cboTo(0).Text) Like "post:*") Then
        If LCase(cboTo(0).Text) Like "anon-post-to:*" Then cboTo(0).Text = "Anon-Post-To: " Else cboTo(0).Text = "Post: "
        cboTo(0).Text = cboTo(0).Text + MH.Newsgroups
        cboHeaders(0).Text = "Newsgroups: "
    Else
        cboHeaders(0).Text = "Newsgroups: " + MH.Newsgroups
    End If
    cboHeaders(0).Text = "References: " + MH.References
    If LCase(MH.XNoArchive) = "yes" Then cboHeaders(0).Text = "X-No-Archive: yes"
    cboHeaders(0).Text = ""
        
    If qr = vbYes Then
        bl = Val(BkData(2)): If bl = 0 Then bl = 80
        fn2 = SplitLines(Body, bl, ErrMsg, Cnf(2, 18))
        If fn2 <> "" Then
            n = FreeFile
            Open fn2 For Input As n
            b = Input(LOF(n), n)
            Close n: n = 0
            DelFile fn2
            
            'Reply heading
            If Trim(MH.Newsgroups) = "" Then a = Cnf(2, 28) Else a = Cnf(2, 29)
            If a <> "" And a <> "<< NONE >>" Then
                a = a + vbCrLf
                a = Replace(a, "$newsgroups", Trim(MH.Newsgroups))
                a = Replace(a, "$newsgroup", Trim(Extract(MH.Newsgroups, ",")))
                a = Replace(a, "$datetime", MH.Date)
                c = MH.Date
                If InStr(c, ":") > 2 Then c = RTrim(Left(c, InStr(c, ":") - 3))
                a = Replace(a, "$date", c)
                a = Replace(a, "$address", CleanAddress(OFrom))
                a = Replace(a, "$from", OFrom)
                '$name
                c = OFrom
                y = InStr(c, Chr(34))
                If y <> 0 Then
                    'Use part in quotes
                    c = Extract(Mid(c, y + 1), Chr(34))
                Else
                    y = InStr(c, "(")
                    If y <> 0 Then
                        'Use part in parenthesis
                        c = Extract(Mid(c, y + 1), ")")
                    Else
                        If Left(Trim(c), 1) <> "<" And InStr(c, "<") <> 0 Then
                            c = Trim(Extract(c, "<"))
                        End If
                    End If
                End If
                a = Replace(a, "$name", c)
                a = Replace(a, "$message-id", MH.MessageID)
                a = Replace(a, "$messageid", MH.MessageID)
                a = Replace(a, "$subject", OSubject)
            Else
                a = ""
            End If
            On Error Resume Next
            TextBox.SelLength = 0
            TextBox.SelText = a + b + vbCrLf
        Else
            Err.Description = ErrMsg
            GoTo ReplyError
        End If
    End If
    Me.MousePointer = 0
Exit Sub
ReplyError:
    MsgBox LMsg(0) + vbCr + Err.Description, vbCritical, LMsg(4)
    CloseFile n
    If Job < 2 Then DelFile fn
    DelFile fn2
    Me.MousePointer = 0
End Sub

Private Sub mnuWrap_Click(Index As Integer)
    Dim a As String, x As Long
    
    On Error GoTo WrapError
    If Index = 0 Then
        'Hard Wrap
        bl = Val(BkData(2)): If bl = 0 Then bl = 70
        If TextBox.SelLength = 0 Then
            fn = SplitLines(TextBox.Text, bl, ErrMsg)
            If fn <> "" Then
                If BkData(6) = True2 Then
                    'Alt Text Box
                    n = FreeFile
                    Open fn For Input As n
                    x = LOF(n): If x > 31035 Then x = 0: MsgBox LMsg(94), vbCritical, LMsg(4)
                    a = Input(x, n)
                    Close n: n = 0
                    If x <> 0 Then txtMessage.Text = a
                Else
                    rtbMessage.LoadFile fn
                End If
            Else
                Err.Description = ErrMsg
                GoTo WrapError
            End If
        Else
            fn = SplitLines(TextBox.SelText, bl, ErrMsg)
            If fn <> "" Then
                n = FreeFile
                Open fn For Input As n
                x = LOF(n): If BkData(6) = True2 And x + Len(TextBox.Text) - Len(TextBox.SelText) > 31035 Then x = 0: MsgBox LMsg(94), vbCritical, LMsg(4)
                a = Input(x, n)
                Close n: n = 0
                If x <> 0 Then
                    x = TextBox.SelStart
                    TextBox.SelText = a
                    TextBox.SelStart = x
                    TextBox.SelLength = Len(a)
                End If
            Else
                Err.Description = ErrMsg
                GoTo WrapError
            End If
        End If
        DelFile fn
    Else
        'Join Lines
        If TextBox.SelLength = 0 Then
            If Index = 2 Then MsgBox LMsg(576), vbInformation: Exit Sub
            TextBox.Text = JoinLines(TextBox.Text, Index = 2)
        Else
            x = TextBox.SelStart
            a = JoinLines(TextBox.SelText, Index = 2)
            TextBox.SelText = a
            TextBox.SelStart = x
            TextBox.SelLength = Len(a)
        End If
        If Index = 2 Then mnuWrap_Click (0)
    End If
Exit Sub
WrapError:
    MsgBox LMsg(0) + vbCrLf + Err.Description, vbCritical, LMsg(4)
    CloseFile n
    DelFile fn
End Sub

Private Sub mnuWrapOpt_Click()
    b = Trim(BkData(2))
    If Val(b) = 0 Then b = "70"
    b = Left(InputBox(LMsg(81) + vbCr + vbCr + LMsg(83), LMsg(84), b), 5)
    x = Int(Abs(Val(b))): If x > 32000 Then x = 32000
    BkData(2) = Str(x)
    mnuWrapOpt.Checked = x <> 0
    BkChange = True
End Sub

Private Sub rtbMessage_Change()
    BkChange = True
End Sub

Private Sub txtMessage_Change()
    BkChange = True
End Sub

Private Sub rtbmessage_KeyDown(KeyCode As Integer, Shift As Integer)
    'To prevent RTF pastes
    If KeyCode = 86 And Shift = 2 Then a = Clipboard.GetText: Clipboard.Clear: Clipboard.SetText a
    'To stop beeping
    If KeyCode < 41 Then
        Select Case KeyCode
        Case vbKeyDown: If rtbMessage.GetLineFromChar(rtbMessage.SelStart) = rtbMessage.GetLineFromChar(Len(rtbMessage.Text)) Then KeyCode = 0
        Case vbKeyRight: If rtbMessage.SelStart = Len(rtbMessage.Text) Then KeyCode = 0
        Case vbKeyUp: If rtbMessage.GetLineFromChar(rtbMessage.SelStart) = 0 Then If rtbMessage.SelLength = 0 Then KeyCode = 0
        Case vbKeyLeft: If rtbMessage.SelStart = 0 Then If rtbMessage.SelLength = 0 Then KeyCode = 0
        End Select
    End If
End Sub

Private Sub mnuOption_Click(Index As Integer)
    mnuOption(Index).Checked = Not mnuOption(Index).Checked
    BkData(5 + Index) = mnuOption(Index).Checked
    Select Case Index
    Case 0
        'Show Advanced
        If Not mnuOption(0).Checked Then
            If fraRemEdit.Visible Then cmdRemEdit_Click (0)
            lblChains.Visible = False
            BkData(0) = "0"
            cboNC.Text = ""
        Else
            lblChains.Visible = BookRType = 1
            UpdateDisp
        End If
        cboLatent.Visible = (BookRType = 0) Or mnuOption(0).Checked
        lblNC.Visible = mnuOption(0).Checked
        cboNC.Visible = mnuOption(0).Checked
    Case 1
        'Alternate Text Box
        If mnuOption(1).Checked Then
            If MsgBox(LMsg(88) + vbCr + vbCr + LMsg(83), vbQuestion + vbOKCancel, LMsg(89)) = vbCancel Then mnuOption(1).Checked = False: BkData(6) = False2: Exit Sub
            txtMessage.Text = Left(rtbMessage.Text, 31035)
            rtbMessage.Text = ""
            rtbMessage.Visible = False
            txtMessage.Visible = True
            Set TextBox = txtMessage
        Else
            rtbMessage.Text = txtMessage.Text
            txtMessage.Text = ""
            txtMessage.Visible = False
            rtbMessage.Visible = True
            Set TextBox = rtbMessage
        End If
    End Select
    BkChange = True
End Sub

Private Sub mnuRType_Click()
    BookRType = Abs(BookRType - 1)
    BkData(1) = Str(BookRType)
    Me.MousePointer = 11
    cmdRemailer_Click (2)
    If BookRType = 0 Then clr = ColorCPunk Else clr = ColorMix
    cboRemailer.BackColor = clr
    txtCaps.BackColor = clr
    txtRemEdit.BackColor = clr
    lstRemailers.BackColor = clr
    lblAddRemailer.Caption = LMsg(79 + BookRType) + ":"
    cboLatent.Visible = (BookRType = 0) Or mnuOption(0).Checked
    lblChains.Visible = (BookRType = 1) And mnuOption(0).Checked
    BkData(0) = "1"
    UpdateDisp
    If BookRType = 1 Then mnuRType.Caption = LMsg(77) Else mnuRType.Caption = LMsg(78)
    mnuRType.Enabled = BookRType = 1 Or (Cnf(1, 15) <> "")
    Me.Refresh
    LoadList ("Remailers")
    BkChange = True
    Me.MousePointer = 0
End Sub

Private Sub cmdRemEdit_Click(Index As Integer)
    Select Case Index
    Case 0
        If fraRemEdit.Visible Then
            If Right(txtHeaders(2).Text, 2) <> vbCrLf Then If txtHeaders(2).Text <> "" Then txtHeaders(2).Text = txtHeaders(2).Text + vbCrLf
            UpRemData Me, RemDirect(Val(lstRemailers.Tag))
            fraRemEdit.Visible = False
            lstRemailers_Click
        End If
    Case 1
        If lstRemailers.ListIndex = -1 Then cmdRemEdit_Click (0): Exit Sub
        If lstRemailers.List(lstRemailers.ListIndex) = "" Then cmdRemEdit_Click (0): Exit Sub
        lstRemailers.Tag = ""
        lstRemailers.List(lstRemailers.ListIndex) = RemDisp(lstRemailers.List(lstRemailers.ListIndex), RemDirect(lstRemailers.ListIndex))
        fraRemEdit.Visible = False
        lstRemailers_Click
    Case 2
        txtHeaders(2).SetFocus
        If MsgBox(LMsg(74) + vbCrLf + vbCrLf + LMsg(75), vbExclamation + vbYesNo + vbDefaultButton2, LMsg(76)) = vbNo Then Exit Sub
        If Replace(Replace(txtHeaders(2).Text, " ", ""), vbCrLf, "") = "" Then txtHeaders(2).Text = ""
        BkData(7 + BookRType) = txtHeaders(2).Text
    End Select
End Sub

Private Sub cboRemailer_click()
    x = lstRemailers.ListIndex
    If x = -1 Then x = lstRemailers.ListCount - 1
    If x = lstRemailers.ListCount - 1 Then Job = 0 Else Job = 1
    If Job = 0 And (lstRemailers.ListCount > MaxChain Or (BookRType = 1 And lstRemailers.ListCount > 20)) Then Exit Sub
    AddRemailer cboRemailer.Text, x, Job
End Sub

Private Sub cboRemailer_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = 38 Or KeyCode = 40 Then KeyCode = 0
End Sub

Private Sub cboRemailer_KeyUp(KeyCode As Integer, Shift As Integer)
    If KeyCode = 38 Or KeyCode = 40 Then KeyCode = 0: Exit Sub
    x = lstRemailers.ListIndex
    If x = -1 Then x = lstRemailers.ListCount - 1
    If x = lstRemailers.ListCount - 1 Then
        x = lstRemailers.ListIndex: If x = -1 Then x = 0
        cboRemailer_click
        If x < lstRemailers.ListCount Then lstRemailers.ListIndex = x
        cboRemailer.SetFocus
        cboRemailer.SelStart = Len(cboRemailer.Text)
        cboRemailer.SelLength = 0
    Else
        rn = Extract(LTrim(cboRemailer.Text), " ")
        If rn = "" Then rn = "AUTO"
        y = InStr(lstRemailers.List(x), " ")
        If y = 0 Then y = Len(lstRemailers.List(x)) + 1
        lstRemailers.List(x) = RemDisp(rn, RemDirect(x))
        If fraRemEdit.Visible Then ShowRemailer Me, x, BookRType
    End If
End Sub

Private Sub cboRemailer_KeyPress(KeyAscii As Integer)
    If BookRType = 1 Then KeyAscii = 0
    If KeyAscii = 13 Then lstRemailers_DblClick
End Sub

Private Sub AddRemailer(ByVal rn As String, x, Job)
    BkChange = True
    rn = Extract(LTrim(rn), " ")
    If rn = "" Then rn = "AUTO"
    If Job = 0 Then
        'Add remailer
        If fraRemEdit.Visible Then UpRemData Me, RemDirect(Val(lstRemailers.Tag))
        If BkData(7 + BookRType) = "" And BookRType = 0 Then BkData(7 + BookRType) = "Anon-To: $final" + vbCrLf + "Anon-To: $next" + vbCrLf
        rd = BkData(7 + BookRType)
        If rn = "AUTO" Then lt = "" Else lt = Trim(cboLatent.Text)
        If lt <> "" Then AddHeader rd, "Latent-Time: " + lt
        lstRemailers.AddItem RemDisp(rn, rd, (BookRType = 1 And x < lstRemailers.ListCount - 1)), x
        For i = lstRemailers.ListCount - 2 To x Step -1
            RemDirect(i + 1) = RemDirect(i)
        Next i
        RemDirect(lstRemailers.NewIndex) = rd
        If fraRemEdit.Visible Then lstRemailers.Tag = Str(x + 1)
        If BookRType = 1 And lstRemailers.NewIndex = lstRemailers.ListCount - 2 And lstRemailers.ListCount > 2 Then
            lstRemailers.List(lstRemailers.NewIndex - 1) = Extract(lstRemailers.List(lstRemailers.NewIndex - 1), " ")
        End If
        If rn = "AUTO" Then
            lstRemailers.ListIndex = lstRemailers.NewIndex
        Else
            lstRemailers.ListIndex = x + 1
        End If
        lstRemailers_Click
    Else
        'Change remailer
        y = InStr(lstRemailers.List(x), " ")
        If y = 0 Then y = Len(lstRemailers.List(x)) + 1
        lstRemailers.List(x) = RemDisp(rn, RemDirect(x))
        lstRemailers.ListIndex = x + 1
        lstRemailers_Click
    End If
End Sub

Private Sub cmdRemailer_Click(Index As Integer)
    Select Case Index
    Case 0
        'Add
        x = lstRemailers.ListIndex
        If x = -1 Then x = lstRemailers.ListCount - 1
        If lstRemailers.ListCount > MaxChain Or (BookRType = 1 And lstRemailers.ListCount > 20) Then Exit Sub
        AddRemailer "AUTO", x, 0
    Case 1
        'Remove
        x = lstRemailers.ListIndex
        If x = -1 Then Exit Sub
        If lstRemailers.List(x) = "" Then Exit Sub
        lstRemailers.RemoveItem x
        For i = x To lstRemailers.ListCount - 2
            RemDirect(i) = RemDirect(i + 1)
        Next i
        lstRemailers.Tag = ""
        If (BookRType = 1) And (x = lstRemailers.ListCount - 1) And x > 0 Then lstRemailers.List(x - 1) = RemDisp(Extract(lstRemailers.List(x - 1), " "), RemDirect(x - 1), False)
        lstRemailers.ListIndex = x
    Case 2
        'Clear
        lstRemailers.Clear
        lstRemailers.AddItem ""
        cboLatent.Text = ""
        cboRemailer.Text = ""
        ReDim RemDirect(MaxChain)
        If fraRemEdit.Visible Then ShowRemData Me, "", BookRType
    End Select
End Sub

Private Sub cboLatent_Click()
    If NoClick Then Exit Sub
    BkChange = True
    x = lstRemailers.ListIndex
    If x = -1 Then Exit Sub
    If lstRemailers.List(x) = "" Then Exit Sub
    If fraRemEdit.Visible Then rd = txtHeaders(2).Text Else rd = RemDirect(x)
    AddHeader rd, "Latent-Time: " + cboLatent.Text
    If fraRemEdit.Visible Then
        txtHeaders(2).Text = rd
    Else
        RemDirect(x) = rd
        lstRemailers.List(x) = RemDisp(lstRemailers.List(x), rd, (BookRType = 1 And x < lstRemailers.ListCount - 2))
    End If
End Sub

Private Sub cboLatent_Change()
    cboLatent_Click
End Sub

Private Sub lstRemailers_Click()
    BkChange = True
    x = lstRemailers.ListIndex
    If x = -1 Then Exit Sub
    If fraRemEdit.Visible Then UpRemData Me, RemDirect(Val(lstRemailers.Tag))
    y = InStr(1, lstRemailers.List(x), "   ;Latent-Time:", vbTextCompare)
    NoClick = True
    If y = 0 Then
        cboLatent.Text = ""
    Else
        cboLatent.Text = Extract(LTrim(Mid(lstRemailers.List(x), y + 16)), " ")
    End If
    NoClick = False
    cboRemailer.Text = Extract(lstRemailers.List(x), " ")
    cboLatent.Enabled = Not ((BookRType = 1) And (x <> lstRemailers.ListCount - 2))
    If fraRemEdit.Visible Then ShowRemData Me, RemDirect(x), BookRType
End Sub

Private Sub lstRemailers_DblClick()
    x = lstRemailers.ListIndex
    If fraRemEdit.Visible Then
        cmdRemEdit_Click (0)
    Else
        If mnuOption(0).Checked Then
            fraRemEdit.Visible = True
            If x = -1 Then rd = "" Else rd = RemDirect(x)
            ShowRemData Me, rd, BookRType
        End If
    End If
End Sub

Private Sub cboEncrypt_Change(Index As Integer)
    UpdateDisp
    BkChange = True
End Sub

Private Sub cboEncrypt_Click(Index As Integer)
    UpdateDisp
    BkChange = True
End Sub

Private Sub cboEncrypt_KeyDown(Index As Integer, KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyDown Or KeyCode = vbKeyUp Then KeyCode = 0
    If KeyCode = 8 And Val(PData(12)) <> 0 Then cboEncrypt(Index).Text = ""
End Sub

Private Sub cboEncrypt_KeyPress(Index As Integer, KeyAscii As Integer)
    If Val(PData(12)) <> 0 Then KeyAscii = 0
End Sub

Private Sub cboTo_KeyDown(Index As Integer, KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyDown Or KeyCode = vbKeyUp Then KeyCode = 0
End Sub

Private Sub cboTo_Change(Index As Integer)
    BkChange = True
End Sub

Private Sub cboTo_Click(Index As Integer)
    BkChange = True
End Sub

Private Sub cboNym_Change()
    BkChange = True
End Sub

Private Sub cboNC_Change()
    BkChange = True
End Sub

Private Sub cboNym_Click()
    BkChange = True
End Sub

Private Sub cboNC_Click()
    BkChange = True
End Sub

Private Sub txtSubject_Change()
    BkChange = True
End Sub

Private Sub txtHeaders_Change(Index As Integer)
    BkChange = True
End Sub

Private Sub cboHeaders_Change(Index As Integer)
    Dim a As String, b As String, c As String, h As String
    Dim x As Long, y As Long, y2 As Long, z As Long
    
    If NoClick Then Exit Sub
    a = cboHeaders(Index).Text
    x = InStr(a, ":")
    If x <> 0 Then
        b = Trim(Mid(a, 1, x - 1)) + ":"
        If InStr(b, " ") = 0 Then
            c = UCase(Left(b, 1))
            For i = 2 To Len(b)
                If d = "-" Then c = c + UCase(Mid(b, i, 1)) Else c = c + LCase(Mid(b, i, 1))
                d = Mid(b, i, 1)
            Next i
            b = c
            h = b + " " + LTrim(Mid(a, x + 1))
            y = InStr(1, vbCrLf + txtHeaders(Index).Text, vbCrLf + b, vbTextCompare)
            If y = 0 Then
                If Right(txtHeaders(Index).Text, 2) <> vbCrLf And Len(txtHeaders(Index).Text) <> 0 Then txtHeaders(Index).Text = txtHeaders(Index).Text + vbCrLf
                txtHeaders(Index).Text = txtHeaders(Index).Text + h + vbCrLf
                z = Len(txtHeaders(Index).Text) - 2
            Else
                y2 = InStr(y, txtHeaders(Index).Text, vbCrLf)
                If y2 = 0 Then txtHeaders(Index).Text = txtHeaders(Index).Text + vbCrLf: y2 = Len(txtHeaders(Index).Text) - 1
                txtHeaders(Index).Text = Left(txtHeaders(Index).Text, y - 1) + h + Mid(txtHeaders(Index).Text, y2)
                z = y + Len(h) - 1
                x = z
                Do
                    y = InStr(x, txtHeaders(Index).Text, vbCrLf + b, vbTextCompare)
                    If y <> 0 Then
                        y2 = InStr(y + 1, txtHeaders(Index).Text, vbCrLf)
                        If y2 = 0 Then txtHeaders(Index).Text = txtHeaders(Index).Text + vbCrLf: y2 = Len(txtHeaders(Index).Text) - 1
                        txtHeaders(Index).Text = Left(txtHeaders(Index).Text, y - 1) + Mid(txtHeaders(Index).Text, y2)
                        x = y2
                    End If
                Loop Until y = 0
            End If
            If RTrim(cboHeaders(Index).Text) <> RTrim(h) Then
                NoClick = True
                cboHeaders(Index).Text = h
                cboHeaders(Index).SelLength = 0
                cboHeaders(Index).SelStart = Len(h)
                NoClick = False
            End If
            txtHeaders(Index).SelLength = 0
            txtHeaders(Index).SelStart = z
        End If
    End If
End Sub

Private Sub cboHeaders_Click(Index As Integer)
    If cboHeaders(Index).ListIndex = -1 Then Exit Sub
    a = cboHeaders(Index).List(cboHeaders(Index).ListIndex)
    If InStr(a, ":") = 0 And LTrim(a) <> "" Then
        'x = InStr(vbCrLf + txtHeaders(Index).Text, vbCrLf + a + vbCrLf)
        'If x = 0 Then
        '    If Right(txtHeaders(Index).Text, 2) <> vbCrLf And Len(txtHeaders(Index).Text) <> 0 Then txtHeaders(Index).Text = txtHeaders(Index).Text + vbCrLf
        '    x = Len(txtHeaders(Index).Text)
        '    txtHeaders(Index).Text = txtHeaders(Index).Text + a + vbCrLf
        '  '  txtHeaders(Index).SelLength = 0
        '    txtHeaders(Index).SelStart = x
        '    Exit Sub
        'Else
        '    txtHeaders(Index).SelLength = 0
        '    txtHeaders(Index).SelStart = x
        '    Exit Sub
        'End If
        cboHeaders(Index).ListIndex = -1: Exit Sub
    Else
        NoClick = True
        'cboHeaders(Index).ListIndex = -1
        'cboHeaders(Index).Text = a
        NoClick = False
        x = InStr(a, ":")
        If x <> 0 And Index <> 2 Then
            b = LCase(Trim(Left(a, x - 1)))
            a = LTrim(Mid(a, x + 1))
            If b = "subject" Then txtSubject.Text = a: cboHeaders(Index).Text = ""
            If b = "to" Then cboTo(0).Text = a: cboHeaders(Index).Text = ""
            If b = "post" Then cboTo(0).Text = cboHeaders(Index).Text: cboHeaders(Index).Text = ""
            If b = "post-to" Then cboTo(0).Text = cboHeaders(Index).Text: cboHeaders(Index).Text = ""
            If b = "anon-post-to" Then cboTo(0).Text = cboHeaders(Index).Text: cboHeaders(Index).Text = ""
            If b = "cc" Then cboTo(1).Text = a: cboHeaders(Index).Text = ""
            If b = "bcc" Then cboTo(2).Text = a: cboHeaders(Index).Text = ""
            If b = "nym-commands" Then cboNC.Text = a: cboHeaders(Index).Text = ""
        End If
    End If
    cboHeaders_Change (Index)
    txtHeaders(Index).SetFocus
End Sub

Private Sub cboHeaders_KeyPress(Index As Integer, KeyAscii As Integer)
    If KeyAscii = 13 Then If InStr(cboHeaders(Index).Text, ":") <> 0 Then cboHeaders(Index).Text = ""
    If KeyAscii = Asc(":") Then
        If InStr(cboHeaders(Index).Text, ":") = 0 Then
            x = InStr(1, vbCrLf + txtHeaders(Index).Text, vbCrLf + Trim(cboHeaders(Index).Text) + ":", vbTextCompare)
            If x <> 0 Then
                txtHeaders(Index).SelLength = 0 'Len(cboHeaders.Text)
                txtHeaders(Index).SelStart = x
                cboHeaders(Index).Text = Extract(Mid(txtHeaders(Index).Text, x), vbCrLf)
                cboHeaders(Index).SelStart = Len(Extract(cboHeaders(Index).Text, ":")) + 2
                cboHeaders(Index).SelLength = Len(cboHeaders(Index).Text) - cboHeaders(Index).SelStart
                KeyAscii = 0
            End If
        End If
    End If
End Sub

Private Sub cboHeaders_LostFocus(Index As Integer)
    cboHeaders(Index).Text = ""
End Sub

Private Sub cmdTo_Click(Index As Integer)
    If cboTo(Index).Text = "" Then ShowConfig (10):  Exit Sub
    If AddrCount = 0 Then Exit Sub
    If cboTo(Index).Text = Searchfound And Searchindex = Index Then
        t = SearchAddr
        s = SearchString
    Else
        s = cboTo(Index).Text
        t = 0
    End If
    If t > AddrCount - 1 Then t = 0
    Searchindex = Index
    SearchString = s
    While InStr(1, Addr(t), s, 1) = 0
        t = t + 1: If t > MaxAddr Then SearchAddr = 0: ShowConfig (10): Exit Sub
    Wend
    Searchfound = Addr(t)
    SearchAddr = t + 1: If SearchAddr > AddrCount - 1 Then SearchAddr = 0
    cboTo(Index).Text = Addr(t)
End Sub

Private Sub lblChains_Click()
    BkData(0) = Str(SVal(BkData(0)) + 1)
    UpdateDisp
End Sub

Private Sub lblChains_DblClick()
    lblChains_Click
End Sub


Private Sub lstAttach_Click()
    If lstAttach.ListIndex = -1 Then Exit Sub
    BkChange = True
    rm = lstAttach.List(lstAttach.ListIndex)
    
    x = InStr(rm, "    Encode:")
    If x = 0 Then Exit Sub
    txtAttach.Text = Trim(Left(rm, x - 1))
    For j = 0 To cboEncode.ListCount - 1
        If cboEncode.List(j) = Mid(rm, x + 12) Then cboEncode.ListIndex = j
    Next j
    UpdateDisp
End Sub

Private Sub cmdAttach_Click(Index As Integer)
    Select Case Index
    Case 0, 1
        'Add/Set Attachment
        If Index = 1 And lstAttach.ListIndex = -1 Then Index = 0
        If Index = 1 And lstAttach.List(lstAttach.ListIndex) = "" Then Index = 0
        txtAttach.Text = Trim(txtAttach.Text)
        If txtAttach.Text <> "" And lstAttach.ListCount < MaxChain Then
            If SDir(txtAttach.Text) = "" Then
                If MsgBox(LMsg(65), vbExclamation + vbOKCancel, LMsg(66)) = vbCancel Then Exit Sub
            End If
            a = txtAttach.Text
            If Len(a) < 55 Then
                a = Left(a + String(60, " "), 60) + "Encode: " + cboEncode.Text
            Else
                a = a + "     Encode: " + cboEncode.Text
            End If
            If lstAttach.ListIndex = -1 Then lstAttach.ListIndex = lstAttach.ListCount - 1
            If Index = 0 Then
                lstAttach.AddItem a, lstAttach.ListIndex
            Else
                lstAttach.List(lstAttach.ListIndex) = a
            End If
        End If
    Case 2
        'Remove Attachment
        If lstAttach.ListIndex <> -1 And lstAttach.ListIndex <> lstAttach.ListCount - 1 Then
            lstAttach.RemoveItem lstAttach.ListIndex
        End If
    Case 3
        'Clear Attachments
        lstAttach.Clear
        lstAttach.AddItem ""
        txtAttach.Text = ""
        cboEncode.ListIndex = 0
    End Select
    txtAttach.SelStart = Len(txtAttach.Text)
    If txtAttach.Visible Then txtAttach.SetFocus
    UpdateDisp
End Sub

Private Sub chkEncrypt_Click(Index As Integer)
    BkChange = True
    UpdateDisp
End Sub

Private Sub mnuMessClear_Click(Index As Integer)
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    If Index = 0 Then
        cmdAttach_Click (3)
    Else
        UpdateDisp
        cmdHeaderClear_Click
        UpdateDisp
    End If
    BkChange = True
End Sub

Private Sub mnuWriteClip_Click(Index As Integer)
    Dim a As String
    
    On Error GoTo ClipError
    'If Index = 1 Then frmMain!CommonDialog1.DialogTitle = LMsg(90) 'Save Clipboard to File
    'If Index = 2 Then frmMain!CommonDialog1.DialogTitle = LMsg(91) 'Append Clipboard to File
    If Index <> 0 Then
        'Save Clip As
        If Val(Cnf(2, 1)) = 1 And Index = 1 Then x = cdlOFNOverwritePrompt Else x = 0
        b = SaveDialog(PlainName(PData(40), 0), PlainName(PData(40), 1), LMsg(117), _
            cdlOFNHideReadOnly + cdlOFNPathMustExist + cdlOFNNoReadOnlyReturn + x, _
            "All Files (*.*)|*.*", 1, Me)
        If b <> "" Then
            n = FreeFile
            If Index = 1 Then
                Open b For Output As n
            Else
                Open b For Append As n
            End If
            Print #n, Clipboard.GetText;
            Close n: n = 0
            lblStat.Caption = LMsg(118) + " " + b
            PData(40) = b
        End If
    Else
        'Load Clipboard
        b = OpenDialog(PlainName(PData(40), 0), PlainName(PData(40), 1), LMsg(67), _
            cdlOFNHideReadOnly + cdlOFNFileMustExist, _
            "All Files (*.*)|*.*", 1, Me)
        If b <> "" Then
            n = FreeFile
            Open b For Input As n
            a = Input(LOF(n), n)
            Close n: n = 0
            PData(40) = b
        End If
        Clipboard.Clear
        Clipboard.SetText a
        lblStat.Caption = LMsg(275) + " " + b
    End If
Exit Sub
ClipError:
    MsgBox LMsg(0) + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
End Sub

Private Sub cboArcType_Click()
    '0 No archive.
    '1 Save message and book to Sent folder.
    '2 Save message to Sent folder.
    '3 Save message and book to folder:
    '4 Save message to folder:
    '5 Append message to text file:
    '6 Log message to text file:
    Select Case cboArcType.ListIndex
    Case 0, 1, 2
        txtArchive.ZOrder
        txtArchive.Enabled = False
        cmdBrowse(0).Enabled = False
    Case 3, 4
        cboArchive.ZOrder
        cmdBrowse(0).Enabled = True
    Case 5, 6
        txtArchive.ZOrder
        txtArchive.Enabled = True
        cmdBrowse(0).Enabled = True
    End Select

End Sub

Private Sub cboArcType_Change()
    '0 No archive.
    '1 Save message and book to Sent folder.
    '2 Save message to Sent folder.
    '3 Save message and book to folder:
    '4 Save message to folder:
    '5 Append message to text file:
    '6 Log message to text file:
    Select Case cboArcType.ListIndex
    Case 0, 1, 2
        txtArchive.ZOrder
        txtArchive.Enabled = False
        cmdBrowse(0).Enabled = False
    Case 3, 4
        cboArchive.ZOrder
        cmdBrowse(0).Enabled = True
    Case 5, 6
        txtArchive.ZOrder
        txtArchive.Enabled = True
        cmdBrowse(0).Enabled = True
    End Select
    BkChange = True
End Sub

Private Sub cmdBrowse_Click(Index As Integer)
    If Index = 0 Then
        If cboArcType.ListIndex < 5 Then a = Trim(cboArchive.Text) Else a = Trim(txtArchive.Text)
    Else: a = Trim(txtAttach.Text)
    End If
    If Index = 0 And cboArcType.ListIndex < 5 Then
        a = SelectFolder(a, LMsg(413), "")
    Else
        a = OpenDialog(PlainName(a, 0), PlainName(a, 1), LMsg(67), cdlOFNHideReadOnly + cdlOFNFileMustExist * Index, "All Files (*.*)|*.*", 1, Me)
    End If
    If a = "" Then Exit Sub
    If Index = 0 Then
        If cboArcType.ListIndex < 5 Then cboArchive.Text = a Else txtArchive.Text = a
    Else: txtAttach.Text = a
    End If
End Sub

Private Sub chkSplit_Click()
    txtSplit.Enabled = chkSplit.Value = 1
    BkChange = True
End Sub

Private Sub cmdHeaderClear_Click()
    Dim temp(1000) As String
    
    If tabBook.SelectedItem.Index <> 2 Then txtHeaders(1).Text = txtHeaders(0).Text
    x = ParseString(txtHeaders(1).Text, temp(), 1000, False)
    For i = 0 To x
        If InStr(temp(i), ":") <> 0 Then
            temp(i) = Trim(temp(i))
            y = InStr(temp(i), ":")
            If InStr(Left(temp(i), y - 1), " ") = 0 Then
                a = a + Trim(Left(temp(i), y - 1)) + ": " + vbCrLf
            End If
        End If
    Next i
    txtHeaders(1).Text = a
    txtHeaders(0).Text = a
    For i = 0 To 2
        cboTo(i).Text = ""
    Next i
    cboNC.Text = ""
    txtSubject.Text = ""
    cboNym.Text = ""
End Sub

Private Sub tabBook_BeforeClick(Cancel As Integer)
    If fraRemEdit.Visible Then cmdRemEdit_Click (0)
    tb = tabBook.SelectedItem.Index
    Select Case tb
    Case 1
        txtHeaders(1).Text = txtHeaders(0).Text
    Case 2
        txtHeaders(0).Text = txtHeaders(1).Text
    End Select
End Sub

Private Sub tabBook_Click()
    tb = tabBook.SelectedItem.Index
    Select Case tb
    Case 1
        fraBook(1).Visible = False
        rtbMessage.Top = 3720
        rtbMessage.Height = fraBook(0).Height - 4080
        fraBook(0).Visible = True
    Case 2
        fraBook(0).Visible = False
        fraBook(1).Visible = True
    Case 3
        fraBook(1).Visible = False
        rtbMessage.Top = 60
        rtbMessage.Height = fraBook(0).Height - 60
        fraBook(0).Visible = True
    End Select
    txtMessage.Top = rtbMessage.Top
    txtMessage.Height = rtbMessage.Height
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    Select Case Shift
    Case 0
        Select Case KeyCode
        Case vbKeyF1: mnuHelpSub_Click (0): KeyCode = 0
        Case vbKeyF7: ShowConfig (ConfigBooks): KeyCode = 0
        End Select
    Case 1 'Shift
        Case vbKeyF5: mnuDisk_Click (8): KeyCode = 0
        Case vbKeyF6: mnuDisk_Click (9): KeyCode = 0
    Case 2  'Ctrl
        Select Case KeyCode
        Case vbKeyA: mnuSelectAll_Click: KeyCode = 0
        Case vbKeyD: mnuEditArray_Click (2): KeyCode = 0
        Case vbKeyF: mnuFind_Click (0): KeyCode = 0
        Case vbKeyG: mnuFind_Click (1): KeyCode = 0
        Case vbKeyH: mnuPasteSig_Click: KeyCode = 0
        Case vbKeyJ: mnuWrap_Click (1): KeyCode = 0
        Case vbKeyM: mnuRType_Click: KeyCode = 0
        Case vbKeyN: mnuDisk_Click (13): KeyCode = 0
        Case vbKeyO: mnuDisk_Click (12): KeyCode = 0
        Case vbKeyP: mnuDisk_Click (15): KeyCode = 0
        Case vbKeyR: mnuClear_Click (0): KeyCode = 0
        Case vbKeyQ: mnuPasteQuote_Click: KeyCode = 0
        Case vbKeyS: mnuDisk_Click (2): KeyCode = 0
        Case vbKeyT: mnuWrap_Click (2): KeyCode = 0
        Case vbKeyU: mnuReply_Click (1): KeyCode = 0
        Case vbKeyW: mnuWrap_Click (0): KeyCode = 0
        Case vbKeyY: mnuReply_Click (0): KeyCode = 0
        End Select
    Case 3 'Ctrl-Shift
    End Select
End Sub

Private Sub mnuHelpSub_Click(Index As Integer)
    Dim Topic As String
    
    Select Case tabBook.SelectedItem.Index
    Case 1: Topic = "#Book"
    Case 2: Topic = "#BookExtra"
    Case 3: Topic = "#BookFullText"
    End Select
    ShowHelp Index, Topic
End Sub

Private Sub mnuConfig_Click(Index As Integer)
    ShowConfig (Index)
End Sub

Private Sub mnuWindow_Click(Index As Integer)
    ShowWindow (Index)
End Sub

Private Function DefaultProf(Optional ProfName As String) As Integer
    DefaultProf = -1
    a = Trim(Left(BkData(10), 12))
    If a <> "" Then
        'Override Default SMTP
        ProfName = a
        For i = 15 To 29
            If Trim(LCase(UserProf(i, 1))) = LCase(a) Or LCase(a) = "unix" Then
                If LCase(a) = "unix" Then i = 30
                DefaultProf = i - 15
                Exit Function
            End If
        Next i
    Else
        a = UserProf(15 + Val(UserProf(15, 7)), 1)
        If a = "" Then a = "SMTP" + Str(Val(UserProf(15, 7)))
        ProfName = a
        DefaultProf = Val(UserProf(15, 7))
    End If
End Function

Private Sub lblStat_Click()
    lblStat.Caption = LMsg(408) + ":" + Str(Len(TextBox.Text)) + "   " + LMsg(409) + ":" + Mid(RemStats(rtype, 0), InStr(RemStats(BookRType, 0), ":") + 1)
End Sub

Private Sub tmrReload_Timer()
    If BookX = -1 Then Exit Sub
    tmrReload.Enabled = False
    If BookBusy(0, BookX) Then Exit Sub
    a = tmrReload.Tag: tmrReload.Tag = ""
    If a <> "" And fraRemEdit.Visible Then cmdRemEdit_Click (0)
    If InStr(a, "X") <> 0 Then
        LoadList ("")
    ElseIf InStr(a, "C") <> 0 Then
        'Close Window
        Unload Me
        Exit Sub
    Else
        If InStr(a, "H") <> 0 Then LoadList ("HeaderChoice")
        If InStr(a, "A") <> 0 Then LoadList ("Addresses")
        If InStr(a, "R") <> 0 Then LoadList ("Remailers")
        If InStr(a, "K") <> 0 Then LoadList ("Keys")
        If InStr(a, "P") <> 0 Then LoadList ("Profiles")
        If InStr(a, "M") <> 0 Then LoadList ("Nyms")
        If InStr(a, "F") <> 0 Then LoadList ("Fonts")
    End If
    If InStr(a, "N") <> 0 Then
        'Nym Config
        nfn = txtSubject.Tag: txtSubject.Tag = ""
        nkey = cboNC.Tag: cboNC.Tag = ""
        nsrv = cboTo(1).Tag: cboTo(1).Tag = ""
        bkf = cboNym.Tag: cboNym.Tag = ""
        nbk = cboTo(2).Tag: cboTo(2).Tag = ""
        If Len(nfn) * Len(nkey) * Len(nsrv) = 0 Or SDir(nfn) = "" Then DelFile nfn: Exit Sub
Query:  If BkChange And Val(Cnf(2, 2)) = 1 Then
            Select Case MsgBox(LMsg(119), vbQuestion + vbYesNoCancel, MsgBookName(BookX))
            Case vbCancel
                DelFile nfn
                Exit Sub
            Case vbYes
                WriteBook (MsgBookName(BookX))
                GoTo Query
            End Select
        End If
        If SDir(bkf) = "" Then
            ClearData
        Else
            OpenBook bkf
        End If
        MsgBookName(BookX) = PlainName(nbk, 0) + PlainName(nbk, 2) + ".BK"
        lblStat.Caption = bkf + " " + LMsg(125) + " " + PlainName(MsgBookName(BookX), 1)
        UpdateDisp
        TextBox.Text = ""
        cboNym.Text = ""
        cboTo(0).Text = nsrv
        InsertFile nfn
        DelFile nfn
        cboEncrypt(0).Text = nsrv
        cboEncrypt(1).Text = nkey
        BkData(2) = ""
        mnuWrapOpt.Checked = False
        TextBox.SelLength = 0
        TextBox.SelStart = 0
        Me.SetFocus
        LoadList ("Profiles")
        NymRun = True
        Exit Sub
    End If
    If InStr(a, "L") <> 0 Then
        'Reload
        fn = cboNym.Tag: cboNym.Tag = ""
        If SDir(fn) = "" Then Exit Sub
Query2:  If BkChange And Val(Cnf(2, 2)) = 1 Then
            Select Case MsgBox(LMsg(119), vbQuestion + vbYesNoCancel, MsgBookName(BookX))
            Case vbCancel
                Exit Sub
            Case vbYes
                WriteBook (MsgBookName(BookX))
                GoTo Query2
            End Select
        End If
        OpenBook fn
        Me.SetFocus
        LoadList ("Profiles")
    End If
    If InStr(a, "Y") <> 0 Then
        'Reply/Followup to File
        rfile = txtSubject.Tag: txtSubject.Tag = ""
        replytype = Int(Abs(SVal(cboNC.Tag))): cboNC.Tag = ""
        If rfile <> "" And replytype < 2 Then
            ReplyMsg rfile, replytype + 2
            TextBox.SelStart = 0
            txtHeaders(0).SelStart = 0
            BkChange = False
            TextBox.SetFocus
            If LCase(PlainName(rfile, 3)) = "tmj" Then DelFile rfile
        End If
    End If
End Sub

Private Sub LoadList(Job As String)
    Dim temp(1000) As String, ProfName As String
    Dim ValidDef As Boolean, ValidReplay As Boolean
    Dim Tmp(2) As String

    If BookX = -1 Then Exit Sub
    If Job = "HeaderChoice" Or Job = "" Then
        cboHeaders(0).Clear
        cboHeaders(1).Clear
        cboHeaders(2).Clear
        x = ParseString(Cnf(2, 20), temp(), 1000, False)
        For i = 0 To x
            cboHeaders(0).AddItem temp(i)
            cboHeaders(1).AddItem temp(i)
        Next i
        Tmp(0) = cboLatent.Text
        If InStr(1, Cnf(2, 21), "latent-time:", vbTextCompare) <> 0 Then cboLatent.Clear
        x = ParseString(Cnf(2, 21), temp(), 1000, False)
        For i = 0 To x
            cboHeaders(2).AddItem temp(i)
            If InStr(1, temp(i), "latent-time:", vbTextCompare) = 1 Then
                a = Trim(Mid(temp(i), InStr(temp(i), ":") + 1))
                If a <> "" Then cboLatent.AddItem a
            End If
        Next i
        cboLatent.Text = Tmp(0)
        
        Tmp(0) = cboArchive.Text
        cboArchive.Clear
        a = SDir(Cnf(4, 0) + "\*.*", vbDirectory)
        While a <> ""
            f = Cnf(4, 0) + "\" + a
            If IsDir(f) And a <> "." And a <> ".." Then cboArchive.AddItem f
            a = Dir
        Wend
        cboArchive.Text = Tmp(0)
    End If
    
    If Job = "Addresses" Or Job = "" Then
        For i = 0 To 2
            Tmp(i) = cboTo(i).Text
            cboTo(i).Clear
        Next i
        For i = 0 To AddrCount - 1
            For j = 0 To 2
                cboTo(j).AddItem Addr(i)
        Next j, i
        For i = 0 To 2
            cboTo(i).Text = Tmp(i)
        Next i
    End If
    
    If Job = "Nyms" Or Job = "" Then
        Tmp(0) = cboNym.Text
        cboNym.Clear
        For i = 0 To MaxRemailers
            If Nyms(i, 0) = "" Then Exit For
            cboNym.AddItem Nyms(i, 0)
        Next i
        cboNym.Text = Tmp(0)
    End If
    
    If Job = "Remailers" Or Job = "" Then
        GetRemailers cboRemailer, BookRType
        If Job = "Remailers" Then lblStat.Caption = LMsg(393)
        mnuRType.Enabled = BookRType = 1 Or Cnf(1, 15) <> ""
    End If

    If Job = "Keys" Or Job = "" Then
        LoadKeyList cboEncrypt(0), False, True
        LoadKeyList cboEncrypt(1), True, False
        cboEncrypt(0).AddItem "-c   [ Conventional Encryption ]", cboEncrypt(0).ListCount
    End If
    
    If Job = "Profiles" Or Job = "" Then
        fr = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._@@"
        If SDir(fr) = "" Then fr = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + "._AA"
        ValidReplay = SDir(fr) <> ""
        If ValidReplay Then ReplayDate = LMsg(236) + " " + Format(FileDateTime(fr), "ddd ") + Format(FileDateTime(fr), "medium date") + " " + Format(FileDateTime(fr), "medium time")
        For i = 0 To 15
            If i <> 15 Then a = UserProf(15 + i, 1) Else a = "UNIX"
            If a = "" Then a = "SMTP" + Str(i + 1)
            mnuQue(i).Caption = a
            mnuQue(i).Enabled = (Val(UserProf(15 + i, 0)) = 1)
            mnuQue(i).Checked = (Val(UserProf(15, 7)) = i)
            mnuQue(i).Visible = (i = 15) Or (UserProf(15 + i, 2) <> "")
            mnuReplay(i).Caption = a
            mnuReplay(i).Enabled = (Val(UserProf(15 + i, 0)) = 1) And ValidReplay
            mnuReplay(i).Checked = (Val(UserProf(15, 7)) = i)
            mnuReplay(i).Visible = (i = 15) Or (UserProf(15 + i, 2) <> "")
            If mnuQue(i).Enabled Then NoProfWarning = True
        Next i
        x = DefaultProf(ProfName)
        If x = -1 Then ValidDef = False Else ValidDef = Val(UserProf(x + 15, 0)) = 1
        a = Trim(Left(BkData(10), 12))
        If a <> "" Then
            'Override Default SMTP
            a = LMsg(247) + "  [" + ProfName + "]"
        Else
            a = LMsg(248) + "  [" + ProfName + "]"
        End If
        mnuQueDef.Enabled = ValidDef
        mnuReplayDef.Enabled = ValidDef And ValidReplay
        mnuQueDef.Caption = a
        mnuReplayDef.Caption = a
        chkQue(0).Enabled = ValidDef
        chkQue(1).Enabled = ValidDef And ValidReplay
        chkQue(0).ToolTipText = LMsg(233) + " " + LMsg(232) + " " + ProfName
        chkQue(1).ToolTipText = LMsg(235) + " " + LMsg(232) + " " + ProfName + "   - " + ReplayDate
    End If
    
    If Job = "Fonts" Or Job = "" Then
        On Error Resume Next
        rtbMessage.Font.Name = Cnf(2, 25)
        rtbMessage.Font.Size = Val(Cnf(2, 26))
        rtbMessage.Font.Bold = (Cnf(2, 27) = True2)
        txtMessage.Font.Name = Cnf(2, 25)
        txtMessage.Font.Size = Val(Cnf(2, 26))
        txtMessage.Font.Bold = (Cnf(2, 27) = True2)
        x = SVal(Cnf(0, 5)) + 8
        For i = 0 To 2
            cboTo(i).FontSize = x
            cboHeaders(i).FontSize = x
            txtHeaders(i).FontSize = x
        Next i
        txtSubject.FontSize = x
        cboNC.FontSize = x
        cboNym.FontSize = x
        cboRemailer.FontSize = x
        cboLatent.FontSize = x
        cboArchive.FontSize = x
        txtArchive.FontSize = x
        txtWork.FontSize = x
        txtAttach.FontSize = x
    End If
End Sub

Private Sub Form_Resize()
    Dim sh As Long, sw As Long, x As Long, fh As Long, fw As Long
    
    If Me.WindowState <> 1 Then
        If Me.Height < 5856 Then Me.Height = 5856
        If Me.Width < 4956 Then Me.Width = 4956
        sh = Me.ScaleHeight
        sw = Me.ScaleWidth
        tabBook.Height = sh - 372
        tabBook.Width = sw - 12
        tabBook.TabFixedWidth = (tabBook.Width / 3) - 24
        lblStat.Top = sh - 324
        lblStat.Width = sw - 3972
        chkQue(0).Top = sh - 324
        chkQue(1).Top = sh - 324
        chkQue(2).Top = sh - 324
        chkQue(0).Left = sw - 3864
        chkQue(1).Left = sw - 2604
        chkQue(2).Left = sw - 1344
        For i = 0 To 1
            fraBook(i).Width = sw - 132
            fraBook(i).Height = sh - 732
        Next i
        fw = fraBook(0).Width
        fh = fraBook(0).Height
                
        'Remailer Editor
        fraRemEdit.Width = fw
        fraRemEdit.Height = fh - 3660
        rh = fraRemEdit.Height
        cmdRemEdit(0).Left = fw - 1512
        cmdRemEdit(1).Left = cmdRemEdit(0).Left
        cmdRemEdit(2).Left = cmdRemEdit(0).Left
        lblGarbage.Left = fw - 1392
        cboGarbage.Left = lblGarbage.Left
        txtHeaders(2).Width = cmdRemEdit(0).Left - txtHeaders(2).Left - 108
        cboHeaders(2).Width = txtHeaders(2).Width - 240
        txtCaps.Height = rh - 660
        txtHeaders(2).Height = txtCaps.Height
        cboHeaders(2).Top = rh - 352
        cmdRemEdit(0).Top = rh - 1272
        cmdRemEdit(1).Top = rh - 852
        cmdRemEdit(2).Top = rh - 432
        
        
        'Message Tab
        txtMessage.Width = fw
        rtbMessage.Width = fw
        rtbMessage.RightMargin = fw - 400 ''''''''
        lstRemailers.Width = fw
        lblEncrypt.Top = fh - 252
        lblSign.Top = lblEncrypt.Top
        cboEncrypt(0).Top = fh - 312
        cboEncrypt(1).Top = cboEncrypt(0).Top
        cmdStar(0).Top = cboEncrypt(0).Top
        cmdStar(1).Top = cmdStar(0).Top
        
        x = 0.229 * fw
        If x > 2052 Then x = 2052
        If x < 1092 Then x = 1092
        cboNC.Width = x
        cboNC.Left = fw - x
        lblNC.Left = cboNC.Left - 360
        cboTo(0).Width = cboNC.Left - cboTo(0).Left - 408
        
        cboTo(1).Width = 0.43 * fw
        cboTo(1).Left = fw - cboTo(1).Width
        cmdTo(1).Left = cboTo(1).Left - 540
        cboNym.Width = cboTo(1).Left - cboNym.Left - 588
        
        cboTo(2).Width = cboTo(1).Width
        cboTo(2).Left = cboTo(1).Left
        cmdTo(2).Left = cmdTo(1).Left
        txtSubject.Width = cboNym.Width
        
        txtHeaders(0).Width = fw
        cboHeaders(0).Width = fw - 230
        
        cmdRemailer(2).Left = fw - 912
        cmdRemailer(1).Left = fw - 1872
        cmdRemailer(0).Left = fw - 2832
        cboLatent.Left = fw - 3972
        cboRemailer.Width = cboLatent.Left - 48
        txtRemEdit.Width = fraRemEdit.Width - 108
        
        cboEncrypt(1).Width = (fw * 0.796) / 2
        cmdStar(1).Left = fw - 312
        cboEncrypt(1).Left = cmdStar(1).Left - cboEncrypt(1).Width + 12
        lblSign.Left = cboEncrypt(1).Left - 420
        cmdStar(0).Left = cboEncrypt(1).Left - 840
        cboEncrypt(0).Width = cboEncrypt(1).Left - cboEncrypt(0).Left - 828
    
    
        'Extra
        x = fw - 3042
        If x < 5196 Then x = 5196
        lblWorkSet.Left = x
        lblWork.Left = x
        txtWork.Left = x - 6
        lstAttach.Width = fw - 120
        txtHeaders(1).Width = lstAttach.Width
        cboHeaders(1).Width = fw - 347
        txtHeaders(1).Height = fh - 3420
        cboHeaders(1).Top = txtHeaders(1).Top + txtHeaders(1).Height - 302
        
    
        tabBook_Click
    End If
End Sub

Private Sub Form_Activate()
    If BookX = -1 Then
        BookX = Val(Me.Tag)
        If Not ReadBook(MsgBookName(BookX)) Then
            MsgBookName(BookX) = ""
            Unload Me
            Exit Sub
        End If
        If LCase(PlainName(MsgBookName(BookX), 3)) = "tbk" Then
            a = MsgBookName(BookX)
            If BkData(13) = True2 Then
                MsgBookName(BookX) = AutoName(MsgBookName(BookX))
            Else
                MsgBookName(BookX) = PlainName(MsgBookName(BookX), 0) + PlainName(MsgBookName(BookX), 2) + ".BK"
            End If
            lblStat.Caption = a + " " + LMsg(125) + " " + PlainName(MsgBookName(BookX), 1)
            UpdateDisp
        End If
    End If
End Sub

Private Sub Form_Load()
    ReDim RemDirect(MaxChain)
    Set TextBox = rtbMessage
    
    frmMain.MousePointer = 11
        
    Me.Left = Val(PData(112))
    Me.Top = Val(PData(113))
    If Val(PData(114)) <> 0 And Val(PData(115)) <> 0 Then
        Me.Width = Val(PData(114))
        Me.Height = Val(PData(115))
    End If
    If Val(PData(116)) <> 1 Then Me.WindowState = Val(PData(116))

    fraBook(0).Left = 60
    fraBook(1).Left = 60
    fraRemEdit.Left = 60
    fraRemEdit.Top = 3960
        
    lstAttach.AddItem ""
    cboRemailer.AddItem "Test1"
    cboRemailer.AddItem "Test2"
    cboRemailer.AddItem "Test3"
    lstRemailers.AddItem ""
    cboEncode.ListIndex = 0
        
    LoadList ("")
       
    BookX = -1
    If Not NoProfWarning Then MsgBox LMsg(545), vbInformation
    frmMain.MousePointer = 0
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If BookX <> -1 Then
        If fraRemEdit.Visible Then cmdRemEdit_Click (0)
Query:
        If BkChange And Val(Cnf(2, 2)) = 1 Then
            Select Case MsgBox(LMsg(119), vbQuestion + vbYesNoCancel, MsgBookName(BookX))
            Case vbCancel
                Cancel = 1
                GlobalCancel = 1
                Exit Sub
            Case vbYes
                WriteBook (MsgBookName(BookX))
                GoTo Query
            End Select
        End If
        If BookBusy(0, BookX) Then
            If MsgBox(LMsg(440), vbYesNo + vbDefaultButton2 + vbExclamation, LMsg(441)) = vbNo Then
                Cancel = 1
                GlobalCancel = 1
            Else
                BookBusy(0, BookX) = False
                frmMain!tmrDOS.Enabled = False
                DOSTag = ""
            End If
        End If
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Erase RemDirect, BkData
    If BookX <> -1 Then MsgBookName(BookX) = "": BookBusy(0, BookX) = False
    BookX = -1
    If Me.WindowState = 0 Then
        PData(112) = Str(Me.Left)
        PData(113) = Str(Me.Top)
        PData(114) = Str(Me.Width)
        PData(115) = Str(Me.Height)
    End If
    PData(116) = Str(Me.WindowState)
End Sub

