'jbn2dos.bas    JBN2 DOS Session                        28Feb9907:03
'Compile for DOS    www.powerbasic.com

$CPU 80286
$STRING 1

on error goto ErrorDOS

rev$ = "4"

Preamble:
	'Usage: jbn2dos.exe Xdir >> test.txt
	'or:  jbn2dos.exe :C:\StartIn::Xdir >> test.txt
	'where X = "D" for normal and "P" for paused
	' or where X = "TgggggD" or "TgggggP"
	':...:: if any, is the working directory

	cls: locate 25, 1: print
	print "Jack B. Nymble DOS Engine v2  Rev "; rev$
	progdir$ = curdir$
	c$ = command$

	'Get StartIn Folder
	if left$ (c$, 1) = ":" then
		x = instr (c$, "::")
		si$ = mid$ (c$, 2, x - 2)
		c$ = mid$ (c$, x + 2)
	end if
	'Get Tag
	if ucase$(left$(c$, 1)) = "T" then
		tag$ = mid$ (c$, 2, 5)
		c$ = mid$ (c$, 7)
	end if
	
	'Debug
	'print "[tag]="; tag$
	'print "[si]="; si$
	'print "[cur]="; curdir$
	'print "[c]="; c$

	'Change Drive
	if si$ <> "" then
		chdrive ucase$ (left$ (si$, 1))
		chdir si$
	end if

	'Shell
	if  ucase$(left$(c$, 1)) = "D" or ucase$(left$(c$, 1)) = "P" then
		print
		sh$ = mid$ (c$, 2)
		if ucase$(left$(c$, 1)) = left$(c$, 1) then print sh$
		print: print
		if len(sh$) > 123 then
			print "DOS Command Line Exceeded 123 Characters - Not Executed"
		else
			shell sh$
		end if
		goto ExitDOS
	else
		print
		print "This program is used internally by Jack B. Nymble and should not be run"
		print "directly."
		end
	end if
ErrorDOS:
	print: print "Error "; err; "@"; eradr: print
	resume ExitDOS
ExitDOS:
	on error goto ErrorExit
	if progdir$ <> "" and si$ <> "" then chdrive ucase$ (left$ (progdir$, 1)): chdir progdir$
	if ucase$ (left$ (c$, 1)) = "P" then
		print: print :print "Please press Enter..."
		a$= inkey$
		while a$ = ""
			a$ = inkey$
		wend
	end if
	if tag$ <> "" then
		open tag$ + ".TAG" for output as 1
		print #1, " ";
		close 1
	end if
end
ErrorExit:
	print: print "Exit Error "; err; "@"; eradr: print
	if ucase$ (left$ (c$, 1)) = "P" then
		print: print :print "Please press Enter..."
		a$= inkey$
		while a$ = ""
			a$ = inkey$
		wend
	end if
end
