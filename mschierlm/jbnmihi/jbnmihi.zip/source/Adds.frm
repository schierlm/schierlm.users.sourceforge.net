VERSION 5.00
Begin VB.Form frmAdds 
   Caption         =   "Email Addresses"
   ClientHeight    =   6120
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5640
   Icon            =   "Adds.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   6120
   ScaleWidth      =   5640
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton cmdAdds 
      Caption         =   "&Update"
      Default         =   -1  'True
      Height          =   312
      Index           =   0
      Left            =   360
      TabIndex        =   1
      Top             =   5760
      Width           =   2052
   End
   Begin VB.CommandButton cmdAdds 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   312
      Index           =   1
      Left            =   3000
      TabIndex        =   2
      Top             =   5760
      Width           =   1992
   End
   Begin VB.TextBox txtAdds 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5592
      Left            =   60
      MaxLength       =   30000
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Beides
      TabIndex        =   0
      Top             =   120
      Width           =   5532
   End
End
Attribute VB_Name = "frmAdds"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Sub cmdAdds_click(Index As Integer)
    If Index = 0 Then
        Me.MousePointer = 11
        a = txtAdds.Text
        AddrCount = ParseString(a, Addr(), MaxAddr, True) + 1
        CheckConfig ("Addresses")
        Me.MousePointer = 0
        Me.Hide
    Else
        Unload Me
    End If
End Sub

Private Sub Form_Resize()
    sw = Me.ScaleWidth
    sh = Me.ScaleHeight
    txtAdds.Width = sw - 108
    txtAdds.Height = sh - 528
    cmdAdds(0).Width = (sw - 1536) / 2
    cmdAdds(1).Width = cmdAdds(0).Width
    cmdAdds(1).Left = sw - cmdAdds(1).Width - 648
    cmdAdds(0).Top = sh - 360
    cmdAdds(1).Top = cmdAdds(0).Top
End Sub

Private Sub Form_Load()
    txtAdds.FontSize = Val(Cnf(0, 5)) + 8
    
    frmAdds.Left = Val(PData(82))
    frmAdds.Top = Val(PData(83))
    If Val(PData(84)) <> 0 And Val(PData(85)) <> 0 Then
        frmAdds.Width = Val(PData(84))
        frmAdds.Height = Val(PData(85))
    End If
    If Val(PData(86)) <> 1 Then Me.WindowState = Val(PData(86))
    
    For i = 0 To AddrCount - 1
        a = a + Addr(i) + vbCrLf
    Next i
    txtAdds.Text = a
End Sub

Private Sub Form_Unload(Cancel As Integer)
    If frmAdds.WindowState = 0 Then
        PData(82) = Str(frmAdds.Left)
        PData(83) = Str(frmAdds.Top)
        PData(84) = Str(frmAdds.Width)
        PData(85) = Str(frmAdds.Height)
    End If
    PData(86) = Str(Me.WindowState)
End Sub

