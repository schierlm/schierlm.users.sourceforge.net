VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmCfRet 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Retrieval - Configuration"
   ClientHeight    =   5400
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   5505
   Icon            =   "CfRet.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5400
   ScaleWidth      =   5505
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   372
      Left            =   3780
      TabIndex        =   7
      Top             =   4980
      Width           =   1632
   End
   Begin VB.Timer tmrProgBusy 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   3480
      Top             =   4980
   End
   Begin VB.CommandButton cmdOpt 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Index           =   0
      Left            =   60
      TabIndex        =   1
      Top             =   4980
      Width           =   1632
   End
   Begin VB.CommandButton cmdOpt 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   372
      Index           =   1
      Left            =   1920
      TabIndex        =   2
      Top             =   4980
      Width           =   1632
   End
   Begin VB.Frame fraOpt 
      BorderStyle     =   0  'Kein
      Caption         =   "Options"
      Height          =   4452
      Index           =   0
      Left            =   60
      TabIndex        =   4
      Top             =   360
      Width           =   5292
      Begin VB.CheckBox chkOpt 
         Caption         =   "Filter news duplicates"
         Height          =   312
         Index           =   6
         Left            =   300
         TabIndex        =   24
         TabStop         =   0   'False
         Top             =   2580
         Width           =   3192
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Trash nym duplicates"
         Height          =   312
         Index           =   5
         Left            =   300
         TabIndex        =   23
         TabStop         =   0   'False
         Top             =   2880
         Width           =   3192
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Update AckSend.TXT"
         Height          =   312
         Index           =   4
         Left            =   300
         TabIndex        =   22
         TabStop         =   0   'False
         Top             =   3180
         Width           =   3072
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Prompt for unknown private-key passphrases"
         Height          =   312
         Index           =   2
         Left            =   300
         TabIndex        =   21
         TabStop         =   0   'False
         Top             =   3780
         Width           =   4932
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Decrypt new messages"
         Height          =   312
         Index           =   0
         Left            =   300
         TabIndex        =   20
         TabStop         =   0   'False
         Top             =   3480
         Width           =   2232
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Decode all binary PGP messages inline"
         Height          =   312
         Index           =   3
         Left            =   300
         TabIndex        =   19
         TabStop         =   0   'False
         Top             =   4080
         Width           =   4932
      End
      Begin VB.ComboBox cboOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         ItemData        =   "CfRet.frx":0442
         Left            =   300
         List            =   "CfRet.frx":0473
         TabIndex        =   12
         Top             =   1860
         Width           =   4272
      End
      Begin VB.TextBox txtOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   312
         Index           =   1
         Left            =   300
         MaxLength       =   255
         TabIndex        =   10
         Top             =   1140
         Width           =   4272
      End
      Begin VB.TextBox txtOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   312
         Index           =   0
         Left            =   300
         MaxLength       =   255
         TabIndex        =   8
         Top             =   420
         Width           =   4272
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "PGP messages only"
         Height          =   312
         Index           =   1
         Left            =   2880
         TabIndex        =   0
         TabStop         =   0   'False
         Top             =   3480
         Width           =   2352
      End
      Begin VB.Label lblDate 
         Caption         =   "Saturday, September 15, 1999 15:44:00PM"
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Left            =   360
         TabIndex        =   14
         Top             =   2220
         Width           =   4752
      End
      Begin VB.Label lblOpt 
         Caption         =   "Date Display Format:"
         Height          =   192
         Index           =   0
         Left            =   300
         TabIndex        =   13
         Top             =   1620
         Width           =   4032
      End
      Begin VB.Label lblOpt 
         Caption         =   "Reply Templates Folder:  (Your books folder)"
         Height          =   192
         Index           =   5
         Left            =   300
         TabIndex        =   11
         Top             =   900
         Width           =   4272
      End
      Begin VB.Label lblOpt 
         Caption         =   "Mail Folder:"
         Height          =   192
         Index           =   4
         Left            =   300
         TabIndex        =   9
         Top             =   180
         Width           =   3492
      End
   End
   Begin VB.Frame fraOpt 
      BorderStyle     =   0  'Kein
      Caption         =   "Options"
      Height          =   4452
      Index           =   1
      Left            =   60
      TabIndex        =   5
      Top             =   360
      Width           =   5232
      Begin VB.TextBox txtOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1752
         Index           =   3
         Left            =   120
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   17
         Top             =   2640
         Width           =   5112
      End
      Begin VB.TextBox txtOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1752
         Index           =   2
         Left            =   120
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   15
         Top             =   480
         Width           =   5112
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "From Aliases:"
         Height          =   252
         Index           =   1
         Left            =   120
         TabIndex        =   18
         Top             =   2400
         Width           =   3012
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Anti-SPAM Filters:"
         Height          =   252
         Index           =   3
         Left            =   120
         TabIndex        =   16
         Top             =   240
         Width           =   3012
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Left            =   1800
         TabIndex        =   6
         Top             =   2640
         Width           =   3972
      End
   End
   Begin ComctlLib.TabStrip tabOpt 
      Height          =   4872
      Left            =   0
      TabIndex        =   3
      Top             =   60
      Width           =   5472
      _ExtentX        =   9657
      _ExtentY        =   8599
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   2
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Options"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Filters"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmCfRet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Sub cboOpt_Click(Index As Integer)
    cboOpt_Change (Index)
End Sub

Private Sub cboOpt_Change(Index As Integer)
    Dim a As String
    If Index = 0 Then
        a = "[ Invalid Format ]"
        On Error Resume Next
        a = Format(SafeTime, cboOpt(0).Text)
        lblDate.Caption = a
    End If
End Sub

Private Sub chkOpt_Click(Index As Integer)
    If txtOpt(0).Visible Then txtOpt(0).SetFocus
    If Index = 0 Then chkOpt(1).Enabled = chkOpt(0).Value = 1
End Sub

Private Sub cmdOpt_Click(Index As Integer)
    If Index = 0 Then
        Me.MousePointer = 11
        cmdOpt(0).Enabled = False
        For i = 0 To 1
            fraOpt(i).Enabled = False
        Next i
        PendingCfg(6) = True
        If ProgBusy("Ret") Then
            tmrProgBusy.Tag = "Ret"
            tmrProgBusy.Enabled = True
            Exit Sub
        End If
        For i = 0 To 3
            Cnf(4, i) = Trim(txtOpt(i).Text)
        Next i
        Cnf(4, 8) = Trim(cboOpt(0).Text)
        For i = 0 To 6
            Cnf(4, i + 12) = Str(chkOpt(i).Value)
        Next i
        CheckConfig ("Ret")
        Me.MousePointer = 0
    End If
    Unload Me
End Sub

Private Sub tmrProgBusy_Timer()
    If Not ProgBusy(tmrProgBusy.Tag) Then tmrProgBusy.Enabled = False: cmdOpt_Click (0)
End Sub

Private Sub tabOpt_Click()
    fraOpt(tabOpt.SelectedItem.Index - 1).ZOrder
End Sub

Private Sub cmdHelp_Click()
    Dim Topic As String
    
    Select Case tabOpt.SelectedItem.Index
    Case 1: Topic = "#CfgRetOptions"
    Case 2: Topic = "#CfgRetFilters"
    End Select
    ShowHelp 0, Topic, "2"
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    If KeyCode = vbKeyF1 And Shift = 0 Then cmdHelp_Click: KeyCode = 0
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(166))
    Me.Top = Val(PData(167))
    
    For i = 0 To 3
        txtOpt(i).Text = Cnf(4, i)
    Next i
    cboOpt(0).Text = Cnf(4, 8)
    For i = 0 To 6
        chkOpt(i).Value = Val(Cnf(4, i + 12))
    Next i
    On Error Resume Next
    x = SVal(Cnf(0, 5)) + 8
    For i = 0 To 3
        txtOpt(i).FontSize = x
    Next i
    cboOpt_Change (0)
    chkOpt_Click (0)
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PendingCfg(6) = False
    PData(166) = Str(Me.Left)
    PData(167) = Str(Me.Top)
End Sub

