VERSION 5.00
Begin VB.Form frmKeys 
   BorderStyle     =   1  'Fest Einfach
   ClientHeight    =   6705
   ClientLeft      =   30
   ClientTop       =   330
   ClientWidth     =   5310
   Icon            =   "Keys.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6705
   ScaleWidth      =   5310
   StartUpPosition =   3  'Windows-Standard
   Begin VB.CheckBox chkDetails 
      Caption         =   "Details"
      Height          =   192
      Left            =   4020
      TabIndex        =   1
      Top             =   6060
      Width           =   1632
   End
   Begin VB.CommandButton cmdRead 
      Caption         =   "Read"
      Height          =   312
      Left            =   2220
      TabIndex        =   3
      Top             =   6300
      Width           =   912
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   312
      Index           =   1
      Left            =   3540
      TabIndex        =   4
      Top             =   6300
      Width           =   1452
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   312
      Index           =   0
      Left            =   360
      TabIndex        =   2
      Top             =   6300
      Width           =   1452
   End
   Begin VB.ComboBox cboID 
      Height          =   288
      Left            =   60
      TabIndex        =   5
      Top             =   240
      Width           =   5172
   End
   Begin VB.ListBox lstKeys 
      Height          =   5448
      IntegralHeight  =   0   'False
      ItemData        =   "Keys.frx":0442
      Left            =   60
      List            =   "Keys.frx":0444
      MultiSelect     =   2  'Erweitert
      Sorted          =   -1  'True
      TabIndex        =   0
      Top             =   600
      Width           =   5172
   End
   Begin VB.Label lblKeys 
      BackStyle       =   0  'Transparent
      Height          =   192
      Left            =   120
      TabIndex        =   7
      Top             =   6060
      Width           =   3852
   End
   Begin VB.Label lblUserID 
      Caption         =   "UserID:         (Enter -c for conventional encryption)"
      Height          =   192
      Left            =   120
      TabIndex        =   6
      Top             =   60
      Width           =   5052
   End
End
Attribute VB_Name = "frmKeys"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim NewLoad As Boolean, Address As String

Private Sub cmdRead_Click()
    a = InputBox(LMsg(29) + ":" + vbCr + vbCr + "(" + LMsg(30) + ")", LMsg(31))
    If a <> "" Then
        If InStr(PlainName(a, 1), ".") = 0 Then a = PlainName(a, 0) + PlainName(a, 2) + ".pgp"
    End If
    lblKeys.Caption = "": lstKeys.Clear
    KeyFile (a)
    DisplayKeys
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    If KeyAscii = 27 Then KeyAscii = 0: cmdOK_Click (1)
    If KeyAscii = 13 Then KeyAscii = 0: cmdOK_Click (0)
End Sub

Private Sub lstKeys_Click()
    If PubKeys(0) <> "" Then
        b = PubKeys(0)
        For i = 1 To 3
            a = Extract(b, " ")
            b = LTrim(Mid(b, Len(a) + 1))
        Next i
        offset = (Len(PubKeys(0)) - Len(b)) + 1
    End If
    For i = 0 To lstKeys.ListCount - 1
        If lstKeys.Selected(i) Then
            x = InStr(PubKeys(lstKeys.ItemData(i)), "/")
            If x <> 0 Then
                KD = KD + "0x" + Extract(Mid(PubKeys(lstKeys.ItemData(i)), x + 1), " ") + " "
            End If
            ID = ID + Chr(34) + Mid(PubKeys(lstKeys.ItemData(i)), offset) + Chr(34) + " "
        End If
    Next i
    If KD <> "" Then
        cboID.Text = KD + "  " + Trim(ID)
    Else
        cboID.Text = Trim(ID)
    End If
End Sub

Private Sub lstKeys_DblClick()
    cmdOK_Click (0)
End Sub

Private Sub DisplayKeys()
    lstKeys.Clear
    If PubKeys(0) <> "" Then
        b = PubKeys(0)
        For i = 1 To 3
            a = Extract(b, " ")
            b = LTrim(Mid(b, Len(a) + 1))
        Next i
        offset = Abs(chkDetails.Value - 1) * (Len(PubKeys(0)) - Len(b)) + 1
    End If
    For i = 0 To Val(PData(14)) - 1
        lstKeys.AddItem Mid(PubKeys(i), offset)
        lstKeys.ItemData(lstKeys.NewIndex) = i
    Next i
    If PData(16) = "::NoAuto::" Then a = "???" Else a = PData(16)
    lblKeys.Caption = "Keyring: " + a + "  " + PData(14) + " keys found."
    If Address <> "" Then FindAddress
End Sub

Private Sub FindAddress()
    For i = 0 To lstKeys.ListCount - 1
        If InStr(1, lstKeys.List(i), Address, vbTextCompare) <> 0 Then
            For j = 0 To lstKeys.ListCount - 1
                lstKeys.Selected(j) = j = i
            Next j
            lstKeys.ListIndex = i
            Exit For
        End If
    Next i
    Address = ""
End Sub

Private Sub chkDetails_Click()
    DisplayKeys
End Sub

Private Sub cmdOK_Click(Index As Integer)
    If Index = 0 Then
        Me.Tag = cboID.Text
        If cboID.ListCount < 40 Then
            a = Extract(cboID.Text, " ")
            For i = 0 To cboID.ListCount - 1
                If InStr(cboID.List(i), a) <> 0 Then Exit For
            Next i
            If i = cboID.ListCount Then cboID.AddItem cboID.Text, 0
        End If
        If Me.WindowState = 0 Then
            PData(17) = Str(frmKeys.Left)
            PData(18) = Str(frmKeys.Top)
            PData(19) = Str(frmKeys.Width)
            PData(20) = Str(frmKeys.Height)
        End If
    Else
        Me.Tag = ""
    End If
    Me.Hide
End Sub

Private Sub Form_Resize()
    If Me.WindowState = 0 Or Me.WindowState = 2 Then
        If Me.Height < 2000 Then Me.Height = 2000
        If Me.Width < 3200 Then Me.Width = 3200
        cmdOK(0).Top = Me.ScaleHeight - 336
        cmdOK(0).Width = Me.ScaleWidth * 0.27
        cmdOK(0).Left = Me.ScaleWidth * 0.076
        cmdOK(1).Top = Me.ScaleHeight - 336
        cmdOK(1).Width = Me.ScaleWidth * 0.27
        cmdRead.Top = Me.ScaleHeight - 336
        cmdRead.Left = cmdOK(0).Left + cmdOK(0).Width + Me.ScaleWidth * 0.076
        cmdRead.Width = Me.ScaleWidth * 0.17
        cmdOK(1).Left = cmdRead.Left + cmdRead.Width + Me.ScaleWidth * 0.076
        lblKeys.Top = Me.ScaleHeight - 576
        chkDetails.Top = Me.ScaleHeight - 576
        chkDetails.Left = Me.ScaleWidth - 864
        lstKeys.Height = Me.ScaleHeight - 1188
        lstKeys.Width = Me.ScaleWidth - 132
        cboID.Width = lstKeys.Width
    End If
End Sub

Private Sub Form_Activate()
    If Me.Tag <> "Loaded" Then
        Address = Me.Tag
        Me.Tag = "Loaded"
        Me.Refresh
        If PData(16) <> "" And PData(16) <> "::NoAuto::" And Val(PData(14)) <> 0 Then
            If SDir(PData(16)) <> "" Then
                If FileDateTime(PData(16)) <> DateVal(PData(15)) Then
                    lblKeys.Caption = "": lstKeys.Clear
                    KeyFile ("")
                    DisplayKeys
                Else
                    If NewLoad Then DisplayKeys
                    If Address <> "" Then FindAddress
                End If
            Else
                lblKeys.Caption = "": lstKeys.Clear
                KeyFile ("")
                DisplayKeys
            End If
        Else
            If PData(16) <> "::NoAuto::" Then lblKeys.Caption = "": lstKeys.Clear: KeyFile (""): DisplayKeys
        End If
        If PData(16) = "::NoAuto::" Then
            If NewLoad Then DisplayKeys
            If Address <> "" Then FindAddress
        End If
        NewLoad = False
        cboID.SetFocus
    End If
    If lstKeys.SelCount <> 0 Then lstKeys_Click
End Sub

Private Sub Form_Load()
    If Me.WindowState = 0 Then
        frmKeys.Left = Val(PData(17))
        frmKeys.Top = Val(PData(18))
        If Val(PData(19)) <> 0 And Val(PData(20)) <> 0 Then
            frmKeys.Width = Val(PData(19))
            frmKeys.Height = Val(PData(20))
        End If
    End If
    'If Lang <> "en" Then
    '    cmdOK(1).Caption = LMsg(279)
    '    cmdRead.Caption = LMsg(292)
    '    lblUserID.Caption = LMsg(291)
    '    chkDetails.Caption = LMsg(293)
    'End If
    NewLoad = True
End Sub

