VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmCfStats 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Stats - Configuration"
   ClientHeight    =   5790
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   6870
   Icon            =   "CfStats.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5790
   ScaleWidth      =   6870
   Begin VB.Timer tmrProgBusy 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   3180
      Top             =   5040
   End
   Begin VB.Frame fraStats 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4872
      Index           =   0
      Left            =   60
      TabIndex        =   32
      Top             =   420
      Width           =   6732
      Begin VB.CommandButton cmdColor 
         Caption         =   "Restore Default Colors"
         Height          =   252
         Index           =   3
         Left            =   3540
         TabIndex        =   11
         Top             =   4500
         Width           =   2592
      End
      Begin VB.ComboBox cboStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   4
         ItemData        =   "CfStats.frx":0442
         Left            =   180
         List            =   "CfStats.frx":0458
         TabIndex        =   7
         Top             =   3060
         Width           =   6372
      End
      Begin VB.CommandButton cmdColor 
         Caption         =   "Link Color"
         Height          =   252
         Index           =   2
         Left            =   3540
         TabIndex        =   10
         Top             =   4200
         Width           =   2592
      End
      Begin VB.CommandButton cmdColor 
         Caption         =   "Background Color"
         Height          =   252
         Index           =   1
         Left            =   480
         TabIndex        =   9
         Top             =   4500
         Width           =   2592
      End
      Begin VB.CommandButton cmdColor 
         Caption         =   "Text Color"
         Height          =   252
         Index           =   0
         Left            =   480
         TabIndex        =   8
         Top             =   4200
         Width           =   2592
      End
      Begin VB.ComboBox cboStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   3
         ItemData        =   "CfStats.frx":0512
         Left            =   180
         List            =   "CfStats.frx":0528
         TabIndex        =   6
         Top             =   2460
         Width           =   6372
      End
      Begin VB.CheckBox chkStats 
         Caption         =   "Refresh machine and chain info"
         Height          =   192
         Index           =   2
         Left            =   180
         TabIndex        =   3
         TabStop         =   0   'False
         Top             =   960
         Width           =   5352
      End
      Begin VB.CheckBox chkStats 
         Caption         =   "Refresh capability strings"
         Height          =   192
         Index           =   1
         Left            =   180
         TabIndex        =   2
         TabStop         =   0   'False
         Top             =   600
         Width           =   6012
      End
      Begin VB.TextBox txtStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   312
         Index           =   0
         Left            =   2100
         MaxLength       =   4
         TabIndex        =   1
         Top             =   180
         Width           =   732
      End
      Begin VB.CheckBox chkStats 
         Caption         =   "Retrieve stats every"
         Height          =   192
         Index           =   0
         Left            =   180
         TabIndex        =   0
         TabStop         =   0   'False
         Top             =   240
         Width           =   1872
      End
      Begin VB.ComboBox cboStats 
         Height          =   288
         Index           =   0
         ItemData        =   "CfStats.frx":05E2
         Left            =   4980
         List            =   "CfStats.frx":05F5
         Style           =   2  'Dropdown-Liste
         TabIndex        =   5
         Top             =   1560
         Width           =   1332
      End
      Begin VB.TextBox txtStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   180
         MaxLength       =   255
         TabIndex        =   4
         Top             =   1560
         Width           =   4692
      End
      Begin VB.Label Label17 
         Caption         =   "Proxy B:"
         Height          =   192
         Left            =   180
         TabIndex        =   44
         Top             =   2820
         Width           =   3372
      End
      Begin VB.Label Label16 
         Caption         =   "Proxy A:"
         Height          =   192
         Left            =   180
         TabIndex        =   43
         Top             =   2220
         Width           =   3372
      End
      Begin VB.Label Label13 
         Caption         =   "hours"
         Height          =   192
         Left            =   2940
         TabIndex        =   36
         Top             =   240
         Width           =   1032
      End
      Begin VB.Label Label11 
         Alignment       =   2  'Zentriert
         Caption         =   "WARNING: All files in this folder are erased."
         Height          =   192
         Left            =   180
         TabIndex        =   35
         Top             =   1920
         Width           =   4752
      End
      Begin VB.Label Label10 
         Caption         =   "Files To Cache:"
         Height          =   192
         Left            =   4980
         TabIndex        =   34
         Top             =   1320
         Width           =   1812
      End
      Begin VB.Label Label9 
         Caption         =   "Temporary Cache Folder:"
         Height          =   192
         Left            =   180
         TabIndex        =   33
         Top             =   1320
         Width           =   3372
      End
   End
   Begin VB.Frame fraStats 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4872
      Index           =   3
      Left            =   60
      TabIndex        =   37
      Top             =   360
      Width           =   6732
      Begin VB.ListBox lstBookmarks 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3480
         Left            =   120
         TabIndex        =   17
         TabStop         =   0   'False
         Top             =   96
         Width           =   6492
      End
      Begin VB.TextBox txtTitle 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   660
         TabIndex        =   18
         Top             =   3756
         Width           =   5952
      End
      Begin VB.TextBox txtURL 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   660
         TabIndex        =   19
         Top             =   4116
         Width           =   5952
      End
      Begin VB.CommandButton cmdBooksmarks 
         Caption         =   "&New"
         Height          =   312
         Index           =   0
         Left            =   1260
         TabIndex        =   20
         TabStop         =   0   'False
         Top             =   4560
         Width           =   912
      End
      Begin VB.CommandButton cmdBooksmarks 
         Caption         =   "&Delete"
         Height          =   312
         Index           =   1
         Left            =   2340
         TabIndex        =   21
         TabStop         =   0   'False
         Top             =   4560
         Width           =   912
      End
      Begin VB.CommandButton cmdBooksmarks 
         Caption         =   "&Up"
         Height          =   312
         Index           =   2
         Left            =   3420
         TabIndex        =   22
         TabStop         =   0   'False
         Top             =   4560
         Width           =   912
      End
      Begin VB.CommandButton cmdBooksmarks 
         Caption         =   "Do&wn"
         Height          =   312
         Index           =   3
         Left            =   4500
         TabIndex        =   23
         TabStop         =   0   'False
         Top             =   4560
         Width           =   912
      End
      Begin VB.Label Label14 
         Caption         =   "Title:"
         Height          =   192
         Left            =   120
         TabIndex        =   39
         Top             =   3816
         Width           =   1452
      End
      Begin VB.Label Label15 
         Caption         =   "URL:"
         Height          =   192
         Left            =   120
         TabIndex        =   38
         Top             =   4176
         Width           =   1572
      End
   End
   Begin VB.Frame fraStats 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4872
      Index           =   2
      Left            =   60
      TabIndex        =   40
      Top             =   360
      Width           =   6732
      Begin VB.TextBox txtStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2052
         Index           =   6
         Left            =   100
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   16
         Top             =   2820
         Width           =   6552
      End
      Begin VB.TextBox txtStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2052
         Index           =   5
         Left            =   100
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   15
         Top             =   360
         Width           =   6552
      End
      Begin VB.Label Label6 
         Caption         =   "Type2.list ; Pubring.mix  URLs:"
         Height          =   192
         Left            =   100
         TabIndex        =   42
         Top             =   2580
         Width           =   5652
      End
      Begin VB.Label Label7 
         Caption         =   "Mix Stats URLs:"
         Height          =   192
         Left            =   96
         TabIndex        =   41
         Top             =   120
         Width           =   3372
      End
   End
   Begin VB.Frame fraStats 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4932
      Index           =   1
      Left            =   60
      TabIndex        =   28
      Top             =   360
      Width           =   6732
      Begin VB.TextBox txtStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1272
         Index           =   4
         Left            =   100
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   14
         Top             =   3600
         Width           =   6552
      End
      Begin VB.TextBox txtStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1212
         Index           =   3
         Left            =   100
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   13
         Top             =   2040
         Width           =   6552
      End
      Begin VB.TextBox txtStats 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1332
         Index           =   2
         Left            =   100
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   12
         Top             =   360
         Width           =   6552
      End
      Begin VB.Label Label4 
         Caption         =   "CPunk Keys URLs:"
         Height          =   192
         Left            =   100
         TabIndex        =   31
         Top             =   3360
         Width           =   1872
      End
      Begin VB.Label Label3 
         Caption         =   "CPunk Chain Stats URLs:"
         Height          =   192
         Left            =   100
         TabIndex        =   30
         Top             =   1800
         Width           =   1872
      End
      Begin VB.Label Label2 
         Caption         =   "CPunk Stats URLs:"
         Height          =   192
         Left            =   100
         TabIndex        =   29
         Top             =   120
         Width           =   1872
      End
   End
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   372
      Left            =   4680
      TabIndex        =   26
      Top             =   5400
      Width           =   1992
   End
   Begin VB.CommandButton cmdStats 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   372
      Index           =   1
      Left            =   2460
      TabIndex        =   25
      TabStop         =   0   'False
      Top             =   5400
      Width           =   1992
   End
   Begin VB.CommandButton cmdStats 
      Caption         =   "&OK"
      Height          =   372
      Index           =   0
      Left            =   240
      TabIndex        =   24
      TabStop         =   0   'False
      Top             =   5400
      Width           =   1992
   End
   Begin ComctlLib.TabStrip tabStats 
      Height          =   5292
      Left            =   0
      TabIndex        =   27
      Top             =   60
      Width           =   6852
      _ExtentX        =   12091
      _ExtentY        =   9340
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   4
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "O&ptions"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "C&ypherpunk"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Mixmaster"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab4 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Bookmarks"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmCfStats"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim Tempmarks(MaxBookmarks) As String

Private Sub cmdBooksmarks_Click(Index As Integer)
    lstBookmarks.SetFocus
    x = lstBookmarks.ListIndex
    Select Case Index
    Case 0  'New
        If Not lstBookmarks.ListCount < MaxBookmarks + 1 Then MsgBox LMsg(363), vbInformation: Exit Sub
        If Trim(txtTitle.Text) <> "" And Trim(txtURL.Text) <> "" Then
            If x <> -1 Then lstBookmarks.AddItem txtTitle.Text, x Else lstBookmarks.AddItem txtTitle.Text
            z = lstBookmarks.NewIndex
            For i = MaxBookmarks - 1 To z Step -1
                Tempmarks(i + 1) = Tempmarks(i)
            Next i
            Tempmarks(z) = txtURL.Text
            lstBookmarks.Tag = ""
            lstBookmarks.ListIndex = z
        End If
    Case 1  'Delete
        If x <> -1 Then
            lstBookmarks.RemoveItem x
            For i = x To MaxBookmarks - 1
                Tempmarks(i) = Tempmarks(i + 1)
            Next i
            txtTitle.Text = "": txtURL.Text = ""
            lstBookmarks.Tag = ""
            If x < lstBookmarks.ListCount Then lstBookmarks.ListIndex = x
        End If
    Case 2, 3 'Up
        UpdateData
        If Index = 2 Then y = 1 Else y = -1
        If x <> -1 And Not (Index = 2 And x = 0) And Not (Index = 3 And x = lstBookmarks.ListCount - 1) And lstBookmarks.ListCount > 1 Then
            tempt = lstBookmarks.List(x)
            tempu = Tempmarks(x)
            If Index = 2 Then y = -1 Else y = 1
            lstBookmarks.List(x) = lstBookmarks.List(x + y)
            Tempmarks(x) = Tempmarks(x + y)
            lstBookmarks.List(x + y) = tempt
            Tempmarks(x + y) = tempu
            lstBookmarks.Tag = ""
            lstBookmarks.ListIndex = lstBookmarks.ListIndex + y
        End If
    End Select
    lstBookmarks.Tag = lstBookmarks.ListIndex
End Sub

Private Sub cmdColor_Click(Index As Integer)
    If Index < 3 Then
        frmMain!CommonDialog1.Flags = cdlCCRGBInit
        frmMain!CommonDialog1.Color = Val(cmdColor(Index).Tag)
        frmMain!CommonDialog1.CancelError = True
        On Error GoTo CancelFont
        frmMain!CommonDialog1.Action = 3
        cmdColor(Index).Tag = Str(frmMain!CommonDialog1.Color)
    Else
        cmdColor(0).Tag = "-2147483630"
        cmdColor(1).Tag = "-2147483633"
        cmdColor(2).Tag = "16711680"
    End If
Exit Sub
CancelFont:
End Sub

Private Sub lstBookmarks_Click()
    UpdateData
    x = lstBookmarks.ListIndex
    If x <> -1 Then
        txtTitle.Text = lstBookmarks.List(x)
        txtURL.Text = Tempmarks(x)
    Else
        txtTitle.Text = "": txtURL.Text = ""
    End If
    lstBookmarks.Tag = Str(x)
End Sub

Private Sub UpdateData()
    If lstBookmarks.Tag <> "" Then
        x = Val(lstBookmarks.Tag)
        If x <> -1 And Trim(txtTitle.Text) <> "" And Trim(txtURL.Text) <> "" Then
            lstBookmarks.List(x) = Trim(txtTitle.Text)
            Tempmarks(x) = Trim(txtURL.Text)
        End If
    End If
End Sub

Private Sub chkStats_Click(Index As Integer)
    txtStats(0).Enabled = chkStats(0).Value = 1
End Sub

Private Sub tabStats_click()
    fraStats(tabStats.SelectedItem.Index - 1).ZOrder
End Sub

Private Sub cmdStats_Click(Index As Integer)
    If Index = 0 Then
        UpdateData
        Me.MousePointer = 11
        cmdStats(0).Enabled = False
        For i = 0 To 3
            fraStats(i).Enabled = False
        Next i
        PendingCfg(5) = True
        If ProgBusy("Stats") Then
            tmrProgBusy.Tag = "Stats"
            tmrProgBusy.Enabled = True
            Exit Sub
        End If
        'Update Data
        '0-2
        For i = 0 To 2
            Cnf(3, i) = Str(chkStats(i).Value)
        Next i
        '11-14    11,12 defunct
        For i = 3 To 4
            Cnf(3, i + 10) = cboStats(i).Text
        Next i
        Cnf(3, 10) = Str(cboStats(0).ListIndex)
        '18-24
        For i = 0 To 6
            Cnf(3, i + 18) = txtStats(i).Text
        Next i
        'Bookmarks
        Erase Bookmarks
        For i = 0 To lstBookmarks.ListCount - 1
            Bookmarks(i, 0) = lstBookmarks.List(i)
            Bookmarks(i, 1) = Tempmarks(i)
        Next i
        'Color
        For i = 0 To 2
            Cnf(3, 7 + i) = cmdColor(i).Tag
        Next i
        'Check
        If Not CheckConfig("Stats") Then
            PendingCfg(5) = False
            Me.MousePointer = 0
            For i = 0 To 3
                fraStats(i).Enabled = True
            Next i
            cmdStats(0).Enabled = True
            Exit Sub
        End If
        Me.MousePointer = 0
    End If
    Unload Me
End Sub

Private Sub tmrProgBusy_Timer()
    If Not ProgBusy(tmrProgBusy.Tag) Then tmrProgBusy.Enabled = False: cmdStats_Click (0)
End Sub

Private Sub cmdHelp_Click()
    Dim Topic As String
    
    Select Case tabStats.SelectedItem.Index
    Case 1: Topic = "#CfgStatsOptions"
    Case 2: Topic = "#CfgStatsCPunk"
    Case 3: Topic = "#CfgStatsMix"
    Case 4: Topic = "#CfgStatsBookmarks"
    End Select
    ShowHelp 0, Topic, "2"
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    If KeyCode = vbKeyF1 And Shift = 0 Then cmdHelp_Click: KeyCode = 0
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(102))
    Me.Top = Val(PData(103))
    
    '0-2
    For i = 0 To 2
        chkStats(i).Value = Val(Cnf(3, i))
    Next i
    chkStats_Click (0)
    '11-14   11,12 defunct
    For i = 3 To 4
        cboStats(i).Text = Cnf(3, i + 10)
    Next i
    If Val(Cnf(3, 10)) < cboStats(0).ListCount Then cboStats(0).ListIndex = Val(Cnf(3, 10))
    If Cnf(3, 10) = "" Then cboStats(0).ListIndex = 2
    '18-24
    For i = 0 To 6
        txtStats(i).Text = Cnf(3, i + 18)
    Next i
    If cboStats(0).Text = "" Then cboStats(0).Text = "16"
    'Color
    For i = 0 To 2
        cmdColor(i).Tag = Cnf(3, 7 + i)
    Next i
    'Bookmarks
    For i = 0 To MaxBookmarks
        If Bookmarks(i, 0) = "" Then Exit For
        lstBookmarks.AddItem Bookmarks(i, 0)
        lstBookmarks.ItemData(lstBookmarks.NewIndex) = i
        Tempmarks(i) = Bookmarks(i, 1)
    Next i
    chkStats_Click (0)
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PendingCfg(5) = False
    PData(102) = Str(Me.Left)
    PData(103) = Str(Me.Top)
End Sub


