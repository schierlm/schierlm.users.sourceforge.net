VERSION 5.00
Begin VB.Form frmMultiBox 
   Caption         =   "Enter Text"
   ClientHeight    =   5100
   ClientLeft      =   45
   ClientTop       =   315
   ClientWidth     =   6735
   Icon            =   "MultiBox.frx":0000
   LinkTopic       =   "Form1"
   MinButton       =   0   'False
   ScaleHeight     =   5100
   ScaleWidth      =   6735
   StartUpPosition =   2  'Bildschirmmitte
   Begin VB.ListBox lstInput 
      Height          =   3648
      IntegralHeight  =   0   'False
      ItemData        =   "MultiBox.frx":0442
      Left            =   60
      List            =   "MultiBox.frx":0444
      Style           =   1  'Kontrollk�stchen
      TabIndex        =   4
      Top             =   900
      Visible         =   0   'False
      Width           =   6612
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   372
      Index           =   1
      Left            =   3720
      TabIndex        =   2
      Top             =   4680
      Width           =   1692
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Index           =   0
      Left            =   1200
      TabIndex        =   1
      Top             =   4680
      Width           =   1692
   End
   Begin VB.TextBox txtInput 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3612
      Left            =   60
      MaxLength       =   31000
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Beides
      TabIndex        =   0
      Top             =   900
      Width           =   6600
   End
   Begin VB.Label lblMsg 
      Height          =   732
      Left            =   60
      TabIndex        =   3
      Top             =   60
      Width           =   6552
   End
End
Attribute VB_Name = "frmMultiBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Sub cmdOK_Click(Index As Integer)
    Dim a As String
    If Index = 0 Then
        If lstInput.Visible Then
            For i = 0 To lstInput.ListCount - 1
                If lstInput.Selected(i) Then a = a + lstInput.List(i) + vbCrLf
            Next i
            txtInput.Text = a
        End If
        Me.Hide
    Else
        txtInput.Text = ""
        Me.Hide
    End If
End Sub

Private Sub Form_Load()
    On Error Resume Next
    txtInput.FontSize = SVal(Cnf(0, 5)) + 8
    lstInput.FontSize = SVal(Cnf(0, 5)) + 8
End Sub

Private Sub Form_Resize()
    If Me.WindowState <> 1 Then
        If Me.Height < 2292 Then Me.Height = 2292
        If Me.Width < 4644 Then Me.Width = 4644
        sw = Me.ScaleWidth
        sh = Me.ScaleHeight
        cmdOK(0).Left = sw / 2 - cmdOK(0).Width - 372
        cmdOK(1).Left = sw / 2 + 372
        cmdOK(0).Top = sh - 420
        cmdOK(1).Top = cmdOK(0).Top
        txtInput.Width = sw - 96
        txtInput.Height = sh - 1452
        lstInput.Width = txtInput.Width
        lstInput.Height = txtInput.Height
    End If
End Sub

