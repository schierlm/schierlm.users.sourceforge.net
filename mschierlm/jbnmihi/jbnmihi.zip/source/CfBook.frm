VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmCfBook 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Books - Configuration"
   ClientHeight    =   6405
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   7905
   Icon            =   "CfBook.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6405
   ScaleWidth      =   7905
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   372
      Left            =   5400
      TabIndex        =   31
      Top             =   6000
      Width           =   1992
   End
   Begin VB.Timer tmrProgBusy 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   4980
      Top             =   6000
   End
   Begin VB.CommandButton cmdOpt 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Index           =   0
      Left            =   540
      TabIndex        =   18
      Top             =   6000
      Width           =   1992
   End
   Begin VB.CommandButton cmdOpt 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   372
      Index           =   1
      Left            =   2940
      TabIndex        =   19
      Top             =   6000
      Width           =   1992
   End
   Begin VB.Frame fraOpt 
      BorderStyle     =   0  'Kein
      Caption         =   "Options"
      Height          =   5472
      Index           =   0
      Left            =   60
      TabIndex        =   21
      Top             =   420
      Width           =   7752
      Begin VB.Frame Frame1 
         BorderStyle     =   0  'Kein
         Caption         =   "Frame1"
         Height          =   192
         Left            =   4740
         TabIndex        =   37
         Top             =   2400
         Width           =   2172
         Begin VB.OptionButton optReply 
            Caption         =   "Email"
            Height          =   192
            Index           =   0
            Left            =   0
            TabIndex        =   39
            TabStop         =   0   'False
            Top             =   0
            Width           =   912
         End
         Begin VB.OptionButton optReply 
            Caption         =   "News"
            Height          =   192
            Index           =   1
            Left            =   1080
            TabIndex        =   38
            TabStop         =   0   'False
            Top             =   0
            Width           =   912
         End
      End
      Begin VB.ComboBox cboOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         ItemData        =   "CfBook.frx":0442
         Left            =   3240
         List            =   "CfBook.frx":0488
         TabIndex        =   36
         Top             =   2640
         Width           =   4332
      End
      Begin VB.ComboBox cboOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         ItemData        =   "CfBook.frx":0705
         Left            =   3240
         List            =   "CfBook.frx":0739
         TabIndex        =   34
         Top             =   2640
         Width           =   4332
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Double-click opens full"
         Height          =   192
         Index           =   10
         Left            =   5400
         TabIndex        =   33
         TabStop         =   0   'False
         Top             =   900
         Value           =   1  'Aktiviert
         Width           =   3732
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Alter PGP time-stamp"
         Height          =   192
         Index           =   6
         Left            =   5400
         TabIndex        =   4
         TabStop         =   0   'False
         Top             =   600
         Value           =   1  'Aktiviert
         Width           =   3732
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Middleman warning"
         Height          =   192
         Index           =   9
         Left            =   2760
         TabIndex        =   32
         TabStop         =   0   'False
         Top             =   1200
         Value           =   1  'Aktiviert
         Width           =   2592
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Uptime-Hist preferred"
         Height          =   192
         Index           =   8
         Left            =   5400
         TabIndex        =   8
         TabStop         =   0   'False
         Top             =   300
         Value           =   1  'Aktiviert
         Width           =   2292
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Pop-up stats warnings"
         Height          =   192
         Index           =   7
         Left            =   2760
         TabIndex        =   7
         TabStop         =   0   'False
         Top             =   900
         Value           =   1  'Aktiviert
         Width           =   3732
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Pop-up capability warnings"
         Height          =   192
         Index           =   5
         Left            =   2760
         TabIndex        =   6
         TabStop         =   0   'False
         Top             =   600
         Value           =   1  'Aktiviert
         Width           =   3672
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Zero remailer warnings"
         Height          =   192
         Index           =   4
         Left            =   2760
         TabIndex        =   5
         TabStop         =   0   'False
         Top             =   300
         Value           =   1  'Aktiviert
         Width           =   3612
      End
      Begin VB.OptionButton optQuote 
         Caption         =   "Prompt"
         Height          =   192
         Index           =   2
         Left            =   2100
         TabIndex        =   13
         TabStop         =   0   'False
         Top             =   2640
         Value           =   -1  'True
         Width           =   1152
      End
      Begin VB.OptionButton optQuote 
         Caption         =   "Never"
         Height          =   192
         Index           =   1
         Left            =   1260
         TabIndex        =   12
         TabStop         =   0   'False
         Top             =   2640
         Width           =   852
      End
      Begin VB.OptionButton optQuote 
         Caption         =   "Always"
         Height          =   192
         Index           =   0
         Left            =   360
         TabIndex        =   11
         TabStop         =   0   'False
         Top             =   2640
         Width           =   912
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Confirm clear"
         Height          =   192
         Index           =   3
         Left            =   180
         TabIndex        =   3
         TabStop         =   0   'False
         Top             =   1200
         Value           =   1  'Aktiviert
         Width           =   3612
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Confirm text overwrite"
         Height          =   192
         Index           =   1
         Left            =   180
         TabIndex        =   1
         TabStop         =   0   'False
         Top             =   600
         Value           =   1  'Aktiviert
         Width           =   3492
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Prompt to save changes"
         Height          =   192
         Index           =   2
         Left            =   180
         TabIndex        =   2
         TabStop         =   0   'False
         Top             =   900
         Value           =   1  'Aktiviert
         Width           =   3552
      End
      Begin VB.CheckBox chkOpt 
         Caption         =   "Confirm book overwrite"
         Height          =   192
         Index           =   0
         Left            =   180
         TabIndex        =   0
         TabStop         =   0   'False
         Top             =   300
         Value           =   1  'Aktiviert
         Width           =   3492
      End
      Begin VB.CommandButton cmdFont 
         Caption         =   "Change"
         Height          =   312
         Index           =   0
         Left            =   3660
         TabIndex        =   10
         TabStop         =   0   'False
         Top             =   1920
         Width           =   1272
      End
      Begin VB.TextBox txtOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1632
         Index           =   1
         Left            =   180
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   15
         Top             =   3780
         Width           =   7392
      End
      Begin VB.TextBox txtOpt 
         Height          =   288
         Index           =   0
         Left            =   1680
         MaxLength       =   5
         TabIndex        =   14
         Top             =   2880
         Width           =   492
      End
      Begin VB.CommandButton cmdFont 
         Caption         =   "Default"
         Height          =   312
         Index           =   1
         Left            =   2340
         TabIndex        =   9
         TabStop         =   0   'False
         Top             =   1920
         Width           =   1332
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Reply heading:"
         Height          =   192
         Index           =   6
         Left            =   3240
         TabIndex        =   35
         Top             =   2400
         Width           =   1512
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Quote message in reply:"
         Height          =   192
         Index           =   1
         Left            =   180
         TabIndex        =   26
         Top             =   2400
         Width           =   3552
      End
      Begin VB.Label lblFont 
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   252
         Left            =   1740
         TabIndex        =   25
         Top             =   1560
         Width           =   3972
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Global Signature:  [Note: This signature is not pasted into messages unless you select Edit|Paste Signature]"
         Height          =   432
         Index           =   3
         Left            =   180
         TabIndex        =   24
         Top             =   3360
         Width           =   6612
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Quote Character(s):"
         Height          =   192
         Index           =   2
         Left            =   180
         TabIndex        =   23
         Top             =   2940
         Width           =   1512
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Text Font / Size:"
         Height          =   192
         Index           =   0
         Left            =   180
         TabIndex        =   22
         Top             =   1620
         Width           =   1392
      End
   End
   Begin VB.Frame fraOpt 
      BorderStyle     =   0  'Kein
      Caption         =   "Options"
      Height          =   5532
      Index           =   1
      Left            =   60
      TabIndex        =   27
      Top             =   360
      Width           =   7752
      Begin VB.TextBox txtOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2352
         Index           =   3
         Left            =   60
         MaxLength       =   20000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   17
         Top             =   3180
         Width           =   7632
      End
      Begin VB.TextBox txtOpt 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2352
         Index           =   2
         Left            =   60
         MaxLength       =   30000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   16
         Top             =   420
         Width           =   7632
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Directive Choice List:  [Appears in drop-down list of the Remailer Editor]"
         Height          =   252
         Index           =   5
         Left            =   60
         TabIndex        =   30
         Top             =   2940
         Width           =   7572
      End
      Begin VB.Label lblOpt 
         BackStyle       =   0  'Transparent
         Caption         =   "Header Choice List:  [Appears in drop-down list of Message Books]"
         Height          =   252
         Index           =   4
         Left            =   60
         TabIndex        =   29
         Top             =   180
         Width           =   7572
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   192
         Left            =   1800
         TabIndex        =   28
         Top             =   2640
         Width           =   3972
      End
   End
   Begin ComctlLib.TabStrip tabOpt 
      Height          =   5892
      Left            =   0
      TabIndex        =   20
      Top             =   60
      Width           =   7872
      _ExtentX        =   13891
      _ExtentY        =   10398
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   2
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Options"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Choice Lists"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmCfBook"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim TempFontName As String, TempFontSize As Integer, TempFontBold As Boolean

Private Sub cmdFont_Click(Index As Integer)
    If Index = 0 Then
        frmMain!CommonDialog1.Flags = &H3 Or cdlCFForceFontExist
        frmMain!CommonDialog1.FontName = TempFontName
        frmMain!CommonDialog1.FontSize = TempFontSize
        frmMain!CommonDialog1.FontBold = TempFontBold
        frmMain!CommonDialog1.CancelError = True
        On Error GoTo CancelFont
        frmMain!CommonDialog1.Action = 4
        TempFontName = frmMain!CommonDialog1.FontName
        TempFontSize = frmMain!CommonDialog1.FontSize
        TempFontBold = frmMain!CommonDialog1.FontBold
    Else
        TempFontName = "Courier New"
        TempFontSize = 9
        TempFontBold = False
    End If
CancelFont:
    On Error Resume Next
    lblFont.Caption = TempFontName + " /" + Str(TempFontSize): If TempFontBold Then lblFont.Caption = lblFont.Caption + " Bold"
    lblFont.Font.Name = TempFontName
    lblFont.Font.Size = TempFontSize
    lblFont.Font.Bold = TempFontBold
End Sub

Private Sub cmdOpt_Click(Index As Integer)
    If Index = 0 Then
        Me.MousePointer = 11
        cmdOpt(0).Enabled = False
        For i = 0 To 1
            fraOpt(i).Enabled = False
        Next i
        PendingCfg(0) = True
        If ProgBusy("Books") Then
            tmrProgBusy.Tag = "Books"
            tmrProgBusy.Enabled = True
            Exit Sub
        End If
        For i = 0 To 10
            Cnf(2, i) = Str(chkOpt(i).Value)
        Next i
        For i = 0 To 2
            Cnf(2, i + 15) = optQuote(i).Value
        Next i
        For i = 0 To 3
            Cnf(2, i + 18) = txtOpt(i).Text
        Next i
        For i = 0 To 1
            Cnf(2, 28 + i) = cboOpt(i).Text
        Next i
        Cnf(2, 25) = TempFontName
        Cnf(2, 26) = Str(TempFontSize)
        Cnf(2, 27) = TempFontBold
        CheckConfig ("Books")
        Me.MousePointer = 0
    End If
    Unload Me
End Sub

Private Sub optReply_Click(Index As Integer)
    cboOpt(Index).ZOrder
End Sub

Private Sub tmrProgBusy_Timer()
    If Not ProgBusy(tmrProgBusy.Tag) Then tmrProgBusy.Enabled = False: cmdOpt_Click (0)
End Sub

Private Sub chkOpt_Click(Index As Integer)
    If Index = 4 And chkOpt(4).Value = 0 Then
        If MsgBox(LMsg(61), vbExclamation + vbYesNo + vbDefaultButton2, LMsg(62)) = vbNo Then chkOpt(4).Value = 1
    End If
End Sub

Private Sub tabOpt_Click()
    fraOpt(tabOpt.SelectedItem.Index - 1).ZOrder
End Sub

Private Sub cmdHelp_Click()
    Dim Topic As String
    
    Select Case tabOpt.SelectedItem.Index
    Case 1: Topic = "#CfgBooksOptions"
    Case 2: Topic = "#CfgBooksChoice"
    End Select
    ShowHelp 0, Topic, "2"
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    If KeyCode = vbKeyF1 And Shift = 0 Then cmdHelp_Click: KeyCode = 0
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(92))
    Me.Top = Val(PData(93))
    
    For i = 0 To 10
        If i <> 4 Then chkOpt(i).Value = Val(Cnf(2, i))
    Next i
    If chkOpt(4).Value <> " 0" Then chkOpt(4).Value = 1
    optQuote(2).Value = True
    If Cnf(2, 15) = True2 Then optQuote(0).Value = True2
    If Cnf(2, 16) = True2 Then optQuote(1).Value = True2
    For i = 0 To 3
        txtOpt(i).Text = Cnf(2, i + 18)
    Next i
    TempFontName = Cnf(2, 25)
    TempFontSize = Val(Cnf(2, 26))
    TempFontBold = (Cnf(2, 27) = True2)
    On Error Resume Next
    lblFont.Caption = TempFontName + " /" + Str(TempFontSize): If TempFontBold Then lblFont.Caption = lblFont.Caption + " Bold"
    lblFont.Font.Name = TempFontName
    lblFont.Font.Size = TempFontSize
    lblFont.Font.Bold = TempFontBold
    x = SVal(Cnf(0, 5)) + 8
    For i = 0 To 3
        txtOpt(i).FontSize = x
    Next i
    For i = 0 To 1
        cboOpt(i).Text = Cnf(2, 28 + i)
    Next i
    optReply(0).Value = True
    optReply_Click (0)
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PendingCfg(0) = False
    PData(92) = Str(Me.Left)
    PData(93) = Str(Me.Top)
End Sub

