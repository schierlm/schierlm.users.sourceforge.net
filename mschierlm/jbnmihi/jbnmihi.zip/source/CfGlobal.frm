VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmCfGlobal 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Global - Configuration"
   ClientHeight    =   5280
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   4575
   Icon            =   "CfGlobal.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5280
   ScaleWidth      =   4575
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   372
      Left            =   3060
      TabIndex        =   36
      Top             =   4860
      Width           =   1452
   End
   Begin VB.Timer tmrProgBusy 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   2700
      Top             =   4500
   End
   Begin VB.CommandButton cmdGlobal 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   372
      Index           =   1
      Left            =   1560
      TabIndex        =   16
      Top             =   4860
      Width           =   1392
   End
   Begin VB.CommandButton cmdGlobal 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Index           =   0
      Left            =   60
      TabIndex        =   15
      Top             =   4860
      Width           =   1392
   End
   Begin VB.Frame fraGlobal 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4392
      Index           =   0
      Left            =   180
      TabIndex        =   17
      Top             =   360
      Width           =   4092
      Begin VB.CheckBox chkSecureMode 
         Caption         =   "Secure Mode  (Encrypts user configuration file)"
         Height          =   372
         Left            =   180
         TabIndex        =   6
         TabStop         =   0   'False
         Top             =   3780
         Width           =   3792
      End
      Begin VB.ComboBox cboGlobal 
         Height          =   288
         Index           =   1
         ItemData        =   "CfGlobal.frx":0442
         Left            =   180
         List            =   "CfGlobal.frx":0452
         Style           =   2  'Dropdown-Liste
         TabIndex        =   3
         Top             =   2580
         Width           =   3732
      End
      Begin VB.TextBox txtGlobal 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   180
         MaxLength       =   256
         TabIndex        =   0
         Top             =   420
         Width           =   3732
      End
      Begin VB.TextBox txtGlobal 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   180
         TabIndex        =   1
         Top             =   1140
         Width           =   3732
      End
      Begin VB.TextBox txtGlobal 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   180
         TabIndex        =   2
         Top             =   1860
         Width           =   3732
      End
      Begin VB.ComboBox cboGlobal 
         Height          =   288
         Index           =   2
         ItemData        =   "CfGlobal.frx":048E
         Left            =   180
         List            =   "CfGlobal.frx":04A1
         Style           =   2  'Dropdown-Liste
         TabIndex        =   4
         Top             =   3300
         Width           =   1692
      End
      Begin VB.ComboBox cboLang 
         Height          =   288
         ItemData        =   "CfGlobal.frx":04B7
         Left            =   2220
         List            =   "CfGlobal.frx":04B9
         Style           =   2  'Dropdown-Liste
         TabIndex        =   5
         Top             =   3300
         Width           =   1692
      End
      Begin VB.Label lblGlobal 
         Caption         =   "DOS Mode:"
         Height          =   192
         Index           =   4
         Left            =   180
         TabIndex        =   23
         Top             =   2340
         Width           =   3612
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Global Work Folder:"
         Height          =   192
         Index           =   0
         Left            =   180
         TabIndex        =   22
         Top             =   180
         Width           =   3492
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Mail Queue Folder:"
         Height          =   192
         Index           =   1
         Left            =   180
         TabIndex        =   21
         Top             =   900
         Width           =   3552
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Wipe Files With:"
         Height          =   192
         Index           =   3
         Left            =   180
         TabIndex        =   20
         Top             =   1620
         Width           =   3612
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Preferred Font Size:"
         Height          =   192
         Index           =   5
         Left            =   180
         TabIndex        =   19
         Top             =   3060
         Width           =   1812
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Preferred Language:"
         Height          =   192
         Index           =   6
         Left            =   2220
         TabIndex        =   18
         Top             =   3060
         Width           =   3612
      End
   End
   Begin VB.Frame fraGlobal 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4392
      Index           =   2
      Left            =   180
      TabIndex        =   25
      Top             =   360
      Width           =   4272
      Begin VB.TextBox txtGlobal 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   3
         Left            =   2400
         MaxLength       =   4
         TabIndex        =   11
         Top             =   2100
         Width           =   492
      End
      Begin VB.CommandButton cmdBrowse 
         Caption         =   "Browse"
         Height          =   312
         Left            =   3000
         TabIndex        =   13
         TabStop         =   0   'False
         Top             =   2736
         Width           =   1032
      End
      Begin VB.TextBox txtGlobal 
         Height          =   1248
         Index           =   4
         Left            =   120
         MaxLength       =   10000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   14
         Top             =   3060
         Width           =   3912
      End
      Begin VB.CheckBox chkHangUp 
         Caption         =   "&Hang up automatically"
         Height          =   252
         Left            =   120
         TabIndex        =   12
         TabStop         =   0   'False
         Top             =   2460
         Width           =   3792
      End
      Begin VB.ComboBox cboEntry 
         Enabled         =   0   'False
         Height          =   288
         Left            =   120
         Style           =   2  'Dropdown-Liste
         TabIndex        =   7
         TabStop         =   0   'False
         Top             =   360
         Width           =   3912
      End
      Begin VB.TextBox txtUsername 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   312
         Left            =   360
         TabIndex        =   8
         Top             =   1020
         Width           =   2412
      End
      Begin VB.TextBox txtPassword 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   312
         IMEMode         =   3  'DISABLE
         Left            =   360
         PasswordChar    =   "*"
         TabIndex        =   9
         Top             =   1680
         Width           =   2412
      End
      Begin VB.CheckBox chkDial 
         Caption         =   "&Dial when needed every"
         Height          =   252
         Left            =   120
         TabIndex        =   10
         TabStop         =   0   'False
         Top             =   2160
         Width           =   2292
      End
      Begin VB.Label Label1 
         Caption         =   "minutes"
         Height          =   192
         Left            =   2940
         TabIndex        =   30
         Top             =   2160
         Width           =   1092
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Start the following apps on connect:"
         Height          =   192
         Index           =   7
         Left            =   120
         TabIndex        =   29
         Top             =   2820
         Width           =   3792
      End
      Begin VB.Label lblConnection 
         Caption         =   "Connection:"
         Height          =   192
         Left            =   120
         TabIndex        =   28
         Top             =   120
         Width           =   3432
      End
      Begin VB.Label lblUsername 
         Caption         =   "Username:"
         Height          =   192
         Left            =   360
         TabIndex        =   27
         Top             =   780
         Width           =   2052
      End
      Begin VB.Label lblPassword 
         Caption         =   "Password:"
         Height          =   192
         Left            =   360
         TabIndex        =   26
         Top             =   1440
         Width           =   2172
      End
   End
   Begin VB.Frame fraGlobal 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   4392
      Index           =   1
      Left            =   240
      TabIndex        =   31
      Top             =   360
      Width           =   4092
      Begin VB.ComboBox cboGlobal 
         Height          =   288
         Index           =   3
         ItemData        =   "CfGlobal.frx":04BB
         Left            =   180
         List            =   "CfGlobal.frx":04C5
         Style           =   2  'Dropdown-Liste
         TabIndex        =   37
         Top             =   1500
         Width           =   3732
      End
      Begin VB.TextBox txtGlobal 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   5
         Left            =   180
         MaxLength       =   70
         TabIndex        =   35
         Top             =   2220
         Width           =   3732
      End
      Begin VB.ComboBox cboGlobal 
         Height          =   288
         Index           =   0
         ItemData        =   "CfGlobal.frx":04E1
         Left            =   180
         List            =   "CfGlobal.frx":04EB
         Style           =   2  'Dropdown-Liste
         TabIndex        =   32
         Top             =   420
         Width           =   3732
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Preferred Algorithm:  (If a remailer has both RSA and DSA keys, which do you prefer to use?) "
         Height          =   552
         Index           =   8
         Left            =   180
         TabIndex        =   38
         Top             =   900
         Width           =   3612
      End
      Begin VB.Label lblGlobal 
         Caption         =   "Version Report:  (Leave blank for default)"
         Height          =   192
         Index           =   9
         Left            =   180
         TabIndex        =   34
         Top             =   1980
         Width           =   3612
      End
      Begin VB.Label lblGlobal 
         Caption         =   "PGP Version:"
         Height          =   192
         Index           =   2
         Left            =   180
         TabIndex        =   33
         Top             =   180
         Width           =   3612
      End
   End
   Begin ComctlLib.TabStrip tabGlobal 
      Height          =   4752
      Left            =   60
      TabIndex        =   24
      Top             =   60
      Width           =   4452
      _ExtentX        =   7858
      _ExtentY        =   8387
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   3
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Program"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&PGP"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Dialer"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmCfGlobal"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Sub UpdateData()
    Dim Tmp(50) As String, a As String, b As String, x As Integer
    
    If cboEntry.Tag = "" Then Exit Sub
    a = txtUsername.Tag
    b = cboEntry.Tag + vbCrLf + txtUsername.Text + vbCrLf + txtPassword.Text + vbCrLf
    x = ParseString(a, Tmp(), 50, True)
    For i = 0 To x Step 3
        If LCase(Tmp(i)) <> LCase(cboEntry.Tag) And Tmp(i) <> "" And i + 2 <= x Then
            For j = 0 To cboEntry.ListCount
                If LCase(Tmp(i)) = LCase(cboEntry.List(j)) Then Exit For
            Next j
            If j < cboEntry.ListCount + 1 Then
                b = b + cboEntry.List(j) + vbCrLf + Tmp(i + 1) + vbCrLf + Tmp(i + 2) + vbCrLf
            End If
        End If
    Next i
    txtUsername.Tag = b
End Sub

Private Sub cboEntry_Click()
    Dim Tmp(50) As String, a As String, b As String, x As Integer
    
    UpdateData
    chkDial.Enabled = (cboEntry.ListIndex <> -1)
    chkHangUp.Enabled = (cboEntry.ListIndex <> -1)
    txtUsername.Text = ""
    txtPassword.Text = ""
    cboEntry.Tag = cboEntry.Text
    If cboEntry.Tag <> "" Then
        a = txtUsername.Tag
        x = ParseString(a, Tmp(), 50, True)
        For i = 0 To x Step 3
            If LCase(Tmp(i)) = LCase(cboEntry.Tag) And i + 2 <= x Then
                txtUsername.Text = Tmp(i + 1)
                txtPassword.Text = Tmp(i + 2)
                Exit For
            End If
        Next i
    End If
End Sub

Private Sub cboGlobal_Click(Index As Integer)
    If Index = 0 Then cboGlobal(3).Enabled = cboGlobal(0).ListIndex <> 0: lblGlobal(8).Enabled = cboGlobal(3).Enabled
End Sub

Private Sub chkDial_Click()
    txtGlobal(3).Enabled = chkDial.Value = 1
End Sub

Private Sub cmdBrowse_Click()
    sm = QueryValueROOT("Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "Start Menu", HKEY_CURRENT_USER)
    If sm = "" Then sm = "C:\Windows\Start Menu"
    a = OpenDialog(sm, "", LMsg(67), cdlOFNHideReadOnly + cdlOFNFileMustExist, "Applications (*.exe;*.com;*.bat;*.lnk)|*.exe;*.com;*.bat;*.lnk|All Files (*.*)|*.*", 1, frmMain)
    If a <> "" And InStr(1, txtGlobal(4).Text, a + vbCrLf, vbTextCompare) = 0 And Len(txtGlobal(4).Text) + Len(a) + 2 < 10000 Then txtGlobal(4).Text = a + vbCrLf + txtGlobal(4).Text
End Sub

Private Sub cmdGlobal_Click(Index As Integer)
    Dim CPass(1) As String
    
    If Index = 0 Then
        UpdateData
        Me.MousePointer = 11
        cmdGlobal(0).Enabled = False
        For i = 0 To 2
            fraGlobal(i).Enabled = False
        Next i
        PendingCfg(1) = True
        If ProgBusy("Global") Then
            tmrProgBusy.Tag = "Global"
            tmrProgBusy.Enabled = True
            Exit Sub
        End If
        'Secure Mode
        If chkSecureMode.Value = 0 And PData(68) = True2 Then
            If MsgBox(LMsg(329), vbExclamation + vbOKCancel + vbDefaultButton2, LMsg(18)) = vbCancel Then chkSecureMode.Value = 1: Exit Sub
        End If
        If chkSecureMode.Value = 1 And PData(68) <> True2 Then
PassEntry:  For i = 0 To 1
                CPass(i) = GetConvPass(LMsg(326))
                If CPass(i) = "" Then Exit For
            Next i
            If CPass(0) = "" Or CPass(1) = "" Or CPass(0) <> CPass(1) Then
                If MsgBox(LMsg(139), vbCritical + vbRetryCancel, LMsg(140)) = vbCancel Then Exit Sub
                GoTo PassEntry
            End If
            SecurePass = Mid(XCrypt(CPass(0), RightWin), 4)
            For i = 0 To 1
                CPass(i) = String(Len(CPass(i)), "@")
            Next i
        End If
        PData(68) = chkSecureMode.Value = 1
        If PData(68) <> True2 Then SecurePass = ""
        'Program
        '0-2
        For i = 0 To 2
            Cnf(0, i) = Trim(txtGlobal(i).Text)
        Next i
        '3-6
        For i = 0 To 3
            Cnf(0, i + 3) = Str(cboGlobal(i).ListIndex)
        Next i
        If PData(0) <> cboLang.Text Then PData(0) = cboLang.Text: MsgBox LMsg(19), vbInformation, LMsg(20)
        'Dialer
        If cboEntry.ListIndex <> -1 Then Cnf(0, 10) = cboEntry.List(cboEntry.ListIndex) Else Cnf(0, 10) = ""
        PData(54) = chkDial.Value = 1
        frmMain!mnuDialOpt(1).Checked = chkDial.Value = 1
        PData(55) = chkHangUp.Value = 1
        frmMain!mnuDialOpt(2).Checked = chkHangUp.Value = 1
        Cnf(0, 11) = txtUsername.Tag
        For i = 3 To 5
            Cnf(0, 9 + i) = txtGlobal(i).Text
        Next i
        'Update
        If Not CheckConfig("Global") Then
            PendingCfg(1) = False
            Me.MousePointer = 0
            For i = 0 To 2
                fraGlobal(i).Enabled = True
            Next i
            cmdGlobal(0).Enabled = True
            Exit Sub
        End If
        
        Me.MousePointer = 0
        If NewSecure And PData(68) = True2 And SDir(DataDir + "\JBNConf.asc") <> "" Then MsgBox LMsg(333), vbInformation, LMsg(334)
    End If
    Unload Me
End Sub

Private Sub cmdHelp_Click()
    Dim Topic As String
    
    Select Case tabGlobal.SelectedItem.Index
    Case 1: Topic = "#CfgGlobalProgram"
    Case 2: Topic = "#CfgGlobalPGP"
    Case 3: Topic = "#CfgGlobalDialer"
    End Select
    ShowHelp 0, Topic, "2"
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    If KeyCode = vbKeyF1 And Shift = 0 Then cmdHelp_Click: KeyCode = 0
End Sub

Private Sub tmrProgBusy_Timer()
    If Not ProgBusy(tmrProgBusy.Tag) Then tmrProgBusy.Enabled = False: cmdGlobal_Click (0)
End Sub

Private Sub tabGlobal_Click()
    fraGlobal(tabGlobal.SelectedItem.Index - 1).ZOrder
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(94))
    Me.Top = Val(PData(95))
    
    'Program
    '0-2
    For i = 0 To 2
        txtGlobal(i).Text = Cnf(0, i)
    Next i
    '3-6
    For i = 0 To 3
        cboGlobal(i).ListIndex = Val(Cnf(0, i + 3))
    Next i
    cboGlobal_Click (0)
    x = -1
    a = SDir(ProgDir + "\JBNL-*.DAT")
    While a <> ""
        l = LCase(Extract(Mid(a, 6), "."))
        If l <> "" Then
            cboLang.AddItem l
            If PData(0) = l Then x = cboLang.NewIndex
        End If
        a = Dir
    Wend
    cboLang.ListIndex = x
    If PData(68) = True2 Then chkSecureMode.Value = 1
    'Dialer
    txtUsername.Tag = Cnf(0, 11)
    For i = 3 To 5
        txtGlobal(i).Text = Cnf(0, 9 + i)
    Next i
    xentry = -1
    On Error Resume Next
    For i = 0 To frmMain!Dialer1.PhoneBookEntries - 1
        cboEntry.AddItem frmMain!Dialer1.PhoneBookEntry(i)
        If Cnf(0, 10) = frmMain!Dialer1.PhoneBookEntry(i) Then xentry = i
    Next i
    
    cboEntry.Enabled = (frmMain!Dialer1.PhoneBookEntries <> 0)
    If xentry = -1 Then
        Cnf(0, 10) = ""
    Else
        cboEntry.ListIndex = xentry
    End If
    On Error GoTo 0
    
    If PData(54) = True2 Then chkDial.Value = 1
    chkDial_Click
    If PData(55) = True2 Then chkHangUp.Value = 1
    cboEntry.Tag = cboEntry.Text
    cboEntry_Click
    tabGlobal_Click
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PendingCfg(1) = False
    PData(94) = Str(Me.Left)
    PData(95) = Str(Me.Top)
End Sub

