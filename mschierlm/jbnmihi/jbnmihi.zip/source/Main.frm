VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{33101C00-75C3-11CF-A8A0-444553540000}#1.0#0"; "CSWSK32.OCX"
Object = "{F070A860-7D7E-11CF-A8A0-444553540000}#1.0#0"; "CSPOP32.OCX"
Object = "{86E75BE0-83F1-11CF-A8A0-444553540000}#1.0#0"; "CSRAS32.OCX"
Object = "{F070A868-7D7E-11CF-A8A0-444553540000}#1.0#0"; "CSMTP32.OCX"
Object = "{33335143-F789-11CE-86F8-0020AFD8C6DB}#2.0#0"; "NETCOD35.OCX"
Begin VB.Form frmMain 
   Caption         =   "Jack B. Nymble v2"
   ClientHeight    =   6135
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   8460
   Icon            =   "Main.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   6135
   ScaleWidth      =   8460
   StartUpPosition =   3  'Windows-Standard
   Begin SmtpClientCtrl.SmtpClient SmtpClient1 
      Left            =   8100
      Top             =   2040
      _Version        =   65536
      _ExtentX        =   741
      _ExtentY        =   741
      _StockProps     =   0
      Address         =   ""
      AutoResolve     =   -1  'True
      Blocking        =   -1  'True
      Domain          =   ""
      HostAddress     =   ""
      HostName        =   ""
      RemotePort      =   0
      RemoteService   =   ""
      Timeout         =   60
   End
   Begin RasDialerCtrl.Dialer Dialer1 
      Left            =   8100
      Top             =   840
      _Version        =   65536
      _ExtentX        =   741
      _ExtentY        =   741
      _StockProps     =   0
      AutoUpdate      =   -1  'True
      Callback        =   0   'False
      CallbackNumber  =   ""
      DialogState     =   0
      Interval        =   1000
      PhoneBook       =   ""
      PhoneEntry      =   ""
      PhoneNumber     =   ""
      Timeout         =   60
      UserDomain      =   ""
      UserName        =   ""
      AutoConnect     =   0   'False
      AutoDisconnect  =   -1  'True
   End
   Begin SocketWrenchCtrl.Socket Socket1 
      Left            =   8160
      Top             =   60
      _Version        =   65536
      _ExtentX        =   741
      _ExtentY        =   741
      _StockProps     =   0
      AutoResolve     =   -1  'True
      Backlog         =   5
      Binary          =   -1  'True
      Blocking        =   -1  'True
      Broadcast       =   0   'False
      BufferSize      =   0
      HostAddress     =   ""
      HostFile        =   ""
      HostName        =   ""
      InLine          =   0   'False
      Interval        =   0
      KeepAlive       =   0   'False
      Library         =   ""
      Linger          =   0
      LocalPort       =   0
      LocalService    =   ""
      Protocol        =   0
      RemotePort      =   0
      RemoteService   =   ""
      ReuseAddress    =   0   'False
      Route           =   -1  'True
      Timeout         =   0
      Type            =   1
      Urgent          =   0   'False
   End
   Begin PopClientCtrl.PopClient PopClient1 
      Left            =   8100
      Top             =   420
      _Version        =   65536
      _ExtentX        =   741
      _ExtentY        =   741
      _StockProps     =   0
      AutoResolve     =   -1  'True
      Binary          =   0   'False
      Blocking        =   -1  'True
      HostAddress     =   ""
      HostName        =   ""
      LineBreak       =   -1  'True
      RemotePort      =   0
      RemoteService   =   ""
      Timeout         =   60
      Username        =   ""
   End
   Begin VB.Frame fraMain 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   5472
      Index           =   0
      Left            =   60
      TabIndex        =   6
      Top             =   360
      Width           =   7872
      Begin VB.DriveListBox drvExplore 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Left            =   180
         TabIndex        =   9
         Top             =   660
         Visible         =   0   'False
         Width           =   3732
      End
      Begin ComctlLib.TreeView trvFolder 
         Height          =   4368
         Left            =   4140
         TabIndex        =   21
         Top             =   0
         Width           =   3732
         _ExtentX        =   6588
         _ExtentY        =   7699
         _Version        =   327682
         HideSelection   =   0   'False
         Indentation     =   176
         LineStyle       =   1
         Sorted          =   -1  'True
         Style           =   7
         Appearance      =   1
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin VB.ComboBox cboRecent 
         DragIcon        =   "Main.frx":0442
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         ItemData        =   "Main.frx":0884
         Left            =   1620
         List            =   "Main.frx":0886
         MouseIcon       =   "Main.frx":0888
         TabIndex        =   13
         Top             =   4440
         Width           =   6252
      End
      Begin VB.ComboBox cboPattern 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         ItemData        =   "Main.frx":0CCA
         Left            =   1620
         List            =   "Main.frx":0CDD
         TabIndex        =   12
         Text            =   "cboPattern"
         Top             =   0
         Width           =   2472
      End
      Begin VB.FileListBox filExplore 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   4050
         Hidden          =   -1  'True
         Index           =   1
         Left            =   1620
         MouseIcon       =   "Main.frx":0D46
         MultiSelect     =   2  'Erweitert
         OLEDragMode     =   1  'Automatisch
         System          =   -1  'True
         TabIndex        =   11
         Top             =   300
         Width           =   2472
      End
      Begin VB.ComboBox cboPattern 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         ItemData        =   "Main.frx":0E98
         Left            =   0
         List            =   "Main.frx":0EAB
         TabIndex        =   10
         Text            =   "cboPattern"
         Top             =   0
         Width           =   1572
      End
      Begin VB.FileListBox filExplore 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3870
         Hidden          =   -1  'True
         Index           =   0
         Left            =   0
         MouseIcon       =   "Main.frx":0F14
         MultiSelect     =   2  'Erweitert
         OLEDragMode     =   1  'Automatisch
         System          =   -1  'True
         TabIndex        =   8
         Top             =   300
         Width           =   1572
      End
      Begin VB.CommandButton cmdOpen 
         Caption         =   "Open Window"
         DragIcon        =   "Main.frx":1066
         Height          =   288
         Left            =   0
         MouseIcon       =   "Main.frx":14A8
         TabIndex        =   7
         Top             =   4440
         Width           =   1572
      End
   End
   Begin VB.Frame fraMain 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   5472
      Index           =   1
      Left            =   60
      TabIndex        =   0
      Top             =   360
      Width           =   7872
      Begin VB.TextBox txtRLatent 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   3060
         MaxLength       =   5
         TabIndex        =   19
         Top             =   160
         Width           =   672
      End
      Begin VB.CommandButton cmdAbort 
         Caption         =   "&Abort"
         Height          =   372
         Left            =   60
         TabIndex        =   17
         Top             =   5100
         Width           =   1572
      End
      Begin VB.TextBox txtRLatent 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   2040
         MaxLength       =   5
         TabIndex        =   1
         Top             =   160
         Width           =   672
      End
      Begin VB.CheckBox chkROrder 
         Caption         =   "Send in random order"
         Height          =   192
         Left            =   120
         TabIndex        =   3
         Top             =   0
         Width           =   2592
      End
      Begin VB.CheckBox chkSend 
         Caption         =   "&Send"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   372
         Left            =   60
         Style           =   1  'Grafisch
         TabIndex        =   4
         Top             =   4620
         Width           =   1572
      End
      Begin VB.CheckBox chkRLatent 
         Caption         =   "Add random latency:"
         Height          =   252
         Left            =   120
         TabIndex        =   2
         Top             =   190
         Width           =   2232
      End
      Begin ComctlLib.ListView lstQ 
         Height          =   4092
         Left            =   0
         TabIndex        =   16
         Top             =   480
         Width           =   7872
         _ExtentX        =   13891
         _ExtentY        =   7223
         View            =   3
         Sorted          =   -1  'True
         MultiSelect     =   -1  'True
         LabelWrap       =   -1  'True
         HideSelection   =   0   'False
         _Version        =   327682
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   0
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Zentriert
         Caption         =   "to"
         Height          =   192
         Left            =   2700
         TabIndex        =   20
         Top             =   216
         Width           =   372
      End
   End
   Begin VB.PictureBox PictureError 
      BackColor       =   &H80000005&
      BorderStyle     =   0  'Kein
      Height          =   252
      Left            =   7380
      Picture         =   "Main.frx":18EA
      ScaleHeight     =   255
      ScaleWidth      =   255
      TabIndex        =   22
      Top             =   5520
      Visible         =   0   'False
      Width           =   252
   End
   Begin VB.Timer tmrOLE 
      Enabled         =   0   'False
      Interval        =   300
      Left            =   7740
      Top             =   -60
   End
   Begin VB.Timer tmrStart 
      Enabled         =   0   'False
      Interval        =   50
      Left            =   8040
      Top             =   1740
   End
   Begin VB.Timer tmrSession 
      Enabled         =   0   'False
      Interval        =   60000
      Left            =   7980
      Top             =   1140
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   6000
      Top             =   0
      _ExtentX        =   688
      _ExtentY        =   688
      _Version        =   393216
   End
   Begin ComctlLib.ProgressBar barProgress 
      DragIcon        =   "Main.frx":1A34
      Height          =   192
      Left            =   6456
      TabIndex        =   15
      Top             =   5880
      Visible         =   0   'False
      Width           =   1320
      _ExtentX        =   2328
      _ExtentY        =   344
      _Version        =   327682
      Appearance      =   1
      MouseIcon       =   "Main.frx":1E76
   End
   Begin ComctlLib.StatusBar barStat 
      Align           =   2  'Unten ausrichten
      DragIcon        =   "Main.frx":2190
      Height          =   240
      Left            =   0
      TabIndex        =   14
      Top             =   5892
      Width           =   8460
      _ExtentX        =   14923
      _ExtentY        =   423
      Style           =   1
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   1
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
         EndProperty
      EndProperty
      MouseIcon       =   "Main.frx":25D2
   End
   Begin VB.Timer tmrDOS 
      Enabled         =   0   'False
      Interval        =   400
      Left            =   5520
      Top             =   0
   End
   Begin VB.TextBox txtLog 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   672
      Left            =   60
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertikal
      TabIndex        =   18
      Top             =   5160
      Width           =   7872
   End
   Begin ComctlLib.TabStrip tabMain 
      Height          =   5892
      Left            =   0
      TabIndex        =   5
      Top             =   0
      Width           =   7992
      _ExtentX        =   14102
      _ExtentY        =   10398
      TabWidthStyle   =   2
      TabFixedWidth   =   2646
      TabFixedHeight  =   441
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   3
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "E&xplore"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Queue"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Log"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin NetCodeLib.NetCode NetCode1 
      Left            =   8160
      Top             =   3480
      _ExtentX        =   741
      _ExtentY        =   741
      IntelliCode     =   -1  'True
   End
   Begin ComctlLib.ImageList ImageList1 
      Left            =   8052
      Top             =   2832
      _ExtentX        =   794
      _ExtentY        =   794
      BackColor       =   -2147483643
      ImageWidth      =   20
      ImageHeight     =   20
      UseMaskColor    =   0   'False
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   14
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":28EC
            Key             =   "FoldClosed"
         EndProperty
         BeginProperty ListImage2 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":29FE
            Key             =   "FoldOpen"
         EndProperty
         BeginProperty ListImage3 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":2B10
            Key             =   "Drive"
         EndProperty
         BeginProperty ListImage4 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":2E2A
            Key             =   "FoldClosedFlag"
         EndProperty
         BeginProperty ListImage5 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":2F3C
            Key             =   "FoldOpenFlag"
         EndProperty
         BeginProperty ListImage6 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":304E
            Key             =   "MailWhite"
         EndProperty
         BeginProperty ListImage7 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":3160
            Key             =   "MailYellow"
         EndProperty
         BeginProperty ListImage8 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":36B2
            Key             =   "MailRed"
         EndProperty
         BeginProperty ListImage9 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":3C04
            Key             =   "MailBlue"
         EndProperty
         BeginProperty ListImage10 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":4156
            Key             =   "Leaf"
         EndProperty
         BeginProperty ListImage11 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":4250
            Key             =   "News"
         EndProperty
         BeginProperty ListImage12 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":456A
            Key             =   "NewsRed"
         EndProperty
         BeginProperty ListImage13 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":4884
            Key             =   "Lock"
         EndProperty
         BeginProperty ListImage14 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Main.frx":4996
            Key             =   "Key"
         EndProperty
      EndProperty
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuOpen 
         Caption         =   "&Open"
      End
      Begin VB.Menu mnuSelected 
         Caption         =   "&Selected Files"
         Begin VB.Menu mnuSelect 
            Caption         =   "&Move To..."
            Index           =   0
            Shortcut        =   ^M
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "Mo&ve Again"
            Index           =   1
            Shortcut        =   ^{F5}
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "&Copy To..."
            Index           =   2
            Shortcut        =   ^O
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "Copy A&gain"
            Index           =   3
            Shortcut        =   ^{F6}
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "&Rename"
            Index           =   4
            Shortcut        =   ^R
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "&Delete"
            Index           =   5
            Shortcut        =   {DEL}
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "Delete &Set  [Ctrl+Del]"
            Index           =   6
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "&Wipe"
            Index           =   7
            Shortcut        =   +{DEL}
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "Wipe Se&t  [Ctrl+Shift+Del]"
            Index           =   8
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "-"
            Index           =   9
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "Cop&y Files  [Ctrl+Shift+C]"
            Index           =   10
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "C&ut Files  [Ctrl+Shift+X]"
            Index           =   11
         End
         Begin VB.Menu mnuSelect 
            Caption         =   "&Paste Files  [Ctrl+Shift+V]"
            Index           =   12
         End
         Begin VB.Menu sepSel1 
            Caption         =   "-"
         End
         Begin VB.Menu mnuSelectSendTo 
            Caption         =   "&Send To"
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   0
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   1
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   2
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   3
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   4
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   5
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   6
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   7
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   8
               Visible         =   0   'False
            End
            Begin VB.Menu mnuSendTo 
               Caption         =   ""
               Index           =   9
               Visible         =   0   'False
            End
         End
      End
      Begin VB.Menu mnuSelFolders 
         Caption         =   "&Folders"
         Begin VB.Menu mnuFolder 
            Caption         =   "&New"
            Index           =   0
         End
         Begin VB.Menu mnuFolder 
            Caption         =   "&Remove"
            Index           =   1
         End
         Begin VB.Menu mnuFolder 
            Caption         =   "Re&name"
            Index           =   2
         End
         Begin VB.Menu mnuFolder 
            Caption         =   "E&xplorer"
            Index           =   3
         End
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuView 
      Caption         =   "&View"
      Begin VB.Menu mnuExSHow 
         Caption         =   "&Double List"
         Index           =   0
      End
      Begin VB.Menu mnuExSHow 
         Caption         =   "&Wide List"
         Index           =   1
      End
      Begin VB.Menu mnuExSHow 
         Caption         =   "Files on &Right"
         Index           =   2
      End
      Begin VB.Menu sepView1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuEditPatterns 
         Caption         =   "Edit Patterns..."
         Index           =   0
      End
      Begin VB.Menu mnuEditPatterns 
         Caption         =   "De&fault Patterns"
         Index           =   1
      End
      Begin VB.Menu sepView3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuClearLog 
         Caption         =   "&Clear Log"
         Shortcut        =   ^L
      End
   End
   Begin VB.Menu mnuQue 
      Caption         =   "Q&ueue"
      Begin VB.Menu mnuMultiQue 
         Caption         =   "Give &Priority"
         Index           =   0
      End
      Begin VB.Menu mnuMultiQue 
         Caption         =   "Delete"
         Index           =   1
      End
      Begin VB.Menu mnuChangeProfile 
         Caption         =   "Change Pro&file"
      End
      Begin VB.Menu mnuViewQue 
         Caption         =   "&View Message"
      End
      Begin VB.Menu sepQue1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuPrevDumm 
         Caption         =   "Previe&w Dummies"
      End
      Begin VB.Menu sepQue2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuRefreshQue 
         Caption         =   "Refresh"
         Index           =   0
      End
      Begin VB.Menu mnuRefreshQue 
         Caption         =   "&Clear Que"
         Index           =   1
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "&Tools"
      Begin VB.Menu mnuCheckMail 
         Caption         =   "&Check Email"
         Index           =   0
         Shortcut        =   ^E
      End
      Begin VB.Menu mnuCheckMail 
         Caption         =   "Get &News"
         Index           =   1
         Shortcut        =   ^N
      End
      Begin VB.Menu mnuCheckMail 
         Caption         =   "Check Email And Ne&ws"
         Index           =   2
         Shortcut        =   ^W
      End
      Begin VB.Menu mnuAbortConnection 
         Caption         =   "&Abort Connection"
         Shortcut        =   {F8}
      End
      Begin VB.Menu mnuSuspendAuto 
         Caption         =   "Disable A&uto Functions"
      End
      Begin VB.Menu sepTools0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuDial 
         Caption         =   "&Dial"
         Index           =   0
      End
      Begin VB.Menu mnuDial 
         Caption         =   "&Hang Up"
         Index           =   1
      End
      Begin VB.Menu sepTools1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuStats 
         Caption         =   "&Refresh Stats"
         Index           =   0
      End
      Begin VB.Menu mnuStats 
         Caption         =   "View &Stats"
         Index           =   1
      End
      Begin VB.Menu mnuStats 
         Caption         =   "Get CPunk &Keys"
         Index           =   2
      End
      Begin VB.Menu mnuStats 
         Caption         =   "Get &Mix Keys"
         Index           =   3
      End
      Begin VB.Menu mnuClipKey 
         Caption         =   "Add Key From Clip&board"
      End
      Begin VB.Menu sepTools2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "&View PGP Keying"
         Index           =   0
      End
      Begin VB.Menu mnuViewRing 
         Caption         =   "View Mi&x Keyring"
         Index           =   1
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuPopUpErrors 
         Caption         =   "Pop-Up &Messages"
         Begin VB.Menu mnuPopUp 
            Caption         =   "Queue"
            Index           =   0
         End
         Begin VB.Menu mnuPopUp 
            Caption         =   "Stats Refresh"
            Index           =   1
         End
         Begin VB.Menu mnuPopUp 
            Caption         =   "Retrieval"
            Index           =   2
         End
         Begin VB.Menu mnuPopUp 
            Caption         =   "News"
            Index           =   3
         End
         Begin VB.Menu mnuPopUp 
            Caption         =   "General"
            Index           =   4
         End
         Begin VB.Menu mnuPopUp 
            Caption         =   "Capability Update"
            Index           =   5
         End
      End
      Begin VB.Menu sepOpt2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuDialOpt 
         Caption         =   "&Verify Connection"
         Index           =   0
      End
      Begin VB.Menu mnuDialOpt 
         Caption         =   "Dial When &Needed"
         Index           =   1
      End
      Begin VB.Menu mnuDialOpt 
         Caption         =   "Hang &Up Automatically"
         Index           =   2
      End
   End
   Begin VB.Menu mnuWind 
      Caption         =   "&Window"
      Begin VB.Menu mnuWindow 
         Caption         =   "E&xplore"
         Index           =   0
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Queue"
         Index           =   1
         Shortcut        =   {F3}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Log"
         Index           =   2
         Shortcut        =   {F4}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&View Mail"
         Index           =   3
         Shortcut        =   {F5}
      End
      Begin VB.Menu mnuWindow 
         Caption         =   "&Stats Browser"
         Index           =   4
         Shortcut        =   {F6}
      End
      Begin VB.Menu sepWindow1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Global Config"
         Index           =   0
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "R&etrieval Config"
         Index           =   1
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Books Config"
         Index           =   2
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Remailers Config"
         Index           =   3
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "S&tats Config"
         Index           =   4
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   5
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Sen&d Profiles"
         Index           =   6
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Retrieval &Profiles"
         Index           =   7
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "Ne&ws Profiles"
         Index           =   8
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Nym Accounts Registry"
         Index           =   9
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Addresses"
         Index           =   10
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "-"
         Index           =   11
      End
      Begin VB.Menu mnuConfig 
         Caption         =   "&Check Configuration"
         Index           =   12
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&User's Manual              F1"
         Index           =   0
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Beginner's Guide"
         Index           =   1
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Troubleshooting Guide"
         Index           =   2
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "&Remailer Reference"
         Index           =   3
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "-"
         Index           =   7
      End
      Begin VB.Menu mnuHelpSub 
         Caption         =   "Open Default &Browser"
         Index           =   8
      End
      Begin VB.Menu sepHelp1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuAbout 
         Caption         =   "&About..."
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Private Type MailType
    Filename As String
    Status As String
    Created As Date
    Schedule As Date
    Origin As String
    Size As Long
    Profile As String
    Toh As String
End Type

Dim NoClick As Boolean
'Queue
Const MaxMail = 1500
Dim Mail(MaxMail) As MailType, SendErrorCode As Long, SendErrorString As String
Dim CurrentSendX As Integer, SendErrorTime(15) As Date
Dim QBusy As Boolean, SendingMail As Boolean
'POP
Dim CheckMailAll As Boolean
Dim POPErrorCode As Long, POPErrorString As String
Dim MailFileNum As Integer
Dim MailHead As String, MailText As String
Dim CancelRetrieve As Boolean
'Explore
Dim FileClip As String, FileClipMode As Byte
Dim DragShift As Integer, DragIndex As Byte

'' ## added
Private Sub filExplore_KeyPress(Index As Integer, KeyAscii As Integer)
    cboRecent_KeyPress KeyAscii
End Sub

Private Sub mnuClearLog_Click()
    txtLog.Text = ""
End Sub

Private Sub mnuClipKey_Click()
    ClipKey
End Sub

Private Sub mnuSuspendAuto_Click()
    mnuSuspendAuto.Checked = Not mnuSuspendAuto.Checked
    PData(170) = mnuSuspendAuto.Checked
    StartSession (-1)
    If mnuSuspendAuto.Checked Then a = LMsg(560) Else a = LMsg(561)
    MsgLog LMsg(559) + " " + a, 4
    
End Sub

Private Sub PictureError_Click()
    Dim h As Long, w As Long
    h = Val(PData(171))
    w = Val(PData(172))
    a = MultiBox(LMsg(538), LMsg(539), ErrorSummary, False, h, w)
    PData(171) = Str(h)
    PData(172) = Str(w)
    If a <> "" Then
        ErrorSummary = LMsg(539) + "   " + DateLine(1) + vbCrLf
        PictureError.Visible = False
        Stat StatMain, StatDec
    End If
End Sub

Private Sub PictureError_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then PictureError.Visible = False: ErrorSummary = "": Stat StatMain, StatDec
End Sub

Private Sub SmtpClient1_Progress(BytesCopied As Long, MessageSize As Long, Percent As Integer)
    DoEvents
End Sub

Private Sub tmrSession_Timer()
    Dim SomeBookBusy As Boolean
    tmrSession.Interval = 60000
Start:
    If AbortSession Then AbortSession = False: Exit Sub
    SomeBookBusy = False
    If Decrypting Or DummyBusy Then
        SomeBookBusy = True
    Else
        For i = 0 To 9
            If BookBusy(0, i) Or BookBusy(1, i) Then SomeBookBusy = True: Exit For
        Next i
    End If
    If SessionStart <> -1 Then x = SessionStart Else x = 0
    xstart = x
    Do
        If CheckingConfig Or PendingConfig Then Exit Sub
        Select Case x
        Case 0 'Read Queue
            If Session(0) = 1 Then
                ReadQue
                If (RASConnected Or PData(54) = True2) And Not SomeBookBusy And Not mnuSuspendAuto.Checked Then SessionStart = 1 Else SessionStart = -1
                Session(x) = 0
                KeepDate(x) = SafeTime
                GoTo Start
            End If
        Case 1 'Send Queue
            If chkSend.Value = 1 And Not SendingMail And _
              (SessionStart = x Or (Not SomeBookBusy And Not mnuSuspendAuto.Checked And SafeTime - KeepDate(x) > 5 / 24 / 60)) _
              And Not NetBusy And (RASConnected Or PData(54) = True2) Then
                If SDir(Cnf(0, 1) + "\*.Q0") <> "" Then
                    NetBusy = True
                    SendingMail = True
                    tmrStart.Tag = "SendQue": tmrStart.Enabled = True
                    KeepDate(x) = SafeTime
                End If
            End If
        Case 2 'Make Dummies
            If SafeTime - KeepDate(x) > 1 / 24 And Not NetBusy And Not mnuSuspendAuto.Checked And Not SomeBookBusy Then
                DummyBusy = True
                MakeDummies (2)
                SessionStart = 0
                Session(0) = 1
                Session(x) = 0
                DummyBusy = False
                GoTo Start
            End If
        Case 3 'Refresh Stats
            If Val(Cnf(3, 0)) = 1 And Not mnuSuspendAuto.Checked And SafeTime - KeepDate(x) > SVal(Cnf(3, 18)) / 24 And Not BrowserLoaded And Not SomeBookBusy And Not NetBusy Then
                If RASConnected Then
                    NetBusy = True
                    tmrStart.Tag = "RefreshStats": tmrStart.Enabled = True
                End If
            End If
        Case 4 'Check Mail
            If SessionStart = x Then
                If Not (RASConnected Or (PData(54) = True2)) Then
                    SessionStart = -1
                    Stat LMsg(294), StatDec
                Else
                    CheckMailAll = True
                End If
            End If
            If Not NetBusy And (((RASConnected Or PData(54) = True2) And Not mnuSuspendAuto.Checked And Not SomeBookBusy And SafeTime - KeepDate(16) > SVal(Cnf(0, 12)) / 24 / 60) Or CheckMailAll) Then
                For i = 0 To 14
                    If Val(UserProf(i, 0)) = 1 And ((Val(UserProf(i, 1)) = 1 And SafeTime - KeepDate(20 + i) > SVal(UserProf(i, 9)) / 24 / 60) Or CheckMailAll) Then
                        NetBusy = True
                        tmrStart.Tag = "GetMail": tmrStart.Enabled = True
                        KeepDate(x) = SafeTime
                        Exit For
                    End If
                Next i
            End If
        Case 5 'Get News
            If SessionStart = x Then
                If Not (RASConnected Or (PData(54) = True2)) Then
                    SessionStart = -1
                    Stat LMsg(294), StatDec
                Else
                    CheckNewsAll = True
                End If
            End If
            If Not NetBusy And (((RASConnected Or PData(54) = True2) And Not mnuSuspendAuto.Checked And Not SomeBookBusy And SafeTime - KeepDate(16) > SVal(Cnf(0, 12)) / 24 / 60) Or CheckNewsAll) Then
                For i = 31 To 45
                    If Val(UserProf(i, 0)) = 1 And ((Val(UserProf(i, 1)) = 1 And SafeTime - KeepDate(i + 4) > SVal(UserProf(i, 9)) / 24 / 60) Or CheckNewsAll) Then
                        NetBusy = True
                        tmrStart.Tag = "GetNews": tmrStart.Enabled = True
                        KeepDate(x) = SafeTime
                        Exit For
                    End If
                Next i
            End If
        Case 6 'Decrypt Messages
            If Not Decrypting And (SessionStart = x Or (Not mnuSuspendAuto.Checked And DecQCount <> 0 And Not NetBusy And Not SomeBookBusy)) Then Decrypting = True: Load frmDecrypt
        End Select
        Session(x) = 0
        x = x + 1
        If x > SessionTop Then x = 0
    Loop Until x = xstart Or AbortSession
    SessionStart = -1
    For i = 0 To SessionTop
        If Session(i) <> 0 Then GoTo Start
    Next i
    If PData(55) = True2 And IEstablished And Not AbortSession Then If RASConnected Then DialRAS (False)
End Sub

Private Sub tmrStart_Timer()
    tmrStart.Enabled = False
    Select Case tmrStart.Tag
    Case "SendQue"
        SendQue
        SendingMail = False
        KeepDate(1) = SafeTime
        NetBusy = False
    Case "RefreshStats"
        CallBrowser 1, ""
        KeepDate(3) = SafeTime
        NetBusy = False
    Case "GetMail"
        CheckingMail = True
        GetMail
        CheckingMail = False
        NetBusy = False
    Case "GetNews"
        Load frmGetNews
        Unload frmGetNews
        NetBusy = False
    End Select
    Stat StatMain, StatDec
    tmrSession.Enabled = False
    tmrSession.Interval = 300
    tmrSession.Enabled = True
End Sub

Private Sub GetMail()
    Dim a As String
    On Error GoTo GetMailError
    For Prof = 0 To 14
        AbortRetrieve = False: CancelRetrieve = False
        If Val(UserProf(Prof, 0)) = 1 And ((Val(UserProf(Prof, 1)) = 1 And SafeTime - KeepDate(20 + Prof) > SVal(UserProf(Prof, 9)) / 24 / 60) Or CheckMailAll) Then
            igcount = 0: svcount = 0: dlcount = 0
            'Check for valid folder, etc
            If UserProf(Prof, 3) <> False2 Then
                'Folder
                MailFolder = UserProf(Prof, 10)
            Else
                'File
                MailFolder = PlainName(UserProf(Prof, 10), 0)
            End If
            If MailFolder = "" Then MailFolder = Cnf(4, 0) + "\Inbox"
            If Not CreateDir(MailFolder) Then
                MsgLog LMsg(56) + " " + LMsg(306) + " " + UserProf(Prof, 5) + ": " + LMsg(450) + " " + MailFolder, 2, True, True
                KeepDate(20 + Prof) = SafeTime
                GoTo NextProf
            End If
            
            'Dial
            If Not RASConnected And PData(54) = True2 Then DialRAS (True)
            If Not RASConnected Then Exit For
            'Connect to POP Server
            Me.MousePointer = 13
            On Error Resume Next
            POPErrorCode = 0
            Stat LMsg(287) + " " + UserProf(Prof, 5) + " [" + UserProf(Prof, 6) + "]...", StatDec
            PopClient1.TimeOut = 60  'seconds
            PopClient1.HostName = Extract(UserProf(Prof, 6), ":")
            'Port
            If InStr(UserProf(Prof, 6), ":") <> 0 Then
                rport = SVal(Mid(UserProf(Prof, 6), InStr(UserProf(Prof, 6), ":") + 1))
            Else
                rport = 0
            End If
            PopClient1.RemotePort = rport
            PopClient1.UserName = UserProf(Prof, 7)
            PopClient1.Password = UserProf(Prof, 8)
            POPErrorString = ""
            POPErrorCode = 0
            ErrCode = PopClient1.Connect
            If POPErrorCode <> 0 Or ErrCode <> 0 Then
                'Connection failed
                Msg = LMsg(290) + " " + UserProf(Prof, 5) + " [" + UserProf(Prof, 6) + "]"
                If POPErrorString <> "" Then Msg = Msg + vbCrLf + "      " + POPErrorString
                MsgLog Msg, 2, True, True
            Else
                'Connected
                On Error GoTo POPError
                PopClient1.Blocking = True
                PopClient1.LineBreak = False
                
                DoEvents
                mcount = PopClient1.MessageCount
                For POPMsg = 1 To mcount
                    Fail = False
                    'Get Size
                    MsgSize = GetPOPSize(POPMsg)
                    'Oversize?
                    If Val(UserProf(Prof, 15)) = 1 And MsgSize > SVal(UserProf(Prof, 16)) * 1024 Then
                        Fail = True
                        'X  Msg = LMsg(447) + " (" + Trim(Str(Int(MsgSize / 1024 + 0.99999))) + "k)"
                    End If
                    'Need Scan?
                    If Not Fail And (UserProf(Prof, 13) <> 0 Or UserProf(Prof, 14) <> 0) Then
                        'Scan
                        AbortRetrieve = False: CancelRetrieve = False
                        MailHead = "": MailText = "": MailFileNum = 0
                        Stat UserProf(Prof, 5) + ": " + LMsg(455) + Str(POPMsg) + " " + LMsg(297) + Str(mcount) + "  (" + Trim(Str(Int(MsgSize / 1024 + 0.99999))) + "k)", StatDec
                        ReadPOPMessage POPMsg, 15
                        If Not CancelRetrieve And Not AbortRetrieve Then
                            'Test Message
                            i = TestMessage(Prof, a)
                            If i <> 0 Then
                                Fail = True
                                If i = 1 Then
                                    igcount = igcount + 1
                                ElseIf i = 2 Then
                                    PopClient1.DeleteMessage POPMsg
                                    dlcount = dlcount + 1
                                    Msg = LMsg(448) + " (" + a + ")"
                                End If
                            End If
                        Else
                            Fail = True
                        End If
                    End If
                    If Not Fail Then
                        'Retrieve
                        'Open mail file
                        If UserProf(Prof, 3) <> False2 Then
                            'Folder
                            Do
                                mailfile = NoSlash(MailFolder) + "\" + MakeTag(8)
                            Loop Until SDir(mailfile + ".*") = ""
                            mailfile = mailfile + ".ML0"
                            NeedLF = False
                        Else
                            'File
                            mailfile = UserProf(Prof, 10)
                            NeedLF = SDir(mailfile) <> ""
                        End If
                        ReserveMailFile = mailfile
                        MailFileNum = FreeFile
                        Open mailfile For Append As MailFileNum
                        If NeedLF Then Print #MailFileNum, vbCrLf
                        Print #MailFileNum, "From POP3-Server@" + UserProf(Prof, 6) + " " + DateLine(1)
                        
                        'Retrieve Message
                        CancelRetrieve = False: AbortRetrieve = False
                        Stat UserProf(Prof, 5) + ": " + LMsg(295) + Str(POPMsg) + " " + LMsg(297) + Str(mcount) + "  (" + Trim(Str(Int(MsgSize / 1024 + 0.99999))) + "k)", StatDec
                        ReadPOPMessage POPMsg, 0
                        If MailFileNum <> 0 Then Close MailFileNum: MailFileNum = 0
                        DoEvents
RetrieveOver:           On Error GoTo GetMailError
                        If Not CancelRetrieve And Not AbortRetrieve Then
                            mailfile2 = mailfile
                            mailfile = ""
                            svcount = svcount + 1
                            If Val(UserProf(Prof, 2)) = 1 Then
                                'Deleted Saved Message
                                PopClient1.DeleteMessage POPMsg
                                dlcount = dlcount + 1
                            End If
                            'SPAM and PGP
                            TestMail mailfile2, PGPFlag, SPAMFlag, MultiFlag
                            If SPAMFlag Then
                                'Move to Trash\Spam
                                xmailfile = Cnf(4, 0) + "\Trash\Spam\" + PlainName(mailfile2, 2)
                                While SDir(xmailfile + ".*") <> ""
                                    xmailfile = Cnf(4, 0) + "\Trash\Spam\" + MakeTag(8)
                                Wend
                                FileCopy mailfile2, xmailfile + ".ML0"
                                DelFile mailfile2
                                mailfile2 = xmailfile + ".ML0"
                                ReserveMailFile = mailfile2
                            ElseIf MultiFlag Then
                                'Move to Multi
                                xmailfile = Cnf(4, 0) + "\Multi\" + PlainName(mailfile2, 2)
                                While SDir(xmailfile + ".*") <> ""
                                    xmailfile = Cnf(4, 0) + "\Multi\" + MakeTag(8)
                                Wend
                                FileCopy mailfile2, xmailfile + ".ML0"
                                DelFile mailfile2
                                mailfile2 = xmailfile + ".ML0"
                                ReserveMailFile = mailfile2
                                MultParts = True
                            Else
                                'Queue Saved Message for Decryption
                                If Val(Cnf(4, 12)) = 1 And (PGPFlag Or Val(Cnf(4, 13)) = 0) Then QueueDec mailfile2
                            End If
                            'Update New IDX if saved to folder
                            If UserProf(Prof, 3) <> False2 Then
                                On Error Resume Next
                                n = FreeFile
                                Open PlainName(mailfile2, 0) + "JBN2NEW.IDX" For Append As n
                                Print #n, mailfile2
                                Close n: n = 0
                                On Error GoTo GetMailError
                            End If
                            'Alert View Mail Window
                            'Disabled due to focus change bug
                            'If LCase(NoSlash(PlainName(mailfile2, 0))) = LCase(ViewerCurBox) And ViewerLoaded Then
                            '    frmViewer!tmrUpdate.Tag = frmViewer!tmrUpdate.Tag + "F"
                            '    frmViewer!tmrUpdate.Enabled = True
                            'End If
                        Else
                            'Retrieval Aborted or Canceled
                            DelFile (mailfile)
                        End If
                    Else
                        'No Retrieve
                        If Msg <> "" Then MsgLog UserProf(Prof, 5) + ": " + Msg, 2, False
                    End If
                    If AbortRetrieve Or CancelRetrieve Then Exit For
                    DoEvents
                    ReserveMailFile = ""
                Next POPMsg
                'Disconnect
DisconnectPOP:
                On Error Resume Next
                barProgress.Visible = False
                Stat LMsg(289) + " " + UserProf(Prof, 5) + "...", StatDec
                PopClient1.Disconnect
                'Summary
                MsgLog UserProf(Prof, 5) + ":" + Str(svcount) + " " + LMsg(452) + " " + Str(dlcount) + " " + LMsg(453) + " " + Str(mcount - dlcount) + " " + LMsg(454), 2, False
                
            End If
            KeepDate(20 + Prof) = SafeTime
            NewMessages = NewMessages + svcount
            If AbortRetrieve Then Exit For
        End If
NextProf:
        DoEvents
    Next Prof
Done:
    On Error Resume Next
    PopClient1.Disconnect
    CheckMailAll = False
    If NewMessages <> 0 Then
        a = Str(NewMessages) + " " + LMsg(456) + "."
        If ViewerLoaded Then
            frmViewer!tmrUpdate.Tag = frmViewer!tmrUpdate.Tag + "D"
            frmViewer!tmrUpdate.Enabled = True
        End If
    Else: a = ""
    End If
    If AbortRetrieve Then a = LMsg(300) + "  " + a
    Stat a, StatDec
    barProgress.Visible = False
    WriteData
    If Not Decrypting And (DecQCount <> 0 Or MultParts) Then StartSession 6
    Me.MousePointer = 0
Exit Sub
POPError:
    ErrDesc = Err.Description
    Resume POPError2
POPError2:
    CloseFile MailFileNum
    MailFileNum = 0
    CancelRetrieve = True
    ReserveMailFile = ""
    MsgLog LMsg(451) + " " + UserProf(Prof, 5) + vbCrLf + "      " + ErrDesc, 2, True, True
    GoTo RetrieveOver
GetMailError:
    ErrDesc = Error
    Resume GetMailError2
GetMailError2:
    If Not AbortRetrieve Then
        MsgLog LMsg(451) + " " + UserProf(Prof, 5) + vbCrLf + "      " + ErrDesc, 2, True, True
        KeepDate(20 + Prof) = SafeTime
    End If
    DelFile (mailfile)
    CloseFile n
    ReserveMailFile = ""
    GoTo DisconnectPOP
End Sub

Private Function TestMessage(Prof, f) As Integer
    'Test Mail Message with filters
    '0 Retrieve
    '1 Ignore
    '2 Delete
    Dim Fltr(200) As String
    m = LCase(MailHead + vbCrLf + MailText)
    For i = 1 To 0 Step -1
        If Val(UserProf(Prof, 13 + i)) <> 0 Then
            If i = 0 And Val(UserProf(Prof, 13 + i)) = 1 Then
                Fltr(0) = "-----BEGIN PGP MESSAGE"
                x = 0
            Else
                x = ParseString(UserProf(Prof, 11 + i), Fltr(), 200, False)
            End If
            For j = 0 To x
                fs = LCase(Fltr(j))
                If InStr(fs, "[") <> 0 Then Replace fs, "[", "[[]"
                If InStr(fs, "^") <> 0 Then Replace fs, "^", vbCrLf
                If m Like "*" + fs + "*" Then
                    f = Fltr(j)
                    TestMessage = Val(UserProf(Prof, 14)) * i
                    Exit Function
                End If
            Next j
        End If
    Next i
    f = ""
    If Val(UserProf(Prof, 13)) = 0 Then TestMessage = 0 Else TestMessage = 1
End Function

Private Sub ReadPOPMessage(POPMsg, MaxLines As Integer)
    Dim Buffer As String, nb As Long, a As String
    Dim ErrCount As Byte
    
    MailHead = "": MailText = ""
    If MaxLines <> 0 Then
        'Scan
        PopClient1.Command = "TOP" + Str(POPMsg) + Str(MaxLines)
        PopClient1.MultiLine = True
    Else
        'Retrieve
        PopClient1.MultiLine = False
        PopClient1.GetMessage POPMsg
        MsgSize = PopClient1.MessageSize
        barProgress.Value = 0
        barProgress.Visible = True
        If MsgSize > 0 Then barProgress.Max = MsgSize
    End If
    POPErrorString = ""
    On Error GoTo BugFix
    If MaxLines <> 0 Then
        'Scan
        Do
            PopClient1.Read Buffer, 1024
            a = a + Buffer
            DoEvents
        Loop Until PopClient1.RecvNext = 0 Or Not PopClient1.Connected
        PopClient1.MultiLine = False
    Else
        'Retrieve
        Do
            PopClient1.RecvLen = 1024
            Buffer = PopClient1.RecvData
            If InStr(Buffer, Chr(0)) <> 0 Then Buffer = Replace(Buffer, Chr(0), " ")
            If InStr(Buffer, Chr(26)) <> 0 Then Buffer = Replace(Buffer, Chr(26), " ")
            If Len(Buffer) > 0 Then Print #MailFileNum, Buffer;
            nb = nb + PopClient1.RecvLen 'Actual bytes received
            If nb < 5000 Then a = a + Buffer
            If nb <= barProgress.Max Then barProgress.Value = nb
            DoEvents
        Loop Until Len(Buffer) < 1024 Or Not PopClient1.Connected
        If Not PopClient1.Connected Then CancelRetrieve = True
        Close MailFileNum: MailFileNum = 0
    End If
    x = InStr(a, vbCrLf + vbCrLf)
    If x = 0 Then
        MailHead = a
    Else
        MailHead = Left(a, x + 1)
        MailText = Mid(a, x + 4)
    End If
Exit Sub
BugFix:
    'This attempts to correct a bug where retrieval is halted
    'by a "runtime error 0"
    If Error = "" And POPErrorString = "" And ErrCount < 2 Then
        ErrCount = ErrCount + 1
        DoEvents
        Resume
    End If
    Err.Raise Err.Number, Err.Description
End Sub

Private Sub PopClient1_LastError(ErrorCode As Integer, ErrorString As String, Response As Integer)
    POPErrorCode = ErrorCode
    POPErrorString = ErrorString
End Sub

Private Function GetPOPSize(MsgNum) As Long
    PopClient1.Command = "LIST" + Str(MsgNum)
    PopClient1.MultiLine = True
    a = Trim(PopClient1.ResultString)
    x = InStr(a, " ")
    If Val(Extract(a, " ")) <> MsgNum Or x = 0 Then
        GetPOPSize = 0
    Else
        GetPOPSize = SVal(Mid(a, x + 1))
    End If
    PopClient1.MultiLine = False
End Function


Private Sub mnuHelpSub_Click(Index As Integer)
    Dim Topic As String, HelpPart As String
    
    If Index = 0 Then
        Select Case tabMain.SelectedItem.Index
        Case 1: Topic = ""
        Case 2: Topic = "#Queue"
        Case 3: Topic = "#Log"
        End Select
        HelpPart = "2"
    End If
    ShowHelp Index, Topic, HelpPart
End Sub

Private Sub mnuExit_Click()
    Unload Me
End Sub

Private Sub mnuCheckMail_Click(Index As Integer)
    If Index < 2 Then
        StartSession (4 + Index)
    Else
        CheckMailAll = True
        CheckNewsAll = True
        StartSession (4)
    End If
End Sub

Private Sub mnuAbortConnection_Click()
    AbortConnection
End Sub

Private Sub barStat_Click()
    StartSession (4)
End Sub

Private Sub mnuRefreshStats_Click()
    CallBrowser 1, ""
End Sub

Private Sub chkSend_Click()
    If txtLog.Visible Then txtLog.SetFocus
    If chkSend.Value = 1 Then
        If Not RASConnected Then Stat LMsg(294), StatDec
        Erase SendErrorTime
        KeepDate(16) = 0
        StartSession (1)
    End If
    If chkSend.Value = 1 Then tabMain.Tabs(2).Tag = LMsg(310) + "*" Else tabMain.Tabs(2).Tag = LMsg(310)
    If lstQ.ListItems.Count = 0 Then a = "" Else a = " [" + Trim(Str(lstQ.ListItems.Count)) + "]"
    tabMain.Tabs(2).Caption = tabMain.Tabs(2).Tag + a
End Sub

Private Sub cmdAbort_Click()
    txtLog.SetFocus
    chkSend.Value = 0
    On Error Resume Next
    SmtpClient1.Cancel
    SmtpClient1.Disconnect
    SmtpClient1.Reset
    Stat LMsg(301), StatDec
    cmdAbort.Tag = True2
End Sub

Private Sub SendQue()
    Dim Q0 As String, Q1 As String, Pri As String
    Dim Connected As Boolean, pcount As Integer, scount As Integer
    Dim MyQBusy As Boolean
    
    If chkSend.Value = 0 Then Exit Sub
    On Error GoTo SendError
    cmdAbort.Tag = ""
    'Check for Priority Messages
    For i = 0 To MaxMail
        If Mail(i).Filename <> "" Then _
         If Mail(i).Status = LMsg(302) Then _
          If InStr(1, Pri, Mail(i).Profile + vbCr, vbTextCompare) = 0 Then _
           Pri = Pri + Mail(i).Profile + vbCr
    Next i
Start:
    For Prof = 15 To 30
        If Prof = 30 Then ProfName = "UNIX" Else ProfName = UserProf(Prof, 1)
        If Trim(ProfName) = "" Then ProfName = Trim(Str(Prof - 15))
        If Val(UserProf(Prof, 0)) = 1 And _
           SafeTime - SendErrorTime(Prof - 15) > 10 / 24 / 60 And _
           (Pri = "" Or InStr(1, Pri, ProfName + vbCr, vbTextCompare) <> 0 Or Prof = 30) Then
            pcount = 0
            mx = GetQue(Prof)
            Connected = False: Msg = ""
            While mx <> -1
                CurrentSendX = mx
                Q0 = Mail(mx).Filename + ".Q0"
                Q1 = Mail(mx).Filename + ".Q1"
                If Dir(Q0) <> "" And Dir(Q1) <> "" Then
                    If Prof <> 30 And Not Connected Then
                        'Dial
                        If Not RASConnected And PData(54) = True2 Then DialRAS (True)
                        If RASConnected Then
                            'Connect to SMTP server
                            chkSend.ForeColor = &HFF&
                            Me.MousePointer = 13
                            On Error GoTo SendError
                            SendErrorCode = 0
                            Stat LMsg(287) + " " + ProfName + " [" + UserProf(Prof, 2) + "]...", StatDec
                            SmtpClient1.Blocking = True
                            SmtpClient1.HostName = Extract(UserProf(Prof, 2), ":")
                            'Port
                            If InStr(UserProf(Prof, 2), ":") <> 0 Then
                                rport = SVal(Mid(UserProf(Prof, 2), InStr(UserProf(Prof, 2), ":") + 1))
                                If rport = 0 Then rport = 25
                            Else
                                rport = 25
                            End If
                            SmtpClient1.RemotePort = rport  'RemoteService = "smtp"
                            SendErrorString = ""
                            On Error Resume Next
                            ErrCode = SmtpClient1.Connect
                            On Error GoTo SendError
                            If SendErrorCode <> 0 Or ErrCode <> 0 Then
                                'Connection failed
                                Msg = LMsg(290) + " " + ProfName + " [" + UserProf(Prof, 2) + "]"
                                If SendErrorString <> "" Then Msg = Msg + vbCrLf + "      " + SendErrorString
                            Else
                                Connected = True
                            End If
                        End If
                    End If
                    If Connected Or Prof = 30 Then
                        'Busy status
                        While QBusy
                            DoEvents
                        Wend
                        QBusy = True: MyQBusy = True
                        OldStatus = Mail(mx).Status
                        If OldStatus <> LMsg(286) And OldStatus <> LMsg(302) Then OldStatus = LMsg(286)
                        Mail(mx).Status = LMsg(288) + "..."
                        UpdateStatus (mx)
                        QBusy = False: MyQBusy = False
                        'Send
                        Stat ProfName + ":" + LMsg(288) + Str(pcount + 1) + " [" + Trim(Str(scount + 1)) + "]  (" + Trim(Str(Int(Mail(mx).Size / 1024 + 0.999))) + "k)", StatDec
                        lstQ.Refresh
                        Msg = SendMsg(mx, Prof)
                        While QBusy
                            DoEvents
                        Wend
                        QBusy = True: MyQBusy = True
                            If Msg = "" Then
                                'Success
                                DelFile Q0
                                DelFile Q1
                                Mail(mx).Filename = ""
                                Mail(mx).Status = "Sent"
                                pcount = pcount + 1
                                scount = scount + 1
                            Else
                                'Failure
                                If cmdAbort.Tag = "" Then Mail(mx).Status = LMsg(4) Else Mail(mx).Status = OldStatus
                            End If
                            CurrentSendX = -1
                            UpdateStatus (mx)
                        QBusy = False: MyQBusy = False
                    End If
                Else
                    DelFile Q0
                    DelFile Q1
                End If
CloseProf:      If Msg <> "" And cmdAbort.Tag = "" Then
                    'Display Error
                    MsgLog ProfName + ": " + Msg, 0, True, True
                    SendErrorTime(Prof - 15) = SafeTime
                End If
                If ((Connected And RASConnected) Or Prof = 30) And Msg = "" And chkSend.Value = 1 Then mx = GetQue(Prof) Else mx = -1
            Wend
            CurrentSendX = -1
            If Connected Then
                'Disconnect
                Connected = False
                Stat LMsg(289) + " " + UserProf(Prof, 2) + "...", StatDec
                If SmtpClient1.Disconnect <> 0 Then SmtpClient1.Reset
            End If
            If pcount > 0 Then MsgLog ProfName + ":" + Str(pcount) + " " + LCase(LMsg(296)), 0, False

        End If
    Next Prof
    If Pri <> "" And chkSend.Value = 1 And RASConnected Then Pri = "": GoTo Start
Leave:
    barProgress.Visible = False
    chkSend.ForeColor = &H80000012
    Me.MousePointer = 0
    If scount <> 0 Then
        Stat CStr(scount) + " " + LCase(LMsg(296)), StatDec
    Else
        Stat "", StatDec
    End If
    If cmdAbort.Tag <> "" Then Stat barStat.SimpleText + "   " + LMsg(300), StatDec
    filExplore(0).Refresh
    If filExplore(1).Visible Then filExplore(1).Refresh
Exit Sub
SendError:
    If MyQBusy Then QBusy = False: MyQBusy = False
    Resume CloseProf
End Sub

Private Function SendMsg(mx, Prof) As String
    Dim Q0 As String, Q1 As String, Tmp(100) As String
    Dim Hdrs As String
    
    Q0 = Mail(mx).Filename + ".Q0"
    Q1 = Mail(mx).Filename + ".Q1"
            
    Err.Clear
    SendErrorString = ""
    barProgress.Value = 0
    barProgress.Visible = True
    On Error GoTo SendError
    
    'Get Recipients
    n = FreeFile
    Open Q0 For Input As n
    While Not EOF(n) And Left(a, 4) <> "To: "
        Line Input #n, a
    Wend
    Do
        x = InStr(a, ":")
        If x <> 0 Then
            b = LCase(Left(a, x - 1))
            c = LTrim(Mid(a, x + 1))
            If b = "to" Or b = "cc" Or b = "bcc" Then Rcpt = Rcpt + "," + c
        End If
        If Not EOF(n) Then Line Input #n, a
    Loop Until EOF(n)
    Close n: n = 0
    If Replace(Rcpt, ",", "") = "" Then SendMsg = "": GoTo Leave
    
    'Address Message
    If Prof <> 30 Then
        'SMTP From Address
        a = CleanAddress(UserProf(Prof, 5))
        If CleanAddress(a) = "" Then
            'Reply-To Header
            a = CleanAddress(UserProf(Prof, 4))
            If a = "" Then a = CleanAddress(UserProf(Prof, 3)) 'From Header
        End If
        Msg = AddressSMTP(Rcpt, a)
        If Msg <> "" Then SendMsg = Msg: GoTo Leave
    End If
    
    'Send Extra Headers
    d = "From: " + UserProf(Prof, 3) + vbCrLf
    d = d + "Date: " + DateLine(0) + vbCrLf
    ReplyTo = EndPart
    If Prof <> 30 And UserProf(Prof, 4) <> "" Then d = d + "Reply-To: " + UserProf(Prof, 4) + vbCrLf: ReplyTo = "replyto"
    d = d + UserProf(Prof, 6)
    x = ParseString(d, Tmp(), 100, False)
    For i = 0 To x
        y = InStr(Tmp(i), ":")
        If y = 0 Then
            If Left(Tmp(i), 1) = " " Then Tmp(i) = "     " + LTrim(Tmp(i)) Else Tmp(i) = ""
        Else
            Tmp(i) = Trim(Left(Tmp(i), y - 1)) + ": " + LTrim(Mid(Tmp(i), y + 1))
        End If
        If Tmp(i) <> "" Then
            If Prof <> 30 Then
                frmMain!SmtpClient1.SendLen = Len(Tmp(i)) + 2
                frmMain!SmtpClient1.SendData = Tmp(i) + vbCrLf
            Else
                Hdrs = Hdrs + Tmp(i) + vbCrLf
            End If
        End If
    Next i
    
    'Send Included Headers
    n = FreeFile
    Open Q0 For Input As n
    a = ""
    While Not EOF(n) And Left(a, 4) <> "To: "
        Line Input #n, a
    Wend
    Do
        If a <> "" Then
            b = LCase(Extract(a, ":"))
            If b <> "bcc" And b <> "date" And b <> "from" And b <> ReplyTo Then
                If Prof <> 30 Then
                    frmMain!SmtpClient1.SendLen = Len(a) + 2
                    frmMain!SmtpClient1.SendData = a + vbCrLf
                Else
                    Hdrs = Hdrs + a + vbCrLf
                End If
            End If
        End If
        If Not EOF(n) Then Line Input #n, a
    Loop Until EOF(n)
    Close n: n = 0
    If Prof <> 30 Then
        frmMain!SmtpClient1.SendLen = 2
        frmMain!SmtpClient1.SendData = vbCrLf
    End If
    'Send Body
    If Prof = 30 Then
        'UNIX
        If UserProf(30, 1) = True2 Then fn = GetWork Else fn = UserProf(30, 4)
        p = FreeFile
        Open fn For Append As p
        Print #p, "From user@JBN2.Queue "; DateLine(1)
        Print #p, Hdrs
    End If
    n = FreeFile
    Open Q1 For Input As n
    flen = LOF(n)
    If flen > 0 Then barProgress.Max = flen
    slen = flen - Seek(n) + 1
    While slen > 0
        If slen > 1024 Then slen = 1024
        a = Input(slen, n)
        If Prof <> 30 Then
            frmMain!SmtpClient1.SendLen = Len(a)
            frmMain!SmtpClient1.SendData = a
        Else
            Print #p, a;
        End If
        slen = flen - Seek(n) + 1
        If Seek(n) + 1 <= flen Then barProgress.Value = Seek(n) + 1
        DoEvents  'Experimental''''
    Wend
    Close n: n = 0
    If Prof = 30 Then
        If UserProf(30, 1) <> True2 Then Print #p, vbCrLf; vbCrLf
        Close p: p = 0
        If UserProf(30, 1) = True2 Then
            'UNIX Folder
            Do
                fn2 = NoSlash(UserProf(30, 4)) + "\JBN" + MakeTag(4)
            Loop Until SDir(fn2 + ".*") = ""
            mailfile = mailfile + ".ML0"
            FileCopy fn, fn2
            DelFile fn
        End If
    End If
             
    barProgress.Value = 0
    SendErrorCode = 0: SendErrorString = ""
    Stat barStat.SimpleText + "  (" + LMsg(296) + ")", StatDec
    If Prof <> 30 And cmdAbort.Tag = "" Then If frmMain!SmtpClient1.SendMail <> 0 Or SendErrorString <> "" Then GoTo SendError
    SendMsg = cmdAbort.Tag
Leave:
Exit Function
SendError:
    If SendErrorString <> "" Then a = SendErrorString Else a = Error
    If a = "" Then a = LMsg(291)
    CloseFile n
    CloseFile p
    DelFile fn
    SendMsg = a
    GoTo Leave
End Function

Public Function AddressSMTP(Rcpt, FromH) As String
    Dim a As String, Aerr As Long
    SendErrorCode = 0: Aerr = 0: SendErrorString = ""
    SmtpClient1.Address = FromH
    Aerr = frmMain!SmtpClient1.AddressMail
    If SendErrorCode <> 0 Then Aerr = SendErrorCode
    If Aerr <> 0 Then
        a = SendErrorString
        If a = "" Then a = LMsg(291)
        AddressSMTP = a
        Exit Function
    End If
    Rcpt = Trim(Rcpt) + ","
    x = InStr(Rcpt, ",")
    y = 1
    While x <> 0
        a = Trim(Mid(Rcpt, y, x - y))
        If a <> "" Then
            SendErrorCode = 0
            SmtpClient1.Recipient = CleanAddress(a)
            If SendErrorCode <> 0 Then
                a = SendErrorString
                If a = "" Then a = LMsg(291)
                AddressSMTP = a
                Exit Function
            End If
        End If
        y = x + 1
        x = InStr(y, Rcpt, ",")
    Wend
    AddressSMTP = ""
End Function

Private Sub SMTPClient1_LastError(ErrorCode As Integer, ErrorString As String, Response As Integer)
    SendErrorCode = ErrorCode
    SendErrorString = ErrorString
End Sub

Private Sub UpdateStatus(mx)
    For i = 1 To lstQ.ListItems.Count
        If lstQ.ListItems.Item(i).Key = "K" + Trim(Str(mx)) Then Exit For
    Next i
    If i <= lstQ.ListItems.Count Then
        If Mail(mx).Filename = "" Then
            'Remove Item
            lstQ.ListItems.Remove i
            If lstQ.ListItems.Count = 0 Then a = "" Else a = " [" + Trim(Str(lstQ.ListItems.Count)) + "]"
            tabMain.Tabs(2).Caption = tabMain.Tabs(2).Tag + a
        Else
            'Status
            lstQ.ListItems.Item(i).SubItems(2) = Mail(mx).Status
        End If
    End If
End Sub

Private Function GetQue(Prof) As Integer
    Dim TmpX() As Integer, x As Long
    Dim dt As Date, lowdt As Date, lowx As Integer
    
    While QBusy
        DoEvents
    Wend
    QBusy = True
    
    x = -1
    If Prof = 30 Then ProfName = "unix" Else ProfName = LCase(UserProf(Prof, 1))
    If Trim(ProfName) = "" Then ProfName = Trim(Str(Prof - 15))
    ReDim TmpX(lstQ.ListItems.Count)
    For i = 1 To lstQ.ListItems.Count
        a = Mid(lstQ.ListItems.Item(i).Key, 2)
        If Trim(a) <> "" Then
            mx = Val(a)
            If LCase(Mail(mx).Profile) = ProfName Then
                If Mail(mx).Status = LMsg(302) Then GetQue = mx: GoTo Leave 'Priority
                If (chkRLatent.Value = 0 And Mail(mx).Origin <> "~Dummy~") Or Mail(mx).Schedule <= SafeTime Or LCase(Mail(mx).Profile) = "unix" Then
                    x = x + 1
                    TmpX(x) = mx
                End If
            End If
        End If
    Next i
    If x = -1 Then GetQue = -1: GoTo Leave
    If chkROrder.Value = 1 Then
        GetQue = TmpX(Int(Rnd(1) * (x + 1)))
    Else
        lowx = 0: lowdt = 0
        For i = 0 To x
            If (chkRLatent.Value = 0 And Mail(TmpX(i)).Origin <> "~Dummy~") Or LCase(Mail(TmpX(i)).Profile) = "unix" Then dt = Mail(TmpX(i)).Created Else dt = Mail(TmpX(i)).Schedule
            If dt < lowdt Or lowdt = 0 Then lowdt = dt: lowx = i
        Next i
        GetQue = TmpX(lowx)
    End If
Leave:
    QBusy = False
End Function

Private Sub ReadQue()
    Dim Q0 As String, Q1 As String, rl As Double, rl2 As Double
    
    While QBusy
        DoEvents
    Wend
    QBusy = True
    
    On Error GoTo ReadQError
    If SDir(Cnf(0, 1) + "\*.*") = "" Then GoTo Leave
    a = Dir(Cnf(0, 1) + "\" + "*.Q0")
    While a <> ""
        Found = False
        'Check for Have
        b = LCase(Cnf(0, 1) + "\" + PlainName(a, 2))
        For i = 0 To MaxMail
            If Mail(i).Filename = b Then Found = True: Exit For
        Next i
        'Check for Busy
        If Not Found Then
            b = LCase(Left(a, 4))
            For i = 0 To 10
                If a = LCase(QBusyTag(i)) Then Found = True: Exit For
            Next i
        End If
        If Not Found Then
            Q0 = Cnf(0, 1) + "\" + a
            Q1 = Cnf(0, 1) + "\" + PlainName(a, 2) + ".Q1"
            'New Mail Pair
            n = FreeFile
            Open Q0 For Input As n
            Line Input #n, a
            If a <> "JBN2_QMAIL" And a <> "RELI_MAIL" Then
                DelFile Q0
                DelFile Q1
            Else
                'Valid Mail Pair
                'Find Slot
                For mx = 0 To MaxMail
                    If Mail(mx).Filename = "" Then Exit For
                Next mx
                If mx > MaxMail Then Close n: n = 0: GoTo Leave
                If a = "JBN2_QMAIL" Then
                    Input #n, Mail(mx).Created
                    If Mail(mx).Created > SafeTime Or Mail(mx).Created = 0 Then Mail(mx).Created = SafeTime
                    Line Input #n, Mail(mx).Profile
                    Line Input #n, Mail(mx).Origin
                Else
                    'Reliable
                    Line Input #n, a
                    Mail(mx).Profile = UserProf(15 + Val(UserProf(15, 7)), 1)
                    If Mail(mx).Profile = "" Then Mail(mx).Profile = "1"
                    Mail(mx).Origin = "~Reliable~"
                End If
                Do
                    If Not EOF(n) Then Line Input #n, a
                Loop Until EOF(n) Or Left(a, 4) = "To: "
                If Left(a, 4) <> "To: " Then
                    'Missing To
                    Close n: n = 0
                    DelFile Q0
                    DelFile Q1
                Else
                    Mail(mx).Toh = Mid(a, 5)
                    'Schedule
                    If LCase(Mail(mx).Profile) <> "unix" Then
                        If Mail(mx).Origin <> "~Dummy~" Then
                            rl = LatentValue(txtRLatent(0).Text)
                            rl2 = LatentValue(txtRLatent(1).Text)
                            If rl > rl2 Then rl = rl2
                            Mail(mx).Schedule = Mail(mx).Created + (rl / 24) + ((Rnd(1) * (rl2 - rl)) / 24)
                        Else
                            Mail(mx).Schedule = SafeTime + (Rnd(1) * 1 / 24)
                        End If
                    Else
                        Mail(mx).Schedule = Mail(mx).Created
                    End If
                    Mail(mx).Status = LMsg(286) 'Queued
                    On Error Resume Next
                    Mail(mx).Size = FileLen(Q1)
                    On Error GoTo ReadQError
                    'Add To List
                    Mail(mx).Filename = LCase(PlainName(Q0, 0) + PlainName(Q0, 2))
                    lstQ.ListItems.Add , "K" + Trim(Str(mx)), Mail(mx).Profile
                    For i = 1 To lstQ.ListItems.Count
                        If lstQ.ListItems.Item(i).Key = "K" + Trim(Str(mx)) Then Exit For
                    Next i
                    If i > lstQ.ListItems.Count Then
                        Mail(mx).Filename = ""
                    Else
                        lstQ.ListItems.Item(i).SubItems(1) = PlainName(Mail(mx).Origin, 1)
                        lstQ.ListItems.Item(i).SubItems(2) = Mail(mx).Status
                        lstQ.ListItems.Item(i).SubItems(3) = Format(Mail(mx).Created, "hh:nn ddd d")
                        lstQ.ListItems.Item(i).SubItems(4) = Format(Mail(mx).Schedule, "hh:nn ddd d")
                        lstQ.ListItems.Item(i).SubItems(5) = Trim(Str(Int(Mail(mx).Size / 1024 + 0.999))) + "k"
                        lstQ.ListItems.Item(i).SubItems(6) = Mail(mx).Toh
                        lstQ.ListItems.Item(i).SubItems(7) = UCase(PlainName(Mail(mx).Filename, 2))
                        rl = Mail(mx).Created
                        a = Trim(Str(rl))
                        x = InStr(a, "."): If x = 0 Then a = a + ".": x = Len(a)
                        lstQ.ListItems.Item(i).SubItems(8) = Right("00000000" + Left(a, x - 1), 8) + Left(Mid(a, x) + "0000000", 8)
                        rl = Mail(mx).Schedule
                        a = Trim(Str(rl))
                        x = InStr(a, "."): If x = 0 Then a = a + ".": x = Len(a)
                        lstQ.ListItems.Item(i).SubItems(9) = Right("00000000" + Left(a, x - 1), 8) + Left(Mid(a, x) + "0000000", 8)
                        lstQ.ListItems.Item(i).SubItems(10) = Right("00000000" + Trim(Str(Mail(mx).Size)), 10)
                    End If
                End If
            End If
            Close n: n = 0
        End If
        a = Dir
    Wend
Leave:
    lstQ.Sorted = True
    If lstQ.ListItems.Count = 0 Then a = "" Else a = " [" + Trim(Str(lstQ.ListItems.Count)) + "]"
    tabMain.Tabs(2).Caption = tabMain.Tabs(2).Tag + a
    QBusy = False
Exit Sub
ReadQError:
    MsgBox LMsg(406) + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
    lstQ.ListItems.Clear
    Erase Mail
    GoTo Leave
End Sub

Private Sub chkRLatent_Click()
    txtRLatent(0).Enabled = chkRLatent.Value = 1
    txtRLatent(1).Enabled = chkRLatent.Value = 1
    StartSession (1)
End Sub

Private Sub mnuPopUp_Click(Index As Integer)
    mnuPopUp(Index).Checked = Not mnuPopUp(Index).Checked
    PData(30 + Index) = mnuPopUp(Index).Checked
End Sub

Private Sub txtRLatent_LostFocus(Index As Integer)
    Dim x As Double
    For i = 1 To 0 Step -1
        x = LatentValue(txtRLatent(i).Text)
        If i = 0 And x > LatentValue(txtRLatent(1).Text) Then x = LatentValue(txtRLatent(1).Text)
        txtRLatent(i).Text = Trim(Str(Int(x))) + ":" + Right("0" + Trim(Str(Int((x - Int(x)) * 60 + 0.0001))), 2)
    Next i
End Sub

Private Sub lstQ_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        PopupMenu mnuQue
    End If
End Sub

Private Sub mnuQue_Click()
    On Error Resume Next
    While QBusy
        DoEvents
    Wend
    x = lstQ.SelectedItem.Index
    If x <> 0 Then
        mnuChangeProfile.Enabled = lstQ.ListItems.Item(x).Key <> "K" + Trim(Str(CurrentSendX))
    Else
        mnuChangeProfile.Enabled = False
    End If
    mnuMultiQue(0).Enabled = x <> 0
    mnuMultiQue(1).Enabled = x <> 0
    mnuViewQue.Enabled = mnuChangeProfile.Enabled
    mnuRefreshQue(0).Enabled = Not SendingMail
    mnuRefreshQue(1).Enabled = Not SendingMail
End Sub

Private Sub mnuChangeProfile_Click()
    lstQ.SetFocus
    lstQ.StartLabelEdit
End Sub

Private Sub lstQ_AfterLabelEdit(Cancel As Integer, NewString As String)
    While QBusy
        DoEvents
    Wend
    QBusy = True
    mx = Val(Mid(lstQ.SelectedItem.Key, 2))
    If Trim(NewString) = "" Or mx = CurrentSendX Then
        Cancel = 1
    Else
        Mail(mx).Profile = Left(Trim(NewString), 12)
        On Error GoTo EditError
        fn = GetWork(Cnf(0, 1))
        n = FreeFile
        Open Mail(mx).Filename + ".Q0" For Input As n
        Line Input #n, a
        Line Input #n, b
        If a = "JBN2_QMAIL" Then Line Input #n, c
        p = FreeFile
        Open fn For Output As p
        Print #p, "JBN2_QMAIL"
        Write #p, Mail(mx).Created
        Print #p, Left(Trim(NewString), 12)
        While Not EOF(n)
            Line Input #n, a
            Print #p, a
        Wend
        Close p: p = 0
        Close n: n = 0
        FileCopy fn, Mail(mx).Filename + ".Q0"
        DelFile fn
    End If
Leave:
    QBusy = False
Exit Sub
EditError:
    MsgBox LMsg(0) + vbCr + Error, vbCritical, LMsg(4)
    CloseFile n
    CloseFile p
    DelFile fn
    'Requeue ''''''''''''''''  ??????????????
    GoTo Leave
End Sub

Private Sub mnuMultiQue_Click(Index As Integer)
    If Index = 1 Then If MsgBox(LMsg(299), vbQuestion + vbOKCancel, LMsg(95)) = vbCancel Then Exit Sub
    While QBusy
        DoEvents
    Wend
    QBusy = True
    For i = 1 To lstQ.ListItems.Count
        If lstQ.ListItems.Item(i).Selected Then
            mx = Val(Mid(lstQ.ListItems.Item(i).Key, 2))
            If mx <> CurrentSendX Then
                If Index = 0 Then
                    'Give Priority
                    Mail(mx).Status = LMsg(302)
                    UpdateStatus (mx)
                Else
                    'Delete
                    DelFile (Mail(mx).Filename + ".Q0")
                    DelFile (Mail(mx).Filename + ".Q1")
                    Mail(mx).Filename = ""
                    UpdateStatus (mx)
                    i = i - 1
                End If
            Else
                Current = True
            End If
        End If
        If i + 1 > lstQ.ListItems.Count Then Exit For
    Next i
    QBusy = False
    If Index = 1 And Current Then If MsgBox(LMsg(303), vbExclamation + vbYesNo, LMsg(304)) = vbYes Then cmdAbort_Click
    If Index = 1 Then ReadQue
    If Index = 0 Then StartSession (1)
End Sub

Private Sub mnuPrevDumm_Click()
    mnuPrevDumm.Checked = Not mnuPrevDumm.Checked
    PData(121) = mnuPrevDumm.Checked
    If mnuPrevDumm.Checked Then
        MsgBox LMsg(444)
    End If
End Sub

Private Sub mnuRefreshQue_Click(Index As Integer)
    If Index = 1 Then If MsgBox(LMsg(305), vbQuestion + vbOKCancel + vbDefaultButton2, LMsg(95)) = vbCancel Then Exit Sub
    If SendingMail Then Exit Sub
    While QBusy
        DoEvents
    Wend
    QBusy = True
    If Index = 1 Then
        For i = 0 To MaxMail
            If Mail(i).Filename <> "" Then DelFile Mail(i).Filename + ".Q*"
        Next i
    End If
    lstQ.ListItems.Clear
    Erase Mail
    QBusy = False
    ReadQue
End Sub

Private Sub mnuViewQue_Click()
    On Error Resume Next
    mx = -1
    mx = Val(Mid(lstQ.SelectedItem.Key, 2))
    If mx = -1 Then Exit Sub
    ViewQueMsg Mail(mx).Filename, "Q", Mail(mx).Profile
End Sub

Private Sub lstQ_ColumnClick(ByVal ColumnHeader As ColumnHeader)
    While QBusy
        DoEvents
    Wend
    QBusy = True
    For i = 1 To 8
        If i = ColumnHeader.Index Then a = "*" Else a = ""
        lstQ.ColumnHeaders.Item(i).Text = lstQ.ColumnHeaders.Item(i).Key + a
    Next i
    If ColumnHeader.Index > 3 And ColumnHeader.Index < 7 Then
        x = ColumnHeader.Index + 5
    Else
        x = ColumnHeader.Index
    End If
    lstQ.SortKey = x - 1
    lstQ.Sorted = True
    QBusy = False
End Sub

Private Sub MakeDummies(dX)
    Dim ProfList(14) As Byte, ChainLen As Integer
    
    Dim Max As MaxType, Rmlr(5) As String, rd(5) As String
    
    For i = 0 To MaxMail
        If Mail(i).Filename <> "" Then If Mail(i).Origin = "~Dummy~" Then KeepDate(2) = SafeTime - 45 / 24 / 60: Exit Sub
    Next i
    Me.MousePointer = 13
    For rtype = 0 To 1
        If rtype = 0 Then rt = LMsg(320) Else rt = LMsg(321)
        ErrMsg = ""
        Erase ProfList: listx = 0
        For Prof = 15 To 29
            If Val(UserProf(Prof, 0)) = 1 And Val(UserProf(Prof, 8 + rtype)) = 1 Then ProfList(listx) = Prof: listx = listx + 1
        Next Prof
        If listx <> 0 Then
            xtop = Int(Rnd(1) * (dX + 1))
            For dcount = 1 To xtop
                ChainLen = 2 + Int(Rnd(1) * 2)
                Prof = ProfList(Int(Rnd(1) * listx))
                If dcount = 1 Then
                    Stat LMsg(319) + "... [" + rt + "]", StatDec
                    MsgLog LMsg(319) + " [" + rt + "]", 4
                End If
                fn = GetWork
                n = FreeFile
                Open fn For Output As n
                Print #n, ""
                Close n: n = 0
                Erase rd
                For i = 0 To ChainLen - 1
                    Rmlr(i) = "AUTO"
                    If rtype = 0 Then
                        x = Int(Rnd(1) * 10): If x > 0 Then gb = "%%%%Garbage:" + Str(x) + "r" + vbCrLf Else gb = ""
                        If i <> ChainLen - 1 Then rd(i) = "Anon-To: $next" + vbCrLf + "Inflate: 10r" + vbCrLf + gb Else rd(i) = "Anon-To: $final" + vbCrLf + gb  'Null: $final
                    End If
                Next i
                For i = 1 To 5
                    If GetRandom(Rmlr(), rd(), ChainLen, rtype, "void@null.void", 0, False, False, True) = -1 Then Exit For
                    For j = 0 To ChainLen - 1
                        Rmlr(j) = "AUTO"
                    Next j
                Next i
                If i = 6 Then
                    'Insufficient random remailers
                    MsgLog LMsg(316) + " [" + rt + "]", 4, False, True
                Else
                    If rtype = 0 Then a = "void@null.null" Else a = "Null: void@null.null"
                    ErrMsg = ""
                    Dst = ChainMsg(fn, a, Rmlr(), rd(), ChainLen, rtype, "", "", False, PData(121) = True2, "", Me, Max, ErrMsg, False)
                    DelFile fn
                    If Dst <> "" And Remailer(Rmlr(0), rtype, "", raddress, "", "", "", "", "") Then
                        ErrMsg = QueMail(Dst, raddress, "", "~Dummy~", rtype, Prof - 15, "", 0, False)
                    End If
                    DelFile Dst
                    If ErrMsg <> "" Then MsgLog LMsg(317) + " [" + rt + "]" + vbCrLf + "      " + ErrMsg, 4, True, True
                End If
                DoEvents
                If ErrMsg <> "" Then Exit For
                If mnuSuspendAuto.Checked Then Exit For
            Next dcount
        End If
        If ErrMsg <> "" Then Exit For
        If mnuSuspendAuto.Checked Then Exit For
    Next rtype
Leave:
    Me.MousePointer = 0
    Stat "", StatDec
    KeepDate(2) = SafeTime
Exit Sub
MakeError:
    MsgLog LMsg(317) + vbCrLf + "      " + Error, 5, True, True
    GoTo Leave
End Sub


'_____________________________________________________________
'DIALER
Private Sub mnuDial_Click(Index As Integer)
    If Index = 0 Then
        'Dial
        If Cnf(0, 10) = "" Or InStr(1, Cnf(0, 11), Cnf(0, 10) + vbCrLf) = 0 Then MsgBox LMsg(315), vbInformation, LMsg(6): Exit Sub
        If Not RASConnected Then KeepDate(16) = 0: DialRAS (True)
    Else
        'Hang Up
        DialRAS (False)
    End If
    tmrSession.Enabled = False
    tmrSession.Interval = 200
    tmrSession.Enabled = True
End Sub

Private Sub mnuDialOpt_Click(Index As Integer)
    'Checks
    mnuDialOpt(Index).Checked = Not mnuDialOpt(Index).Checked
    PData(53 + Index) = mnuDialOpt(Index).Checked
    If Index = 0 Then
        'Verify Connection
        If Not mnuDialOpt(Index).Checked Then
            If PData(54) = True2 Then
                MsgBox LMsg(322), vbInformation, LMsg(6)
                PData(53) = True2: mnuDialOpt(Index).Checked = True
            Else
                If MsgBox(LMsg(323), vbInformation + vbOKCancel, LMsg(18)) = vbCancel Then
                    PData(53) = True2: mnuDialOpt(Index).Checked = True
                End If
            End If
        End If
    End If
    If Index = 1 And mnuDialOpt(1).Checked And (Cnf(0, 10) = "" Or InStr(1, Cnf(0, 11), Cnf(0, 10) + vbCrLf) = 0) Then mnuDialOpt(1).Checked = False: MsgBox LMsg(315), vbInformation, LMsg(6)
    tmrSession.Enabled = False
    tmrSession.Interval = 200
    tmrSession.Enabled = True
End Sub

Private Sub Dialer1_Status(state As Integer)
   '8192   RAS_CONNECTED   The connection has been established
    'Debug.Print "STATE "; Dialer1.Connected, Dialer1.State, State
End Sub

Private Sub Dialer1_Connect()
    If Dialer1.Tag <> "Trying" And Dialer1.Tag <> "Waiting" Then
        frmMain!tmrSession.Enabled = False
        frmMain!tmrSession.Interval = 1500
        frmMain!tmrSession.Enabled = True
    End If
    Dialer1.Tag = "Connect"
    'Debug.Print "CONNECT "; Dialer1.Connected, Dialer1.State
End Sub

Private Sub Dialer1_Timeout()
    Dialer1.Tag = "Timeout"
    'Debug.Print "TIMEOUT "; Dialer1.Connected, Dialer1.State
End Sub

Private Sub Dialer1_Disconnect()
    'Debug.Print "DISCONNECT "; Dialer1.Connected, Dialer1.State
    IEstablished = False
    Dialer1.Tag = "Timeout"
    Stat LMsg(311), StatDec
End Sub


'==============================================================
'EXPLORE
Private Sub mnuFile_Click()
    tabMain.Tabs(1).Selected = True
End Sub

Private Sub mnuView_Click()
    tabMain.Tabs(1).Selected = True
End Sub

Private Sub mnuEditPatterns_Click(Index As Integer)
    Dim a As String
    
    If Index = 0 Then
        For i = 0 To cboPattern(0).ListCount - 1
            a = a + cboPattern(0).List(i) + vbCrLf
        Next i
        a = MultiBox("", LMsg(335), a)
        If a = "" Then Exit Sub
    End If
    PData(69) = a: MainLoadList ("")
    If Index = 1 Then cboPattern(0).ListIndex = 0: cboPattern(1).ListIndex = 1
End Sub

Private Sub cboPattern_Click(Index As Integer)
    a = Trim(cboPattern(Index).Text)
    For i = 0 To cboPattern(Index).ListCount - 1
        If LCase(cboPattern(Index).List(i)) = LCase(a) Then Found = True: Exit For
    Next i
    If Trim(a) = "" Then cboPattern(Index).Text = filExplore(Index).Pattern: Exit Sub
    x = InStr(a, "(")
    If x <> 0 Then a = Trim(Extract(Mid(a, x + 1), ")"))
    If Not Found And cboPattern(Index).ListCount < 50 Then cboPattern(0).AddItem cboPattern(Index).Text: cboPattern(1).AddItem cboPattern(Index).Text
    filExplore(Index).Pattern = Replace(a, " ", "")
    If cboRecent.Visible Then cboRecent.SetFocus
End Sub

Private Sub cboPattern_KeyDown(Index As Integer, KeyCode As Integer, Shift As Integer)
    If KeyCode = 13 Then cboPattern_Click (Index)
End Sub

Private Sub mnuFolder_Click(Index As Integer)
    Select Case Index
    Case 0
        'New Folder
        a = InputBox(LMsg(350) + ":", LMsg(351))
        If a <> "" Then
            If PlainName(a, 0) = "" Then a = trvFolder.Tag + "\" + a
            CreateDir a
            ChangeFolder a, True
        End If
    Case 1
        'Remove Folder
        If SDir(trvFolder.Tag + "\*.*", vbHidden + vbSystem) <> "" Then MsgBox LMsg(486), vbInformation: Exit Sub
        On Error GoTo RemoveError
        RmDir trvFolder.Tag
        ChangeFolder trvFolder.Tag, True
    Case 2
        'Rename Folder
        If Not trvFolder.SelectedItem Is Nothing Then trvFolder.StartLabelEdit
    Case 3
        'Explore Folder
        On Error Resume Next
        a = trvFolder.Tag
        If Right(a, 1) = ":" Then a = a + "\"
        Shell "EXPLORER.EXE /n,/e," + a, vbNormalFocus
    End Select
Exit Sub
RemoveError:
    MsgBox LMsg(0) + vbCr + Error, vbCritical, LMsg(4)
    ChangeFolder trvFolder.Tag, True
End Sub

Private Sub filExplore_MouseDown(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        PopupMenu mnuSelected
    End If
End Sub

Private Sub trvFolder_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = vbRightButton Then
        PopupMenu mnuSelFolders
    End If
End Sub

Private Sub trvFolder_AfterLabelEdit(Cancel As Integer, NewString As String)
    If trvFolder.SelectedItem Is Nothing Then Exit Sub
    a = NewString
    If InStr(a, "\") = 0 Then a = PlainName(trvFolder.SelectedItem.Tag, 0) + NewString
    On Error GoTo ErrorName
    Name trvFolder.SelectedItem.Tag As a
Exit Sub
ErrorName:
    Cancel = 1
End Sub

Private Sub trvFolder_NodeClick(ByVal Node As ComctlLib.Node)
    If Node.Tag = trvFolder.Tag And Len(Node.Tag) > 2 Then
        'Current folder selected - refresh
        filExplore(0).Refresh
        If filExplore(1).Visible Then filExplore(1).Refresh
        cboRecent.Text = trvFolder.Tag
    Else
        If Right$(Node.Tag, 2) = "::" Then
            Node.Tag = Left$(Node.Tag, Len(Node.Tag) - 2)
            ReadFolders Node.Tag, Node.Index
        End If
        'New folder selected
        ChangeFolder Node.Tag
        cboRecent.SetFocus
    End If
End Sub

Private Sub trvFolder_DragOver(Source As Control, x As Single, y As Single, state As Integer)
    Dim nod As Node
    Set nod = trvFolder.HitTest(x, y)
    If Not trvFolder.DropHighlight Is nod Then
        Set trvFolder.DropHighlight = nod
        tmrOLE.Enabled = True
    End If
    If y < 300 Or y > trvFolder.Height - 350 Then
        If Not tmrOLE.Enabled And Not trvFolder.DropHighlight Is Nothing Then
            If y < 300 Then
                Set nod = trvFolder.DropHighlight.Previous
                If nod Is Nothing Then Set nod = trvFolder.DropHighlight.Parent
                If Not nod Is Nothing Then
                    nod.EnsureVisible
                    Set trvFolder.DropHighlight = nod
                    tmrOLE.Enabled = True
                End If
            Else
                Set nod = trvFolder.DropHighlight.Next
                If nod Is Nothing Then Set nod = trvFolder.DropHighlight.Child
                If Not nod Is Nothing Then
                    nod.EnsureVisible
                    Set trvFolder.DropHighlight = nod
                    tmrOLE.Enabled = True
                End If
            End If
        End If
    End If
End Sub

Private Sub trvFolder_DragDrop(Source As Control, x As Single, y As Single)
    If Source.Name = "filExplore" And Not trvFolder.DropHighlight Is Nothing Then
        filExplore(DragIndex).Drag vbEndDrag
        If DragShift And vbCtrlMask <> 0 Then
            PData(104) = trvFolder.DropHighlight.Tag
            mnuSelect_Click (3)
        Else
            PData(74) = trvFolder.DropHighlight.Tag
            mnuSelect_Click (1)
        End If
        Set trvFolder.DropHighlight = Nothing
    End If
End Sub

Private Sub filExplore_MouseMove(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
    If Button = 0 Then
        filExplore(Index).Drag vbCancel
    ElseIf (Button And vbLeftButton) <> 0 Then
        'Turn on Drag Mode
        filExplore(Index).Drag vbBeginDrag
        DragIndex = Index
        If Shift = vbCtrlMask Then filExplore(Index).DragIcon = filExplore(1).MouseIcon Else filExplore(Index).DragIcon = filExplore(0).MouseIcon
        DragShift = Shift
    End If
End Sub

Private Sub filExplore_OLEStartDrag(Index As Integer, Data As DataObject, AllowedEffects As Long)
    Data.Clear   'Required to fix bug
End Sub

Private Sub tmrOLE_Timer()
    tmrOLE.Enabled = False
End Sub

Private Sub filExplore_Click(Index As Integer)
    If NoClick Then Exit Sub
    For i = 0 To filExplore(Index).ListCount - 1
        If filExplore(Index).Selected(i) Then a = a + Chr(34) + NoSlash(filExplore(Index).Path) + "\" + filExplore(Index).List(i) + Chr(34) + " ": x = x + 1
    Next i
    If x = 1 Then a = Replace(a, Chr(34), "")
    NoClick = True
    cboRecent.Text = RTrim(a)
    For i = 0 To filExplore(Abs(Index - 1)).ListCount - 1
        filExplore(Abs(Index - 1)).Selected(i) = False
    Next i
    filExplore(Abs(Index - 1)).ListIndex = -1
    NoClick = False
''    cboRecent.SetFocus
End Sub

Private Sub filExplore_DblClick(Index As Integer)
    If Not OpenSpec(NoSlash(filExplore(Index).Path) + "\" + filExplore(Index).List(filExplore(Index).ListIndex), False) Then
        MsgBox LMsg(70), vbCritical, LMsg(66)
    Else
        AddRecent cboRecent.Text
    End If
End Sub

Private Sub cmdOpen_Click()
    If Trim(cboRecent.Text) = "" Then mnuOpen_Click: Exit Sub
    If Not OpenSpec(cboRecent.Text, True) Then
        MsgBox LMsg(70), vbCritical, LMsg(66)
    Else
        AddRecent cboRecent.Text
    End If
End Sub

Private Sub cboRecent_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 And Trim(cboRecent.Text) <> "" Then cboRecent_Click
End Sub

Private Sub cboRecent_Click()
    r = cboRecent.Text
    If r = "" Then Exit Sub
    If Not IsDir(r) Then
        If IsDir(trvFolder.Tag + "\" + r) Then r = trvFolder.Tag + "\" + r
    End If
    If Left(r, 1) = "\" Then r = Left(trvFolder.Tag, 2) + r
    If IsDir(r) Then
        If InStr(r, "..") <> 0 Then
            On Error Resume Next
            a = filExplore(1).Path
            filExplore(1).Path = r
            r = filExplore(1).Path
            filExplore(1).Path = a
            On Error GoTo 0
        End If
        ChangeFolder r
        AddRecent (r)
        cboRecent.SelStart = 0
        cboRecent.SelLength = Len(cboRecent.Text)
    Else
        AddRecent (r)
        If LCase(Left(r, 5)) = "http:" Then
            CallBrowser 0, r
        Else
            If InStr(r, "\") = 0 And InStr(r, ":") = 0 Then r = NoSlash(trvFolder.Tag) + "\" + r
            OpenSpec r, False
        End If
    End If
End Sub

Private Sub AddRecent(r)
    r = Replace(Extract(r, Chr(34) + " " + Chr(34)), Chr(34), "")
    'X If Not IsDir(r) And LCase(Left(r, 5)) <> "http:" Then r = NoSlash(PlainName(r, 0))
    a = LCase(r)
    cboRecent.AddItem r, 0
    For i = 1 To cboRecent.ListCount - 1
        If LCase(cboRecent.List(i)) = a Then cboRecent.RemoveItem i: i = i - 1
        If i + 1 > cboRecent.ListCount - 1 Then Exit For
    Next i
    If cboRecent.ListCount > 75 Then cboRecent.RemoveItem cboRecent.ListCount - 1
End Sub

Private Sub mnuSelect_Click(Index As Integer)
    Dim dt As Date, Tmp() As String
    
    On Error GoTo FileError
    If Index = 1 Then df = PData(74): Index = 0
    If Index = 3 Then df = PData(104): Index = 2
    If Index < 12 Then
        For i = 0 To 1
            For j = 0 To filExplore(i).ListCount - 1
                If filExplore(i).Selected(j) Then
                    f = NoSlash(filExplore(i).Path) + "\" + filExplore(i).List(j)
                    If Index > 4 And Index < 9 And Not Ask Then
                        If Index < 7 Then a = LMsg(341) Else a = LMsg(342)
                        b = a
                        If Index = 6 Or Index = 8 Then a = a + " " + LMsg(343)
                        a = a + " " + LMsg(344)
                        If Index = 8 Then a = a + vbCr + vbCr + "[" + LMsg(345) + "]"
                        If MsgBox(a, vbQuestion + vbOKCancel, LMsg(95) + " " + b) = vbCancel Then Exit Sub
                        Ask = True
                    End If
                    If (Index = 10 Or Index = 11) And Not Ask Then
                        FileClip = "": FileClipMode = Abs(Index - 11)
                        Ask = True
                    End If
                    Select Case Index
                    Case 0, 2   'Move To, Copy To
                        If df = "" Then
                            If Index = 0 Then x = 74 Else x = 104
                            If PData(x) = "" Then PData(x) = filExplore(0).Path
                            df = SelectFolder(PData(x), LMsg(336 + (Index / 2)), PData(75))
                            If df = "" Then Exit Sub
                        End If
                        If LCase(df) = LCase(NoSlash(PlainName(f, 0))) Then MsgBox LMsg(346), vbInformation, LMsg(347): Exit Sub
                        f2 = df + "\" + PlainName(f, 1)
                        If SDir(f2) <> "" Then
                            dt = FileDateTime(f2): fl = FileLen(f2)
                            dt2 = FileDateTime(f): fl2 = FileLen(f)
                            y = MsgBox(f2 + " " + LMsg(338) + vbCr + vbCr + LMsg(348) + vbCr + vbCr + f2 + vbCr + Format(dt, "ddd d mmm yyyy  hh:nn   ") + Str(fl) + " " + LMsg(222) + vbCr + vbCr + LMsg(349) + vbCr + vbCr + f + vbCr + Format(dt, "ddd d mmm yyyy  hh:nn   ") + Str(fl2) + " " + LMsg(222), vbQuestion + vbYesNo, LMsg(339))
                        Else
                            y = -1
                        End If
                        If y <> vbNo Then
                            ecode = 0
                            If Index = 0 And LCase(Left(f, 1)) = LCase(Left(f2, 1)) And y <> vbYes Then
                                Name f As f2
                            Else
                                FileCopy f, f2
                                If Index = 0 And ecode = 0 Then DelFile f
                            End If
                        End If
                    Case 4      'Rename
                        ext = PlainName(f, 3)
                        a = InputBox(LMsg(339) + vbCr + vbCr + f, LMsg(340), PlainName(f, 2))
                        If a <> "" Then
                            If PlainName(a, 3) = "" And ext <> "" Then a = a + "." + ext
                            If PlainName(a, 0) = "" Then a = PlainName(f, 0) + a
                            Name f As a
                        End If
                    Case 5      'Delete
                        Kill f
                    Case 6      'Delete Set
                        b = PlainName(f, 0) + PlainName(f, 2)
                        DelFile b + ".BK"
                        DelFile b + "._*"
                    Case 7     'Wipe
                        WipeFile f
                    Case 8      'Wipe Set
                        b = PlainName(f, 0) + PlainName(f, 2)
                        If SDir(b + ".BK") <> "" Then WipeFile b + ".BK"
                        DelFile b + "._*"
                    Case 10, 11  'Copy, Cut
                        FileClip = FileClip + f + vbCrLf
                    End Select
                End If
            Next j
        Next i
    Else
        If Index = 12 Then
            'Paste
            If FileClip = "" Then Exit Sub
            ReDim Tmp(1000) As String
            x = ParseString(FileClip, Tmp(), 1000, False)
            cd = trvFolder.Tag
            If Right(cd, 1) = ":" Then cd = cd + "\"
            If x <> -1 Then
                If LCase(NoSlash(PlainName(Tmp(0), 0))) = LCase(cd) Then MsgBox LMsg(346), vbInformation, LMsg(347): Exit Sub
            End If
            For i = 0 To x
                If SDir(Tmp(i)) <> "" Then
                    f2 = cd + "\" + PlainName(Tmp(i), 1)
                    If SDir(f2) <> "" Then
                        dt = FileDateTime(f2): fl = FileLen(f2)
                        dt2 = FileDateTime(Tmp(i)): fl2 = FileLen(Tmp(i))
                        y = MsgBox(f2 + " " + LMsg(338) + vbCr + vbCr + LMsg(348) + vbCr + vbCr + f2 + vbCr + Format(dt, "ddd d mmm yyyy  hh:nn   ") + Str(fl) + " " + LMsg(222) + vbCr + vbCr + LMsg(349) + vbCr + vbCr + Tmp(i) + vbCr + Format(dt, "ddd d mmm yyyy  hh:nn   ") + Str(fl2) + " " + LMsg(222), vbQuestion + vbYesNo, LMsg(339))
                    Else
                        y = -1
                    End If
                    If y <> vbNo Then
                        ecode = 0
                        If FileClipMode = 0 And LCase(Left(f, 1)) = LCase(Left(f2, 1)) And y <> vbYes Then
                            Name Tmp(i) As f2
                        Else
                            FileCopy Tmp(i), f2
                            If FileClipMode = 0 And ecode = 0 Then DelFile Tmp(i)
                        End If
                    End If
                End If
            Next i
        End If
    End If
    If Index <> 10 And Index <> 11 Then
        filExplore(0).Refresh
        If filExplore(1).Visible Then filExplore(1).Refresh
    End If
Exit Sub
FileError:
    MsgBox LMsg(0) + vbCr + Error, vbCritical, LMsg(4)
    ecode = Err.Number
    Resume Next
End Sub

Private Sub mnuSendTo_Click(Index As Integer)
    Dim fn As String
    
    On Error GoTo SendError
    If SDir(mnuSendTo(Index).Tag) <> "" Then
        If filExplore(0).ListIndex <> -1 Then
            If filExplore(0).Selected(filExplore(0).ListIndex) Then x = 0 Else x = 1
        Else
            x = 1
        End If
        If filExplore(x).ListIndex = -1 Then Exit Sub
        If Not filExplore(x).Selected(filExplore(x).ListIndex) Then Exit Sub
        fn = mnuSendTo(Index).Tag
        pr = NoSlash(filExplore(x).Path) + "\" + filExplore(x).List(filExplore(x).ListIndex)
        If LCase(fn) Like "*floppy (*).lnk" Then
            d = Mid(fn, InStr(fn, "(") + 1, 1)
            If Trim(d) <> "" Then
                f2 = d + ":\" + PlainName(pr, 1)
                If SDir(f2) <> "" Then
                    dt = FileDateTime(f2): fl = FileLen(f2)
                    dt2 = FileDateTime(pr): fl2 = FileLen(pr)
                    If MsgBox(f2 + " " + LMsg(338) + vbCr + vbCr + LMsg(348) + vbCr + vbCr + f2 + vbCr + Format(dt, "ddd d mmm yyyy  hh:nn   ") + Str(fl) + " " + LMsg(222) + vbCr + vbCr + LMsg(349) + vbCr + vbCr + pr + vbCr + Format(dt, "ddd d mmm yyyy  hh:nn   ") + Str(fl2) + " " + LMsg(222), vbQuestion + vbYesNo, LMsg(339)) = vbNo Then Exit Sub
                End If
                FileCopy pr, f2
            End If
        Else
            ret = ShellExecute(frmMain.hwnd, "Open", fn, pr, filExplore(x).Path, 1)
        End If
    End If
Exit Sub
SendError:
    MsgBox LMsg(0) + vbCr + Error, vbCritical, LMsg(4)
End Sub

Private Sub ChangeFolder(pth, Optional Reset As Boolean)
    Dim p As String, p2 As String
    On Error Resume Next
    mp = Me.MousePointer
    Me.MousePointer = 11
    trvFolder.Nodes.Item(UCase(trvFolder.Tag)).Image = "FoldClosed"
    p = NoSlash(pth)
    If Not IsDir(p + "\") Then
        If IsDir(PlainName(p, 0)) Then
            p = NoSlash(PlainName(p, 0))
        ElseIf CreateDir(ProgDir + "\Books") Then
            p = ProgDir + "\Books"
        Else
            p = ProgDir
        End If
        Reset = True
    End If
    If IsDir(p + "\") Then
        If Right(p, 1) = ":" Then
            ReadFolders p, 0
            trvFolder.SelectedItem = trvFolder.Nodes.Item(UCase(p))
        Else
            x = InStr(p, "\")
            If x <> 0 Then
                p2 = Left(p, 3) + Extract(Mid(p, x + 1), "\")
                If (p2 <> p Or Len(trvFolder.Tag) > 2) And Not Reset Then
                    x = -1
                    x = trvFolder.Nodes.Item(UCase(p)).Index
                    If x <> -1 Then Set trvFolder.SelectedItem = trvFolder.Nodes.Item(x): GoTo Done
                End If
                ReadFolders p2, 0
                On Error GoTo 0
                trvFolder.SelectedItem = trvFolder.Nodes.Item(UCase(p))
            End If
        End If
    End If
Done:
    If trvFolder.SelectedItem Is Nothing Then
        Set trvFolder.SelectedItem = trvFolder.Nodes.Item(UCase("C:\"))
        Set trvFolder.SelectedItem = trvFolder.Nodes.Item(UCase(ProgDir + "\Books"))
    End If
    trvFolder.SelectedItem.Image = "FoldOpen"
    trvFolder.SelectedItem.Expanded = True
    trvFolder.Tag = trvFolder.SelectedItem.Tag
    a = trvFolder.Tag
    If Right(a, 1) = ":" Then a = a + "\"
    filExplore(0).Path = a
    filExplore(1).Path = a
    cboRecent.Text = a
    Me.Caption = "Jack B. Nymble v2 - [" + a + "]"
    Me.MousePointer = mp
End Sub

Private Function ReadFolders(pth As String, parentnode As Integer) As Boolean
    Dim nod As Node, rootnod As Node
    Dim dirs() As String, dirmax As Integer, dircount As Integer
    
    On Error GoTo ErrorReadFolders
    If parentnode = 0 Then
        trvFolder.Nodes.Clear
        Me.Refresh
        'Read Drives
        drvExplore.Refresh
        For i = 0 To drvExplore.ListCount - 1
            Set nod = trvFolder.Nodes.Add(, , UCase(Left(drvExplore.List(i), 2)), UCase(drvExplore.List(i)))
            nod.Expanded = True
            nod.Tag = UCase(Left(drvExplore.List(i), 2))
            nod.Image = "Drive"
            nod.Sorted = True
        Next i
        Set rootnod = trvFolder.Nodes.Item(UCase(Left(pth, 2)))
        If Right(pth, 1) = ":" Then
            RootDir = True
        Else
            Set rootnod = trvFolder.Nodes.Add(rootnod, tvwChild, UCase(pth), Mid(pth, 4))
            rootnod.Expanded = True
            rootnod.Tag = pth
            rootnod.Image = "FoldClosed"
            rootnod.Sorted = True
        End If
    End If
StartRead:
    dircount = 0: dirmax = 10
    ReDim dirs(dirmax)
    a = Dir(pth + "\*.*", vbDirectory)
    While a <> "" And dircount < 32000
        If IsDir(pth + "\" + a) And a <> "." And a <> ".." Then
            If dircount > dirmax Then dirmax = dirmax * 2 + 1: ReDim Preserve dirs(dirmax)
            dirs(dircount) = a
            dircount = dircount + 1
        End If
        a = Dir
    Wend
    For i = 0 To dircount - 1
        On Error GoTo ErrorReadFolders
        'Add Node
        If parentnode = 0 Then
            'Add SubRoot Node
            Set nod = trvFolder.Nodes.Add(rootnod, tvwChild, UCase(pth + "\" + dirs(i)), dirs(i))
        Else
            Set nod = trvFolder.Nodes.Add(parentnode, tvwChild, UCase(pth + "\" + dirs(i)), dirs(i))
        End If
        nod.Sorted = True
        nod.Expanded = False
        nod.Tag = pth + "\" + dirs(i)
        nod.Image = "FoldClosed"
        Dim doit As Boolean
        doit = Not RootDir
        If Left$(ProgDir, Len(pth)) = pth And ProgDir <> pth Then
            If Left$(ProgDir, Len(nod.Tag)) <> nod.Tag Then
                doit = False
                nod.Tag = nod.Tag + "::"
            End If
        End If
        If doit Then ReadFolders pth + "\" + dirs(i), nod.Index
'        If Not RootDir Then ReadFolders pth + "\" + dirs(i), nod.Index
    Next i
Exit Function
ErrorReadFolders:
    MsgBox LMsg(537) + vbCr + Error, vbCritical
    CloseFile n
    Unload Me
End Function
'=================================================================

Private Sub mnuConfig_Click(Index As Integer)
    ShowConfig (Index)
End Sub

Private Sub mnuWindow_Click(Index As Integer)
    ShowWindow (Index)
End Sub

Private Sub mnuExShow_Click(Index As Integer)
    mnuExSHow(Index).Checked = Not mnuExSHow(Index).Checked
    PData(105 + Index) = mnuExSHow(Index).Checked
    Form_Resize
End Sub

Private Sub mnuStats_Click(Index As Integer)
    Select Case Index
    Case 0  'Refresh Stats
        CallBrowser 1, ""
    Case 1  'View Stats
        CallBrowser 0, ProgDir + "\Stats\stats.htm"
    Case 2, 3 'Update CPunk/Mix Keys
        CallBrowser Index, ""
    End Select
End Sub

Private Sub mnuViewRing_Click(Index As Integer)
    If Index = 0 Then
        SelectKey (LMsg(415))
    Else
        ShowConfig ConfigRemailers, 3
    End If
End Sub

Private Sub mnuAbout_Click()
    frmAbout.Show 1
End Sub

Private Sub mnuOpen_Click()
    On Error Resume Next
    For i = 0 To 1
        If filExplore(i).Selected(filExplore(i).ListIndex) Then fn = filExplore(i).List(filExplore(i).ListIndex): Exit For
    Next i
    fn = OpenDialog(trvFolder.Tag + "\", PlainName(fn, 1), LMsg(67), cdlOFNHideReadOnly + cdlOFNFileMustExist, "All Files (*.*)|*.*|Templates (*.TBK)|*.TBK|Message Books (*.BK)|*.BK|Nym Books (*.NBK)|*.NBK", 1, Me)
    If fn <> "" Then OpenSpec fn, False
End Sub

Private Sub tmrDOS_Timer()
    If DOSTag = "" Then tmrDOS.Enabled = False: Exit Sub
    If Dir(DOSTag + ".TAG") <> "" Then
        tmrDOS.Enabled = False
    Else
        tmrDOS.Tag = Str(Val(tmrDOS.Tag)) + 1
        If Val(tmrDOS.Tag) > (300000 / tmrDOS.Interval) Then
            tmrDOS.Enabled = False
            tmrDOS.Tag = "TIMEOUT"
        End If
    End If
End Sub


'___________________________________________________
'SOCKET
Private Sub Socket1_Connect()
    On Error Resume Next
    Socket1.Interval = 60000 ' Set finger timeout here
    frmWeb!barStat.SimpleText = frmWeb!barStat.SimpleText + "   (Connected)"
    Socket1.Write FingerUser, Len(FingerUser)
End Sub

Private Sub Socket1_Disconnect()
    Socket1.Disconnect
    FingerConnecting = False
End Sub

Private Sub Socket1_Read(DataLength As Integer, IsUrgent As Integer)
    Dim sBuffer As String
    
    On Error GoTo ReadError
    Socket1.Read sBuffer, DataLength
    FingerText = FingerText & sBuffer
Exit Sub
ReadError:
    Resume ReadError2
ReadError2:
    On Error Resume Next
    Socket1.Disconnect
    FingerConnecting = False
End Sub

Private Sub Socket1_Timer()
    Socket1.Interval = 0
    FingerConnecting = False
    Socket1_Disconnect
End Sub


'____________________________________________________
'FORM

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    Select Case Shift
    Case 0
        Select Case KeyCode
        Case vbKeyF1: ShowHelp 0, "#Explore", "2": KeyCode = 0
        Case vbKeyF7
            If tabMain.SelectedItem.Index = 2 Then ShowConfig (ConfigSendProf) Else ShowConfig (ConfigGlobal)
            KeyCode = 0
        Case vbKeyDelete
            If tabMain.SelectedItem.Index = 1 Then
                mnuSelect_Click (5)
            ElseIf tabMain.SelectedItem.Index = 2 And mnuMultiQue(1).Enabled Then
                mnuMultiQue_Click (1)
            End If
            KeyCode = 0
        End Select
    Case 1 'Shift
        Case vbKeyDelete: mnuSelect_Click (7): KeyCode = 0
    Case 2  'Ctrl
        Select Case KeyCode
        Case vbKeyF5: mnuSelect_Click (1): KeyCode = 0
        Case vbKeyF6: mnuSelect_Click (3): KeyCode = 0
        Case vbKeyE: mnuCheckMail_Click (0): KeyCode = 0
        Case vbKeyM: mnuSelect_Click (0): KeyCode = 0
        Case vbKeyN: mnuCheckMail_Click (1): KeyCode = 0
        Case vbKeyO: mnuSelect_Click (2): KeyCode = 0
        Case vbKeyR: mnuSelect_Click (4): KeyCode = 0
        Case vbKeyW: mnuCheckMail_Click (2): KeyCode = 0
        Case vbKeyDelete: mnuSelect_Click (6): KeyCode = 0
        End Select
    Case 3 'Ctrl-Shift
        Case vbKeyC: mnuSelect_Click (10): KeyCode = 0
        Case vbKeyX: mnuSelect_Click (11): KeyCode = 0
        Case vbKeyV: mnuSelect_Click (12): KeyCode = 0
        Case vbKeyDelete: mnuSelect_Click (8): KeyCode = 0
    End Select
    If Shift = vbCtrlMask Then filExplore(DragIndex).DragIcon = filExplore(1).MouseIcon Else filExplore(DragIndex).DragIcon = filExplore(0).MouseIcon
    DragShift = Shift
End Sub

Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
    If Shift = vbCtrlMask Then filExplore(DragIndex).DragIcon = filExplore(1).MouseIcon Else filExplore(DragIndex).DragIcon = filExplore(0).MouseIcon
    DragShift = Shift
End Sub

Private Sub tabMain_Click()
    x = tabMain.SelectedItem.Index
    Select Case x
    Case 1
        fraMain(0).ZOrder
        txtLog.Top = cmdOpen.Top + 360 + fraMain(0).Top
        txtLog.Height = fraMain(0).Height - txtLog.Top + fraMain(0).Top
        txtLog.Width = fraMain(0).Width
        txtLog.Left = 60
        txtLog.ZOrder
        If cboRecent.Visible Then cboRecent.SetFocus
    Case 2
        fraMain(1).ZOrder
        txtLog.Top = chkSend.Top + fraMain(1).Top
        txtLog.Height = fraMain(1).Height - txtLog.Top + fraMain(1).Top
        txtLog.Width = fraMain(1).Width - 1680
        txtLog.Left = 1740
        txtLog.ZOrder
        txtLog.SetFocus
    Case 3
        txtLog.Top = 360
        txtLog.Height = fraMain(0).Height
        txtLog.Width = fraMain(0).Width
        txtLog.Left = 60
        txtLog.ZOrder
        txtLog.SelLength = 0
        txtLog.SelStart = Len(txtLog.Text)
        txtLog.SetFocus
    End Select
    txtLog.SelStart = Len(txtLog.Text)
    If x < 3 Then txtLog.Tag = Str(x)
    PictureError.ZOrder
    mnuQue.Enabled = x = 2
End Sub

Private Sub txtLog_DblClick()
    x = Val(txtLog.Tag): If x = 0 Then x = 1
    If tabMain.SelectedItem.Index < 3 Then x = 3
    tabMain.Tabs(x).Selected = True
End Sub

Private Sub Form_Resize()
    Dim OldW As Single
    
    If Me.WindowState = 1 Then Exit Sub
    If Me.Height < 4452 Then Me.Height = 4452
        
    tabMain.Width = Me.ScaleWidth
    tabMain.Height = Me.ScaleHeight
    tabMain.TabFixedWidth = tabMain.Width / 3 - 48
    fw = Me.ScaleWidth - 120
    fh = Me.ScaleHeight - 612
        
    fraMain(0).Height = fh
    fraMain(0).Width = fw
    fraMain(1).Height = fh
    fraMain(1).Width = fw
    
    '=========Explore
    'General
    
    filExplore(0).Height = fh - 1368
    If mnuExSHow(1).Checked Then
        'Wide List
        filExplore(0).Width = 2472
    Else
        'Narrow List
        filExplore(0).Width = 1572
    End If
    cboPattern(0).Width = filExplore(0).Width
    cmdOpen.Width = filExplore(0).Width
    cboRecent.Top = filExplore(0).Top + filExplore(0).Height + 36
    
    If Not mnuExSHow(2).Checked Then
        'Left Side
        filExplore(0).Left = 0
        
        If mnuExSHow(0).Checked Then
            'Show Double
            filExplore(1).Left = filExplore(0).Width + 48
            cboRecent.Left = filExplore(1).Left
            trvFolder.Left = filExplore(0).Width * 2 + 96
        Else
            'Show Single
            trvFolder.Left = filExplore(0).Width + 48
            cboRecent.Left = trvFolder.Left
        End If
        x = fw - trvFolder.Left '- 48 '120
        If x < 40 Then x = 40
        trvFolder.Width = x
    Else
        'Right Side
        trvFolder.Left = 0
        cboRecent.Left = 0
        
        filExplore(0).Left = fw - filExplore(0).Width '- 48
        If mnuExSHow(0).Checked Then
            'Show Double
            filExplore(1).Left = filExplore(0).Left - filExplore(0).Width - 48
            x = filExplore(1).Left - 48: If x < 0 Then x = 1
            trvFolder.Width = x
            cboRecent.Width = trvFolder.Width + 48 + filExplore(1).Width
        Else
            'Show Single
            trvFolder.Width = filExplore(0).Left - 48
            cboRecent.Width = trvFolder.Width
        End If
    End If
    
    trvFolder.Height = filExplore(0).Top + filExplore(0).Height - cboPattern(0).Top - 10
    cboPattern(0).Left = filExplore(0).Left
    
    If mnuExSHow(0).Checked Then
        'Double
        filExplore(1).Width = filExplore(0).Width
        filExplore(1).Height = filExplore(0).Height
        cboPattern(1).Left = filExplore(1).Left
        cboPattern(1).Width = filExplore(1).Width
        cboRecent.Width = filExplore(1).Width + trvFolder.Width + 48
    Else
        cboRecent.Width = trvFolder.Width
    End If
    cboPattern(1).Visible = mnuExSHow(0).Checked
    filExplore(1).Visible = mnuExSHow(0).Checked
    
    'Recent and Open
    cmdOpen.Left = filExplore(0).Left
    cmdOpen.Top = cboRecent.Top

    barProgress.Top = Me.ScaleHeight - 204
    barProgress.Left = Me.ScaleWidth - 1524
    
    '============Queue
    
    lstQ.Width = fw
    lstQ.Height = fh - 1380
    chkSend.Top = lstQ.Top + lstQ.Height + 48
    cmdAbort.Top = chkSend.Top + 480
    For i = 9 To 11
        lstQ.ColumnHeaders.Item(i).Width = 0
    Next i
    
    PictureError.Top = Me.ScaleHeight - 612
    PictureError.Left = Me.ScaleWidth - 642 '612
    tabMain_Click
End Sub

Private Sub Form_Activate()
    On Error Resume Next
    If Me.Tag = "" Then
        Me.Tag = "Loaded"
        CurrentSendX = -1
        DoEvents
        If BrandNew Then
            'Data
            KeepDate(17) = 0
            PData(73) = ""
            PData(14) = "0"
            PData(40) = ""
            Cnf(0, 10) = ""
            Cnf(0, 11) = ""
            'Folders
            Cnf(0, 0) = Left(ProgDir, 1) + ":\TMP"
            CreateDir Cnf(0, 0)
            PData(10) = Cnf(0, 0)
            Cnf(0, 1) = ProgDir + "\Queue"
            CreateDir Cnf(0, 1)
            CreateDir (ProgDir + "\Books")
            Cnf(4, 1) = ProgDir + "\Books"
            CreateDir (ProgDir + "\Stats")
            Cnf(3, 19) = ProgDir + "\Stats\Cache"
            CreateDir Cnf(3, 19)
            Cnf(4, 0) = ProgDir + "\Mail"
            CreateDir (Cnf(4, 0))
            CreateDir (Cnf(4, 0) + "\Inbox")
            cboRecent.Clear
            cboRecent.AddItem ProgDir + "\Books"
            cboRecent_Click
            If SDir(ProgDir + "\Books\Nyms\Default.TBK") = "" Then FileCopy ProgDir + "\Books\Default.TBK", ProgDir + "\Books\Nyms\Default.TBK"
            
            On Error Resume Next
            
''            'Program Files
''            If InStr(ProgDir, "Program Files") = 4 Then MsgBox LMsg(555), vbInformation
            'PGP
            If MsgTime(LMsg(419), 0, "Jack B. Nymble v2", 999, 1, 0, "PGP 5.5.3x/6.x", "PGP 2.6.x", "") = 2 Then Cnf(0, 3) = "0" Else Cnf(0, 3) = "1"
            PData(12) = Cnf(0, 3)
            'Mix
            m = ""
            mp = Environ("MIXPATH")
            If mp = "" Then mp = "C:\MIX"
            m = NoSlash(SelectFolder(mp, LMsg(424), "", LMsg(420)))
            If SDir(m + "\mixmaste.exe") = "" And m <> "" Then
                MsgBox LMsg(421), vbCritical, LMsg(66)
                m = ""
            End If
            Cnf(1, 15) = m
            'Verify Dialup Connection?
            mnuDialOpt(0).Checked = (MsgBox(LMsg(446), vbQuestion + vbYesNo) = vbYes)
            PData(53) = mnuDialOpt(0).Checked
            'Stats
            a = InputBox(LMsg(423), "Jack B. Nymble v2", "5")
            x = SVal(a)
            If x > 0 Then
                If x < 1 Then x = 1
                Cnf(3, 18) = Str(x)
                Cnf(3, 0) = "1"
            Else
                Cnf(3, 0) = "0"
            End If
            SaveConfig
            If MsgBox(LMsg(422), vbQuestion + vbOKCancel) = vbOK Then
                Me.MousePointer = 11
                fraMain(0).Enabled = False
                tabMain.Enabled = False
                mnuFile.Enabled = False
                mnuView.Enabled = False
                mnuQue.Enabled = False
                mnuTools.Enabled = False
                mnuOptions.Enabled = False
                mnuWind.Enabled = False
                mnuHelp.Enabled = False
                'refresh Stats
                CheckingConfig = True
                BrowserJob = ":::RefreshStats:::"
                Load frmWeb
                Unload frmWeb
                'Update Keys
                If m = "" Then BrowserJob = ":::UpdateCPunkKeys:::" Else BrowserJob = ":::UpdateBothKeys:::"
                Load frmWeb
                Unload frmWeb
                CheckingConfig = False
                UpdatingKeys = True
                CheckConfig ("")
                UpdatingKeys = False
                fraMain(0).Enabled = True
                tabMain.Enabled = True
                mnuFile.Enabled = True
                mnuView.Enabled = True
                mnuQue.Enabled = True
                mnuTools.Enabled = True
                mnuOptions.Enabled = True
                mnuWind.Enabled = True
                mnuHelp.Enabled = True
                Me.MousePointer = 0
            Else
                MsgBox LMsg(425), vbInformation
            End If
            Session(2) = 1
            StartSession (0)
            ShowHelp 0
        Else
            CheckConfig "", True
            Session(2) = 1
            StartSession (0)
        End If
    End If
End Sub

Private Sub Form_Load()
    mihiInitialize '' ## added
    Dim CPass As String, i As Long
    
    On Error GoTo LoadError
    If App.PrevInstance Then Unload Me: End
    
    'Initialize
    Randomize Timer
    Me.KeyPreview = True
    trvFolder.ImageList = ImageList1
    LeftWin = 57563729.56432
    For i = 128 To 255: BinChars = BinChars + Chr(i): Next i
    BinChars = BinChars + Chr(0) + Chr(26)
    If Not IDE Then ProgDir = NoSlash(App.Path) Else ProgDir = "C:\JBN2"
    LeftWin = LeftWin + 742.4586574
    RightWin = Int(Rnd(1) * 99999999) + 1 + Rnd(1)
            
    'GMT
    gmtoffset = GetGMTOffset
    AlterDate = -1

    'Get Program Data
    ReDim LMsg(26)
    LMsg(26) = "Unable to create or access directory"
    LMsg(4) = "Error"
    DataDir = ""
    If Command <> "" Then
        a = NoSlash(Command)
        If CreateDir(a) Then
            If SDir(a + "\JBNData.*") <> "" Or SDir(a + "\JBNConf.*") <> "" Then
                DataDir = a
            End If
            If DataDir = "" Then MsgBox "No data files found in specified folder: " + vbCr + a, vbCritical, "File Not Found"
        End If
    End If
    If DataDir = "" Then DataDir = ProgDir + "\Config"
    If CreateDir(DataDir) Then
        If SDir(DataDir + "\JBNData.DAT") = "" Then
            On Error Resume Next
            If SDir(ProgDir + "\JBNData.NEW") <> "" Then FileCopy ProgDir + "\JBNData.NEW", DataDir + "\JBNData.DAT"
            On Error GoTo LoadError
        End If
    End If
    If SDir(DataDir + "\JBNData.DAT") = "" Then
        MsgBox "Program data file " + DataDir + "\JBNData.DAT and backup files are missing.  Reinstallation is recommended." + _
          vbCr + vbCr + "If this file is located elsewhere, you must specify its folder in the shortcut used to run Jack B. Nymble." + _
          vbCr + vbCr + "For example:" + vbCr + vbCr + "     " + ProgDir + "\Nymble.exe D:\JBN\ConfigFolder", vbCritical, "File Not Found"
    Else
        ReadData
    End If

    'Read Lang File
ReadLang:
    On Error GoTo LangError
    If Dir(ProgDir + "\JBNL-" + PData(0) + ".DAT") = "" Then PData(0) = "en"
    If Dir(ProgDir + "\JBNL-" + PData(0) + ".DAT") = "" Then Msg = "Language File Missing": GoTo LangError
    n = FreeFile
    If Not IDE Then
        Open ProgDir + "\JBNL-" + PData(0) + ".DAT" For Input As n
    Else
        '' ### next line modified
        Open "C:\JBN2\JBNL-" + PData(0) + ".DAT" For Input As n
    End If
    If Not EOF(n) Then Line Input #n, a
    If a <> "JBN_LANG" Then Msg = "Invalid language file.: GoTo LangError"
    Do While Not EOF(n)
        Line Input #n, a
        Select Case a
        Case "---VER"
            Line Input #n, a
            If Trim(a) <> Trim(LangVersion) Then Msg = "Wrong version language file.  This version of Jack B. Nymble requires language file version " + LangVersion: GoTo LangError
        Case "---TOP"
            Line Input #n, a
            ReDim LMsg(Val(a))
        Case "---0"
            x = 0
            Do
                Line Input #n, LMsg(x)
                a = ""
                While Not EOF(n) And Trim(a) = ""
                    Line Input #n, a
                Wend
                x = Val(Mid(a, 4))
            Loop Until EOF(n) Or Trim(a) = "---END"
            If Trim(a) <> "---END" Then Msg = "Language File Incomplete": GoTo LangError
            If PData(0) = "en" Then Exit Do
        Case "---LABELS"
            If PData(0) <> "en" Then
                t = 0
                Do While Not EOF(n)
                    Line Input #n, a
                    a = Trim(a)
                    If a = "---END" Then Exit Do
                    t = t + 1
                    Select Case t
                        Case 1: 'mnuFile.Caption = a
                    End Select
                Loop
            End If
        End Select
    Loop
    Close n: n = 0
    On Error GoTo LoadError
        
    'Setup Queue
    For i = 44 To 51
        If Val(PData(i)) <= 0 Then PData(i) = "400"
    Next i
    lstQ.ColumnHeaders.Add 1, "Profile", "Profile", Val(PData(46))
    lstQ.ColumnHeaders.Add 2, "Origin", "Origin", Val(PData(45))
    lstQ.ColumnHeaders.Add 3, "Status", "Status", Val(PData(44))
    lstQ.ColumnHeaders.Add 4, "Created", "Created", Val(PData(47))
    lstQ.ColumnHeaders.Add 5, "Schedule", "Schedule", Val(PData(48))
    lstQ.ColumnHeaders.Add 6, "Size", "Size", Val(PData(49))
    lstQ.ColumnHeaders.Add 7, "To", "To", Val(PData(50))
    lstQ.ColumnHeaders.Add 8, "Filename", "Filename", Val(PData(51))
    lstQ.ColumnHeaders.Add 9, "Priority-C", "Priority-C", 0
    lstQ.ColumnHeaders.Add 10, "Priority-S", "Priority-S", 0
    lstQ.ColumnHeaders.Add 11, "Priority-Z", "Priority-Z", 0
    On Error Resume Next
    For i = 1 To 8
        'Required to correct bug in ListView columnheaders.width property
        'MSKB Article ID: Q179988
        SendMessage lstQ.hwnd, LVM_SETCOLUMNWIDTH, i - 1, Val(PData(43 + i))
    Next i
    On Error GoTo LoadError
    lstQ.SortKey = Val(PData(52))
    x = lstQ.SortKey: If x > 7 Then x = x - 5
    lstQ.ColumnHeaders.Item(x + 1).Text = lstQ.ColumnHeaders.Item(x + 1).Text + "*"
    chkRLatent.Value = Val(PData(6))
    chkROrder.Value = Val(PData(7))
    txtRLatent(0).Text = PData(120)
    txtRLatent(1).Text = PData(8)
    chkSend.Value = Val(PData(9))
    chkRLatent_Click
    If chkSend.Value = 1 Then tabMain.Tabs(2).Tag = LMsg(310) + "*" Else tabMain.Tabs(2).Tag = LMsg(310)
    mnuPrevDumm.Checked = PData(121) = True2
    
    'Size Window
    fraMain(0).Left = 60
    fraMain(1).Left = 60
    For i = 0 To 2
        mnuExSHow(i).Checked = PData(105 + i) = True2
    Next i
    Me.Left = Val(PData(1))
    Me.Top = Val(PData(2))
    If Val(PData(3)) <> 0 And Val(PData(4)) <> 0 Then
        Me.Width = Val(PData(3))
        Me.Height = Val(PData(4))
    End If
    If Val(PData(5)) = 2 Then Me.WindowState = 2
    
    'Set PData Options
    If PData(53) = True2 Then mnuDialOpt(0).Checked = True
    If PData(54) = True2 Then mnuDialOpt(1).Checked = True
    If PData(55) = True2 Then mnuDialOpt(2).Checked = True
    For i = 0 To 5
        If PData(30 + i) <> False2 Then mnuPopUp(i).Checked = True
    Next i
    mnuSuspendAuto.Checked = PData(170) = True2
    ErrorSummary = LMsg(539) + "   " + DateLine(1) + vbCrLf
    
    'Read Config
    If PData(68) = True2 And SDir(DataDir + "\JBNConf.asc") = "" Then
        MsgBox LMsg(324) + vbCr + DataDir + "\JBNConf.asc", vbExclamation, LMsg(66)
        PData(68) = False2
    End If
    fn = ""
    If PData(68) <> True2 And SDir(DataDir + "\JBNConf.DAT") = "" And SDir(DataDir + "\JBNConf.asc") <> "" Then PData(68) = True2
    If PData(68) = True2 Then
        'Secure Mode
        'Decrypt file to fn
        If PData(10) = "" Then PData(10) = "C:\TMP"
        If Not CreateDir(PData(10)) Then PData(10) = "C:\TMP"
        If Not CreateDir(PData(10)) Then PData(10) = ProgDir
        y = 0
TryDec: CPass = GetConvPass(LMsg(326))
        Me.MousePointer = 11: Me.Refresh
        If CPass <> "" Or Val(PData(12)) = 0 Then fn = Decrypt(DataDir + "\JBNConf.asc", CPass) Else fn = ""
        Me.MousePointer = 0: Me.Refresh
        If fn = "" Then
            y = y + 1
            If y > 4 Then x = vbOKOnly Else x = vbAbortRetryIgnore + vbDefaultButton2
            x = MsgBox(LMsg(327), x, LMsg(328))
            If x = vbAbort Or x = vbOK Then Unload Me: Exit Sub
            If x = vbRetry Then GoTo TryDec
            PData(68) = False2
            fn = DataDir + "\JBNConf.DAT"
        Else
            SecurePass = Mid(XCrypt(CPass, RightWin), 4)
            If SDir(DataDir + "\JBNConf.DAT") <> "" Then WipeFile (DataDir + "\JBNConf.DAT")
        End If
        CPass = String(Len(CPass), "@")
    Else
        fn = DataDir + "\JBNConf.DAT"
    End If
    If SDir(fn) = "" Or fn = "" Then fn = ProgDir + "\JBNConf.NEW"
    If SDir(fn) = "" Or fn = "" Then
        MsgBox LMsg(325) + vbCr + fn, vbCritical, LMsg(66)
    Else
        'Read Plain Config
ReadConf:
        Msg = ReadConfig(fn)
        If Msg <> "" Then MsgBox Msg, vbCritical, LMsg(4)
    End If
    If PData(68) = True2 Then
        'Secure Mode wipe
        WipeFile (fn)
    End If

    'Setup Explore
    MainLoadList ("")
    On Error Resume Next
    If PData(72) <> "" And Not BrandNew Then ChangeFolder PData(72) Else ChangeFolder ProgDir + "\Books"
    For i = 0 To 1
        If PData(70 + i) <> "" Then cboPattern(i).Text = PData(70 + i) Else cboPattern(i).ListIndex = i
        cboPattern_Click (i)
    Next i
    On Error GoTo LoadError
    
    'Send To
    st = NoSlash(QueryValueROOT("Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "SendTo", HKEY_CURRENT_USER))
    If st <> "" And IsDir(st) Then
        a = SDir(st + "\*.lnk")
        For i = 0 To 9
            If a <> "" Then
                mnuSendTo(i).Caption = PlainName(a, 2)
                mnuSendTo(i).Tag = st + "\" + a
                mnuSendTo(i).Visible = True
                mnuSelectSendTo.Visible = True
            Else
                Exit For
            End If
            a = Dir
        Next i
    End If
    
    CurrentSendX = -1
    tmrSession.Enabled = False
Exit Sub
LangError:
    If Msg = "" Then Msg = "An error occured reading the language file:"
    MsgBox Msg + vbCr + ProgDir + "\JBNL-" + PData(0) + ".DAT" + vbCr + vbCr + Error, vbCritical, "Language File Error"
    CloseFile (n)
    Unload Me
Exit Sub
LoadError:
    MsgBox "An error occured during load" + vbCr + Error, vbCritical
    Resume Next
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    For i = 0 To 9
        If BookBusy(0, i) Or BookBusy(1, i) Then Exit For
    Next i
    If i < 10 Or NetBusy Or StatsBusy Then
        x = MsgTime(LMsg(443), 0, LMsg(441), vbYesNo, 2, 20)
        If x = 2 Then
            Cancel = 1
        End If
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Dim i As Long
    If Me.Tag = "Loaded" Then
        On Error Resume Next
        'Cause Query
        GlobalCancel = 0
        For i = 0 To 9
            Unload MsgBook(i)
            Unload NymBook(i)
        Next i
        If GlobalCancel = 1 Then Cancel = 1: Exit Sub
        If Me.WindowState = 0 Then
            PData(1) = Str(Me.Left)
            PData(2) = Str(Me.Top)
            PData(3) = Str(Me.Width)
            PData(4) = Str(Me.Height)
        End If
        PData(5) = Str(Me.WindowState)
        For i = 1 To 8
            'PData(43 + i) = Str(lstQ.ColumnHeaders.Item(i).Width)
            'Required to correct bug in ListView columnheaders.width property
            'MSKB Article ID: Q179988
            PData(43 + i) = Str(SendMessage(lstQ.hwnd, LVM_GETCOLUMNWIDTH, i - 1, 0))
        Next i
        PData(52) = lstQ.SortKey
        PData(70) = cboPattern(0).Text
        PData(71) = cboPattern(1).Text
        PData(69) = ""
        For i = 0 To cboPattern(0).ListCount - 1
            PData(69) = PData(69) + cboPattern(0).List(i) + vbCrLf
        Next i
        PData(72) = trvFolder.Tag
        x = cboRecent.ListCount: If x > 30 Then x = 30
        PData(73) = ""
        For i = 0 To x - 1
            PData(73) = PData(73) + cboRecent.List(i) + vbCrLf
        Next i
        PData(6) = Str(chkRLatent.Value)
        PData(7) = Str(chkROrder.Value)
        PData(120) = txtRLatent(0).Text
        PData(8) = txtRLatent(1).Text
        PData(9) = Str(chkSend.Value)
        WriteData
        If Not IDE And Cnf(0, 1) <> "" Then DelFile Cnf(0, 1) + "\*.T*"
        If Not IDE And PData(10) <> "" Then DelFile PData(10) + "\*.tmj"
        If Not IDE Then DelFile ProgDir + "\*.tag"
        If SDir(Cnf(3, 19) + "\*.*") <> "" And Cnf(3, 19) <> "" Then DelFile Cnf(3, 19) + "\*.*"
    End If
    End
End Sub

