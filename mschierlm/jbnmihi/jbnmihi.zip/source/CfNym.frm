VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmCfNym 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Nym Accounts - Configuration"
   ClientHeight    =   6165
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   6690
   Icon            =   "CfNym.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6165
   ScaleWidth      =   6690
   Begin VB.Timer tmrReload 
      Enabled         =   0   'False
      Interval        =   200
      Left            =   2040
      Top             =   5760
   End
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   372
      Left            =   4560
      TabIndex        =   25
      Top             =   5760
      Width           =   1992
   End
   Begin VB.Timer tmrProgBusy 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   3060
      Top             =   5340
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   372
      Index           =   1
      Left            =   2340
      TabIndex        =   15
      Top             =   5760
      Width           =   1992
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Index           =   0
      Left            =   120
      TabIndex        =   14
      Top             =   5760
      Width           =   1992
   End
   Begin VB.Frame fraNym 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame2"
      Height          =   5292
      Index           =   0
      Left            =   60
      TabIndex        =   20
      Top             =   360
      Width           =   6552
      Begin VB.TextBox txtAccount 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2652
         Index           =   1
         Left            =   120
         MaxLength       =   31000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   7
         Top             =   2580
         Width           =   6312
      End
      Begin VB.TextBox txtAccount 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2652
         Index           =   2
         Left            =   120
         MaxLength       =   31000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   8
         Top             =   2580
         Width           =   6312
      End
      Begin ComctlLib.TabStrip tabPass 
         Height          =   3072
         Left            =   0
         TabIndex        =   26
         Top             =   2220
         Width           =   6552
         _ExtentX        =   11562
         _ExtentY        =   5424
         TabWidthStyle   =   2
         TabFixedWidth   =   4851
         TabFixedHeight  =   441
         _Version        =   327682
         BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
            NumTabs         =   2
            BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "Conventional Passphrases"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
            BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
               Caption         =   "Prior Passphrases"
               Key             =   ""
               Object.Tag             =   ""
               ImageVarType    =   2
            EndProperty
         EndProperty
      End
      Begin VB.ComboBox cboKey 
         Height          =   288
         Index           =   0
         Left            =   1740
         Sorted          =   -1  'True
         TabIndex        =   6
         Top             =   1860
         Width           =   4752
      End
      Begin VB.ListBox lstNym 
         Height          =   1230
         ItemData        =   "CfNym.frx":0442
         Left            =   60
         List            =   "CfNym.frx":0444
         TabIndex        =   4
         TabStop         =   0   'False
         Top             =   72
         Width           =   4272
      End
      Begin VB.TextBox txtAccount 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   1740
         MaxLength       =   1024
         TabIndex        =   5
         Top             =   1512
         Width           =   4752
      End
      Begin VB.CommandButton cmdNym 
         Caption         =   "&New"
         Height          =   372
         Index           =   0
         Left            =   4440
         TabIndex        =   0
         TabStop         =   0   'False
         Top             =   72
         Width           =   1272
      End
      Begin VB.CommandButton cmdNym 
         Caption         =   "D&elete"
         Height          =   372
         Index           =   1
         Left            =   4440
         TabIndex        =   1
         TabStop         =   0   'False
         Top             =   600
         Width           =   1272
      End
      Begin VB.CommandButton cmdUpDown 
         Caption         =   "&Up"
         Height          =   372
         Index           =   0
         Left            =   5820
         TabIndex        =   2
         TabStop         =   0   'False
         Top             =   72
         Width           =   672
      End
      Begin VB.CommandButton cmdUpDown 
         Caption         =   "&Down"
         Height          =   372
         Index           =   1
         Left            =   5820
         TabIndex        =   3
         TabStop         =   0   'False
         Top             =   588
         Width           =   672
      End
      Begin VB.Label Label7 
         BackStyle       =   0  'Transparent
         Caption         =   "Account PGP Key:"
         Height          =   192
         Left            =   60
         TabIndex        =   22
         Top             =   1920
         Width           =   1812
      End
      Begin VB.Label Label5 
         BackStyle       =   0  'Transparent
         Caption         =   "Account Address:"
         Height          =   252
         Left            =   60
         TabIndex        =   21
         Top             =   1572
         Width           =   1752
      End
   End
   Begin VB.Frame fraNym 
      BorderStyle     =   0  'Kein
      Caption         =   "Frame1"
      Height          =   5292
      Index           =   1
      Left            =   60
      TabIndex        =   16
      Top             =   360
      Width           =   6552
      Begin VB.CommandButton cmdAdd 
         Caption         =   "Remove"
         Height          =   372
         Index           =   1
         Left            =   3540
         TabIndex        =   27
         Top             =   4800
         Width           =   1932
      End
      Begin VB.TextBox txtPass 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         IMEMode         =   3  'DISABLE
         Index           =   1
         Left            =   60
         MaxLength       =   255
         PasswordChar    =   "*"
         TabIndex        =   12
         Top             =   4380
         Width           =   6432
      End
      Begin VB.TextBox txtPass 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         IMEMode         =   3  'DISABLE
         Index           =   0
         Left            =   60
         MaxLength       =   255
         PasswordChar    =   "*"
         TabIndex        =   11
         Top             =   3780
         Width           =   6432
      End
      Begin VB.CommandButton cmdAdd 
         Caption         =   "Add / Update"
         Height          =   372
         Index           =   0
         Left            =   960
         TabIndex        =   13
         Top             =   4800
         Width           =   1932
      End
      Begin VB.ComboBox cboKey 
         Height          =   288
         Index           =   1
         Left            =   60
         TabIndex        =   10
         Top             =   3180
         Width           =   6432
      End
      Begin VB.ListBox lstKeys 
         Height          =   2595
         ItemData        =   "CfNym.frx":0446
         Left            =   60
         List            =   "CfNym.frx":0448
         TabIndex        =   9
         TabStop         =   0   'False
         Top             =   60
         Width           =   6432
      End
      Begin VB.Label Label4 
         Alignment       =   2  'Zentriert
         Caption         =   "(Double-click on key to test passphrase)"
         Height          =   192
         Left            =   780
         TabIndex        =   24
         Top             =   2820
         Width           =   4932
      End
      Begin VB.Label Label3 
         Caption         =   "Private Key:"
         Height          =   192
         Left            =   60
         TabIndex        =   19
         Top             =   2940
         Width           =   2112
      End
      Begin VB.Label Label2 
         Caption         =   "Re-enter Passphrase [Optional]:"
         Height          =   192
         Left            =   60
         TabIndex        =   18
         Top             =   4140
         Width           =   4152
      End
      Begin VB.Label Label1 
         Caption         =   "Passphrase:"
         Height          =   192
         Left            =   60
         TabIndex        =   17
         Top             =   3540
         Width           =   2112
      End
   End
   Begin ComctlLib.TabStrip tabNym 
      Height          =   5652
      Left            =   0
      TabIndex        =   23
      Top             =   60
      Width           =   6672
      _ExtentX        =   11774
      _ExtentY        =   9975
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   2
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Nym Accounts"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Key Passphrases"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmCfNym"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim TempNyms(MaxNyms, 3) As String
Dim TempKeyPass(MaxNyms, 1) As String
Dim NoClick As Boolean

Private Sub cmdOK_Click(Index As Integer)
    If tabNym.SelectedItem.Index = 1 Then UpdateData
    If Index = 0 Then
        Me.MousePointer = 11
        cmdOK(0).Enabled = False
        For i = 0 To 1
            fraNym(i).Enabled = False
        Next i
        PendingCfg(2) = True
        If ProgBusy("Nyms") Then
            tmrProgBusy.Tag = "Nyms"
            tmrProgBusy.Enabled = True
            Exit Sub
        End If
        Erase Nyms, KeyPass
        While NymDataBusy: DoEvents: Wend
        NymDataBusy = True
        RBTagLocation = ""
        x = 0
        For i = 0 To lstNym.ListCount - 1
            If Trim(TempNyms(i, 0)) <> "" Then
                For j = 0 To 3
                    Nyms(x, j) = Trim(TempNyms(i, j))
                Next j
                x = x + 1
            End If
        Next i
        NymDataBusy = False
        For i = 0 To lstKeys.ListCount - 1
            For j = 0 To 1
                KeyPass(i, j) = TempKeyPass(i, j)
            Next j
        Next i
        Erase TempNyms, TempKeyPass
        Me.MousePointer = 11
        If Not CheckConfig("Nyms") Then
            PendingCfg(2) = False
            For i = 0 To 1
                fraNym(i).Enabled = True
            Next i
            cmdOK(0).Enabled = True
            txtCaps.Text = ""
            lstNym.Clear
            lstKeys.Clear
            Form_Load
            Me.MousePointer = 0
            Exit Sub
        End If
        Me.MousePointer = 0
    End If
    Unload Me
End Sub

Private Sub tabPass_Click()
    txtAccount(tabPass.SelectedItem.Index).ZOrder
    txtAccount(tabPass.SelectedItem.Index).SetFocus
End Sub

Private Sub tmrProgBusy_Timer()
    If Not ProgBusy(tmrProgBusy.Tag) Then tmrProgBusy.Enabled = False: cmdOK_Click (0)
End Sub

Private Sub cmdAdd_Click(Index As Integer)
    lstNym.SetFocus
    a = Trim(cboKey(1).Text)
    If a = "" Then Exit Sub
    If Index = 0 Then
        If txtPass(1).Text <> "" And txtPass(0).Text <> "" And txtPass(0).Text <> txtPass(1).Text Then
            For i = 0 To 1
                txtPass(i).Text = String(Len(txtPass(i)), "@")
                txtPass(i).Text = ""
            Next i
            MsgBox LMsg(139), vbCritical, LMsg(140)
            Exit Sub
        End If
        x = -1
        For i = 0 To lstKeys.ListCount - 1
            If lstKeys.List(i) = a Then x = i: Exit For
        Next i
        If x = -1 Then
            'Add key
            If Index = 0 And lstKeys.ListCount = MaxNyms Then Exit Sub
            lstKeys.AddItem a
            x = lstKeys.NewIndex
            TempKeyPass(x, 0) = a
        End If
        'Update Pass
        TempKeyPass(x, 1) = String(Len(TempKeyPass(x, 1)), "@")
        a = txtPass(0).Text
        If a = "" Then a = Chr(4) + "NONE"
        TempKeyPass(x, 1) = Mid(XCrypt(a, LeftWin), 4)
    Else
        'Remove key
        x = -1
        For i = 0 To lstKeys.ListCount - 1
            If lstKeys.List(i) = a Then x = i: Exit For
        Next i
        If x <> -1 Then
            lstKeys.RemoveItem x
            For i = x To MaxNyms - 1
                For j = 0 To 1
                    TempKeyPass(i, j) = String(Len(TempKeyPass(i, j)), "@")
                    TempKeyPass(i, j) = TempKeyPass(i + 1, j)
                Next j
            Next i
            TempKeyPass(MaxNyms, 0) = ""
            TempKeyPass(MaxNyms, 1) = String(Len(TempKeyPass(MaxNyms, 1)), "@")
            TempKeyPass(MaxNyms, 1) = ""
            cboKey(1).Text = ""
            For i = 0 To 1
                txtPass(i).Text = String(Len(txtPass(i)), "@")
                txtPass(i).Text = ""
            Next i
        End If
    End If
    cboKey(1).Text = ""
    For i = 0 To 1
        txtPass(i).Text = String(Len(txtPass(i)), "@")
        txtPass(i).Text = ""
    Next i
    lstKeys.ListIndex = -1
End Sub

Private Sub lstKeys_DblClick()
    x = lstKeys.ListIndex
    If x = -1 Then Exit Sub
    Me.MousePointer = 11
    a = TestPGP(Extract(lstKeys.List(x), "   "), XCrypt("@@@" + TempKeyPass(x, 1), LeftWin))
    If a = "" Then
        a = LMsg(144)
        x = vbInformation
    Else
        x = vbCritical
    End If
    Me.MousePointer = 0
    MsgBox a, x, LMsg(145)
End Sub

Private Sub lstKeys_Click()
    x = lstKeys.ListIndex
    If x = -1 Then Exit Sub
    NoClick = True
    cboKey(1).Text = TempKeyPass(x, 0)
    NoClick = False
    For i = 0 To 1
        txtPass(i).Text = String(Len(txtPass(i)), "@")
    Next i
    txtPass(0).Text = XCrypt("@@@" + TempKeyPass(x, 1), LeftWin)
    If txtPass(0).Text = Chr(4) + "NONE" Then txtPass(0).Text = ""
    txtPass(1).Text = ""
    If txtPass(0).Visible Then txtPass(0).SetFocus
End Sub

Private Sub cboKey_Click(Index As Integer)
    If Index = 1 And Not NoClick Then
        For i = 0 To 1
            txtPass(i).Text = String(Len(txtPass(i)), "@")
            txtPass(i).Text = ""
        Next i
        lstKeys.ListIndex = -1
    End If
End Sub

Private Sub cboKey_Change(Index As Integer)
    If Index = 1 Then cboKey_Click (1)
End Sub



Private Sub cmdNym_Click(Index As Integer)
    UpdateData
    txtAccount(0).SetFocus
    If Index = 0 Then
        If lstNym.ListCount = MaxNyms Then Exit Sub
        lstNym.AddItem "yournym@nym.alias.net"
        x = lstNym.NewIndex
        TempNyms(x, 0) = "yournym@nym.alias.net"
        For i = 1 To 3
            TempNyms(x, 1) = ""
        Next i
        lstNym.ListIndex = x
    Else
        x = lstNym.ListIndex
        If x = -1 Then Exit Sub
        If MsgBox(LMsg(138) + " " + lstNym.List(x) + " ?", vbExclamation + vbOKCancel, LMsg(95)) = vbCancel Then Exit Sub
        lstNym.RemoveItem x
        For i = x To MaxNyms - 1
            For j = 0 To 3
                TempNyms(i, j) = TempNyms(i + 1, j)
            Next j
        Next i
        TempNyms(MaxNyms, 0) = ""
        For i = 0 To 2
            txtAccount(i).Text = ""
        Next i
        cboKey(0).Text = ""
        lstNym.Tag = "-1"
    End If
    txtAccount(0).SetFocus
End Sub

Private Sub cmdUpDown_Click(Index As Integer)
    UpdateData
    txtAccount(0).SetFocus
    lstNym.Tag = "-1"
    x = lstNym.ListIndex
    If x = -1 Or lstNym.ListCount < 2 Then Exit Sub
    If Index = 0 Then
        If x = 0 Then Exit Sub
        y = x - 1
    Else
        If x = lstNym.ListCount - 1 Then Exit Sub
        y = x + 1
    End If
    For i = 0 To 3
        temp = TempNyms(x, i)
        TempNyms(x, i) = TempNyms(y, i)
        If i = 0 Then
            lstNym.List(x) = TempNyms(y, i)
            lstNym.List(y) = temp
        End If
        TempNyms(y, i) = temp
    Next i
    lstNym.ListIndex = y
End Sub

Private Sub lstNym_Click()
    UpdateData
    x = lstNym.ListIndex
    lstNym.Tag = Str(x)
    If x = -1 Then Exit Sub
    For i = 0 To 2
        txtAccount(i).Text = TempNyms(x, i)
    Next i
    cboKey(0).Text = TempNyms(x, i)
    If txtAccount(0).Visible Then txtAccount(0).SetFocus
End Sub

Private Sub UpdateData()
    x = Val(lstNym.Tag)
    If x = -1 Or lstNym.Tag = "" Then Exit Sub
    For i = 0 To 2
        TempNyms(x, i) = txtAccount(i).Text
    Next i
    TempNyms(x, 3) = cboKey(0).Text
    lstNym.List(x) = TempNyms(x, 0)
End Sub

Private Sub tmrReload_Timer()
    tmrReload.Enabled = False
    a = tmrReload.Tag: tmrReload.Tag = ""
    If tmrProgBusy.Enabled Then Unload Me: Exit Sub
    If InStr(a, "P") <> 0 Then
        cboKey(0).Text = "": cboKey(1).Text = ""
        Form_Load
    End If
End Sub

Private Sub txtAccount_Change(Index As Integer)
    If Index = 0 And lstNym.ListIndex <> -1 Then
        lstNym.List(lstNym.ListIndex) = txtAccount(0).Text
    End If
End Sub

Private Sub cboKey_KeyDown(Index As Integer, KeyCode As Integer, Shift As Integer)
    If KeyCode = 38 Or KeyCode = 40 Then KeyCode = 0
    If KeyCode = 8 And Val(PData(12)) <> 0 Then cboKey(Index).Text = ""
End Sub

Private Sub cboKey_KeyPress(Index As Integer, KeyAscii As Integer)
    If Val(PData(12)) <> 0 Then KeyAscii = 0
End Sub

Private Sub tabNym_Click()
    UpdateData
    fraNym(tabNym.SelectedItem.Index - 1).ZOrder
End Sub

Private Sub cmdHelp_Click()
    Dim Topic As String
    
    Select Case tabNym.SelectedItem.Index
    Case 1: Topic = "#CfgNymsAccounts"
    Case 2: Topic = "#CfgNymsPass"
    End Select
    ShowHelp 0, Topic, "2"
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    If KeyCode = vbKeyF1 And Shift = 0 Then cmdHelp_Click: KeyCode = 0
End Sub

Private Sub Form_Load()
    Me.Left = Val(PData(96))
    Me.Top = Val(PData(97))
    
    LoadKeyList cboKey(0), True, True
    LoadKeyList cboKey(1), True, False
    lstNym.Clear
    While NymDataBusy: DoEvents: Wend
    NymDataBusy = True
    For i = 0 To MaxNyms
        If Nyms(i, 0) = "" Then Exit For
        lstNym.AddItem Nyms(i, 0)
        For j = 0 To 3
            TempNyms(i, j) = Nyms(i, j)
            If (j = 1 Or j = 2) And Len(TempNyms(i, j)) > 31000 Then TempNyms(i, j) = Left(TempNyms(i, j), 31000)
        Next j
    Next i
    NymDataBusy = False
    lstKeys.Clear
    For i = 0 To MaxNyms
        If KeyPass(i, 0) = "" Then Exit For
        lstKeys.AddItem KeyPass(i, 0)
        For j = 0 To 1
            TempKeyPass(i, j) = KeyPass(i, j)
        Next j
    Next i
    lstNym.Tag = "-1"
    If lstNym.ListCount <> 0 Then lstNym.ListIndex = 0
    NARLoaded = True
    tabNym_Click
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PendingCfg(2) = False
    NARLoaded = False
    PData(96) = Str(Me.Left)
    PData(97) = Str(Me.Top)
End Sub

