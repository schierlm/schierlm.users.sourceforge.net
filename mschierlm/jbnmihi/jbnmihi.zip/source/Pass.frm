VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmPass 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "PGP Passphrase Entry"
   ClientHeight    =   5295
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   7380
   Icon            =   "Pass.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5295
   ScaleWidth      =   7380
   Begin VB.CheckBox chkSound 
      Caption         =   "Sound"
      Height          =   192
      Left            =   4560
      TabIndex        =   18
      TabStop         =   0   'False
      Top             =   1560
      Width           =   1812
   End
   Begin VB.CheckBox chkChaf 
      Caption         =   "Filter Chaff"
      Height          =   192
      Index           =   1
      Left            =   360
      TabIndex        =   17
      TabStop         =   0   'False
      Top             =   2100
      Width           =   1752
   End
   Begin VB.Timer tmrChaf 
      Enabled         =   0   'False
      Interval        =   500
      Left            =   2220
      Top             =   480
   End
   Begin VB.CheckBox chkChaf 
      Caption         =   "Generate Chaff"
      Height          =   192
      Index           =   0
      Left            =   360
      TabIndex        =   16
      TabStop         =   0   'False
      Top             =   1860
      Width           =   1752
   End
   Begin ComctlLib.Slider Slider1 
      Height          =   252
      Left            =   6180
      TabIndex        =   15
      Top             =   4596
      Width           =   972
      _ExtentX        =   1720
      _ExtentY        =   450
      _Version        =   327682
      LargeChange     =   50
      Min             =   25
      Max             =   1200
      SelStart        =   200
      TickStyle       =   3
      Value           =   200
   End
   Begin VB.CheckBox chkStyle 
      Caption         =   "Auto-Click"
      Height          =   252
      Index           =   2
      Left            =   4980
      TabIndex        =   14
      TabStop         =   0   'False
      Top             =   4584
      Width           =   1332
   End
   Begin VB.Timer tmrMove 
      Enabled         =   0   'False
      Interval        =   200
      Left            =   6840
      Top             =   1500
   End
   Begin VB.CheckBox chkStyle 
      Caption         =   "Scramble"
      Height          =   252
      Index           =   1
      Left            =   3660
      TabIndex        =   12
      TabStop         =   0   'False
      Top             =   4584
      Width           =   1332
   End
   Begin VB.CheckBox chkStyle 
      Caption         =   "Stagger"
      Height          =   252
      Index           =   0
      Left            =   2400
      TabIndex        =   7
      TabStop         =   0   'False
      Top             =   4584
      Width           =   1332
   End
   Begin VB.TextBox txtKeys 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   7.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   288
      Left            =   1140
      MaxLength       =   103
      TabIndex        =   11
      TabStop         =   0   'False
      Text            =   "1!2@3#4$5%6^7&8*9(0)-_=+^^qQwWeErRtTyYuUiIoOpP[{]}^^aAsSdDfFgGhHjJkKlL;:'QQ`~^^zZxXcCvVbBnNmM,<.>/?\|"
      Top             =   4860
      Width           =   6012
   End
   Begin VB.OptionButton optStyle 
      Caption         =   "Custom:"
      Height          =   192
      Index           =   2
      Left            =   180
      TabIndex        =   10
      TabStop         =   0   'False
      Top             =   4920
      Width           =   1392
   End
   Begin VB.OptionButton optStyle 
      Caption         =   "Plain"
      Height          =   192
      Index           =   1
      Left            =   1260
      TabIndex        =   9
      TabStop         =   0   'False
      Top             =   4620
      Width           =   1392
   End
   Begin VB.OptionButton optStyle 
      Caption         =   "Qwerty"
      Height          =   192
      Index           =   0
      Left            =   180
      TabIndex        =   8
      TabStop         =   0   'False
      Top             =   4620
      Value           =   -1  'True
      Width           =   1392
   End
   Begin VB.CheckBox chkVBoard 
      Caption         =   "VBoard"
      Height          =   312
      Left            =   5040
      Style           =   1  'Grafisch
      TabIndex        =   6
      TabStop         =   0   'False
      Top             =   2040
      Width           =   1332
   End
   Begin VB.CheckBox chkHide 
      Caption         =   "Hide typing"
      Height          =   192
      Left            =   1320
      TabIndex        =   4
      TabStop         =   0   'False
      Top             =   1560
      Width           =   2052
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   432
      Left            =   2340
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   1920
      Width           =   1932
   End
   Begin VB.TextBox txtPass 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   312
      IMEMode         =   3  'DISABLE
      Left            =   300
      MaxLength       =   255
      TabIndex        =   0
      TabStop         =   0   'False
      Top             =   1200
      Width           =   6132
   End
   Begin VB.Label lblSpace 
      Alignment       =   2  'Zentriert
      Caption         =   "SPACE"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   252
      Left            =   2820
      TabIndex        =   13
      Top             =   4236
      Width           =   1092
   End
   Begin VB.Label lblKB 
      BackStyle       =   0  'Transparent
      Caption         =   $"Pass.frx":0442
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   16.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1512
      Left            =   180
      TabIndex        =   5
      Top             =   2700
      Width           =   7092
   End
   Begin VB.Label lblDirections 
      Height          =   852
      Left            =   300
      TabIndex        =   3
      Top             =   180
      Width           =   6072
   End
   Begin VB.Label lblPass1 
      Caption         =   "PGP Passphrase:"
      Height          =   192
      Left            =   300
      TabIndex        =   2
      Top             =   996
      Width           =   3612
   End
End
Attribute VB_Name = "frmPass"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim kX As Single, kY As Single, kShift As Integer, kTimer As Double
Dim kXLast As Single, kYLast As Single
Dim LastChaf As String, ChafFocus As String, ChafString As String
Dim ChafAsk As Boolean

Private Sub chkChaf_Click(Index As Integer)
    If Index = 0 Then
        ChafFocus = False
        If Not ChafAsk And chkChaf(0).Value = 1 Then MsgBox LMsg(359) + vbCr + vbCr + LMsg(360) + vbCr + vbCr + LMsg(361), vbInformation, LMsg(362): ChafAsk = True
        If chkChaf(0).Value = 1 Then chkChaf(1).Value = 1
    End If
    tmrChaf.Enabled = chkChaf(0).Value = 1
    If txtPass.Visible Then txtPass.SetFocus
End Sub

Private Sub Form_Activate()
    txtPass.SetFocus
End Sub

Private Sub tmrChaf_Timer()
    'ChafString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-=\~!@#$%^&*()_+|[]{};':,./<>?` " + Chr(34)
    If ChafFocus Then
        If chkChaf(1).Value = 0 Then If Len(txtPass.Text) > 250 Then txtPass.Text = ""
        x = Int(Rnd(1) * 20) + 1
        y = Len(ChafString)
        If x < 16 Then y = 62  'upper and lower digits only
        If x < 11 Then y = 26  'lower case only
        tmrChaf.Interval = 30 + Int(Rnd(1) * 100)
        LastChaf = Mid(ChafString, Int(Rnd(1) * y) + 1, 1)
        If InStr("+^%~()[]{}", LastChaf) <> 0 Then SendKeys ("{" + LastChaf + "}") Else SendKeys (LastChaf)
        If chkSound.Value = 1 Then Beep
    End If
End Sub

Private Sub chkSound_Click()
    If txtPass.Visible Then txtPass.SetFocus
End Sub

Private Sub lblKB_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Dim x1 As Single, y1 As Single
    Const BoxW = 192
    Const BoxH = 372
    If Button = 2 And chkStyle(2).Value = 1 And chkChaf(0).Value = 0 Then
        If txtPass.SelStart <> 0 Then
            x = txtPass.SelStart
            txtPass.Text = Left(txtPass.Text, txtPass.SelStart - 1) + Mid(txtPass.Text, txtPass.SelStart + 1)
            txtPass.SelStart = x - 1
            txtPass.SetFocus
        End If
        Exit Sub
    End If
    y1 = Int((y) / BoxH)
    If y1 > 3 Then y1 = 3
    x1 = Int((x + BoxW - (y1 * BoxW * chkStyle(0).Value)) / (BoxW * 3))
    If x1 > 12 Then x1 = 12
    If x1 < 0 Then x1 = 0
    'Find Character
    If optStyle(2).Value Then AllKeys = txtKeys.Text Else AllKeys = lblKB.Tag
    If chkStyle(1).Value = 1 Then AllKeys = txtKeys.Tag
    a = AllKeys + "^^"
    For i = 1 To y1
        a = Mid(a, InStr(a, "^^") + 2)
    Next i
    a = Extract(a, "^^")
    bt = Button - 1: If Shift <> 0 Then bt = 1
    a = Mid(a, x1 * 2 + 1 + bt, 1)
    txtPass.SelText = a: If chkStyle(2).Value = 1 Then If chkSound.Value = 1 Then Beep
    txtPass.SetFocus
End Sub

Private Sub lblKB_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If chkStyle(2).Value = 1 Then
        kX = x
        kY = y
        kShift = Shift
        tmrMove.Enabled = False
        tmrMove.Enabled = True
    End If
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If chkStyle(2).Value = 1 Then
        kX = 0
        kY = 0
        tmrMove.Enabled = False
    End If
End Sub

Private Sub lblSpace_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If chkStyle(2).Value = 1 Then
        kX = -x
        kY = -y
        tmrMove.Enabled = False
        tmrMove.Enabled = True
    End If
End Sub

Private Sub Slider1_Change()
    tmrMove.Interval = Slider1.Value
    If txtPass.Visible Then txtPass.SetFocus
End Sub

Private Sub tmrMove_Timer()
    tmrMove.Enabled = False
    If chkStyle(2).Value = 1 Then
        If kX * kY <> 0 And Timer - kTimer > 0.6 And _
           Abs(kX - kXLast) > 100 Or Abs(kY - kYLast) > 100 Then
            If kX > 0 Then lblKB_MouseDown 1, kShift, kX, kY Else lblSpace_Click
        End If
        kXLast = kX:  kYLast = kY
        kX = 0: kY = 0
        kTimer = Timer
    End If
End Sub

Private Sub lblSpace_Click()
    txtPass.SelText = " ": If chkStyle(2).Value = 1 Then If chkSound.Value = 1 Then Beep
    txtPass.SetFocus
End Sub

Private Sub optStyle_Click(Index As Integer)
    If txtPass.Visible Then txtPass.SetFocus
    Select Case Index
    Case 0 'Qwerty
        lblKB.Tag = "1!2@3#4$5%6^7&8*9(0)-_=+^^qQwWeErRtTyYuUiIoOpP[{]}^^aAsSdDfFgGhHjJkKlL;:'" + Chr(34) + "`~^^zZxXcCvVbBnNmM,<.>/?\|"
        chkStyle(0).Value = 1: chkStyle(1).Value = 0
    Case 1 'Plain
        lblKB.Tag = "aAbBcCdDeEfFgGhHiIjJkKlL^^mMnNoOpPqQrRsStTuUvVwWxX^^yYzZ1!2@3#4$5%6^7&8*9(0)^^-_=+\|[{]};:'" + Chr(34) + ",<.>/?`~"
        chkStyle(0).Value = 0: chkStyle(1).Value = 0
    Case 2 'Custom
    End Select
    txtKeys.Enabled = Index = 2
    DisplayKeys
End Sub

Private Sub chkStyle_Click(Index As Integer)
    If txtPass.Visible Then txtPass.SetFocus
    If Index = 2 Then Slider1.Enabled = chkStyle(2).Value = 1
    If Index = 1 Then
        If chkStyle(1).Value = 1 Then
            If optStyle(2).Value Then AllKeys = txtKeys.Text Else AllKeys = lblKB.Tag
            lblSpace.Left = Int(Rnd(1) * 6241)
            Do
                c = ""
                a = Replace(AllKeys, "^^", "")
                While a <> ""
                    x = Int(Rnd(1) * Len(a))
                    If x / 2 = Int(x / 2) Then x = x + 1
                    b = Mid(a, x, 2)
                    c = c + b
                    a = Replace(a, b, "")
                Wend
                a = "": x = 1
                For i = 1 To Len(AllKeys) Step 2
                    If Mid(AllKeys, i, 2) = "^^" Then
                        a = a + "^^"
                    Else
                        a = a + Mid(c, x, 2)
                        x = x + 2
                    End If
                Next i
            Loop Until InStr(a, "^^^") = 0
            txtKeys.Tag = a
        Else
            lblSpace.Left = 2820
        End If
    End If
    DisplayKeys
End Sub

Private Sub chkVBoard_Click()
    If txtPass.Visible Then txtPass.SetFocus
    If chkVBoard.Value = 1 Then
        Me.Height = 5628
        Me.Width = 7440
        chkHide.Value = 0
        DisplayKeys
    Else
        Me.Height = 2904
        Me.Width = 6804
    End If
End Sub

Private Sub txtKeys_Change()
    If optStyle(2).Value Then chkStyle_Click (1)
    DisplayKeys
    If txtKeys.Visible And txtKeys.Enabled Then txtKeys.SetFocus
End Sub

Private Sub DisplayKeys()
    If optStyle(2).Value Then AllKeys = txtKeys.Text Else AllKeys = lblKB.Tag
    If chkStyle(1).Value = 1 Then AllKeys = txtKeys.Tag
    If Len(AllKeys) / 2 <> Int(Len(AllKeys) / 2) Or Len(AllKeys) = 0 Then lblKB.Caption = "": Exit Sub
    l = 1: StartLine = True: c = ""
    For i = 1 To Len(AllKeys) - 1 Step 2
        a = Mid(AllKeys, i, 2)
        If a = "^^" Then
            c = c + vbCrLf
            l = l + 1
            If chkStyle(0).Value = 1 Then c = c + String(l, " ")
            StartLine = True
        Else
            If Not StartLine Then c = c + "  "
            c = c + UCase(Left(a, 1))
            StartLine = False
        End If
    Next i
    lblKB.Caption = c
End Sub




Private Sub chkHide_Click()
    txtPass.PasswordChar = Left("*", chkHide.Value)
    If txtPass.Visible Then txtPass.SetFocus
End Sub

Private Sub cmdOK_Click()
    Me.Hide
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    If KeyAscii = 27 Then Unload Me
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PData(41) = (chkHide.Value = 1)
    'Save VBoard
    PData(57) = txtKeys.Text
    For i = 0 To 2
        PData(58 + i) = optStyle(i).Value
        PData(61 + i) = Str(chkStyle(i).Value)
    Next i
    PData(64) = Str(chkVBoard.Value)
    PData(65) = Str(Slider1.Value)
    PData(66) = Str(chkChaf(0).Value)
    PData(67) = Str(chkChaf(1).Value)
    PData(76) = Str(chkSound.Value)
    lblKB.Caption = String(Len(lblKB.Caption), "@")
    lblKB.Tag = String(Len(lblKB.Tag), "@")
    txtKeys.Text = String(Len(txtKeys.Text), "@")
    txtKeys.Tag = String(Len(txtKeys.Tag), "@")
End Sub

Private Sub txtPass_GotFocus()
    ChafFocus = True
End Sub

Private Sub txtPass_LostFocus()
    ChafFocus = False
End Sub

Private Sub txtPass_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then KeyAscii = 0: cmdOK_Click: Exit Sub
    If LastChaf <> "" Then
        If LCase(LastChaf) = LCase(Chr(KeyAscii)) Then LastChaf = "": If chkChaf(1).Value = 1 Then KeyAscii = 0
    End If
End Sub

Private Sub Form_Load()
    ChafString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-=\~!@#$%^&*()_+|[]{};':,./<>?` " + Chr(34)
    
    'Position
    On Error Resume Next
    Me.Left = Screen.Width / 2 - 7440 / 2
    Me.Top = Screen.Height / 2 - 5628 / 2
        
    'Load VBoard
    optStyle_Click (0)
    For i = 0 To 2
        If PData(58 + i) = True2 Then optStyle(i).Value = True: optStyle_Click (i)
    Next i
    If PData(57) <> "" Then txtKeys.Text = PData(57)
    For i = 0 To 2
         chkStyle(i).Value = Val(PData(61 + i))
    Next i
    If Val(PData(65)) <> 0 Then Slider1.Value = Val(PData(65))
    Slider1_Change
    chkStyle_Click (2)
    chkVBoard.Value = Val(PData(64))
    chkVBoard_Click
    If PData(41) <> False2 Then chkHide.Value = 1
    ChafAsk = True
    chkChaf(0).Value = Str(PData(66))
    ChafAsk = False
    chkChaf(1).Value = Str(PData(67))
    chkSound.Value = Str(PData(76))
End Sub

