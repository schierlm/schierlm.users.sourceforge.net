VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmCfRmlr 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "Remailers - Configuration"
   ClientHeight    =   6735
   ClientLeft      =   30
   ClientTop       =   300
   ClientWidth     =   7770
   Icon            =   "CfRmlr.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6735
   ScaleWidth      =   7770
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   372
      Left            =   5400
      TabIndex        =   55
      Top             =   6300
      Width           =   1992
   End
   Begin VB.Timer tmrProgBusy 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   4920
      Top             =   6300
   End
   Begin VB.CommandButton cmdRmlr 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   372
      Index           =   0
      Left            =   420
      TabIndex        =   30
      Top             =   6300
      Width           =   1992
   End
   Begin VB.CommandButton cmdRmlr 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   372
      Index           =   1
      Left            =   2880
      TabIndex        =   31
      Top             =   6300
      Width           =   1992
   End
   Begin VB.Frame fraRmlr 
      BorderStyle     =   0  'Kein
      Caption         =   "Auto"
      Height          =   5832
      Index           =   0
      Left            =   60
      TabIndex        =   33
      Top             =   360
      Width           =   7632
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1632
         Index           =   4
         Left            =   120
         MaxLength       =   10000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   7
         Top             =   4140
         Width           =   7332
      End
      Begin VB.ComboBox cboRmlr 
         Height          =   288
         Index           =   0
         ItemData        =   "CfRmlr.frx":0442
         Left            =   120
         List            =   "CfRmlr.frx":0455
         Style           =   2  'Dropdown-Liste
         TabIndex        =   6
         TabStop         =   0   'False
         Top             =   3840
         Width           =   7332
      End
      Begin VB.CommandButton cmdDefaults 
         Caption         =   "Use Defaults"
         Height          =   312
         Left            =   3840
         TabIndex        =   3
         TabStop         =   0   'False
         Top             =   960
         Width           =   1752
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1632
         Index           =   3
         Left            =   120
         MaxLength       =   10000
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   5
         Top             =   2100
         Width           =   7332
      End
      Begin VB.CheckBox chkRmlr 
         Caption         =   "Consider history (CPunk && Mix)"
         Height          =   192
         Index           =   0
         Left            =   240
         TabIndex        =   4
         TabStop         =   0   'False
         Top             =   1440
         Width           =   4212
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   2
         Left            =   2580
         MaxLength       =   2
         TabIndex        =   2
         Top             =   960
         Width           =   672
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   1
         Left            =   6180
         MaxLength       =   5
         TabIndex        =   1
         Top             =   540
         Width           =   672
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   0
         Left            =   2580
         MaxLength       =   5
         TabIndex        =   0
         Top             =   540
         Width           =   672
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Never choose these remailers as AUTO or RANDOM  (List one name or address per line):"
         Height          =   192
         Index           =   9
         Left            =   120
         TabIndex        =   38
         Top             =   1860
         Width           =   7092
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Minimum Distance: (CPunk)"
         Height          =   192
         Index           =   8
         Left            =   240
         TabIndex        =   37
         Top             =   1020
         Width           =   2292
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Max Latency (hh:mm): (CPunk)"
         Height          =   192
         Index           =   7
         Left            =   3840
         TabIndex        =   36
         Top             =   600
         Width           =   2292
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Minimum Uptime%: (CPunk)"
         Height          =   192
         Index           =   6
         Left            =   240
         TabIndex        =   35
         Top             =   600
         Width           =   2232
      End
      Begin VB.Label lblRmlr 
         Caption         =   "These settings affect AUTO remailer selection and stats warnings.  See the Mixmaster tab for additional settings."
         Height          =   432
         Index           =   5
         Left            =   60
         TabIndex        =   34
         Top             =   120
         Width           =   6972
      End
   End
   Begin VB.Frame fraRmlr 
      BorderStyle     =   0  'Kein
      Caption         =   "Mixmaster"
      Height          =   5832
      Index           =   1
      Left            =   60
      TabIndex        =   39
      Top             =   360
      Width           =   7632
      Begin VB.CheckBox chkAdvanced 
         Caption         =   "Change Advanced Settings"
         Height          =   252
         Left            =   300
         TabIndex        =   13
         TabStop         =   0   'False
         Top             =   2520
         Width           =   3372
      End
      Begin VB.ComboBox cboRmlr 
         Height          =   288
         Index           =   1
         ItemData        =   "CfRmlr.frx":053B
         Left            =   4140
         List            =   "CfRmlr.frx":0545
         Style           =   2  'Dropdown-Liste
         TabIndex        =   9
         Top             =   300
         Width           =   3192
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   8
         Left            =   300
         TabIndex        =   12
         Top             =   2100
         Width           =   972
      End
      Begin VB.CommandButton cmdEdit 
         Caption         =   "Edit"
         Enabled         =   0   'False
         Height          =   312
         Index           =   0
         Left            =   5640
         TabIndex        =   15
         TabStop         =   0   'False
         Top             =   3060
         Width           =   1212
      End
      Begin VB.TextBox txtRmlr 
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   12
         Left            =   540
         TabIndex        =   21
         Top             =   5280
         Width           =   4752
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   7
         Left            =   300
         TabIndex        =   11
         Top             =   960
         Width           =   972
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   6
         Left            =   300
         TabIndex        =   10
         Top             =   1500
         Width           =   972
      End
      Begin VB.CommandButton cmdEdit 
         Caption         =   "Edit"
         Enabled         =   0   'False
         Height          =   312
         Index           =   2
         Left            =   5640
         TabIndex        =   20
         TabStop         =   0   'False
         Top             =   4620
         Width           =   1212
      End
      Begin VB.CommandButton cmdEdit 
         Caption         =   "Edit"
         Enabled         =   0   'False
         Height          =   312
         Index           =   1
         Left            =   5640
         TabIndex        =   18
         TabStop         =   0   'False
         Top             =   3960
         Width           =   1212
      End
      Begin VB.TextBox txtRmlr 
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   11
         Left            =   540
         TabIndex        =   19
         Top             =   4620
         Width           =   4752
      End
      Begin VB.TextBox txtRmlr 
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   10
         Left            =   540
         TabIndex        =   17
         Top             =   3960
         Width           =   4752
      End
      Begin VB.CheckBox chkRmlr 
         Caption         =   "Auto-Maintain mixmaste.con (recommended except for Reliable operators)"
         Enabled         =   0   'False
         Height          =   192
         Index           =   1
         Left            =   540
         TabIndex        =   16
         TabStop         =   0   'False
         Top             =   3420
         Width           =   7212
      End
      Begin VB.TextBox txtRmlr 
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   9
         Left            =   540
         TabIndex        =   14
         Top             =   3060
         Width           =   3552
      End
      Begin VB.TextBox txtRmlr 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   288
         Index           =   5
         Left            =   300
         TabIndex        =   8
         Top             =   300
         Width           =   3552
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Mixmaster Version:"
         Height          =   192
         Index           =   10
         Left            =   4140
         TabIndex        =   52
         Top             =   60
         Width           =   2952
      End
      Begin VB.Label lblRmlr 
         Caption         =   "DISTANCE: (Minimum distance between AUTO/RANDOM remailers)"
         Height          =   192
         Index           =   19
         Left            =   300
         TabIndex        =   51
         Top             =   1860
         Width           =   6972
      End
      Begin VB.Label lblRmlr 
         Caption         =   "RELLIST: (Mixmaster statistics file)"
         Enabled         =   0   'False
         Height          =   192
         Index           =   16
         Left            =   540
         TabIndex        =   46
         Top             =   5040
         Width           =   5292
      End
      Begin VB.Label lblRmlr 
         Caption         =   "MINREL: (Minimum Uptime% of AUTO && RANDOM remailers)"
         Height          =   192
         Index           =   18
         Left            =   300
         TabIndex        =   45
         Top             =   720
         Width           =   6912
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Pubring.mix:"
         Enabled         =   0   'False
         Height          =   192
         Index           =   15
         Left            =   540
         TabIndex        =   43
         Top             =   4380
         Width           =   4512
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Type2.lis:"
         Enabled         =   0   'False
         Height          =   192
         Index           =   14
         Left            =   540
         TabIndex        =   42
         Top             =   3720
         Width           =   4512
      End
      Begin VB.Label lblRmlr 
         Caption         =   "MIXPATH: (Contains mixmaste.con  [Leave blank for default location]"
         Enabled         =   0   'False
         Height          =   192
         Index           =   13
         Left            =   540
         TabIndex        =   41
         Top             =   2820
         Width           =   7032
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Program Folder: (Folder containing mixmaste.exe)"
         Height          =   192
         Index           =   12
         Left            =   300
         TabIndex        =   40
         Top             =   60
         Width           =   4572
      End
      Begin VB.Label lblRmlr 
         Caption         =   "MAXLAT: (Maximum Latency of AUTO && RANDOM remailers)  [hh:mm]"
         Height          =   192
         Index           =   17
         Left            =   300
         TabIndex        =   44
         Top             =   1320
         Width           =   6852
      End
   End
   Begin VB.Frame fraRmlr 
      BorderStyle     =   0  'Kein
      Caption         =   "Mix Keys"
      Height          =   5832
      Index           =   2
      Left            =   60
      TabIndex        =   47
      Top             =   360
      Width           =   7632
      Begin VB.CommandButton cmdAdd 
         Caption         =   "Remove"
         Height          =   372
         Index           =   1
         Left            =   2580
         TabIndex        =   24
         TabStop         =   0   'False
         Top             =   1920
         Width           =   1632
      End
      Begin VB.CommandButton cmdAdd 
         Caption         =   "Add / Update"
         Height          =   372
         Index           =   0
         Left            =   480
         TabIndex        =   23
         TabStop         =   0   'False
         Top             =   1920
         Width           =   1632
      End
      Begin VB.TextBox txtMixKey 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3372
         Left            =   60
         MaxLength       =   31000
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   25
         Top             =   2400
         Width           =   7512
      End
      Begin VB.ListBox lstMix 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1680
         Left            =   60
         Sorted          =   -1  'True
         TabIndex        =   22
         TabStop         =   0   'False
         Top             =   60
         Width           =   7512
      End
      Begin VB.Label lblPubring 
         Caption         =   "pubring.mix"
         Height          =   192
         Left            =   4500
         TabIndex        =   49
         Top             =   2100
         Width           =   3192
      End
      Begin VB.Label lblType2 
         Caption         =   "type2.lis"
         Height          =   192
         Left            =   4500
         TabIndex        =   48
         Top             =   1860
         Width           =   3192
      End
   End
   Begin VB.Frame fraRmlr 
      BorderStyle     =   0  'Kein
      Caption         =   "Mixmaster"
      Height          =   5832
      Index           =   3
      Left            =   60
      TabIndex        =   50
      Top             =   360
      Width           =   7632
      Begin VB.CheckBox chkRefresh 
         Caption         =   "Auto-Refresh"
         Height          =   192
         Index           =   1
         Left            =   4380
         TabIndex        =   28
         TabStop         =   0   'False
         Top             =   4476
         Width           =   2712
      End
      Begin VB.TextBox txtMachine 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1152
         Left            =   0
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertikal
         TabIndex        =   29
         Top             =   4680
         Width           =   7632
      End
      Begin VB.CheckBox chkRefresh 
         Caption         =   "Auto-Refresh"
         Height          =   192
         Index           =   0
         Left            =   4380
         TabIndex        =   26
         TabStop         =   0   'False
         Top             =   40
         Width           =   2712
      End
      Begin VB.TextBox txtCaps 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   7.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   4152
         Left            =   0
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Beides
         TabIndex        =   27
         Top             =   240
         Width           =   7632
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Machine and Chain Info:"
         Height          =   192
         Index           =   20
         Left            =   0
         TabIndex        =   54
         Top             =   4440
         Width           =   2832
      End
      Begin VB.Label lblRmlr 
         Caption         =   "Remailer Capability Strings:"
         Height          =   192
         Index           =   11
         Left            =   0
         TabIndex        =   53
         Top             =   0
         Width           =   2832
      End
   End
   Begin ComctlLib.TabStrip tabRmlr 
      Height          =   6192
      Left            =   0
      TabIndex        =   32
      Top             =   60
      Width           =   7752
      _ExtentX        =   13679
      _ExtentY        =   10927
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   4
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Auto"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Mixmaster"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Mix &Keys"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab4 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "&Capabilities"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmCfRmlr"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Copyright 1999 Potato Software.   See MAIN.BAS and LICENSE.TXT.

Dim TempCnf()

Private Sub chkAdvanced_Click()
    x = chkAdvanced.Value = 1
    For i = 9 To 12
        txtRmlr(i).Enabled = x
        lblRmlr(i + 4).Enabled = x
    Next i
    chkRmlr(1).Enabled = x
    For i = 0 To 2
        cmdEdit(i).Enabled = x
    Next i
End Sub

Private Sub cmdRmlr_Click(Index As Integer)
    Dim temp(MaxRemailers) As String
    
    If Index = 0 Then
        Me.MousePointer = 11
        cmdRmlr(0).Enabled = False
        For i = 0 To 3
            fraRmlr(i).Enabled = False
        Next i
        PendingCfg(4) = True
        If ProgBusy("Remailers") Then
            tmrProgBusy.Tag = "Remailers"
            tmrProgBusy.Enabled = True
            Exit Sub
        End If
        'Update Data
        '0-1
        For i = 0 To 1
            Cnf(1, i) = Val(cboRmlr(i).ListIndex)
        Next i
        '2-3
        For i = 2 To 3
            Cnf(1, i) = Str(chkRmlr(i - 2).Value)
            Cnf(3, i - 1) = Str(chkRefresh(i - 2))
        Next i
        'Clean 13 and 14 lists
        For i = 13 To 14
            a = txtRmlr(i - 10)
            x = ParseString(a, temp(), MaxRemailers, False)
            b = ""
            For j = 0 To x
                b = b + Trim(temp(j)) + vbCrLf
            Next j
            txtRmlr(i - 10) = b
        Next i
        '10-22
        For i = 0 To 12
            Cnf(1, i + 10) = txtRmlr(i).Text
        Next i
        'RString
        Dim rs(MaxRemailers) As String
        x = ParseString(txtCaps.Text, rs(), MaxRemailers, False)
        t = 0
        Erase RString
        For i = 0 To x
            If Left(Trim(rs(i)), 9) = "$remailer" Then RString(t) = Trim(rs(i)): t = t + 1
        Next i
        PData(42) = txtMachine.Text
        If Not CheckConfig("Remailers") Then
            PendingCfg(4) = False
            For i = 0 To 3
                fraRmlr(i).Enabled = True
            Next i
            cmdRmlr(0).Enabled = True
            txtCaps.Text = ""
            Form_Load
            Me.MousePointer = 0
        Exit Sub
        End If
        Me.MousePointer = 0
    End If
    Unload Me
End Sub

Private Sub tmrProgBusy_Timer()
    If Not ProgBusy(tmrProgBusy.Tag) Then tmrProgBusy.Enabled = False: cmdRmlr_Click (0)
End Sub

Private Sub tabRmlr_Click()
    tb = tabRmlr.SelectedItem.Index - 1
    fraRmlr(tb).ZOrder
    If tb = 2 Then
        'Load Mix Keys
        On Error GoTo ReadMixError
        lstMix.Clear
        lblPubring.Caption = ""
        txtMixKey.Text = ""
        mixpath = NoSlash(txtRmlr(9).Text)
        If mixpath = "" Then mixpath = NoSlash(txtRmlr(5).Text)
        t2 = Trim(txtRmlr(10).Text)
        If t2 = "" Then t2 = "type2.lis"
        If PlainName(t2, 0) = "" And mixpath <> "" Then t2 = mixpath + "\" + t2
        If SDir(t2) = "" Then
            lblType2.Caption = LMsg(7)
            lstMix.Enabled = False
            txtMixKey.Enabled = True
            cmdAdd(0).Enabled = True
            cmdAdd(1).Enabled = False
        Else
            lstMix.Enabled = True
            lblType2.Caption = t2
            'Read
            n = FreeFile
            Open t2 For Input As n
            While Not EOF(n)
                Line Input #n, a
                If Trim(a) <> "" And InStr(a, vbLf) = 0 Then lstMix.AddItem a
            Wend
            Close n: n = 0
            'Save Sorted
            t2x = GetWork
            n = FreeFile
            Open t2x For Output As n
            For i = 0 To lstMix.ListCount - 1
                Print #n, Trim(lstMix.List(i))
            Next i
            Close n: n = 0
            FileCopy t2x, t2
            DelFile t2x
            
            lstMix.ListIndex = -1
            lstMix.Enabled = True
            txtMixKey.Enabled = True
            cmdAdd(0).Enabled = True
            cmdAdd(1).Enabled = False
        End If
    End If
Exit Sub
ReadMixError:
    MsgBox LMsg(15) + vbCr + Error, vbCritical, LMsg(4)
    CloseFile (n)
End Sub

Private Sub lstMix_Click()
    On Error GoTo ListMixError
    k = lstMix.List(lstMix.ListIndex)
    txtMixKey.Text = ""
    mixpath = NoSlash(txtRmlr(9).Text)
    If mixpath = "" Then mixpath = NoSlash(txtRmlr(5).Text)
    pm = Trim(txtRmlr(11).Text)
    If pm = "" Then pm = "pubring.mix"
    If PlainName(pm, 0) = "" And mixpath <> "" Then pm = mixpath + "\" + pm
    If SDir(pm) = "" Then
        txtMixKey.Enabled = True
        cmdAdd(0).Enabled = True
        cmdAdd(1).Enabled = False
        lblPubring.Caption = LMsg(8)
    Else
        n = FreeFile
        Open pm For Input As n
        Do While Not EOF(n)
            Line Input #n, a
            If a = k Then
                a = ""
                While Not EOF(n) And Trim(a) = ""
                    Line Input #n, a
                Wend
                If a = "-----Begin Mix Key-----" Then
                    Line Input #n, a
                    If InStr(k, a) <> 0 Then
                        b = k + vbCrLf + vbCrLf + "-----Begin Mix Key-----" + vbCrLf
                        Do
                            b = b + a + vbCrLf
                            If EOF(n) Then a = "": Exit Do
                            Line Input #n, a
                        Loop Until Trim(a) = "" Or Trim(a) = "-----End Mix Key-----"
                        b = b + a + vbCrLf
                        Exit Do
                    End If
                End If
            End If
        Loop
        Close n: n = 0
        If b = "" Then
            MsgBox LMsg(9), vbExclamation, LMsg(10)
        Else
            txtMixKey.Text = b
        End If
        txtMixKey.Enabled = True
        cmdAdd(0).Enabled = True
        cmdAdd(1).Enabled = True
        lblPubring.Caption = pm
    End If
Exit Sub
ListMixError:
    MsgBox LMsg(16), vbCritical, LMsg(4)
    CloseFile (n)
End Sub

Private Sub cmdAdd_Click(Index As Integer)
    Dim temp(1000) As String
    
    On Error GoTo AddMixError
    mixpath = NoSlash(txtRmlr(9).Text)
    If mixpath = "" Then mixpath = NoSlash(txtRmlr(5).Text)
    pm = Trim(txtRmlr(11).Text)
    If pm = "" Then pm = "pubring.mix"
    If PlainName(pm, 0) = "" And mixpath <> "" Then pm = mixpath + "\" + pm
    t2 = Trim(txtRmlr(10).Text)
    If t2 = "" Then t2 = "type2.lis"
    If PlainName(t2, 0) = "" And mixpath <> "" Then t2 = mixpath + "\" + t2
    If Index = 0 Then
        keylistfile = GetWork
        n = FreeFile
        Open keylistfile For Output As n
        pubkeyfile = GetWork
        p = FreeFile
        Open pubkeyfile For Output As p
        a = Replace(txtMixKey.Text, "- -----", "-----")
        x = ParseString(a, temp(), 1000, True)
        For i = 0 To x
            If Trim(temp(i)) <> "" Then
                If Type2Entry(Trim(temp(i)), "", "", "", "", "") Then
                    Print #n, Trim(temp(i))
                    t = t + 1
                End If
            End If
            Print #p, temp(i)
        Next i
        Close n: n = 0
        Close p: p = 0
        If t <> 0 Then t = AddMixKeys(keylistfile, pubkeyfile, t2, pm, PData(10), True)
        If t = 0 Then MsgBox LMsg(12), vbCritical, LMsg(4)
        DelFile keylistfile
        DelFile pubkeyfile
    Else
        If lstMix.ListIndex = -1 Then Exit Sub
        k = lstMix.List(lstMix.ListIndex)
        If MsgBox(LMsg(13) + vbCr + vbCr + k, vbQuestion + vbOKCancel, LMsg(14)) = vbCancel Then Exit Sub
        AddSingleMixKey k, t2, pm, PData(10), 1
    End If
    tabRmlr_Click
Exit Sub
AddMixError:
    MsgBox LMsg(17), vbCritical, LMsg(4)
    CloseFile (n)
    DelFile PlainName(pm, 0) + "\type2_.tmj"
    DelFile PlainName(pm, 0) + "\pubring_.tmj"
End Sub

Private Sub cmdDefaults_Click()
    txtRmlr(0).Text = "98.0"
    txtRmlr(1).Text = "4:00"
    txtRmlr(2).Text = "4"
    chkRmlr(0).Value = 1
End Sub

Private Sub cmdEdit_Click(Index As Integer)
    mixpath = NoSlash(txtRmlr(9).Text)
    If mixpath = "" Then mixpath = NoSlash(txtRmlr(5).Text)
    Select Case Index
    Case 0
        fn = mixpath + "\mixmaste.con"
    Case 1
        t2 = Trim(txtRmlr(10).Text)
        If t2 = "" Then t2 = "type2.lis"
        If PlainName(t2, 0) = "" And mixpath <> "" Then t2 = mixpath + "\" + t2
        fn = t2
    Case 2
        pm = Trim(txtRmlr(11).Text)
        If pm = "" Then pm = "pubring.mix"
        If PlainName(pm, 0) = "" And mixpath <> "" Then pm = mixpath + "\" + pm
        fn = pm
    End Select
    If SDir(fn) <> "" Then
        fx = OpenFileAPI("c:\test1234.txt")
        If fx <> "" Then
            On Error Resume Next
            Shell Replace(fx, "c:\test1234.txt", fn)
        End If
    Else
        MsgBox fn, vbCritical, LMsg(66)
    End If
End Sub

Private Sub cmdHelp_Click()
    Dim Topic As String
    
    Select Case tabRmlr.SelectedItem.Index
    Case 1: Topic = "#CfgRmlrAuto"
    Case 2: Topic = "#CfgRmlrMix"
    Case 3: Topic = "#CfgRmlrMixKeys"
    Case 4: Topic = "#CfgRmlrCaps"
    End Select
    ShowHelp 0, Topic, "2"
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    GlobalKeyDown KeyCode, Shift
    If KeyCode = vbKeyF1 And Shift = 0 Then cmdHelp_Click: KeyCode = 0
End Sub

Private Sub Form_Activate()
    If Me.Tag <> "" Then
        tabRmlr.Tabs(Val(Me.Tag)).Selected = True
        Me.Tag = ""
    End If
End Sub

Private Sub Form_Load()
    Dim x As Integer
    
    Me.Left = Val(PData(100))
    Me.Top = Val(PData(101))
    
    tabRmlr_Click
    
    'Load View
    '0-1
    For i = 0 To 1
        x = Val(Cnf(1, i)): If x > cboRmlr(i).ListCount - 1 Then x = 0
        cboRmlr(i).ListIndex = x
    Next i
    '2-3
    For i = 2 To 3
        chkRmlr(i - 2).Value = Val(Cnf(1, i))
        chkRefresh(i - 2) = Val(Cnf(3, i - 1))
    Next i
    '10-22
    For i = 0 To 12
        txtRmlr(i).Text = Cnf(1, i + 10)
    Next i
    If txtRmlr(10).Text = "" Then txtRmlr(10).Text = "type2.lis"
    If txtRmlr(11).Text = "" Then txtRmlr(11).Text = "pubring.mix"
    If txtRmlr(12).Text = "" Then txtRmlr(12).Text = "mixmaste.htm"
    'Load Strings
    x = 0
    Do While RString(x) <> ""
        txtCaps.Text = txtCaps.Text + RString(x) + vbCrLf
        x = x + 1: If x > MaxRemailers Then Exit Do
    Loop
    'Machine
    txtMachine.Text = PData(42)
End Sub

Private Sub Form_Unload(Cancel As Integer)
    PendingCfg(4) = False
    PData(100) = Str(Me.Left)
    PData(101) = Str(Me.Top)
End Sub

