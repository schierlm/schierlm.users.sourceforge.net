Jack B. Nymble 2.1.4mihi1
=========================

This is a patch for JBN2.1.4 from Michael Schierl,
availble at http://home.arcor.de/mschierlm/jbnmihi/

JBN is under GNU General Public License. You find it in the original
package.

Installaion instructions
------------------------

Install Jack Be Nymble from
<http://www.bigfoot.com/~potatoware/jbn2/index.html> 
into any directory. Before the first start, replace jbn2.exe and
netcod35.ocx in the JBN2 directory with those shipped in this zip
file. You might want to create backup copies of the replaced files.

If you are already using JBN, you can try to replace the files
nevertheless. If there were already "broken" settings in your config
file, it won't help.

You can use all files created with this version with the original
2.1.4 version as well. (If you use English national settings for
it...). So if there are bugs in this version, you can go back whenever
you want.

THERE IS NO WARRANTY FOR THIS SOFTWARE! IF IT BLOWS UP YOUR COMPUTER,
IT'S ENTIRELY YOUR FAULT.

Have fun,

Michael

PS: You can report bugs to the mail address on the website
    mentioned above.
