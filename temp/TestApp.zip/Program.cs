﻿using ManagedWinapi.Windows;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            IntPtr handle = Process.GetCurrentProcess().MainWindowHandle;
            SystemWindow window = new SystemWindow(handle);
            window.Style &= ~WindowStyleFlags.MAXIMIZEBOX &  ~WindowStyleFlags.MINIMIZEBOX &  ~WindowStyleFlags.SYSMENU; 
            Console.ReadKey();
        }
    }
}
