<?php

    \phpinfo();